This is a supplementary dataset for our following paper in IEEE Computer Graphics and Applications:

Aamir Khan Jadoon, Chenming Wu, Yong-Jin Liu, Ying He and Charlie C.L. Wang, "Interactive Partitioning of 3D Models into Printable Parts", IEEE Computer Graphics and Applications.

Contact information: liuyongjin@tsinghua.edu.cn c.c.wang@tudelft.nl