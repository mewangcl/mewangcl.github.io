
#include <stdio.h>
#include <Windows.h>
#include "LDNIDLL.h"
#include "GL\glew.h"

//#define USING_STL_FILE		True

HDC			hDC = NULL;		// Private GDI Device Context
HGLRC		hRC = NULL;		// Permanent Rendering Context
HWND		hWnd = NULL;	// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application
BOOL		keys[256];			// Array Used For The Keyboard Routine
BOOL		active = TRUE;		// Window Active Flag Set To TRUE By Default
BOOL		fullscreen = TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);		// Declaration for WndProc
GLvoid KillGLWindow(GLvoid);								// Declaration for Properly Kill The Window
BOOL CreateGLWindow(char* title, int width, int height, int bits, BOOL fullscreenflag);		// Declaration for CreateGLWindow

int main(void)
{
	float boundingBox[6] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };

	if (initCUDA(2, 0) == 0) return 0;

	//Mesh
	struct mesh *stlMeshA = malloc(sizeof(struct mesh));
	struct mesh *stlMeshB = malloc(sizeof(struct mesh));
	struct mesh *outMesh = malloc(sizeof(struct mesh));

	//LDNI
	struct cuda_ldni *solid = malloc(sizeof(struct cuda_ldni));
	struct cuda_ldni *Outsolid = malloc(sizeof(struct cuda_ldni));

#ifdef USING_STL_FILE
	char *filenameA = "data//sphere.stl";
	char *filenameB = "data//box.stl";
	int triNum = ImportSTLFile(filenameA, stlMeshA);
	int triNumB = ImportSTLFile(filenameB, stlMeshB);
#else	// OBJ file format is used
	char *filenameA = "data//fanDiskFine.obj";
	char *filenameB = "data//cubeTrgl.obj";
	int triNumA = ImportOBJFile(filenameA, stlMeshA);
	int triNumB = ImportOBJFile(filenameB, stlMeshB);
#endif

	const int iRunningExample = 2;

	if (CreateGLWindow("Temp OpenGL Context for Sampling", 640, 480, 16, fullscreen))
	{
		switch (iRunningExample) {
		case 1:{
				   //--------------------------------------------------------------------------------------
				   //	Example 1: Convert meshA to LDNI solid and convert it back to a mesh
				   //--------------------------------------------------------------------------------------		
				   LDNISampling(stlMeshA, solid, boundingBox, 1024);
				   LDNIContouring(solid, outMesh, 256, 0);
#ifdef USING_STL_FILE
				   ExportSTLFile("data//result.stl", outMesh);
#else	// OBJ file format is used
				   ExportOBJFile("data//result.obj", outMesh);
#endif
				   FreeLDNI(solid);
		}break;
		case 2:{
				   //--------------------------------------------------------------------------------------
				   //	Example 2: Boolean operations are taking by the following steps
				   //		1) Convert meshA to LDNI solid;
				   //		2) Perform Boolean operations with meshB, where the 3rd parameter of "LDNIBoolean" indicates the type of Boolean operation
				   //				( 0 -- Union; 1 -- Intersection; 2 -- Subtraction (as meshA \ meshB); 3 -- Inverse Subtraction (as meshB \ meshA) );  
				   //		3) Rotate and translate meshB;
				   //		4) Perform Boolean operations with meshB again;
				   //		5) Convert the result back to a mesh -- outMesh;
				   //--------------------------------------------------------------------------------------		
				   LDNISampling(stlMeshA, solid, boundingBox, 256);  
				   LDNIBoolean(solid, stlMeshB, 2);
				   float axisVec[] = { 1, 1, 1 };
				   Rotation(stlMeshB, axisVec, 25);   
				   LDNIBoolean(solid, stlMeshB, 0);  
				   Translation(stlMeshB, 0.1f, 0.2f, 0.1f);
				   LDNIBoolean(solid, stlMeshB, 0);
				   LDNIContouring(solid, outMesh, 256, 0);
#ifdef USING_STL_FILE
				   ExportSTLFile("data//result.stl", outMesh);
#else	// OBJ file format is used
				   ExportOBJFile("data//result.obj", outMesh);
#endif
				   FreeLDNI(solid);
		}break;
		case 3:{
				   //--------------------------------------------------------------------------------------
				   //	Example 3: Perform Boolean operations with mesh A and meshB, then convert the result back to a mesh
				   //		Note that the 3rd parameter of "LDNIBoolean2" indicates the type of Boolean operation
				   //		( 0 -- Union; 1 -- Intersection; 2 -- Subtraction (as meshA \ meshB); 3 -- Inverse Subtraction (as meshB \ meshA) );  
				   //--------------------------------------------------------------------------------------
				   LDNIBoolean2(stlMeshA, stlMeshB, solid, 1024, 3);
				   LDNIContouring(solid, outMesh, 256, 0);
#ifdef USING_STL_FILE
				   ExportSTLFile("data//result.stl", outMesh);
#else	// OBJ file format is used
				   ExportOBJFile("data//result.obj", outMesh);
#endif
				   FreeLDNI(solid);
		}break;
		case 4:{
				   //--------------------------------------------------------------------------------------
				   //	Example 4: Combination of Offsetting together with Boolean 
				   //		1. Convert meshA to ldni solidA
				   //		2. Offset (shrinking) solidA
				   //       3. Perform Intersection with meshB
				   //		4. Convert the result back to a mesh
				   //--------------------------------------------------------------------------------------
				   LDNISampling(stlMeshA, solid, boundingBox, 256);
				   float sampleWidth = solid->m_sampleWidth;
				   //LDNISuccessiveOffsettingBySpatialHashing(solid, Outsolid, -15.0f * sampleWidth, 1);		
				   LDNIOffsetting(solid, Outsolid, -15.0f * sampleWidth);
				   LDNIBoolean(Outsolid, stlMeshB, 0);
				   LDNIContouring(Outsolid, outMesh, 256, 0);
#ifdef USING_STL_FILE
				   ExportSTLFile("data//result.stl", outMesh);
#else	// OBJ file format is used
				   ExportOBJFile("data//result.obj", outMesh);
#endif
				   FreeLDNI(solid);
				   FreeLDNI(Outsolid);
		}break;
		case 5:{
				   //--------------------------------------------------------------------------------------
				   //	Example 5: For hollowing a model by uniform offsetting 
				   //		1. Convert meshA to ldni solidA
				   //		2. Offset (shrinking) solidA
				   //       3. Perform inverse subtraction with meshA
				   //		4. Convert the result back to a mesh
				   //--------------------------------------------------------------------------------------
				   LDNISampling(stlMeshA, solid, boundingBox, 256);
				   float sampleWidth = solid->m_sampleWidth;
				   LDNIOffsetting(solid, Outsolid, -5.0f * sampleWidth);
				   LDNIBoolean(Outsolid, stlMeshA, 3);
//				   LDNIBoolean(Outsolid, stlMeshB, 2);
				   LDNIContouring(Outsolid, outMesh, 256, 0);
#ifdef USING_STL_FILE
				   ExportSTLFile("data//result.stl", outMesh);
#else	// OBJ file format is used
				   ExportOBJFile("data//result.obj", outMesh);
#endif
				   FreeLDNI(solid);
				   FreeLDNI(Outsolid);
		}break;
		}

		KillGLWindow();
	}

	free(stlMeshA->faceArray);	free(stlMeshA->verArray);	free(stlMeshA->normArray);
	free(stlMeshB->faceArray);	free(stlMeshB->verArray);	free(stlMeshB->normArray);
	free(outMesh->faceArray);	free(outMesh->verArray);	free(outMesh->normArray);

	free(stlMeshA);		free(stlMeshB);		free(outMesh);		free(solid);		free(Outsolid);	
}




LRESULT CALLBACK WndProc(HWND	hWnd,			// Handle For This Window
	UINT	uMsg,			// Message For This Window
	WPARAM	wParam,			// Additional Message Information
	LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{

	case WM_CLOSE:								// Did We Receive A Close Message?
	{
													PostQuitMessage(0);						// Send A Quit Message
													return 0;								// Jump Back
	}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

GLvoid KillGLWindow(GLvoid)								// Properly Kill The Window
{
	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL, NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL, "Release Of DC And RC Failed.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL, "Release Rendering Context Failed.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		}
		hRC = NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd, hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL, "Release Device Context Failed.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		hDC = NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL, "Could Not Release hWnd.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		hWnd = NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL", hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL, "Could Not Unregister Class.", "SHUTDOWN ERROR", MB_OK | MB_ICONINFORMATION);
		hInstance = NULL;									// Set hInstance To NULL
	}
}

BOOL CreateGLWindow(char* title, int width, int height, int bits, BOOL fullscreenflag)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left = (long)0;			// Set Left Value To 0
	WindowRect.right = (long)width;		// Set Right Value To Requested Width
	WindowRect.top = (long)0;				// Set Top Value To 0
	WindowRect.bottom = (long)height;		// Set Bottom Value To Requested Height

	fullscreen = fullscreenflag;			// Set The Global Fullscreen Flag

	hInstance = GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc = (WNDPROC)WndProc;					// WndProc Handles Messages
	wc.cbClsExtra = 0;									// No Extra Window Data
	wc.cbWndExtra = 0;									// No Extra Window Data
	wc.hInstance = hInstance;							// Set The Instance
	wc.hIcon = LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground = NULL;									// No Background Required For GL
	wc.lpszMenuName = NULL;									// We Don't Want A Menu
	wc.lpszClassName = "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL, "Failed To Register The Window Class.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}


	dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
	dwStyle = WS_OVERLAPPEDWINDOW;							// Windows Style


	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(hWnd = CreateWindowEx(dwExStyle,							// Extended Style For The Window
		"OpenGL",							// Class Name
		title,								// Window Title
		dwStyle |							// Defined Window Style
		WS_CLIPSIBLINGS |					// Required Window Style
		WS_CLIPCHILDREN,					// Required Window Style
		0, 0,								// Window Position
		WindowRect.right - WindowRect.left,	// Calculate Window Width
		WindowRect.bottom - WindowRect.top,	// Calculate Window Height
		NULL,								// No Parent Window
		NULL,								// No Menu
		hInstance,							// Instance
		NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Window Creation Error.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd =				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		16,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};

	if (!(hDC = GetDC(hWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Can't Create A GL Device Context.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat = ChoosePixelFormat(hDC, &pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Can't Find A Suitable PixelFormat.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!SetPixelFormat(hDC, PixelFormat, &pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Can't Set The PixelFormat.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(hRC = wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Can't Create A GL Rendering Context.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!wglMakeCurrent(hDC, hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL, "Can't Activate The GL Rendering Context.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(hWnd, SW_HIDE);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	//ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	//if (!InitGL())									// Initialize Our Newly Created GL Window
	//{
	//	KillGLWindow();								// Reset The Display
	//	MessageBox(NULL, "Initialization Failed.", "ERROR", MB_OK | MB_ICONEXCLAMATION);
	//	return FALSE;								// Return FALSE
	//}

	return TRUE;									// Success
}
