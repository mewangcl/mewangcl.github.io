#ifndef	_LDNI_BASIC
#define	_LDNI_BASIC


#ifdef __cplusplus
extern "C" {
#endif

	struct vertex
	{
		float x, y, z;
	};

	struct face
	{
		unsigned int ind1, ind2, ind3;
	};

	struct mesh
	{
		struct face *faceArray;
		struct vertex *verArray;
		struct vertex *normArray;
		int faceNum;
		int nodeNum;
	};

	//-------------------------------------------
	// LDNI structure on GPU
	//-------------------------------------------
	struct cuda_ldni
	{
		unsigned int *dev_indexArray[3];
		float *dev_sampleNxArray[3];
		float *dev_sampleNyArray[3];
		float *dev_sampleDepthArray[3];
		float m_origin[3];
		float m_sampleWidth;
		int m_res, m_xSampleNum, m_ySampleNum, m_zSampleNum;
	};

	//Free gpu memory for dev_indexArray[], dev_sampleNxArray[], dev_sampleNyArray[] and dev_sampleDepthArray[], m_res = 0
	__declspec(dllexport) int FreeLDNI(struct cuda_ldni *ldniSolid);

	//Allocate gpu memory for dev_indexArray[]
	__declspec(dllexport) void mallocLDNI(struct cuda_ldni *ldniSolid, int res);

	//Allocate gpu memory for dev_sampleNxArray[nAxis], dev_sampleNyArray[nAxis] and dev_sampleDepthArray[nAxis] with sampleNum
	__declspec(dllexport) void mallocLDNISamples(struct cuda_ldni *ldniSolid, short nAxis, int sampleNum);

	//Free and clean up  dev_sampleNxArray[], dev_sampleNyArray[] and dev_sampleDepthArray[]
	__declspec(dllexport) void CleanUpSamples(struct cuda_ldni *ldniSolid, int res);


	__declspec(dllexport) void Rotation(struct mesh *inputMesh, float axisVec[], float angle/*in degree*/);
	__declspec(dllexport) void Translation(struct mesh *inputMesh, float dx, float dy, float dz);

	//-------------------------------------------
	// Import OBJ File
	// Input: obj file
	// Output: mesh file (inMesh), (1 - import successfully 0 - import fail)
	//-------------------------------------------
	__declspec(dllexport) int ImportOBJFile(char* filename, struct mesh *inMesh);


	//-------------------------------------------
	// Export OBJ File
	// Input: mesh file (outMesh)	
	// Output: obj file (1 - export successfully 0 - export fail)
	//-------------------------------------------
	__declspec(dllexport) int ExportOBJFile(char* filename, struct mesh *outMesh);


	//-------------------------------------------
	// Import STL File
	// Input: stl file
	// Output: mesh file (stlMesh)
	//-------------------------------------------
	__declspec(dllexport) int ImportSTLFile(char* filename, struct mesh *inMesh);

	//-------------------------------------------
	// Export STL File
	// Input: mesh file (stlMesh)	
	// Output: stl file
	//-------------------------------------------
	__declspec(dllexport) int ExportSTLFile(char* filename, struct mesh *outMesh);

	//-------------------------------------------
	// Initialize CUDA setup
	// Input: Desired device properties, (major - Major compute capability, minor - Minor compute capability)
	// Output: 1-Success 0-Fail
	//-------------------------------------------
	__declspec(dllexport) int initCUDA(int major, int minor);

	//-------------------------------------------
	// Convert mesh file to ldni file
	// Input: mesh file 
	//        boundingBox (sampling within the boundingBox. User can specific the range (optional))
	//        res (sampling resolution)
	// Output: ldni file, boundingBox
	//-------------------------------------------
	__declspec(dllexport) int LDNISampling(struct mesh *inMesh, struct cuda_ldni *solid, float boundingBox[], int res);


	//-------------------------------------------
	// Boolean operation for a mesh file and a ldni file
	// Input: mesh file - A	
	//        ldni file - B
	//        nOperationType 0-Union(A U B) 1-Intersection (A\B) 2-Difference (A-B) 3-Reverse Difference (B-A)
	// Output: ldni file 
	//-------------------------------------------
	__declspec(dllexport) int LDNIBoolean(struct cuda_ldni *solid, struct mesh *inMesh, short nOperationType);


	//-------------------------------------------
	// Boolean operation for two mesh files
	// Input: mesh file - A	
	//        mesh file - B
	//        res (sampling resolution)
	//        nOperationType 0-Union(A U B) 1-Intersection (A\B) 2-Difference (A-B) 3-Reverse Difference (B-A)
	// Output: ldni file 
	//-------------------------------------------
	__declspec(dllexport) int LDNIBoolean2(struct mesh *meshA, struct mesh *meshB, struct cuda_ldni *Outputsolid, int res, short nOperationType);


	//-------------------------------------------
	// Offsetting for ldni file
	// Input: ldni file - inputSolid
	//        offset distance (distance is a multiple of the ldni sample width)
	// Output: ldni file (outputSolid)
	//-------------------------------------------
	__declspec(dllexport) void LDNIOffsetting(struct cuda_ldni* inputSolid, struct cuda_ldni* outputSolid, float offset);


	//-------------------------------------------
	// Successive offsetting based on Spatial Hashing for ldni file
	// Input: ldni file - inputSolid
	//        offset distance (distance is a multiple of the ldni sample width)
	//        bWithNormal - (TRUE:with normal; FALSE:without normal)
	// Output: ldni file (outputSolid)
	//-------------------------------------------
	__declspec(dllexport) void LDNISuccessiveOffsettingBySpatialHashing(struct cuda_ldni *inputSolid, struct cuda_ldni *outputSolid, float offset, int bWithNormal);


	//-------------------------------------------
	// Offsetting based on Spatial Hashing for ldni file
	// Input: ldni file - inputSolid
	//        offset distance (distance is a multiple of the ldni sample width)
	//        bWithRayPacking - (TRUE:Spatial Hashing + Packing; FALSE:Spatial Hashing)
	// Output: ldni file (outputSolid)
	//-------------------------------------------
	__declspec(dllexport) void LDNIOffsettingWithoutNormal(struct cuda_ldni *inputSolid, struct cuda_ldni *outputSolid, float offset, int bWithRayPacking);


	//-------------------------------------------
	// Convert ldni file to mesh file
	// Input: ldni file - solid
	//        meshRes (Resolution to construct mesh)
	//        bWithIntersectionPrevention - (1:Prevent self intersection)
	// Output: mesh file (outputMesh)
	//-------------------------------------------
	__declspec(dllexport) void LDNIContouring(struct cuda_ldni *solid, struct mesh *outputMesh, int meshRes, int bWithIntersectionPrevention);





#ifdef __cplusplus
};
#endif

#endif