#pragma once

#include <stdio.h>
#include <math.h>

class TriList
{
public:
	int i0, i1, i2;
	TriList* next;

	TriList(int i0, int i1, int i2)
	{
		this->i0 = i0;
		this->i1 = i1;
		this->i2 = i2;
		next = NULL;
	}

	~TriList()
	{
		if(next != NULL)
		delete next;
	}

	TriList* add(int i0, int i1, int i2)
	{
		TriList* head = new TriList(i0, i1, i2);
		head->next = this;
		return head;
	}
};



class POT_Mesh
{
public:
  int m_vertexN;
  int m_faceN;
  float (*m_vertex)[3];
  int (*m_face)[3];
  float (*m_normal_f)[3];
  float (*m_normal_v)[3];
public:
	POT_Mesh(int vN, int fN);
	~POT_Mesh(void);

	void setSize(int vN, int fN);
	void setVertex(int i, float x, float y, float z);
	void setFace(int i, int i0, int i1, int i2);
	void flipNormal();
	void computeNormal();
	void faceNormal(float n[3], int i);
	void fillSmallHolesMinA(int T);
	void traceOpt(TriList *&tri_list, int i, int k, int** opt, int *v);
	void fillPolygon(TriList *&tri_list, int* v, int* f, int N);

	inline float areaF(int i, int j, int k)
	{
		float* p0 = m_vertex[i];
		float* p1 = m_vertex[j];
		float* p2 = m_vertex[k];

		float v1x = p1[0] - p0[0];
		float v1y = p1[1] - p0[1];
		float v1z = p1[2] - p0[2];

		float v2x = p2[0] - p0[0];
		float v2y = p2[1] - p0[1];
		float v2z = p2[2] - p0[2];

		float nx = v1y*v2z - v1z*v2y;
		float ny = v1z*v2x - v1x*v2z;
		float nz = v1x*v2y - v1y*v2x;

		return (float)sqrt(nx*nx + ny*ny + nz*nz);
	}
	inline void normal(float n[3], int i, int j, int k)
	{
		float* p0 = m_vertex[i];
		float* p1 = m_vertex[j];
		float* p2 = m_vertex[k];

		float v1x = p1[0] - p0[0];
		float v1y = p1[1] - p0[1];
		float v1z = p1[2] - p0[2];

		float v2x = p2[0] - p0[0];
		float v2y = p2[1] - p0[1];
		float v2z = p2[2] - p0[2];

		float nx = v1y*v2z - v1z*v2y;
		float ny = v1z*v2x - v1x*v2z;
		float nz = v1x*v2y - v1y*v2x;

		float len = (float)sqrt(nx*nx + ny*ny + nz*nz);
		if(len != 0)
		{
			nx /= len;
			ny /= len;
			nz /= len;
		}

		n[0] = nx;
		n[1] = ny;
		n[2] = nz;
	}
	//1 - Cos(dihedral angle)
	inline float dihedral(int i1, int j1, int k1, int i2, int j2, int k2)
	{
		float n1[3], n2[3];
		normal(n1, i1, j1, k1);
		normal(n2, i2, j2, k2);
		float dot = n1[0]*n2[0] + n1[1]*n2[1] + n1[2]*n2[2];
		return 1.0f - dot;
	}
};
