#pragma once
#include "POT_PointSet.h"
#include "POT_KdTree.h"
#include "POT_Sphere.h"
#include <stdlib.h>
#include <time.h>

class POT_SphereGenerator
{
public:

	clock_t m_duration;

	POT_PointSet* m_ps;
	POT_KdTree* m_tree;
	
	bool m_recomputeNormal;

	double m_totalA;
	double m_dia, m_dia2;

	double m_Terr;
	double m_Terr2;
	float m_Tqem;
	float m_Tave;

	int m_TTNmin;

	int m_baN;

	FILE* m_ball_out;
	FILE* m_vertex_out;
	FILE* m_normal_out;
	//FOR splitting
	bool *m_isSelected;
	bool *m_isSelectedNeigh;
	int m_neighNum;
	int m_selectNum;
	POT_PointSet *m_ballPts;
	POT_PointSet *m_vertPts;
public:
	POT_SphereGenerator(POT_PointSet* ps);
	~POT_SphereGenerator(void);

	POT_PointSet* getBalls2();
	POT_PointSet* getBalls();
	POT_PointSet* getVertices();

	void precom();
	void generate(float err, float ave, float qem);
	void computeWeightAndNormal();
	void computeNormalWithCV(float n[3], int* list, int N);
	void computeNormalWithCVOrientationAware(float n[3], int* list, int N);
	void computeNormalOrientationAware();

	void generateBalls();
	void computeOptimalSupportL2(POT_Sphere* ba);
	double localFitQ(POT_Sphere* ba);
	void computeHull(bool* onHull, int* list, int N, float c[3]);
	void quickHull(int s, int e, float (*p)[2], bool* onHull, int* index);

	void selectSpheres(float eigv);
	void splitSpheres();
	void PCA(float **ivec, float *ival, int *list, POT_PointSet *pts, int N);

	int removeTempFile();

	//From Numerical Recipes in C
	#define IA 16807
	#define IM 2147483647
	#define AM (1.0/IM)
	#define IQ 127773
	#define IR 2836
	#define MASK 123459876

	double ran0(long *idum)
	{
		long k;
		double ans;

		*idum ^= MASK;
		k=(*idum)/IQ;
		*idum=IA*(*idum-k*IQ)-IR*k;
		if (*idum < 0) *idum += IM;
		ans=AM*(*idum);
		*idum ^= MASK;
		return ans;
	}
	#undef IA
	#undef IM
	#undef AM
	#undef IQ
	#undef IR
	#undef MASK
};
