#include <afxwin.h>
#include "POT_PointSet.h"
////////////////////////////////////////////////////////////////
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
////////////////////////////////////////////////////////////////

POT_PointSet::POT_PointSet(int num)
{
    m_pointN = num;
    m_point = new float[num][3];
    m_normal = NULL;
    m_weight = NULL;
}

POT_PointSet::~POT_PointSet(void)
{
    delete[] m_point;
    if(m_normal != NULL)
		delete[] m_normal;
    if(m_weight != NULL)
		delete[] m_weight;
}
void POT_PointSet::setPoint(int i, float x, float y, float z)
{
	float* p = m_point[i];
	p[0] = x;
	p[1] = y;
	p[2] = z;
}
  
void POT_PointSet::setNormal(int i, float x, float y, float z)
{
	if(m_normal == NULL)
		m_normal = new float[m_pointN][3];
	float* n = m_normal[i];
	n[0] = x;
	n[1] = y;
	n[2] = z;
}
  
void POT_PointSet::setWeight(int i, float w)
{
	if(m_weight == NULL)
		m_weight = new float[m_pointN];
	m_weight[i] = w;
}
  
void POT_PointSet::flipNormal()
{
	if(m_normal == NULL)
		return;
	int i;
	for(i=0; i<m_pointN; i++)
	{
		float* n = m_normal[i];
		n[0] = -n[0];
		n[1] = -n[1];
		n[2] = -n[2];
	}
}
  
void POT_PointSet::getBound(float min[3], float max[3])
{
	float* p = m_point[0];
	min[0] = max[0] = p[0];
	min[1] = max[1] = p[1];
	min[2] = max[2] = p[2];
	int i;
	for(i=1; i<m_pointN; i++)
	{
			p = m_point[i];

		if(p[0] > max[0])
			max[0] = p[0];
		else if(p[0] < min[0])
			min[0] = p[0];

		if(p[1] > max[1])
			max[1] = p[1];
		else if(p[1] < min[1])
			min[1] = p[1];

		if(p[2] > max[2])
			max[2] = p[2];
		else if(p[2] < min[2])
			min[2] = p[2];
	}
}
float POT_PointSet::fitIntoBox(float ct[3], float boxSize)
{
	float max[3], min[3];
	getBound(min, max);
	//  calculate scale to fit into a 2*2*2 box
	float sX = 	2.0/(max[0] - min[0]);
	float sY = 	2.0/(max[1] - min[1]);
	float sZ = 	2.0/(max[2] - min[2]);
	float scale = sX;
	if (sY < scale)
		scale = sY;
	if (sZ < scale)
		scale = sZ;
	scale *= boxSize;

	float cX = 0.5f*(max[0]+min[0]);
	float cY = 0.5f*(max[1]+min[1]);
	float cZ = 0.5f*(max[2]+min[2]);

	ct[0] = cX;	ct[1] = cY;	ct[2] = cZ;
	int numVert = m_pointN;
	for (int i = 0; i < numVert; i++)
	{
		//  pointer to vertex information
		float *p = m_point[i];
		p[0] = (p[0]-cX)*scale;
		p[1] = (p[1]-cY)*scale;
		p[2] = (p[2]-cZ)*scale;
	}

	return scale;
}
float POT_PointSet::rescale(float ori[3], float scale)
{
	float max[3], min[3];
	getBound(min, max);

	float mx = 0.5f*(max[0]+min[0]);
	float my = 0.5f*(max[1]+min[1]);
	float mz = 0.5f*(max[2]+min[2]);

	float sx = max[0] - min[0];
	float sy = max[1] - min[1];
	float sz = max[2] - min[2];
	float s = scale/(float)sqrt(sx*sx + sy*sy + sz*sz);

	int i;
	for(i=0; i<m_pointN; i++)
	{
		float* p = m_point[i];
		p[0] = (p[0]-mx)*s;
		p[1] = (p[1]-my)*s;
		p[2] = (p[2]-mz)*s;
	}

	ori[0] = mx;	ori[1] = my;	ori[2] = mz;
	return s;
}

float POT_PointSet::PointTriDist(int *posFlag, float q[3], const float p[3], const float tri[3][3])
{
	float v[3], e1[3], e2[3];
	v[0] = tri[0][0];	v[1] = tri[0][1];	v[2] = tri[0][2];
	e1[0] = tri[1][0] - tri[0][0];	e1[1] = tri[1][1] - tri[0][1];	e1[2] = tri[1][2] - tri[0][2];
	e2[0] = tri[2][0] - tri[0][0];	e2[1] = tri[2][1] - tri[0][1];	e2[2] = tri[2][2] - tri[0][2];

	double a, b, c, d, e, f;
	double vp[3];
	vp[0] = v[0]-p[0];	vp[1] = v[1]-p[1];	vp[2] = v[2]-p[2];

	a = e1[0]*e1[0]+e1[1]*e1[1]+e1[2]*e1[2];
	b = e1[0]*e2[0]+e1[1]*e2[1]+e1[2]*e2[2];
	c = e2[0]*e2[0]+e2[1]*e2[1]+e2[2]*e2[2];
	d = e1[0]*vp[0]+e1[1]*vp[1]+e1[2]*vp[2];
	e = e2[0]*vp[0]+e2[1]*vp[1]+e2[2]*vp[2];
	f = vp[0]*vp[0]+vp[1]*vp[1]+vp[2]*vp[2];

	double det, s, t;
	det = fabs(a*c-b*b);	s = b*e-c*d;	t = b*d-a*e;
	if(s+t<=det)
	{
		if(s<0)
		{
			if(t<0)
			{
				//region 4
				if(d<0)	// minimum on edge t=0
				{
					t = 0;
					s = -d>=a?1:-d/a;
				}
				else	//minimum on edge s=0
				{
					s = 0;
					t = (e>=0?0:(-e>=c?1:-e/c));
				}
			}
			else
			{
				//region 3
				s = 0.0;
				t = (e>=0?0:(-e>=c?1:-e/c));
			}
		}
		else if(t<0)
		{
			//region 5
			t = 0.0;
			s = (d>=0?0:(-d>=a?1:-d/a));
		}
		else
		{
			//region 0
			double invDet = 1.0/det;
			s *= invDet;
			t *= invDet;
		}
	}
	else
	{
		if(s<0)
		{
			//region 2
			//s = 0.0;
			//t = 1.0;
			double tmp0=b+d;	double tmp1=c+e;
			if(tmp1>tmp0)	// minimum on edge s+t=1
			{
				double numer = tmp1-tmp0;
				double denom = fabs(a-2.0*b+c);
				s = (numer>=denom?1:numer/denom);
				t = 1-s;
			}
			else	//minimum on edge s=0
			{
				s = 0;
				t = (tmp1<=0?1:(e>=0?0:-e/c));
			}
		}
		else if(t<0)
		{
			//region 6
			//s = 1.0;
			//t = 0.0;
			double tmp0=b+e;	double tmp1=a+d;
			if(tmp1>tmp0)	//	minimum on edge s+t=1
			{
				double numer = tmp1-tmp0;
				double denom = fabs(a-2.0*b+c);
				t = (numer>=denom?1:numer/denom);
				s = 1-t;
			}
			else //minimum on edge t=0;
			{
				t = 0;
				s = (tmp1<=0?1:(d>=0?0:-d/a));
			}
		}
		else
		{
			//region 1
			double numer = c+e-b-d;
			if(numer <= 0)
			{
				s = 0.0;
			}
			else
			{
				double denom = fabs(a-2.0*b+c);
				s = (numer >= denom ? 1:numer/denom);
			}
			t = 1.0-s;
		}
	}

	q[0]=v[0]+s*e1[0]+t*e2[0];	q[1]=v[1]+s*e1[1]+t*e2[1];	q[2]=v[2]+s*e1[2]+t*e2[2];	

	double dist = (p[0]-q[0])*(p[0]-q[0])+(p[1]-q[1])*(p[1]-q[1])+(p[2]-q[2])*(p[2]-q[2]);
	dist = sqrt(dist);

	*posFlag = -1;
	if(s==0 && t==0)
	{
		*posFlag=4;	
	}
	else if(s==1 && t==0)
	{	
		*posFlag = 5;
	}
	else if(s==0 && t==1)
	{
		*posFlag = 6;
	}
	else if(s<1 && t==0)
	{
		*posFlag = 1;
	}
	else if(s+t==1 && s<1 && s>0 && t<1 && t>0)
	{
		*posFlag = 2;
	}
	else if(s==0 && t<1)
	{
		*posFlag = 3;
	}
	else if(s+t<1 && s>0 && t>0)
	{
		*posFlag = 0;
	}
	return dist;
}