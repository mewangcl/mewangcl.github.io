#include <afxwin.h>
#include "POT_Mesh.h"
#include <math.h>
////////////////////////////////////////////////////////////////
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
////////////////////////////////////////////////////////////////

POT_Mesh::POT_Mesh(int vN, int fN)
{
    setSize(vN, fN);
    m_normal_f = NULL;
    m_normal_v = NULL;
}

POT_Mesh::~POT_Mesh(void)
{
	delete[] m_vertex;
	delete[] m_face;

	if(m_normal_f != NULL)
		delete[] m_normal_f;
	if(m_normal_v != NULL)
		delete[] m_normal_v;
}
void POT_Mesh::setSize(int vN, int fN)
{
	m_vertexN = vN;
	m_faceN = fN;
	m_vertex = new float[vN][3];
	m_face = new int[fN][3];
}

void POT_Mesh::setVertex(int i, float x, float y, float z)
{
	m_vertex[i][0] = x;
	m_vertex[i][1] = y;
	m_vertex[i][2] = z;
}

void POT_Mesh::setFace(int i, int i0, int i1, int i2)
{
	m_face[i][0] = i0;
	m_face[i][1] = i1;
	m_face[i][2] = i2;
}

void POT_Mesh::flipNormal()
{
	int i;

	for(i=0; i<m_vertexN; i++)
	{
		float* n = m_normal_v[i];
		n[0] = -n[0];
		n[1] = -n[1];
		n[2] = -n[2];
	}

	for(i=0; i<m_faceN; i++)
	{
		float* n = m_normal_f[i];
		n[0] = -n[0];
		n[1] = -n[1];
		n[2] = -n[2];
	}
}

void POT_Mesh::computeNormal()
{
	if(m_normal_f != NULL)
		delete[] m_normal_f;
	if(m_normal_v != NULL)
		delete[] m_normal_v;

	m_normal_f = new float[m_faceN][3];
	m_normal_v = new float[m_vertexN][3];

	int i, j;
	for(i=0; i<m_vertexN; i++)
		m_normal_v[i][0] = m_normal_v[i][1] = m_normal_v[i][2] = 0;

	for(i=0; i<m_faceN; i++)
	{
		int* f = m_face[i];

		float* p0 = m_vertex[f[0]];
		float* p1 = m_vertex[f[1]];
		float* p2 = m_vertex[f[2]];

		float v1x = p1[0] - p0[0];
		float v1y = p1[1] - p0[1];
		float v1z = p1[2] - p0[2];

		float v2x = p2[0] - p0[0];
		float v2y = p2[1] - p0[1];
		float v2z = p2[2] - p0[2];

		float *n = m_normal_f[i];
		n[0] = v1y*v2z - v1z*v2y;
		n[1] = v1z*v2x - v1x*v2z;
		n[2] = v1x*v2y - v1y*v2x;

		for(j=0; j<3; j++)
		{
			float *nv;
			nv = m_normal_v[f[j]];
			nv[0] += n[0];
			nv[1] += n[1];
			nv[2] += n[2];
		}
	}

	for(i=0; i<m_vertexN; i++)
	{
		float* n = m_normal_v[i];
		float l = 1.0f/(float)sqrt(n[0]*n[0] + n[1]*n[1] + n[2]*n[2]);
		n[0] *= l;
		n[1] *= l;
		n[2] *= l;
	}

	for(i=0; i<m_faceN; i++)
	{
		float* n = m_normal_f[i];
		float l = 1.0f/(float)sqrt(n[0]*n[0] + n[1]*n[1] + n[2]*n[2]);
		n[0] *= l;
		n[1] *= l;
		n[2] *= l;
	}
}

void POT_Mesh::faceNormal(float n[3], int i)
{
	int* f = m_face[i];

	float* p0 = m_vertex[f[0]];
	float* p1 = m_vertex[f[1]];
	float* p2 = m_vertex[f[2]];

	float v1x = p1[0] - p0[0];
	float v1y = p1[1] - p0[1];
	float v1z = p1[2] - p0[2];

	float v2x = p2[0] - p0[0];
	float v2y = p2[1] - p0[1];
	float v2z = p2[2] - p0[2];

	double nx = v1y*v2z - v1z*v2y;
	double ny = v1z*v2x - v1x*v2z;
	double nz = v1x*v2y - v1y*v2x;

	double len = sqrt(nx*nx + ny*ny + nz*nz);
	if((float)len != 0)
	{
		len = 1.0/len;
		n[0] = (float)(nx/len);
		n[1] = (float)(ny/len);
		n[2] = (float)(nz/len);
	}
	else
		n[0] = n[1] = n[2] = 0;
}

void POT_Mesh::fillSmallHolesMinA(int T)
{
	int i, j, k;
	int *degree = new int[m_vertexN];
	for(i=0; i<m_vertexN; i++)
		degree[i] = 0;

	for(i=0; i<m_faceN; i++)
	{
		int* f = m_face[i];
		degree[f[0]]++;
		degree[f[1]]++;
		degree[f[2]]++;
	}

	int** link = new int*[m_vertexN];
	for(i=0; i<m_vertexN; i++)
	{
		link[i] = new int[degree[i]];
		degree[i] = 0;
	}

	for(i=0; i<m_faceN; i++)
	{
		int* f = m_face[i];
		for(j=0; j<3; j++)
		{
			k = f[j];
			link[k][degree[k]++] = i;
		}
	}

	int** linkT = new int*[m_vertexN];
	for(i=0; i<m_vertexN; i++)
	{
		int degT = degree[i];
		int degE = 0;
		int* lT = link[i];
		int* lE = new int[2*degT];
		int* lF = new int[2*degT];
		for(j=0; j<degT; j++)
		{
			int *f = m_face[lT[j]];
			int v;
			if(f[0]==i)
				v = f[1];
			else if(f[1]==i)
				v = f[2];
			else
				v = f[0];
			for(k=0; k<degT; k++)
			{
			if(j==k)
				continue;
			int * f1 = m_face[lT[k]];
			if(f1[0]==v || f1[1]==v || f1[2]==v)
				break;
			}
			if(k==degT)
			{
				lE[degE] = v;
				lF[degE] = lT[j];
				degE++;
			}
		}

		for(j=0; j<degT; j++)
		{
			int *f = m_face[lT[j]];
			int v;
			if(f[0]==i)
				v = f[2];
			else if(f[1]==i)
				v = f[0];
			else
				v = f[1];
			for(k=0; k<degT; k++)
			{
				if(j==k)
					continue;
				int * f1 = m_face[lT[k]];
				if(f1[0]==v || f1[1]==v || f1[2]==v)
					break;
			}
			if(k==degT)
			{
				lE[degE] = v;
				lF[degE] = lT[j];
				degE++;
			}
		}
		degree[i] = degE;
		delete[] lT;
		if(degE == 0)
		{
			delete[] lE;
			delete[] lF;
		}
		else
		{
			link[i] = lE;
			linkT[i] = lF;
		}
	}

	bool* visit = new bool[m_vertexN];
	for(i=0; i<m_vertexN; i++)
		visit[i] = false;
	int top;
	int *stack = new int[T+1];
	int *stackF = new int[T+1];
	TriList* tri_list = new TriList(-1, -1, -1);
	for(i=0; i<m_vertexN; i++)
	{
		if(visit[i] == true)
			continue;

		top = 0;
		stack[0] = i;
		visit[i] = true;

		bool isFilled = false;
		while(top < T)
		{
			int index = stack[top];

			if(degree[index] < 2)
			{
				if(degree[index] != 0)
				{
					delete[] link[index];
					degree[index] = 0;
				}
				break;
			}

			int next = link[index][0];
			int f = linkT[index][0];
			stackF[top] = f;

			delete[] link[index];
			delete[] linkT[index];
			degree[index] = 0;

			if(next == i)
			{
				isFilled = true;
				break;
			}

			if(visit[next])
				break;

			stack[++top] = next;
			visit[next] = true;
		}

		if(!isFilled)
			continue;
		int size = top+1;

		fillPolygon(tri_list, stack, stackF, size);
	}
	delete[] stack;
	delete[] stackF;
	delete[] visit;
    for(i=0; i<m_vertexN; i++)
	{
		if(degree[i] != 0)
		{
			delete[] link[i];
			delete[] linkT[i];
		}
	}
	delete[] link;
	delete[] linkT;
	delete[] degree;

	int N = 0;
	TriList* l;
	for(l=tri_list; l!=NULL; l=l->next)
		N++;
	N--;
	int (*face_tmp)[3] = new int[m_faceN + N][3];
	for(i=0; i<m_faceN; i++)
	{
		face_tmp[i][0] = m_face[i][0];
		face_tmp[i][1] = m_face[i][1];
		face_tmp[i][2] = m_face[i][2];
	}
	delete[] m_face;
	m_face = face_tmp;

	for(l=tri_list; l->next!=NULL; l=l->next)
	{
		m_face[m_faceN][0] = l->i0;
		m_face[m_faceN][1] = l->i1;
		m_face[m_faceN][2] = l->i2;
		m_faceN++;
	}

	delete tri_list;
}

void POT_Mesh::fillPolygon(TriList *&tri_list, int* v, int* f, int N)
{
	float** area = new float*[N];
	float** angle = new float*[N];
	int** opt = new int*[N];
	int i, j, k, m;
	for(i=0; i<N; i++)
	{
		area[i] = new float[N];
		angle[i] = new float[N];
		opt[i] = new int[N];
	}
    
	for(i=0; i<N-1; i++)
	{
		area[i][i+1] = 0;
		angle[i][i+1] = 0;
	}
    
	for(i=0; i<N-2; i++)
	{
		area[i][i+2] = areaF(v[i], v[i+1], v[i+2]);
		float a1 = dihedral(v[i], v[i+1], v[i+2],m_face[f[i]][0], m_face[f[i]][2], m_face[f[i]][1]);
		float a2 = dihedral(v[i], v[i+1], v[i+2],m_face[f[i+1]][0], m_face[f[i+1]][2], m_face[f[i+1]][1]);
		if(a1 > a2)
			angle[i][i+2] = a1;
		else
			angle[i][i+2] = a2;
		opt[i][i+2] = i+1;
	}
    
	for(j=3; j<N; j++)
	{
		for(i=0; i<N-j; i++)
		{
			k = i + j;
			area[i][k] = 1000000.0f;
			angle[i][k] = 1000000.0f;
			for(m=i+1; m<k; m++)
			{
				float a = area[i][m] + area[m][k] + areaF(v[i], v[m], v[k]);
				float a1, a2;
				if(i+1 == m)
					a1 = dihedral(v[i], v[m], v[k],	m_face[f[i]][0], m_face[f[i]][2], m_face[f[i]][1]);
				else
					a1 = dihedral(v[i], v[m], v[k], v[i], v[opt[i][m]], v[m]);
				if(m+1 == k)
					a2 = dihedral(v[i], v[m], v[k],	m_face[f[m]][0], m_face[f[m]][2], m_face[f[m]][1]);
				else
					a2 = dihedral(v[i], v[m], v[k], v[m], v[opt[m][k]], v[k]);
				float maxA = a1;
				if(maxA < a2) maxA = a2;
				if(maxA < angle[i][m]) maxA = angle[i][m];
				if(maxA < angle[m][k]) maxA = angle[m][k];
				if(maxA < angle[i][k])
				{
					if(maxA < angle[i][k])
					{
						area[i][k] = a;
						angle[i][k] = maxA;
						opt[i][k] = m;
					}
				}
				else if(maxA == angle[i][k])
				{
					if(a < area[i][k])
					{
						area[i][k] = a;
						angle[i][k] = maxA;
						opt[i][k] = m;
					}
				}
			}
		}
	}
    
	traceOpt(tri_list, 0, N-1, opt, v);
    
	for(i=0; i<N; i++)
	{
		delete[] area[i];
		delete[] angle[i];
		delete[] opt[i];
	}
	delete[] opt;
	delete[] angle;
	delete[] area;
}
  
void POT_Mesh::traceOpt(TriList *&tri_list, int i, int k, int** opt, int *v)
{
	if(i+2 == k)
		tri_list = tri_list->add(v[i], v[k], v[i+1]);
    else
	{
		int o = opt[i][k];
		if(o != i+1)
			traceOpt(tri_list, i, o, opt, v);

		tri_list = tri_list->add(v[i], v[k], v[o]);

		if(o != k-1)
			traceOpt(tri_list, o, k, opt, v);
	}
}

