#pragma once
#include "nrbase.h"

//template <typename T>
class NRSVD :
	public NRBase
{
public:
	NRSVD(void);
	virtual ~NRSVD(void);

	static bool svdcmp(float **a, int m, int n, float w[], float **v);
	static void svbksb(float **u, float w[], float **v, int m, int n, float b[], float x[]);

	static bool svdcmp(double **a, int m, int n, double w[], double **v);
	static void svbksb(double **u, double w[], double **v, int m, int n, double b[], double x[]);

protected:
	static float pythag(float a, float b);
	static double pythag(double a, double b);
};
