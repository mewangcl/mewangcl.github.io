#pragma once
#include "NRutils.h"
#include <math.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>

#define TINY 1.0e-20;
#define NR_END 1
#define FREE_ARG char*
#define EPS 1.0e-14


class NRBase
{
public:
	NRBase(void);
	virtual ~NRBase(void);

	static void nrerror(char error_text[]);
	/* Numerical Recipes standard error handler */

	static float *vector(long nl, long nh);
	/* allocate a float vector with subscript range v[nl..nh] */

	static int *ivector(long nl, long nh);
	/* allocate an int vector with subscript range v[nl..nh] */

	static unsigned char *cvector(long nl, long nh);
	/* allocate an unsigned char vector with subscript range v[nl..nh] */

	static unsigned long *lvector(long nl, long nh);
	/* allocate an unsigned long vector with subscript range v[nl..nh] */

	static double *dvector(long nl, long nh);
	/* allocate a double vector with subscript range v[nl..nh] */

	static float **matrix(long nrl, long nrh, long ncl, long nch);
	/* allocate a float matrix with subscript range m[nrl..nrh][ncl..nch] */

	static double **dmatrix(long nrl, long nrh, long ncl, long nch);
	/* allocate a double matrix with subscript range m[nrl..nrh][ncl..nch] */

	static int **imatrix(long nrl, long nrh, long ncl, long nch);
	/* allocate a int matrix with subscript range m[nrl..nrh][ncl..nch] */


	static float **submatrix(float **a, long oldrl, long oldrh, long oldcl, long oldch,
					long newrl, long newcl);
					/* point a submatrix [newrl..][newcl..] to a[oldrl..oldrh][oldcl..oldch] */


	static float **convert_matrix(float *a, long nrl, long nrh, long ncl, long nch);
	/* allocate a float matrix m[nrl..nrh][ncl..nch] that points to the matrix
	declared in the standard C manner as a[nrow][ncol], where nrow=nrh-nrl+1
	and ncol=nch-ncl+1. The routine should be called with the address
	&a[0][0] as the first argument. */


	static float ***f3tensor(long nrl, long nrh, long ncl, long nch, long ndl, long ndh);
	/* allocate a float 3tensor with range t[nrl..nrh][ncl..nch][ndl..ndh] */


	static void free_vector(float *v, long nl, long nh);
	/* free a float vector allocated with vector() */

	static void free_ivector(int *v, long nl, long nh);
	/* free an int vector allocated with ivector() */


	static void free_cvector(unsigned char *v, long nl, long nh);
	/* free an unsigned char vector allocated with cvector() */

	static void free_lvector(unsigned long *v, long nl, long nh);
	/* free an unsigned long vector allocated with lvector() */


	static void free_dvector(double *v, long nl, long nh);
	/* free a double vector allocated with dvector() */


	static void free_matrix(float **m, long nrl, long nrh, long ncl, long nch);
	/* free a float matrix allocated by matrix() */

	static void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch);
	/* free a double matrix allocated by dmatrix() */

	static void free_imatrix(int **m, long nrl, long nrh, long ncl, long nch);
	/* free an int matrix allocated by imatrix() */

	static void free_submatrix(float **b, long nrl, long nrh, long ncl, long nch);
	/* free a submatrix allocated by submatrix() */

	static void free_convert_matrix(float **b, long nrl, long nrh, long ncl, long nch);
	/* free a matrix allocated by convert_matrix() */

	static void free_f3tensor(float ***t, long nrl, long nrh, long ncl, long nch,
					long ndl, long ndh);
					/* free a float f3tensor allocated by f3tensor() */

/* (C) Copr. 1986-92 Numerical Recipes Software 9z!+!1(t+%. */
};
