#ifndef _NR_UTILS_H_
#define _NR_UTILS_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

static float sqrarg;
#ifndef SQR
#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg)
#endif

static double dsqrarg;
#ifndef DSQR
#define DSQR(a) ((dsqrarg=(a)) == 0.0 ? 0.0 : dsqrarg*dsqrarg)
#endif

static double dmaxarg1,dmaxarg2;
#ifndef DMAX
#define DMAX(a,b) (dmaxarg1=(a),dmaxarg2=(b),(dmaxarg1) > (dmaxarg2) ?\
(dmaxarg1) : (dmaxarg2))
#endif

static double dminarg1,dminarg2;
#ifndef DMIN
#define DMIN(a,b) (dminarg1=(a),dminarg2=(b),(dminarg1) < (dminarg2) ?\
(dminarg1) : (dminarg2))
#endif

static float maxarg1,maxarg2;
#ifndef FMAX
#define FMAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ?\
(maxarg1) : (maxarg2))
#endif

static float minarg1,minarg2;
#ifndef FMIN
#define FMIN(a,b) (minarg1=(a),minarg2=(b),(minarg1) < (minarg2) ?\
(minarg1) : (minarg2))
#endif

static long lmaxarg1,lmaxarg2;
#ifndef LMAX
#define LMAX(a,b) (lmaxarg1=(a),lmaxarg2=(b),(lmaxarg1) > (lmaxarg2) ?\
(lmaxarg1) : (lmaxarg2))
#endif

static long lminarg1,lminarg2;
#ifndef LMIN
#define LMIN(a,b) (lminarg1=(a),lminarg2=(b),(lminarg1) < (lminarg2) ?\
(lminarg1) : (lminarg2))
#endif

static int imaxarg1,imaxarg2;
#ifndef IMAX
#define IMAX(a,b) (imaxarg1=(a),imaxarg2=(b),(imaxarg1) > (imaxarg2) ?\
(imaxarg1) : (imaxarg2))
#endif

static int iminarg1,iminarg2;
#ifndef IMIN
#define IMIN(a,b) (iminarg1=(a),iminarg2=(b),(iminarg1) < (iminarg2) ?\
(iminarg1) : (iminarg2))
#endif

#ifndef SIGN
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
#endif

#endif
