#pragma once
#include "NRutils.h"
#include "NRBase.h"
#include "NRSVD.h"
#include "NRJacobi.h"

#include <iostream>
#include <iomanip>

using namespace std;

template<class T>
void print_array(T *a, const int nrl, const int nrh)
{
	int i;
	int col_width = 12;
	for (i=nrl; i <= nrh; i++) {
		cout << setw(col_width) << a[i];
	}
	cout <<endl<<endl;
}

template<class T>
void print_matrix(T **a, const int nrl, const int nrh, const int ncl, const int nch)
{
	int i,j;
	int col_width = 12;
	for (i=nrl; i <= nrh; i++) {
		for(j = ncl; j<=nch; j++)
		{
			cout << setw(col_width) << a[i][j];
		}
		cout<<endl;
	}
	cout << endl;
}