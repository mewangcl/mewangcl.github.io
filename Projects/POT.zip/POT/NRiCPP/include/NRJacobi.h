#pragma once
#include "nrbase.h"

class NRJacobi :
	public NRBase
{
public:
	NRJacobi(void);
	~NRJacobi(void);

	static bool Jacobi(double **a, int n, double d[], double **v, int *nrot);
	static bool Jacobi(float **a, int n, float d[], float **v, int *nrot);
protected:
	inline static void rot(double **a, const double s, const double tau, const int i,
		const int j, const int k, const int l)
	{
		double g,h;

		g=a[i][j];
		h=a[k][l];
		a[i][j]=g-s*(h+g*tau);
		a[k][l]=h+s*(g-h*tau);
	}
	inline static void rot(float **a, const float s, const float tau, const int i,
		const int j, const int k, const int l)
	{
		float g,h;

		g=a[i][j];
		h=a[k][l];
		a[i][j]=g-s*(h+g*tau);
		a[k][l]=h+s*(g-h*tau);
	}
};
