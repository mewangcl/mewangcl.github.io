#include <afxwin.h>
#include "POT_FileIO.h"
#include <stdio.h>
#include <fstream>
#include <iostream>
////////////////////////////////////////////////////////////////
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
////////////////////////////////////////////////////////////////

using namespace std;

char CAP(char c)
{
	if (c >= 'a' && c < 'z')
		return c + ('A' - 'a');
	else
		return c;
}

POT_FileIO::POT_FileIO()
{

}

POT_FileIO::~POT_FileIO()
{

}
POT_PointSet* POT_FileIO::readObjFile(char* name)
{
	FILE* file = fopen(name,"r");
	int vertNum, normNum;
	vertNum = normNum = 0;
	//	first pass to get the vertices number and face number from reading the file 
	char buffer[1024];
	while (!feof(file) && fgets(buffer, 1023, file))
	{
		//  get length
		int len = strlen(buffer);

		//  trim off any leading spaces
		int i;
		for (i = 0; i < len; i++)
		{
			if (buffer[i] != ' ' && buffer[i] != '\t')
				break;
		}

		if (CAP(buffer[i]) == 'V' && buffer[i+1] == ' ')
		{
			vertNum++;
		}
		else if (CAP(buffer[i]) == 'V' && CAP(buffer[i+1]) == 'N' && buffer[i+2] == ' ')
		{
			normNum++;
		}
	}
	POT_PointSet* ps = new POT_PointSet(vertNum);

	//	second pass to get the data
	//  read the file and process each line
	rewind(file);
	int v_count, n_count;
	v_count = n_count = 0;
	while (!feof(file) && fgets(buffer, 1023, file))
	{
		//  get length
		int len = strlen(buffer);

		//  trim off any leading spaces
		int i;
		for (i = 0; i < len; i++)
		{
			if (buffer[i] != ' ' && buffer[i] != '\t')
				break;
		}

		if (CAP(buffer[i]) == 'V' && buffer[i+1] == ' ')
		{
			//  do new VERTEX
			float p[3];
			sscanf(buffer+i+1, "%f %f %f", &p[0], &p[1], &p[2]);
			ps->setPoint(v_count, p[0], p[1], p[2]);
			ps->setWeight(v_count, 1);
			v_count++;
		}
		else if (CAP(buffer[i]) == 'V' && CAP(buffer[i+1]) == 'N' && buffer[i+2] == ' ' && n_count<vertNum)
		{
			//  do new Normal
			float n[3];
			sscanf(buffer+i+2, "%f %f %f", &n[0], &n[1], &n[2]);
			ps->setNormal(n_count, n[0], n[1], n[2]);
			n_count++;
		}
	}
	if(normNum<vertNum)
	{
		int i;
		for(i = normNum; i<vertNum; i++)
		{
			ps->setNormal(i, 0.0f,0.0f,0.0f);
		}
	}
	fclose(file);
	return ps;
}

POT_PointSet* POT_FileIO::readPwnFile(char* name)
{
	ifstream in(name);

	int N;
	in >> N;

	POT_PointSet* ps = new POT_PointSet(N);

	int i;
	for(i=0; i<N; i++)
	{
		float x,y,z;
		in >> x >> y >> z;
		ps->setPoint(i, x, y, z);
		ps->setWeight(i, 1);
	}

	for(i=0; i<N; i++)
	{
		float x,y,z;
		in >> x >> y >> z;
		ps->setNormal(i, x, y, z);
	}

	in.close();

	return ps;
}
void POT_FileIO::writePwnFile(POT_PointSet* ps, float ori[3], float scale, char* name)
{
	ofstream out(name);

	int N = ps->m_pointN;
	out << N << endl;

	int i;
	float (*point)[3] = ps->m_point;
	for(i=0; i<N; i++)
	{
		float *p = point[i];
		out << p[0]/scale + ori[0] << " " << p[1]/scale + ori[1] << " " << p[2]/scale + ori[2] << endl;
	}

	float (*m_normal)[3] = ps->m_normal;
	for(i=0; i<N; i++)
	{
		float* n = m_normal[i];
		out << n[0] << " " << n[1] << " " << n[2] << endl;
	}

	out.close();
}
