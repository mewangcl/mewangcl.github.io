#include <afxwin.h>
#include "POT_Orientator.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <iostream>
using namespace std;

////////////////////////////////////////////////////////////////////
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

POT_Orientator::POT_Orientator(void)
{
	m_meshGen = NULL;
	m_sphGen = NULL;
	m_spheres = NULL;
	m_mesh = NULL;	m_ps = NULL;
	m_fScale = 1.0f;	m_fCenter[0]=m_fCenter[1]=m_fCenter[2]=0.0f;
	m_duration = 0;
	m_fileIO = new POT_FileIO();
}

POT_Orientator::~POT_Orientator(void)
{
	delete m_fileIO;

	if(m_ps != NULL){
		delete m_ps;
		m_ps = NULL;
	}
	if(m_sphGen != NULL){
		delete m_sphGen;
		m_sphGen = NULL;
	}
	if(m_spheres != NULL){
		delete m_spheres;
		m_spheres = NULL;
	}
	if(m_mesh != NULL){
		delete m_mesh;
		m_mesh = NULL;
	}
	if(m_meshGen != NULL){
		delete m_meshGen;
		m_meshGen = NULL;
	}
}

void POT_Orientator::fileOpen(char* fName)
{
	if(m_ps != NULL){
		delete m_ps;
		m_ps = NULL;
	}
	if(m_sphGen != NULL){
		delete m_sphGen;
		m_sphGen = NULL;
	}
	if(m_spheres != NULL){
		delete m_spheres;
		m_spheres = NULL;
	}
	if(m_mesh != NULL){
		delete m_mesh;
		m_mesh = NULL;
	}
	if(m_meshGen != NULL){
		delete m_meshGen;
		m_meshGen = NULL;
	}

	cout<<"Read points file..."<<endl;
	char filename[256];
	strcpy(filename,"Data\\");
	strcat(filename,fName);
	int length=strlen(filename);

	//--------------------------------------------------------------------------
	//	Input files
	if(strstr(fName, ".obj") != NULL){
		cout << "Points file (obj)" << endl;
		m_ps = m_fileIO->readObjFile(filename);
	}
	else if(strstr(fName, ".pwn") != NULL){
		cout << "Points with normals file (pwn)" << endl;
		m_ps = m_fileIO->readPwnFile(filename);
	}
	else
	{
		cout<<"Input file should be a pwn or obj file."<<endl;
		exit(0);
	}
	m_fScale = m_ps->rescale(m_fCenter, 30.0f);
	cout<<fName<<": file input finished!"<<endl;
	cout<<m_ps->m_pointN<<" points input"<<endl;
}
void POT_Orientator::fileSave(char* fName)
{
	cout<<"Write points with normals in a file..."<<endl;
	char filename[256];
	strcpy(filename,"Data\\");
	strcat(filename,fName);
	
	//--------------------------------------------------------------------------
	//	Output files
	m_fileIO->writePwnFile(m_ps, m_fCenter, m_fScale, filename);
	cout<<fName<<": file output finished!"<<endl;
}

void POT_Orientator::preCompute(bool renorm)
{
	if(m_ps == NULL)
		return;
	if(m_sphGen != NULL)
		delete m_sphGen;

	clock_t start = clock();
	m_sphGen = new POT_SphereGenerator(m_ps);
	m_sphGen->m_recomputeNormal = renorm;
	m_sphGen->precom();
	m_duration+=clock()-start;
}
void POT_Orientator::generateSpheres(float terr, float tave, float tq) 
{
	if(m_ps == NULL)
		return;
	if(m_sphGen == NULL)// || ps->weight == NULL || ps->normal == NULL)
	{
		m_sphGen = new POT_SphereGenerator(m_ps);
		m_sphGen->precom();
	}

	clock_t start = clock();
	m_sphGen->generate(terr, tave, tq);//0.01
	m_spheres = m_sphGen->getBalls();

	m_duration += clock()-start;
}
void POT_Orientator::selectSpheres(float tv)
{
	clock_t start = clock();
	if(m_sphGen != NULL)
		m_sphGen->selectSpheres(tv);
	m_duration += clock()-start;
}
void POT_Orientator::splitSpheres()
{
	clock_t start = clock();
	if(m_sphGen != NULL)
		m_sphGen->splitSpheres();
	if(m_spheres!=NULL)	delete m_spheres;
	m_spheres = m_sphGen->getBalls();
	m_duration += clock()-start;
}
void POT_Orientator::generateGuidingMesh()
{
	clock_t start = clock();

	if(m_meshGen == NULL)
		m_meshGen = new POT_MeshGenerator();
	if(m_spheres==NULL)	
		m_spheres = m_sphGen->getBalls();
	m_meshGen->createTriangles(m_spheres);

	POT_PointSet* vs = m_sphGen->getVertices();
	m_meshGen->createMesh(vs);
	m_mesh = m_meshGen->m_mesh;
	m_mesh->computeNormal();

	m_duration += clock()-start;
}
void POT_Orientator::cleanGuidingMesh()
{
	clock_t start = clock();

	m_meshGen->cleanBadTriangles();
	m_mesh->computeNormal();

	m_duration += clock()-start;
}
void POT_Orientator::fixPointNormals()
{
	clock_t start = clock();

	int ballN = m_spheres->m_pointN;

	int **node = new int*[ballN];
	int *nodeN = new int[ballN];
	int **link = new int*[m_ps->m_pointN];
	int *linkN = new int[m_ps->m_pointN];
	bool *covered = new bool[m_ps->m_pointN];
	memset(covered, 0, m_ps->m_pointN*sizeof(bool));

	memset(linkN, 0, m_ps->m_pointN*sizeof(int));
	//	get the include points in each sphere
	int i, j, k;

	float (*point)[3] = m_spheres->m_point;
	float *radius = m_spheres->m_weight;
	for(i = 0; i< ballN; i++)
	{
		int *list, listN;
		m_sphGen->m_tree->collectPointIndexInSphere(list, listN, point[i], radius[i]);
		nodeN[i] = listN;
		node[i] = new int[listN];
		for(j = 0; j< listN; j++)
		{
			node[i][j] = list[j];

			linkN[list[j]]++;

			covered[list[j]] = true;
		}
	}
	
	//	get the spheres which include each point
	for(i = 0; i< m_ps->m_pointN; i++)
		if(covered[i])
			link[i] = new int[linkN[i]];


	memset(linkN, 0, m_ps->m_pointN*sizeof(int));
	for(i = 0; i< m_spheres->m_pointN; i++)
	{
		for(j = 0; j< nodeN[i]; j++)
		{
			int vid = node[i][j];
			link[vid][linkN[vid]] = i;
			linkN[vid]++;
		}
	}

	//	dump the points in each sphere
	for(i = 0; i< ballN; i++)
		delete[] node[i];
	memset(nodeN, 0, ballN*sizeof(int));

	//	get the neighbour spheres for each sphere
    POT_KdTree* ballTree = new POT_KdTree(m_spheres);
    
    for(i=0; i<ballN; i++)
	{
		float* p = point[i];
		float r = radius[i];

		int listN, *list;
		ballTree->collectPointIndexInSphere(list, listN, p, 2.0f*r);

		for(j=0; j<listN; j++)
		{
			int i1 = list[j];
			if(i == i1)
				continue;
			float* p1 = point[i1];
			float r1 = radius[i1];

			float vx = p[0]-p1[0];
			float vy = p[1]-p1[1];
			float vz = p[2]-p1[2];
			double d = sqrt(vx*vx + vy*vy + vz*vz);

			if(r + r1 > d && fabs(r - r1) < d)
			{
				int* tmp = node[i];
				int nN = nodeN[i];
				int* n = node[i] = new int[nN+1];
				for(k=0; k<nN; k++)
					n[k] = tmp[k];
				if(nN != 0)
					delete[] tmp;
				n[k] = i1;
				nodeN[i]++;

				if(2*r1 < d)
				{
					tmp = node[i1];
					nN = nodeN[i1];
					n = node[i1] = new int[nN+1];
					for(k=0; k<nN; k++)
						n[k] = tmp[k];
					if(nN != 0)
						delete[] tmp;
					n[k] = i;
					nodeN[i1]++;
				}
			}
		}
	}
	delete ballTree;	

	printf(".");

	//	reconstruct the topology of the mesh
	int vertNum = m_mesh->m_vertexN;
	int triNum = m_mesh->m_faceN;
	int **linkedTri = new int*[vertNum];
	int *linkedTriN = new int[vertNum];
	memset(linkedTriN, 0, vertNum*sizeof(int));
	for(i = 0; i< triNum; i++)
	{
		int *face = m_mesh->m_face[i];
		linkedTriN[face[0]]++;
		linkedTriN[face[1]]++;
		linkedTriN[face[2]]++;
	}
	for(i = 0; i< vertNum; i++)
		linkedTri[i] = new int[linkedTriN[i]];
	memset(linkedTriN, 0, vertNum*sizeof(int));
	for(i = 0; i< triNum; i++)
	{
		int *face = m_mesh->m_face[i];
		linkedTri[face[0]][linkedTriN[face[0]]] = i;
		linkedTriN[face[0]]++;
		
		linkedTri[face[1]][linkedTriN[face[1]]] = i;
		linkedTriN[face[1]]++;
		
		linkedTri[face[2]][linkedTriN[face[2]]] = i;
		linkedTriN[face[2]]++;
	}
	//	get the valid sphere index
	int *table = m_meshGen->getValidBallTable(m_spheres->m_pointN);


	//	consistent the points normals
	bool *isTested = new bool[triNum];
	for(i = 0; i< m_ps->m_pointN; i++)
	{
		memset(isTested, 0, triNum*sizeof(bool));
		float minDist = 1.0e+8;
		int minFId = -1;

		if(!covered[i])// there are no sphere covered the point i
		{
			// select the spheres covered the nearest point of point i as its cover spheres
			float size = m_sphGen->m_tree->getLeafSize();
			float *p_i = m_ps->m_point[i];
			for(;;)
			{
				int *list, listN;
				m_sphGen->m_tree->collectPointIndexInSphere(list, listN, m_ps->m_point[i], size);
				
				int coveredNum = 0;
				minDist = 1.0e+8;
				minFId = -1;
				for(j = 0; j< listN; j++)
				{
					if(i == list[j])	continue;
					if(covered[list[j]])
					{
						float *p_j = m_ps->m_point[list[j]];
						covered[i] = true;
						float disSQR = (p_i[0]-p_j[0])*(p_i[0]-p_j[0])+(p_i[1]-p_j[1])*(p_i[1]-p_j[1])+
							(p_i[2]-p_j[2])*(p_i[2]-p_j[2]);
						if(disSQR<minDist)
						{
							minDist = disSQR;
							minFId = list[j];
						}
					}
				}
				if(covered[i])	
				{
					linkN[i] = linkN[minFId];
					link[i] = new int[linkN[i]];
					for(j = 0; j< linkN[i]; j++)
					{
						link[i][j] = link[minFId][j];
					}
					break;
				}
				size *= 2.0;
			}
		}

		{

			minDist = 1.0e+8;
			minFId = -1;
			bool isok = false;
			for(j = 0; j< linkN[i]; j++)	//for each sphere covered the point
			{
				int sid = table[link[i][j]];
				if(sid>=0)	//	if there is one sphere which is valid
				{
					//	test the triangles linked this sphere

					//	find the closest triangle
					for(k = 0; k< linkedTriN[sid]; k++)
					{
						int fid = linkedTri[sid][k];
						if(isTested[fid])	continue;

						isTested[fid] = true;
						float tri[3][3];
						tri[0][0] = m_mesh->m_vertex[m_mesh->m_face[fid][0]][0];
						tri[0][1] = m_mesh->m_vertex[m_mesh->m_face[fid][0]][1];
						tri[0][2] = m_mesh->m_vertex[m_mesh->m_face[fid][0]][2];

						tri[1][0] = m_mesh->m_vertex[m_mesh->m_face[fid][1]][0];
						tri[1][1] = m_mesh->m_vertex[m_mesh->m_face[fid][1]][1];
						tri[1][2] = m_mesh->m_vertex[m_mesh->m_face[fid][1]][2];

						tri[2][0] = m_mesh->m_vertex[m_mesh->m_face[fid][2]][0];
						tri[2][1] = m_mesh->m_vertex[m_mesh->m_face[fid][2]][1];
						tri[2][2] = m_mesh->m_vertex[m_mesh->m_face[fid][2]][2];
						int posFlag;	
						float closestPt[3];

						float dis = m_ps->PointTriDist(&posFlag, closestPt, m_ps->m_point[i], tri);
						if(minDist > dis)
						{
							minDist = dis;
							minFId = fid;
						}
					}
				}
				if(minFId>0)	isok = true;
			}
			if(!isok)
			{

				bool* isSphereTested = new bool[ballN];
				memset(isSphereTested, 0, ballN*sizeof(bool));
				int* lastNeiSph = new int[linkN[i]];
				for(j = 0; j< linkN[i]; j++)
				{
					int sid = link[i][j];
					isSphereTested[sid] = true;
					lastNeiSph[j] = sid;
				}
				int lastNeiSphN = linkN[i];
				bool* inNeiSpheres = new bool[ballN];
				while(true)
				{
					minDist = 1.0e+8;
					minFId = -1;
					//	test the neighborhood by propagating

					//	collect the neighbor spheres
					memset(inNeiSpheres, 0, ballN*sizeof(bool));

					int neiSphN = 0;
					for(j = 0; j< lastNeiSphN; j++)
					{
						int sid = lastNeiSph[j];
						for(k = 0; k< nodeN[sid]; k++)
						{
							int nei_sid = node[sid][k];
							if(!isSphereTested[nei_sid])
							{
								isSphereTested[nei_sid] = true;
								inNeiSpheres[nei_sid] = true;
								neiSphN++;
							}
						}
					}
					if(neiSphN == 0)	break;

					int *neiSph = new int[neiSphN];
					neiSphN = 0;
					for(j = 0; j< ballN; j++)
					{
						if(inNeiSpheres[j])
						{
							neiSph[neiSphN] = j;
							neiSphN++;
						}
					}
					for(j = 0; j< neiSphN; j++)
					{
						int sid = table[neiSph[j]];
						if(sid > 0)
						{
							//	test the triangles linked this sphere

							//	find the closest triangle
							int kk;
							for(kk = 0; kk< linkedTriN[sid]; kk++)
							{
								int fid = linkedTri[sid][kk];
								if(isTested[fid])	continue;

								isTested[fid] = true;
								float tri[3][3];
								tri[0][0] = m_mesh->m_vertex[m_mesh->m_face[fid][0]][0];
								tri[0][1] = m_mesh->m_vertex[m_mesh->m_face[fid][0]][1];
								tri[0][2] = m_mesh->m_vertex[m_mesh->m_face[fid][0]][2];

								tri[1][0] = m_mesh->m_vertex[m_mesh->m_face[fid][1]][0];
								tri[1][1] = m_mesh->m_vertex[m_mesh->m_face[fid][1]][1];
								tri[1][2] = m_mesh->m_vertex[m_mesh->m_face[fid][1]][2];

								tri[2][0] = m_mesh->m_vertex[m_mesh->m_face[fid][2]][0];
								tri[2][1] = m_mesh->m_vertex[m_mesh->m_face[fid][2]][1];
								tri[2][2] = m_mesh->m_vertex[m_mesh->m_face[fid][2]][2];
								int posFlag;	
								float closestPt[3];

								float dis = m_ps->PointTriDist(&posFlag, closestPt, m_ps->m_point[i], tri);
								if(minDist > dis)
								{
									minDist = dis;
									minFId = fid;
								}
							}
						}
					}
					delete[] lastNeiSph;
					lastNeiSph = neiSph;
					lastNeiSphN = neiSphN;

					if(minFId>0)	isok = true;

					if(isok)	break;

				}
				delete[] lastNeiSph;
				delete[] isSphereTested;
				delete[] inNeiSpheres;
			}
			if(isok)
			{
				float *fn = m_mesh->m_normal_f[minFId];
				float *pn = m_ps->m_normal[i];
				if(pn[0]*fn[0]+pn[1]*fn[1]+pn[2]*fn[2]<0)
				{
					pn[0]*=-1.0;	pn[1]*=-1.0;	pn[2]*=-1.0;
				}
			}
		}
	}

	//	free the memory
	for(i = 0; i< vertNum; i++)
		if(linkedTriN[i]>0)
			delete[] linkedTri[i];
	delete[] linkedTri;
	delete[] linkedTriN;

	for(i = 0; i< ballN; i++)
		if(nodeN[i]>0)
			delete[] node[i];
	delete[] node;
	delete[] nodeN;

	for(i = 0; i< m_ps->m_pointN; i++)
	{
		if(covered[i])
			delete[] link[i];
	}
	delete[] link;
	delete[] linkN;

	delete[] covered;
	delete[] table;

	delete[] isTested;

	int correctPtId = 0;
	float maxCSZ = -1.0e+6;
	for(i = 0; i< m_ps->m_pointN; i++)
	{
		float *p = m_ps->m_point[i];
		if(p[2]>maxCSZ)
		{
			maxCSZ = p[2];
			correctPtId = i;
		}
	}

	float *nn = m_ps->m_normal[correctPtId];
	if(nn[2]<0.0)
		m_ps->flipNormal();

	m_duration += clock()-start;
}


void POT_Orientator::pointConsolidate(bool renorm, float terr, float tave, float tq, float teig)
{
	printf(".");
	preCompute(renorm);
	printf(".");
	generateSpheres(terr, tave, tq);
	printf(".");
	if(teig>1.0f)
	{
		selectSpheres(teig);
		splitSpheres();
		printf(".");
	}
	generateGuidingMesh();
	printf(".");
	cleanGuidingMesh();
	printf(".");
	fixPointNormals();
	printf(".");
	if(renorm)
		orientationAwarePCA();
}
void POT_Orientator::orientationAwarePCA()
{
	if(m_sphGen != NULL)
		m_sphGen->computeNormalOrientationAware();
}

int POT_Orientator::finished()
{
	int ret = m_sphGen->removeTempFile();
	if(m_meshGen->removeTempFile() == -1)
		ret+=8;

	return ret;
}