#pragma once
#include <math.h>

//for spline patched Gaussian
#define EE16 2.1653645317858030703

class POT_Sphere
{
public:
  float m_nx, m_ny, m_nz;

  float m_cx, m_cy, m_cz;
  float m_px, m_py, m_pz;
  float m_r;
public:
	POT_Sphere(void);
	POT_Sphere(float x, float y, float z);
	~POT_Sphere(void);

	inline double weight(float x, float y, float z)
	{
		float vx = x - m_cx;
		float vy = y - m_cy;
		float vz = z - m_cz;

		return weight(sqrt(vx*vx+vy*vy+vz*vz), m_r);
	}
  
	static inline double weight(double d, float R)
	{
		//spline patched Gaussian  
		if(R < d)
			return 0;
		else
		{
			d /= R;
			if(d < 0.5f)
				return exp(-8*d*d);
			else
			{
				d = 1.0 - d;
				d = d*d;
				return EE16*d*d;
			}
		}
	}
};
