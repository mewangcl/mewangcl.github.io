#include "POT_Sphere.h"
//////////////////////////////////////////////////////////////////////
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//////////////////////////////////////////////////////////////////////

POT_Sphere::POT_Sphere(void)
{
}

POT_Sphere::~POT_Sphere(void)
{
}
POT_Sphere::POT_Sphere(float x, float y, float z)
{
	m_cx = x;
	m_cy = y;
	m_cz = z;
}