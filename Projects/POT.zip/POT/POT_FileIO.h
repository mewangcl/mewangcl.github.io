#pragma once
#include "POT_PointSet.h"

class POT_FileIO
{
public:
	POT_FileIO(void);
	~POT_FileIO(void);

	POT_PointSet* readObjFile(char* name);
	POT_PointSet* readPwnFile(char* name);

	void writePwnFile(POT_PointSet* ps, float ori[3], float scale, char* name);
};
