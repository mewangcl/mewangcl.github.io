// POT.cpp : Defines the entry point for the console application. 
//
//	points orientation tool
//
#include <afxwin.h>
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include "POT_Orientator.h"

using namespace std;
////////////////////////////////////////////////////////////////////
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////

int main(int argc, char* argv[])
{
	if(argc < 3 || argc > 8)
	{
		cout<<"HBRecon inputfile.obj(.pwn) outputfile.pwn [if_recompute_normal] [error_threshold]"<<
			" [average_radius_weight] [influence_radius_weight] [sphere_splitting_selection_weight]"<<endl;
		return 1;
	}	

	bool ifRecomputeNormal = true;
	float errorThreshold, aveRadWeight, influRadWeight, sphSplSelWeight;
	errorThreshold = 1.0e-5f;	aveRadWeight = 0.0f;	influRadWeight = 2.0f;	sphSplSelWeight = 3.0f;
	if(argc > 3)
	{
		ifRecomputeNormal = atoi(argv[3]);
	}
	if(argc > 4)
	{
		errorThreshold = atof(argv[4]);
	}
	if(argc > 5)
	{
		aveRadWeight = atof(argv[5]);
	}
	if(argc > 6)
	{
		influRadWeight = atof(argv[6]);
	}
	if(argc > 7)
	{
		sphSplSelWeight = atof(argv[7]);
	}


	POT_Orientator *orientator = new POT_Orientator();

	//-------------------------------------------------------------------------
	//	read file
	cout<<"********************************************************************"<<endl;
	orientator->fileOpen(argv[1]);
	cout<<"********************************************************************"<<endl;

	//-------------------------------------------------------------------------
	//	points processing
	cout<<endl;
	cout<<"********************************************************************"<<endl;
	cout<<"Points orientation"<<endl;
	clock_t start = clock();
	orientator->pointConsolidate(ifRecomputeNormal, errorThreshold, aveRadWeight, influRadWeight, sphSplSelWeight);
	clock_t duration = clock()-start;
	cout<<endl<<"done!"<<endl<<"Time: "<<(float)duration/CLOCKS_PER_SEC<<"s"<<endl;	
	cout<<"********************************************************************"<<endl;
	orientator->finished();

	//------------------------------------------------------------------
	//	output files
	cout<<endl<<endl;
	cout<<"********************************************************************"<<endl;
	orientator->fileSave(argv[2]);
	cout<<"********************************************************************"<<endl;

	delete orientator;
	return 0;
}

