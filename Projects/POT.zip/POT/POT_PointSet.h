#pragma once
#include <stdio.h>
#include <math.h>

class POT_PointSet
{
public:
	int m_pointN;
	float (*m_point)[3];
	float (*m_normal)[3];
	float *m_weight;
public:
	POT_PointSet(int num);
	~POT_PointSet(void);

	void setPoint(int i, float x, float y, float z);
	void setNormal(int i, float x, float y, float z);
	void setWeight(int i, float w);
	void flipNormal();
	void getBound(float min[3], float max[3]);
	float fitIntoBox(float ct[3], float boxSize);
	float rescale(float ori[3], float scale);
	float PointTriDist(int *posFlag, float q[3], const float p[3], const float tri[3][3]);

};
