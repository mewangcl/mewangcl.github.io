#pragma once
#include "POT_FileIO.h"
#include "POT_KdTree.h"
#include "POT_SphereGenerator.h"
#include "POT_MeshGenerator.h"
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <string.h>

class POT_Orientator
{
protected:
	POT_MeshGenerator* m_meshGen;
	POT_SphereGenerator* m_sphGen;
	POT_PointSet* m_spheres;
	POT_Mesh* m_mesh;
	POT_PointSet* m_ps;
	float m_fScale;
	float m_fCenter[3];

	POT_FileIO* m_fileIO;

public:
	clock_t m_duration;

public:
	POT_Orientator(void);
	~POT_Orientator(void);

	void fileOpen(char* fName);
	void fileSave(char* fName);

	void pointConsolidate(bool renorm = true, float terr = 0.00001, float tave = 0.0f, float tq = 2.0f, float teig = 3.0f);

	int finished();
protected:

	void preCompute(bool renorm = true); 
	void generateSpheres(float terr = 0.00001f, float tave = 0.0f, float tq = 2.0f) ;
	void selectSpheres(float tv = 3.0f);
	void splitSpheres();
	void generateGuidingMesh();
	void cleanGuidingMesh();
	void fixPointNormals();
	void orientationAwarePCA();
};
