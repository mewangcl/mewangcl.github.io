#pragma once

#include <math.h>
#include "POT_PointSet.h"

#define LEAF_MAX 20

class POT_KdTree
{
public:
	int nodeN;
	int* split_index;
	POT_PointSet* ps;
	int* index_table;
	float* middle;
	char* axis;
	int listN;
	int *list;
	long idum;
public:
	POT_KdTree(POT_PointSet* ps);
	~POT_KdTree(void);
	void constructNodes();
	void createIndexTable(int index, int s, int e);
	void sort(int s, int e, char a, int mid);
	void collectPointIndexInSphere(int* &l, int &N, float c[3], float r);
	void collectPointIndexInSphere(float c[3], float r, int index, int s, int e);
	float getLeafSize();
	void collectLeafSize(double &sizeS, int index, int s, int e);

	//From Numerical Recipes in C
	#define IA 16807
	#define IM 2147483647
	#define AM (1.0/IM)
	#define IQ 127773
	#define IR 2836
	#define MASK 123459876

	double ran0(long *idum)
	{
		long k;
		double ans;

		*idum ^= MASK;
		k=(*idum)/IQ;
		*idum=IA*(*idum-k*IQ)-IR*k;
		if (*idum < 0) *idum += IM;
		ans=AM*(*idum);
		*idum ^= MASK;
		return ans;
	}
	#undef IA
	#undef IM
	#undef AM
	#undef IQ
	#undef IR
	#undef MASK
};
