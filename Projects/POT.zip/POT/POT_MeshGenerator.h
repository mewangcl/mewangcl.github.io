#pragma once
#include "POT_KdTree.h"
#include "POT_Mesh.h"

class POT_MeshGenerator
{
public:
	POT_Mesh* m_mesh;
	int (*m_tris)[3];
	int m_triN;

public:
	POT_MeshGenerator(void);
	~POT_MeshGenerator(void);

	void createTriangles(POT_PointSet* bs);
	void createMesh(POT_PointSet* vs);
	void cleanBadTriangles();
	bool intersectionOf3Balls(float p1[3], float p2[3],
                            float c1[3], float c2[3], float c3[3],
                            float r1, float r2, float r3);
	bool sortOneRings(bool* decideT, int* list, int N, int current, int* visitID);
	bool getBestOneRing(int* &blist, int &blistN, float& error, bool* decideT,
		bool* validT, int* list, int N, int current, int* visitID);
	float measureOneRingError(int* list, int N, int current);
	bool removeNonManifoldV(bool* decideT);
	int* getValidBallTable(int baN);
	int removeTempFile();

	inline void upheap(float *a, int N, int k, int *p, int *q)
	{
		int v;
		v = p[k];
		while(k > 1 && a[p[k/2]] >= a[v])
		{
			p[k] = p[k/2]; q[p[k/2]] = k; k = k/2;
		}
		p[k] = v; q[v] = k;
	}
  
	inline void downheap(float *a, int N, int k, int *p, int *q)
	{
		int j, v;
		v = p[k];
		while(k <= N/2)
		{
			j = k+k;
			if(j < N && a[p[j]] > a[p[j+1]]) j++;
			if(a[v] <= a[p[j]]) break;
			p[k] = p[j]; q[p[j]] = k; k = j;
		}
		p[k] = v; q[v] = k;
	}

};
