#ifndef _CCL_QTHICKENINGPATCH
#define _CCL_QTHICKENINGPATCH

class QMeshPatch;
class QMeshNode;
class PQP_Model;

struct ThickeningGridNode{
	bool bInsideSolid;				// Flag to specify if it is inside the thickened solid
	bool bClosestPntOnBnd;			// Flag to specify if its closest point is on the boundary of patch	
	bool bFieldValueDefined;		// Flag to specify if the field value has been defined
	float signedDist;				// the signed distance to the surface patch
};

struct ThickeningGridEdge{
	int index;
	double interPntAlpha;	// float vn[3];	
	bool bCrossOffsetSurf;
	ThickeningGridEdge* next;
};

struct ThickeningGridCell{
	int k;
	QMeshNode *nodePtr;
	bool bBoundaryCell;
	ThickeningGridCell* next;
};

class ThickeningMeshPatch
{
public:
	ThickeningMeshPatch(void);
	virtual ~ThickeningMeshPatch(void);

    //	The implementation of the thickening algorithm is based on:
    //		"Thickening freeform surfaces for solid fabrication", C.C.L. Wang and Y. Chen,
    //		Rapid Prototyping Journal, vol.19, no.6, pp.395-406, November 2013.
	void DoPatchThickening(QMeshPatch *mesh, double offset, int res);
    
    //	The implementation of the minimal area hole triangulation is based on the section 6.2 of:
    //		"Filling gaps in the boundary of a polyhedron", G. Barequet and M. Sharir,
    //		Computer Aided Geometric Design, vol.12, pp.207-229, 1995.
    void DoHoleTriangulation(QMeshPatch *mesh);

private:
	int m_res;
	double m_origin[3];
	double m_gridWidth, m_offset;
	ThickeningGridNode *m_gridNodesArray;
	ThickeningGridEdge **m_gridEdgeArray[3];
	ThickeningGridCell **m_gridCellArray;

	int m_trglFaceNum;
	QMeshFace** m_faceArray;

private:	// member functions
	//------------------------------------------------------------------------------------------
	//	The functions for initialization
	bool _isTrglMeshSurface(QMeshPatch *mesh);
	bool _isOpenMeshSurface(QMeshPatch *mesh);
	void _compBndBoxAndUpdateRes(QMeshPatch *mesh, int res, double offset);
	PQP_Model* _pqpInitialization(QMeshPatch *mesh);

	//------------------------------------------------------------------------------------------
	//	The functions for grid-node generation in a top-down manner
	void _fieldValueGeneration(PQP_Model *pqpModel, int iSX, int iSY, int iSZ, int iEX, int iEY, int iEZ);
	bool _isInsideSolid(double signedDist, bool bIsClosestPntOnBnd);
	bool _isGridNodeCandidate(double signedDist, bool bIsClosestPntOnBnd);

	//------------------------------------------------------------------------------------------
	//	The functions for cell construction and face generation
	void _constructionOfGridEdges(PQP_Model *pqpModel, bool bAccurate);
	void _constructionOfGridCells(QMeshPatch *mesh);
	double _searchAccurateBndPntOnEdge(PQP_Model *pqpModel, double sp[], bool spInside, double ep[], bool epInside, int nRefinementTimes);
	//------------------------------------------------------------------------------------------
	void _dualContouringBasedFaceGeneration(QMeshPatch *mesh, PQP_Model *pqpModel, bool bInverseOrientation = false);
	void _createMeshFaceByVertices(int nodeNum, QMeshNode *nodeArray[], QMeshPatch *mesh);

	//------------------------------------------------------------------------------------------
	//	The functions for position adjustment inside a grid cell
	void _shapeOptimization(QMeshPatch *mesh, int nIterationSteps, double blendingFactor);
	void _compPositionByHermiteData(int ii, int jj, int kk, double origin[], double gwidth,
		int pntNum, double sx[], double sy[], double sz[], double nx[], double ny[], double nz[], double pp[]);

	//------------------------------------------------------------------------------------------
	//	The functions for boundary cell construction in a top-down manner
	void _constructionOfBndGridCells(QMeshPatch *mesh);
	void _bndGridCellGeneration(QMeshPatch *mesh, GLKObList *bndEdgeList, int iSX, int iSY, int iSZ, int iEX, int iEY, int iEZ);
	bool _isBndBoxHoldingPnt(double bndBox[]/*(minX,minY,minZ,maxX,maxY,maxZ*/, double pnt[]);
	bool _isBndBoxLineSegIntersect(double bndBox[]/*(minX,minY,minZ,maxX,maxY,maxZ*/, double sp[], double ep[]);
	void _projectPntOntoEdge(double pp[], double sp[], double ep[]);
	void _compBndBoxLineSegIntersect(double bndBox[]/*(minX,minY,minZ,maxX,maxY,maxZ*/, double sp[], double ep[]);
	QMeshNode* _findSharedVertex(QMeshEdge *edge1, QMeshEdge *edge2);
	//------------------------------------------------------------------------------------------
	void _splittingBoundaryEdgesOnExistingPatch(QMeshPatch *mesh, GLKObList *removedFaceList, GLKObList *removedEdgeList);
	void _minimalAreaHoleTriangulation(GLKObList *nodeList, QMeshPatch *mesh, int id);
	double _areaFunction(QMeshNode *node1, QMeshNode *node2, QMeshNode *node3);
	void _trackTriangles(int i, int k, int *O, int num, QMeshNode **nodeArray, QMeshPatch *mesh, int id);
	void _constructTriangle(QMeshNode *node1, QMeshNode *node2, QMeshNode *node3, QMeshPatch *mesh, int id);

	//------------------------------------------------------------------------------------------
	//	The functions for post processing
	void _quadMeshToTrglMesh(QMeshPatch *mesh);
	void _refillMeshTopology(QMeshPatch *mesh);
	//------------------------------------------------------------------------------------------
	void _nodeOpeningForHoleTopologyFiltering(QMeshPatch *mesh);
	void _singularRemovalForHoleTopologyFiltering(QMeshPatch *mesh);
	void _holeTriangulation(QMeshPatch *mesh);
	void _fillMeshTopology(QMeshPatch *mesh);
	//------------------------------------------------------------------------------------------
	void _faceRegionIDPropagate(QMeshFace *seedFace, QMeshNode *aroundNode, int id);
	bool _removeRegionByFaceFlag(QMeshPatch *_mesh, int whichFlag);

	//------------------------------------------------------------------------------------------
	//	The service functions
	double _distanceToPatch(PQP_Model *pqpModel, double queryPnt[], double closestPnt[], bool &bIsClosestPntOnBnd);
	double _distanceToPatch(PQP_Model *pqpModel, int i, int j, int k, double closestPnt[], bool &bIsClosestPntOnBnd);
	//------------------------------------------------------------------------------------------
	void _mallocGridNodeArray();
	void _freeGridNodeArray();
	ThickeningGridNode* _getGridNode(int i, int j, int k);
	//------------------------------------------------------------------------------------------
	void _mallocBoolArray(bool*** &_array, int size);
	void _freeBoolArray(bool*** &_array, int size);
	//------------------------------------------------------------------------------------------
	void _mallocGridEdgeArray();
	void _freeGridEdgeArray();
	void _addHeadGridEdge(ThickeningGridEdge *edge, short nAxis, int i, int j);
	ThickeningGridEdge* _getGridEdge(short nAxis, int i, int j, int index);
	//------------------------------------------------------------------------------------------
	void _mallocGridCellArray();
	void _freeGridCellArray();
	void _addHeadGridCell(ThickeningGridCell *cell, int i, int j);
	ThickeningGridCell* _getGridCell(int i, int j, int k);
};

#endif
