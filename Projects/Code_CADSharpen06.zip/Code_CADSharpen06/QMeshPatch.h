// QMeshPatch.h: interface for the QMeshPatch class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _CW_QMESHPATCH
#define _CW_QMESHPATCH

#include "../GLKLib/GLKObList.h"

class QMeshFace;
class QMeshEdge;
class QMeshNode;

class QMeshPatch : public GLKObject  
{
public:
	QMeshPatch();
	virtual ~QMeshPatch();

public:
	void ClearAll();

	bool GetAttribFlag( const int whichBit );
	void SetAttribFlag( const int whichBit, const bool toBe = true );

	int GetIndexNo();		//from 1 to n
	void SetIndexNo( const int _index = 1 );

	int GetFaceNumber();
	QMeshFace* GetFaceRecordPtr(int No);	//from 1 to n
    GLKObList& GetFaceList();

    int GetEdgeNumber();
	QMeshEdge* GetEdgeRecordPtr(int No);	//from 1 to n
    GLKObList& GetEdgeList();

    int GetNodeNumber();
	QMeshNode* GetNodeRecordPtr(int No);	//from 1 to n
    GLKObList& GetNodeList();

	void SetMaterial(bool bDir, int material);
	int GetMaterial(bool bDir);

	bool inputOBJFile(char* filename);
	bool inputMFile(char* filename);
	bool inputOFFFile(char* filename);

	void outputOBJFile(char* filename);
	void outputTrglOBJFile(char* filename);

private:
	int indexno;			// start from 1 to n  

	bool flags[8];			// bit 0 -- TRUE for 2D pattern have been computed
							//			FALSE for 2D pattern have NOT been computed yet

	int m_materialPositiveDir,m_materialNegativeDir;

	GLKObList faceList;		// a list of mesh's faces (QMeshFace)
	GLKObList edgeList;		// a list of mesh's edges (QMeshEdge)
	GLKObList nodeList;		// a list of mesh's nodes (QMeshNode)
};

#endif
