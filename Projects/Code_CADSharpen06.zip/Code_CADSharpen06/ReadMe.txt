
The code in -- class QSharpener4 -- is an implementation of our algorithm developed in the following paper.

- Charlie C.L. Wang, "Incremental reconstruction of sharp edges on mesh surfaces", Computer-Aided Design, vol.38, no.6, pp.689-702, 2006.
