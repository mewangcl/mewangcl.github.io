// QSharpener4.h: interface for the QSharpener4 class.
//		(This is the implementation for the CADSharpen paper)
//
//////////////////////////////////////////////////////////////////////

#ifndef _QSHARPENER_4_0
#define _QSHARPENER_4_0

class QSharpener4  
{
public:
	QSharpener4();
	virtual ~QSharpener4();
	
	void TriangularMeshSharpen(GLKObList* meshList);

private:
	void _prepareSubRegions(GLKObList* meshList, double boxSize);
	void _clearSubRegions();
	//--------------------------------------------------------------------------
	void _thinningSharpFeatureRegion(GLKObList* meshList);
	void _findErosionNodeList(GLKObList* meshList, GLKObList* nodeList);
	bool _detectAbilityOfNodeRemovementInThinning(QMeshNode *detectedNode);
	void _nodeStarCenter(QMeshNode *node, double pp[]);
	void _positioningNode(QMeshNode *node, double criterion);
	void _determineStaticTriangleSet(QMeshNode *node, double supportSize, bool bSamePatch);
	//--------------------------------------------------------------------------
	void _openLocalLoop(GLKObList* meshList);
	double _faceInnerAngle(QMeshFace *face, int nIndex); // the angle is returned in rotation
	//--------------------------------------------------------------------------
	void _skeletonSharpening(GLKObList* meshList);
	int _numberOfSharpEdgesAroundNode(QMeshNode *node);
	void _nodeSharpNodeCenter(QMeshNode *node, double pp[]);
	//--------------------------------------------------------------------------
	void _positioningJointNode(QMeshNode *node, double criterion);
	bool _isNodeInFace(QMeshNode *node, QMeshFace *face);
	void _positioningSkeletonNode(QMeshNode *node, double criterion);
	void _normalPropagation(QMeshNode *node, double normal[], QMeshNode *exceptLinkNode);
	int _numberOfSharpNodesInFace(QMeshFace *face);
	//--------------------------------------------------------------------------
	void _positioningAllBoundarySharpVertex(GLKObList* meshList);

	int m_xNum,m_yNum,m_zNum;
	double m_xmin,m_ymin,m_zmin;
	double m_boxSize;
	GLKObList ****m_boxArray;
};

#endif
