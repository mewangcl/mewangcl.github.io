// QMeshFace.cpp: implementation of the QMeshFace class.
//
//////////////////////////////////////////////////////////////////////

#include <math.h>

#include "..\GLKLib\GLKGeometry.h"

#include "QMeshFace.h"
#include "QMeshEdge.h"
#include "QMeshNode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QMeshFace::QMeshFace()
{
	nSplittedNode=-1;
	for(int i=0;i<8;i++) flags[i]=false;
	indexno=0;	edgeNum=0;
	meshSurface=NULL;

	rgb[0]=0.0f;	rgb[1]=0.8f;	rgb[2]=0.8f;

	attachedList.RemoveAll();	

	m_nIdentifiedPatchIndex=-1;
}

QMeshFace::~QMeshFace()
{

}

//////////////////////////////////////////////////////////////////////
// Implementation
//////////////////////////////////////////////////////////////////////

bool QMeshFace::GetAttribFlag( const int whichBit )
{
	return flags[whichBit];
}

void QMeshFace::SetAttribFlag( const int whichBit, const bool toBe )
{
	flags[whichBit]=toBe;
}

int QMeshFace::GetIndexNo()		//from 1 to n
{
	return indexno;
}

void QMeshFace::SetIndexNo( const int _index )
{
	indexno=_index;
}

int QMeshFace::GetEdgeNum()
{
	return edgeNum;
}

void QMeshFace::SetEdgeNum(int num)
{
	edgeNum=num;
}

bool QMeshFace::IsNormalDirection( const int whichEdge )
{
	return edgeDir[whichEdge];
}

void QMeshFace::SetDirectionFlag( const int whichEdge, const bool toBe )
{
	edgeDir[whichEdge]=toBe;
}

QMeshEdge* QMeshFace::GetEdgeRecordPtr( const int whichEdge )
{
	return edges[whichEdge];
}

void QMeshFace::SetEdgeRecordPtr( const int whichEdge, QMeshEdge * _edge )
{
	edges[whichEdge]=_edge;
}

void QMeshFace::GetNodePos( const int whichNode, double &xx, double &yy, double &zz)
{
	GetNodeRecordPtr(whichNode)->GetCoord3D(xx,yy,zz);
}

QMeshNode* QMeshFace::GetNodeRecordPtr( const int whichNode )
{
	if (IsNormalDirection(whichNode))
	    return edges[whichNode]->GetStartPoint();
	else
	    return edges[whichNode]->GetEndPoint();
	return NULL;
}

void QMeshFace::SetColor(float r, float g, float b)
{
	rgb[0]=r;	rgb[1]=g;	rgb[2]=b;
}

void QMeshFace::GetColor(float &r, float &g, float &b)
{
	r=rgb[0];	g=rgb[1];	b=rgb[2];
}

void QMeshFace::SetPlaneEquation( double A, double B, double C, double D )
{
	abcd[0]=A;	abcd[1]=B;	abcd[2]=C;	abcd[3]=D;
}

void QMeshFace::GetPlaneEquation( double & A, double & B, double & C, double & D )
{
	A=abcd[0];	B=abcd[1];	C=abcd[2];	D=abcd[3];
}

double QMeshFace::CalArea()
{
	double cp[3],p1[3],p2[3];
	double area;
	double x1,y1,z1,x2,y2,z2;
	double ii,jj,kk;
	int i;

	CalCenterPos(cp[0],cp[1],cp[2]);	area=0.0;

	GetNodePos(0,p1[0],p1[1],p1[2]);
	for(i=0;i<edgeNum;i++) {
		GetNodePos(((i+1)%edgeNum),p2[0],p2[1],p2[2]);

		x1=p1[0]-cp[0];	y1=p1[1]-cp[1];	z1=p1[2]-cp[2];
		x2=p2[0]-cp[0];	y2=p2[1]-cp[1];	z2=p2[2]-cp[2];

		ii=y1*z2-z1*y2;
		jj=x2*z1-x1*z2;
		kk=x1*y2-x2*y1;

		area+=sqrt(ii*ii+jj*jj+kk*kk)/2.0;

		p1[0]=p2[0]; p1[1]=p2[1]; p1[2]=p2[2];
	}

	m_area=area;

	return area;
}

void QMeshFace::CalBoundingBox(double &xmin, double &ymin, double &zmin,
							   double &xmax, double &ymax, double &zmax)
{
	int pntNum=GetEdgeNum();
	double pp[3];

	GetNodePos(0,xmin,ymin,zmin);
	GetNodePos(0,xmax,ymax,zmax);
	for(int i=1;i<pntNum;i++) {
		GetNodePos(i,pp[0],pp[1],pp[2]);
		if (pp[0]<xmin) xmin=pp[0];
		if (pp[0]>xmax) xmax=pp[0];
		if (pp[1]<ymin) ymin=pp[1];
		if (pp[1]>ymax) ymax=pp[1];
		if (pp[2]<zmin) zmin=pp[2];
		if (pp[2]>zmax) zmax=pp[2];
	}
}

void QMeshFace::CalCenterPos(double &xx, double &yy, double &zz)
{
	int pntNum=GetEdgeNum();
	double pp[3];

	xx=0.0;	yy=0.0;	zz=0.0;
	for(int i=0;i<pntNum;i++) {
		GetNodePos(i,pp[0],pp[1],pp[2]);
		xx=xx+pp[0];	yy=yy+pp[1];	zz=zz+pp[2];
	}
	xx=xx/(double)pntNum;	yy=yy/(double)pntNum;	zz=zz/(double)pntNum;	

	centerPos[0]=xx;	centerPos[1]=yy;	centerPos[2]=zz;
}

void QMeshFace::SetNormal(double nx, double ny, double nz)
{
	abcd[0]=nx;		abcd[1]=ny;		abcd[2]=nz;
}

void QMeshFace::CalPlaneEquation( )
{
	GLKGeometry geo;
	double** p;
	int i,nodeNum;
	double aa,bb,cc,dd;

	nodeNum=edgeNum;
	p=(double**)new long[nodeNum];
	for(i=0;i<nodeNum;i++) p[i]=new double[3];

	for(i=0;i<nodeNum;i++) GetNodePos(i,p[i][0],p[i][1],p[i][2]);

	for(i=0;i<4;i++) abcd[i]=0.0;
	for(i=0;i<nodeNum;i++) {
		geo.CalPlaneEquation(p[(i-1+nodeNum)%nodeNum],p[i],p[(i+1)%nodeNum],aa,bb,cc,dd);
		abcd[0]+=aa;		abcd[1]+=bb;		abcd[2]+=cc;		abcd[3]+=dd;
	}
	for(i=0;i<4;i++) abcd[i]=abcd[i]/(double)nodeNum;

	for(i=0;i<nodeNum;i++) delete [](double*)(p[i]);
	delete [](double**)p;
}

void QMeshFace::SetMeshPatchPtr(QMeshPatch* _mesh)
{
	meshSurface=_mesh;
}

QMeshPatch* QMeshFace::GetMeshPatchPtr()
{
	return meshSurface;
}