// QMeshEdge.h: interface for the QMeshEdge class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _CW_QMESHEDGE
#define _CW_QMESHEDGE

#include "../GLKLib/GLKObList.h"

class QMeshPatch;
class QMeshNode;
class QMeshFace;

class QMeshEdge : public GLKObject  
{
public:
	QMeshEdge();
	virtual ~QMeshEdge();

public:
	bool GetAttribFlag( const int whichBit );
	void SetAttribFlag( const int whichBit, const bool toBe = true );

	int GetIndexNo();		//from 1 to n
	void SetIndexNo( const int _index = 1 );

	bool IsBoundaryEdge();

	QMeshNode * GetStartPoint();
	void SetStartPoint( QMeshNode * _pStartPoint = NULL );

	QMeshNode * GetEndPoint();
	void SetEndPoint( QMeshNode * _pEndPoint = NULL );

	QMeshFace * GetLeftFace();
	void SetLeftFace( QMeshFace * _pLeftFace = NULL );

	QMeshFace * GetRightFace();
	void SetRightFace( QMeshFace * _pRightFace = NULL );

	void SetMeshPatchPtr(QMeshPatch* _mesh);
	QMeshPatch* GetMeshPatchPtr();

	void CalNormal(double normal[]);

	void SetSharpFactor(int factor);
	int GetSharpFactor();

	double CalLength();
	double GetLength() {return m_edgeLength;};

    GLKObList& GetAttachedList() {return attachedList;};

private:
	int indexno;
	bool flags[8];
				// bit 0 -- TRUE for boundary edge
				// bit 1 -- TRUE for sharp-feature edge
				// bit 2 -- TRUE for sharp-feature-region edge
				// bit 4 -- TRUE for the edge needs to be splitted	
				// bit 6 -- TRUE for the edge needs to be cut/separated	
				// bit 7 -- temp use

                                    //*** Edge vector definition ***
                                    //                             *
		                            //         end point           *
	QMeshNode * pStartPoint;		//           /|\               *
	QMeshNode * pEndPoint;			//            |                *
                                    //  left face | right face     *
	QMeshFace * pLeftFace;			//            |                *
	QMeshFace * pRightFace;			//            |                *
		                            //       start point           *
		                            //                             *
		                            //******************************

	QMeshPatch *meshSurface;		// QMesh contain this edge

	GLKObList attachedList;			// a list of attached object
	double m_edgeLength;

	int m_sharpFactor;
};

#endif
