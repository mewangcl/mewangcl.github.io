// QSharpener4.cpp: implementation of the QSharpener4 class.
//
//////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <math.h>

#include "..\GLKLib\GLKObList.h"
#include "..\GLKLib\GLKGeometry.h"
#include "..\GLKLib\GLKMatrixLib.h"
#include "..\GLKLib\GLKHeap.h"

#include "..\QMeshLib\QMeshPatch.h"
#include "..\QMeshLib\QMeshFace.h"
#include "..\QMeshLib\QMeshEdge.h"
#include "..\QMeshLib\QMeshNode.h"

#include "QTopologyOperator.h"
#include "QGeometryComputing.h"
#include "QSmoothing.h"

#include "QSharpener4.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QSharpener4::QSharpener4()
{
	m_xNum=0;	m_yNum=0;	m_zNum=0;
}

QSharpener4::~QSharpener4()
{
	_clearSubRegions();
}

//////////////////////////////////////////////////////////////////////
// Implementation
//////////////////////////////////////////////////////////////////////

void QSharpener4::TriangularMeshSharpen(GLKObList* meshList)
{
	int k=0;
	bool bWithSharpFeature;
	GLKPOSITION Pos;
	GLKPOSITION PosNode;
	double boxSize, angleProj=0.75;
	boxSize=QGeometryComputing::computeAverageEdgeLength(meshList);

	//-----------------------------------------------------------------------
	//	Check whether sharp feature has been detected
	bWithSharpFeature=false;
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			if (node->GetAttribFlag(5)) {bWithSharpFeature=true;	break;}
		}
		if (bWithSharpFeature) break;
	}
	//-----------------------------------------------------------------------
	//	Detect sharp features
	if (!bWithSharpFeature) {
		boxSize=boxSize*0.75;
		QGeometryComputing::detectSharpFeaturesByUSSOD(meshList,boxSize,angleProj); 
												// "*0.75" , "angleProj=0.75"	- for Example01.mpj
												// "*1.5" , "angleProj=0.75"	- for Example02.mpj
		bWithSharpFeature=true;
		return;
	}

	//-----------------------------------------------------------------------
	//	Preparation
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext (Pos));
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			node->SetAttribFlag(7,false);
		}
	}

	_prepareSubRegions(meshList,boxSize);//*2.0);

	_thinningSharpFeatureRegion(meshList);
	_openLocalLoop(meshList);
	_skeletonSharpening(meshList);
	_positioningAllBoundarySharpVertex(meshList);

//	QSmoothing::FeaturePreservedMeshSmoothing(meshList,1.0,0.25,false,30,true);
//	QGeometryComputing::sharpEdgeDetection(meshList,angleProj);
}

void QSharpener4::_positioningAllBoundarySharpVertex(GLKObList* meshList)
{
	GLKPOSITION PosMesh;
	GLKPOSITION PosNode;
	GLKPOSITION PosFace;
	double criterion=1.0/(QGeometryComputing::computeAverageEdgeLength(meshList)*4.0);
	double pp[3];

	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			if ((node->GetAttribFlag(0)) && (node->GetAttribFlag(5))) {
				_nodeStarCenter(node,pp);
				node->SetCoord3D(pp[0],pp[1],pp[2]);

				_determineStaticTriangleSet(node,m_boxSize,false);
				_positioningNode(node,criterion);
			}
		}
	}

	//-------------------------------------------------------------------
	//	update normals
	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
		for(PosFace=mesh->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			node->CalNormal();
		}
	}
}

void QSharpener4::_skeletonSharpening(GLKObList* meshList)
{
/*	GLKPOSITION Pos;
	GLKPOSITION PosNode;
	GLKPOSITION PosEdge;
	GLKPOSITION PosFace;
	double pp[3],lp[3];
	double criterion=1.0/(QGeometryComputing::computeAverageEdgeLength(meshList)*4.0);
	GLKGeometry geo;

	//--------------------------------------------------------------------------------
	//	Step 1: position the branch nodes on skeleton
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));

		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			if (node->GetAttribFlag(0)) continue;
			if (!(node->GetAttribFlag(5))) continue;

			if (_numberOfSharpEdgesAroundNode(node)==2) {
				_nodeSharpNodeCenter(node,pp);
//				_nodeStarCenter(node,pp);
				node->SetCoord3D(pp[0],pp[1],pp[2]);

				double supportSize=m_boxSize*0.5;
				for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
					QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
					if (edge->GetStartPoint()==node)
						edge->GetEndPoint()->GetCoord3D(lp[0],lp[1],lp[2]);
					else
						edge->GetStartPoint()->GetCoord3D(lp[0],lp[1],lp[2]);
					double ll=geo.Distance_to_Point(lp,pp);
					if (ll>supportSize) supportSize=ll;
				}
				_determineStaticTriangleSet(node,supportSize,true);
				_positioningNode(node,criterion);
			}
		}
	}
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));

		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			if (node->GetAttribFlag(0)) continue;
			if (!(node->GetAttribFlag(5))) continue;

			if (_numberOfSharpEdgesAroundNode(node)==2) {
				node->SetAttribFlag(5,false);
				//-------------------------------------------------------------------
				//	update face normals
				for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
					QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
					face->CalPlaneEquation();
				}
			}
		}
	}

	//--------------------------------------------------------------------------------
	//	Step 2: position the joint nodes on skeleton
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));

		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			if (node->GetAttribFlag(0)) continue;
			if (!(node->GetAttribFlag(5))) continue;

			if (_numberOfSharpEdgesAroundNode(node)!=2) {
				_nodeSharpNodeCenter(node,pp);
				//_nodeStarCenter(node,pp);
				node->SetCoord3D(pp[0],pp[1],pp[2]);

				double supportSize=m_boxSize*0.5;
				for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
					QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
					if (edge->GetStartPoint()==node)
						edge->GetEndPoint()->GetCoord3D(lp[0],lp[1],lp[2]);
					else
						edge->GetStartPoint()->GetCoord3D(lp[0],lp[1],lp[2]);
					double ll=geo.Distance_to_Point(lp,pp);
					if (ll>supportSize) supportSize=ll;
				}
				_determineStaticTriangleSet(node,supportSize,true);
				_positioningNode(node,criterion);
				node->SetAttribFlag(5,false);
				//-------------------------------------------------------------------
				//	update face normals
				for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
					QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
					face->CalPlaneEquation();
				}
			}
		}
	}

	//--------------------------------------------------------------------------------
	//	Step 3: update normals
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=mesh->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			node->CalNormal();
		}
	}
*/

	GLKPOSITION Pos;
	GLKPOSITION PosNode;
	GLKPOSITION PosFace;
	double pp[3];
	double criterion=1.0/(QGeometryComputing::computeAverageEdgeLength(meshList)*4.0);

	//--------------------------------------------------------------------------------
	//	Step 2: position the tail nodes on skeleton
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));

		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			if (node->GetAttribFlag(0)) continue;
			if (!(node->GetAttribFlag(5))) continue;

			if (_numberOfSharpEdgesAroundNode(node)==1) {
				_nodeStarCenter(node,pp);
				node->SetCoord3D(pp[0],pp[1],pp[2]);
				_positioningSkeletonNode(node,criterion);
			}
		}
	}
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=mesh->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			node->CalNormal();
		}
	}

	//--------------------------------------------------------------------------------
	//	Step 1: position the branch nodes on skeleton
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));

		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			if (node->GetAttribFlag(0)) continue;
			if (!(node->GetAttribFlag(5))) continue;

			if (_numberOfSharpEdgesAroundNode(node)==2) {
				_nodeSharpNodeCenter(node,pp);
				node->SetCoord3D(pp[0],pp[1],pp[2]);
				_positioningSkeletonNode(node,criterion);
			}
		}
	}
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=mesh->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			node->CalNormal();
		}
	}

	//--------------------------------------------------------------------------------
	//	Step 2: position the joint nodes on skeleton
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));

		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			if (node->GetAttribFlag(0)) continue;
			if (!(node->GetAttribFlag(5))) continue;

			if (_numberOfSharpEdgesAroundNode(node)>2) {
				_nodeSharpNodeCenter(node,pp);
				node->SetCoord3D(pp[0],pp[1],pp[2]);
				_positioningJointNode(node,criterion);
			}
		}
	}

	//--------------------------------------------------------------------------------
	//	Step 3: update normals
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=mesh->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			node->CalNormal();
		}
	}
}

void QSharpener4::_nodeSharpNodeCenter(QMeshNode *node, double pp[])
{
	GLKPOSITION PosEdge;
	QMeshNode *linkedNode;
	double xx,yy,zz;

	int num=_numberOfSharpEdgesAroundNode(node);
	if (num==1) {node->GetCoord3D(pp[0],pp[1],pp[2]);return;}
	pp[0]=0.0;	pp[1]=0.0;	pp[2]=0.0;
	for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
		QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
		if (!(edge->GetAttribFlag(1))) continue;
		if (edge->GetStartPoint()==node)
			linkedNode=edge->GetEndPoint();
		else
			linkedNode=edge->GetStartPoint();
		linkedNode->GetCoord3D(xx,yy,zz);
		pp[0]+=xx;	pp[1]+=yy;	pp[2]+=zz;
	}
	pp[0]=pp[0]/(double)num;
	pp[1]=pp[1]/(double)num;
	pp[2]=pp[2]/(double)num;
}

int QSharpener4::_numberOfSharpEdgesAroundNode(QMeshNode *node)
{
	int sharpEdgeNum;
	GLKPOSITION Pos;

	sharpEdgeNum=0;
	for(Pos=node->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
		QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(Pos));
		if (edge->GetAttribFlag(1)) sharpEdgeNum++;
	}

	return sharpEdgeNum;
}

void QSharpener4::_prepareSubRegions(GLKObList* meshList, double boxSize)
{
	int i,j,k,i1,i2,j1,j2,k1,k2;
	double xmin,ymin,zmin,xmax,ymax,zmax;
	double x1,y1,z1,x2,y2,z2;
	GLKPOSITION Pos;
	GLKPOSITION PosFace;

	_clearSubRegions();

	//----------------------------------------------------------------------------------
	//	Step 1: malloc the memory and prepare the boxes
	m_boxSize=boxSize;
	QGeometryComputing::computeBoundingBox(meshList,xmin,ymin,zmin,xmax,ymax,zmax);
	m_xmin=xmin;	m_ymin=ymin;	m_zmin=zmin;
	m_xNum=(int)((xmax-xmin)/m_boxSize)+2;
	m_yNum=(int)((ymax-ymin)/m_boxSize)+2;
	m_zNum=(int)((zmax-zmin)/m_boxSize)+2;
	m_boxArray=(GLKObList ****)new long[m_xNum];
	for(i=0;i<m_xNum;i++) {
		m_boxArray[i]=(GLKObList ***)new long[m_yNum];
		for(j=0;j<m_yNum;j++) {
			m_boxArray[i][j]=(GLKObList **)new long[m_zNum];
			for(k=0;k<m_zNum;k++) {
				m_boxArray[i][j][k]=new GLKObList;
				m_boxArray[i][j][k]->RemoveAll();
			}
		}
	}

	//----------------------------------------------------------------------------------
	//	Step 2: insert faces into boxes
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->CalBoundingBox(x1,y1,z1,x2,y2,z2);
			i1=(int)((x1-xmin)/m_boxSize);
			j1=(int)((y1-ymin)/m_boxSize);
			k1=(int)((z1-zmin)/m_boxSize);
			i2=(int)((x2-xmin)/m_boxSize)+1;
			j2=(int)((y2-ymin)/m_boxSize)+1;
			k2=(int)((z2-zmin)/m_boxSize)+1;
			for(i=i1;i<=i2;i++)
				for(j=j1;j<=j2;j++)
					for(k=k1;k<=k2;k++)
						m_boxArray[i][j][k]->AddTail(face);
		}
	}
}

void QSharpener4::_thinningSharpFeatureRegion(GLKObList* meshList)
{
	GLKPOSITION Pos;
	GLKPOSITION PosEdge;
	GLKPOSITION PosFace;
	GLKPOSITION PosNode;
	GLKObList nodeList;
	bool bFlag;		double pp[3];
	double criterion=1.0/(QGeometryComputing::computeAverageEdgeLength(meshList)*4.0);

	do{
		bFlag=false;

		_findErosionNodeList(meshList,&nodeList);
		if (nodeList.IsEmpty()) break;

		//-------------------------------------------------------------------
		//	thinning operation
		for(Pos=nodeList.GetHeadPosition();Pos!=NULL;) {
			QMeshNode *node=(QMeshNode *)(nodeList.GetNext(Pos));
			if (_detectAbilityOfNodeRemovementInThinning(node)) 
			{
				//-------------------------------------------------------------------
				//	Positioning the erosed node
				_nodeStarCenter(node,pp);
				node->SetCoord3D(pp[0],pp[1],pp[2]);
				_determineStaticTriangleSet(node,m_boxSize*0.5,true);
				_positioningNode(node,criterion);
				node->SetAttribFlag(5,false);
				bFlag=true;

				//-------------------------------------------------------------------
				//	update face normals
				for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
					QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
					face->CalPlaneEquation();
				}
			}
		}
	}while(bFlag);

	//-------------------------------------------------------------------
	//	update edge flag of sharpness
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosEdge=mesh->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
			QMeshEdge *edge=(QMeshEdge *)(meshList->GetNext(PosEdge));
			if ((edge->GetStartPoint()->GetAttribFlag(5))
				&& (edge->GetEndPoint()->GetAttribFlag(5)))
				edge->SetAttribFlag(1,true);
			else
				edge->SetAttribFlag(1,false);
		}
	}

	//-------------------------------------------------------------------
	//	update vertex normals
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			node->CalNormal();
		}
	}
}

void QSharpener4::_determineStaticTriangleSet(QMeshNode *node, double supportSize, bool bSamePatch)
{
	double xx,yy,zz,range,ll,pp[3],p1[3],p2[3],p3[3];
	int gridNum,i,j,k,ii,jj,kk,num,n;
	GLKPOSITION PosFace;
	GLKGeometry geo;

	node->attachedList.RemoveAll();
	node->GetCoord3D(xx,yy,zz);

	range=supportSize;	num=0;
	while(node->attachedList.IsEmpty()) {
		//-------------------------------------------------------------------------
		//	determine the set of static triangle inside the support
		gridNum=(int)(range/m_boxSize)+1;

		node->GetCoord3D(pp[0],pp[1],pp[2]);
		i=(int)((pp[0]-m_xmin)/m_boxSize);
		j=(int)((pp[1]-m_ymin)/m_boxSize);
		k=(int)((pp[2]-m_zmin)/m_boxSize);

		for(ii=i-gridNum;ii<=i+gridNum;ii++) {
			if (ii<0) continue;
			if (ii>=m_xNum) continue;
			for(jj=j-gridNum;jj<=j+gridNum;jj++) {
				if (jj<0) continue;
				if (jj>=m_yNum) continue;
				for(kk=k-gridNum;kk<=k+gridNum;kk++) {
					if (kk<0) continue;
					if (kk>=m_zNum) continue;

					for(PosFace=m_boxArray[ii][jj][kk]->GetHeadPosition();PosFace!=NULL;) {
						QMeshFace *face=(QMeshFace*)(m_boxArray[ii][jj][kk]->GetNext(PosFace));
						if (bSamePatch && (face->GetMeshPatchPtr()!=node->GetMeshPatchPtr())) continue;

						int edgeNum=face->GetEdgeNum();	bool bFlag=false;
						for(n=0;n<edgeNum;n++) {
							if (face->GetNodeRecordPtr(n)->GetAttribFlag(5)) {
								bFlag=true;	break;
							}
						}
						if (bFlag) continue;

						for(n=0;n<=(edgeNum-3);n++) {
							face->GetNodePos(n,p1[0],p1[1],p1[2]);
							face->GetNodePos(n+1,p2[0],p2[1],p2[2]);
							face->GetNodePos(n+2,p3[0],p3[1],p3[2]);
							//ll=geo.Distance_to_Triangle(pp,p1,p2,p3);
							ll=geo.Distance_to_Triangle_Approx(pp,p1,p2,p3);
							if (ll<=range) {(node->attachedList).AddTail(face);break;}
						}
					}
				}
			}
		}

		range+=supportSize*0.1;			num++;
	}
}

void QSharpener4::_positioningSkeletonNode(QMeshNode *node, double criterion)
{
	GLKPOSITION PosEdge;
	GLKPOSITION PosFace;
	double **A,*X,*B,**UU,**UUT,**VV,**VVT,pp[3],qq[3],normal[3];
	int i,j;

	GLKMatrixLib::CreateMatrix(A,3,3);
	GLKMatrixLib::CreateMatrix(UU,3,3);
	GLKMatrixLib::CreateMatrix(VV,3,3);
	GLKMatrixLib::CreateMatrix(UUT,3,3);
	GLKMatrixLib::CreateMatrix(VVT,3,3);
	X=new double[3];	B=new double[3];

	for(i=0;i<3;i++) {
		B[i]=0.0;	X[i]=0.0;
		for(j=0;j<3;j++) A[i][j]=0.0;
	}

	node->GetCoord3D(pp[0],pp[1],pp[2]);

	//-----------------------------------------------------------------
	//	Set the equation system
	QMeshNode* linkedNode;	bool bFlag=false;
	for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
		QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
		if (edge->GetStartPoint()==node)
			linkedNode=edge->GetEndPoint();
		else
			linkedNode=edge->GetStartPoint();
		if (linkedNode->GetAttribFlag(5)) continue;

		linkedNode->GetCoord3D(qq[0],qq[1],qq[2]);
		_normalPropagation(linkedNode,normal,node);

		bFlag=true;

		//  For matrix A
		A[0][0]+=normal[0]*normal[0];
		A[0][1]+=normal[0]*normal[1];
		A[0][2]+=normal[0]*normal[2];
		A[1][1]+=normal[1]*normal[1];
		A[1][2]+=normal[1]*normal[2];
		A[2][2]+=normal[2]*normal[2];

		//  For vector B
		double dd=(qq[0]-pp[0])*normal[0]+(qq[1]-pp[1])*normal[1]+(qq[2]-pp[2])*normal[2];
		B[0]+=normal[0]*dd;
		B[1]+=normal[1]*dd;
		B[2]+=normal[2]*dd;
	}
	A[1][0]=A[0][1];	A[2][0]=A[0][2];	A[2][1]=A[1][2];

	if (bFlag) {
		//-----------------------------------------------------------------
		//	Singular Value Decomposition
		GLKMatrixLib::SingularValueDecomposition(A,3,3,UU,VVT);
		GLKMatrixLib::Transpose(UU,3,3,UUT);
		GLKMatrixLib::Transpose(VVT,3,3,VV);
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				if (i!=j) {
					A[i][j]=0.0;
				}
				else {
					if (A[i][j]<criterion)
						A[i][j]=0.0;
					else
						A[i][j]=1.0/A[i][j];
				}
			}
		}
		GLKMatrixLib::Mul(UUT,B,3,3,X);
		GLKMatrixLib::Mul(A,X,3,3,B);
		GLKMatrixLib::Mul(VV,B,3,3,X);

		//-----------------------------------------------------------------
		//	update node position
		double dist=X[0]*X[0]+X[1]*X[1]+X[2]*X[2];
		if (dist>(1.0/(4.0*criterion*criterion))) {X[0]=0.0;X[1]=0.0;X[2]=0.0;}
		pp[0]+=X[0];	pp[1]+=X[1];	pp[2]+=X[2];
		node->SetCoord3D(pp[0],pp[1],pp[2]);
		for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
		node->SetAttribFlag(7,true);
	}

	GLKMatrixLib::DeleteMatrix(A,3,3);  delete []X;  delete []B;
	GLKMatrixLib::DeleteMatrix(UU,3,3);
	GLKMatrixLib::DeleteMatrix(VV,3,3);
	GLKMatrixLib::DeleteMatrix(UUT,3,3);
	GLKMatrixLib::DeleteMatrix(VVT,3,3);
}

int QSharpener4::_numberOfSharpNodesInFace(QMeshFace *face)
{
	int i,edgeNum,sharpNodeNum;

	sharpNodeNum=0;
	edgeNum=face->GetEdgeNum();
	for(i=0;i<edgeNum;i++)
		if (face->GetNodeRecordPtr(i)->GetAttribFlag(5)) sharpNodeNum++;

	return sharpNodeNum;
}

void QSharpener4::_normalPropagation(QMeshNode *node, double normal[], QMeshNode *exceptLinkNode)
{
	double totalArea,area,aa,bb,cc,dd;
	GLKPOSITION PosFace;
	GLKPOSITION PosEdge;
	GLKGeometry geo;
	
	totalArea=0.0;	normal[0]=0.0;	normal[1]=0.0;	normal[2]=0.0;
	for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
		QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
		if (_numberOfSharpNodesInFace(face)>0) continue;
		face->GetPlaneEquation(aa,bb,cc,dd);
		area=face->CalArea();
		totalArea+=area;
		normal[0]+=aa*area;	normal[1]+=bb*area;	normal[2]+=cc*area;
	}
	if (totalArea>0.0) {
		normal[0]=normal[0]/totalArea;	
		normal[1]=normal[1]/totalArea;	
		normal[2]=normal[2]/totalArea;	
		geo.Normalize(normal);
	}
	else {
		QMeshNode *linkedNode;
		for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
			QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
			if (edge->GetStartPoint()==node)
				linkedNode=edge->GetEndPoint();
			else
				linkedNode=edge->GetStartPoint();
			if (linkedNode->GetAttribFlag(5)) continue;
			if (linkedNode==exceptLinkNode) continue;	// for preventing a closed loop recursion

			_normalPropagation(linkedNode,normal,node);
		}
	}
}

void QSharpener4::_positioningJointNode(QMeshNode *node, double criterion) 
{
	GLKPOSITION PosEdge;
	GLKPOSITION PosFace;
	double **A,*X,*B,**UU,**UUT,**VV,**VVT,pp[3],qq[3],normal[3],totalArea,area,aa,bb,cc,dd;
	int i,j;
	GLKGeometry geo;

	GLKMatrixLib::CreateMatrix(A,3,3);
	GLKMatrixLib::CreateMatrix(UU,3,3);
	GLKMatrixLib::CreateMatrix(VV,3,3);
	GLKMatrixLib::CreateMatrix(UUT,3,3);
	GLKMatrixLib::CreateMatrix(VVT,3,3);
	X=new double[3];	B=new double[3];

	for(i=0;i<3;i++) {
		B[i]=0.0;	X[i]=0.0;
		for(j=0;j<3;j++) A[i][j]=0.0;
	}

	node->GetCoord3D(pp[0],pp[1],pp[2]);

	//-----------------------------------------------------------------
	//	Set the equation system
	QMeshNode* linkedNode;	bool bFlag=false;
	for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
		QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
		if (edge->GetStartPoint()==node)
			linkedNode=edge->GetEndPoint();
		else
			linkedNode=edge->GetStartPoint();

		linkedNode->GetCoord3D(qq[0],qq[1],qq[2]);
		totalArea=0.0;	normal[0]=0.0;	normal[1]=0.0;	normal[2]=0.0;
		for(PosFace=linkedNode->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(linkedNode->GetFaceList().GetNext(PosFace));
			if (_isNodeInFace(node,face)) continue;
			face->GetPlaneEquation(aa,bb,cc,dd);
			area=face->CalArea();
			totalArea+=area;
			normal[0]+=aa*area;	normal[1]+=bb*area;	normal[2]+=cc*area;
		}
		if (totalArea>0.0) {
			normal[0]=normal[0]/totalArea;	
			normal[1]=normal[1]/totalArea;	
			normal[2]=normal[2]/totalArea;	
			geo.Normalize(normal);
		}

		bFlag=true;

		//  For matrix A
		A[0][0]+=normal[0]*normal[0];
		A[0][1]+=normal[0]*normal[1];
		A[0][2]+=normal[0]*normal[2];
		A[1][1]+=normal[1]*normal[1];
		A[1][2]+=normal[1]*normal[2];
		A[2][2]+=normal[2]*normal[2];

		//  For vector B
		double dd=(qq[0]-pp[0])*normal[0]+(qq[1]-pp[1])*normal[1]+(qq[2]-pp[2])*normal[2];
		B[0]+=normal[0]*dd;
		B[1]+=normal[1]*dd;
		B[2]+=normal[2]*dd;
	}
	A[1][0]=A[0][1];	A[2][0]=A[0][2];	A[2][1]=A[1][2];

	if (bFlag) {
		//-----------------------------------------------------------------
		//	Singular Value Decomposition
		GLKMatrixLib::SingularValueDecomposition(A,3,3,UU,VVT);
		GLKMatrixLib::Transpose(UU,3,3,UUT);
		GLKMatrixLib::Transpose(VVT,3,3,VV);
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				if (i!=j) {
					A[i][j]=0.0;
				}
				else {
					if (A[i][j]<criterion)
						A[i][j]=0.0;
					else
						A[i][j]=1.0/A[i][j];
				}
			}
		}
		GLKMatrixLib::Mul(UUT,B,3,3,X);
		GLKMatrixLib::Mul(A,X,3,3,B);
		GLKMatrixLib::Mul(VV,B,3,3,X);

		//-----------------------------------------------------------------
		//	update node position
		double dist=X[0]*X[0]+X[1]*X[1]+X[2]*X[2];
		if (dist>(1.0/(4.0*criterion*criterion))) {X[0]=0.0;X[1]=0.0;X[2]=0.0;}
		pp[0]+=X[0];	pp[1]+=X[1];	pp[2]+=X[2];
		node->SetCoord3D(pp[0],pp[1],pp[2]);
		for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
		node->SetAttribFlag(7,true);
	}

	GLKMatrixLib::DeleteMatrix(A,3,3);  delete []X;  delete []B;
	GLKMatrixLib::DeleteMatrix(UU,3,3);
	GLKMatrixLib::DeleteMatrix(VV,3,3);
	GLKMatrixLib::DeleteMatrix(UUT,3,3);
	GLKMatrixLib::DeleteMatrix(VVT,3,3);
}

bool QSharpener4::_isNodeInFace(QMeshNode *node, QMeshFace *face)
{
	int i,edgeNum;

	edgeNum=face->GetEdgeNum();
	for(i=0;i<edgeNum;i++)
		if (face->GetNodeRecordPtr(i)==node) return true;

	return false;
}

void QSharpener4::_positioningNode(QMeshNode *node, double criterion)
{
	GLKPOSITION PosFace;
	double **A,*X,*B,**UU,**UUT,**VV,**VVT,pp[3],qq[3],normal[3],dd;
	int i,j;

	GLKMatrixLib::CreateMatrix(A,3,3);
	GLKMatrixLib::CreateMatrix(UU,3,3);
	GLKMatrixLib::CreateMatrix(VV,3,3);
	GLKMatrixLib::CreateMatrix(UUT,3,3);
	GLKMatrixLib::CreateMatrix(VVT,3,3);
	X=new double[3];	B=new double[3];

	for(i=0;i<3;i++) {
		B[i]=0.0;	X[i]=0.0;
		for(j=0;j<3;j++) A[i][j]=0.0;
	}

	node->GetCoord3D(pp[0],pp[1],pp[2]);

	//-----------------------------------------------------------------
	//	Set the equation system
	for(PosFace=node->attachedList.GetHeadPosition();PosFace!=NULL;) {
		QMeshFace *face=(QMeshFace *)(node->attachedList.GetNext(PosFace));
		face->CalCenterPos(qq[0],qq[1],qq[2]);
		face->GetPlaneEquation(normal[0],normal[1],normal[2],dd);
		double area=face->CalArea();

		//  For matrix A
		A[0][0]+=area*normal[0]*normal[0];
		A[0][1]+=area*normal[0]*normal[1];
		A[0][2]+=area*normal[0]*normal[2];
		A[1][1]+=area*normal[1]*normal[1];
		A[1][2]+=area*normal[1]*normal[2];
		A[2][2]+=area*normal[2]*normal[2];

		//  For vector B
		dd=(qq[0]-pp[0])*normal[0]+(qq[1]-pp[1])*normal[1]+(qq[2]-pp[2])*normal[2];
		dd=dd*area;
		B[0]+=normal[0]*dd;
		B[1]+=normal[1]*dd;
		B[2]+=normal[2]*dd;
	}
	A[1][0]=A[0][1];	A[2][0]=A[0][2];	A[2][1]=A[1][2];

	if (!(node->attachedList.IsEmpty())) {
		//-----------------------------------------------------------------
		//	Singular Value Decomposition
		GLKMatrixLib::SingularValueDecomposition(A,3,3,UU,VVT);
		GLKMatrixLib::Transpose(UU,3,3,UUT);
		GLKMatrixLib::Transpose(VVT,3,3,VV);
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				if (i!=j) {
					A[i][j]=0.0;
				}
				else {
					if (A[i][j]<criterion)
						A[i][j]=0.0;
					else
						A[i][j]=1.0/A[i][j];
				}
			}
		}
		GLKMatrixLib::Mul(UUT,B,3,3,X);
		GLKMatrixLib::Mul(A,X,3,3,B);
		GLKMatrixLib::Mul(VV,B,3,3,X);

		//-----------------------------------------------------------------
		//	update node position
		double dist=X[0]*X[0]+X[1]*X[1]+X[2]*X[2];
		if (dist>(1.0/(4.0*criterion*criterion))) {X[0]=0.0;X[1]=0.0;X[2]=0.0;}
		pp[0]+=X[0];	pp[1]+=X[1];	pp[2]+=X[2];
		node->SetCoord3D(pp[0],pp[1],pp[2]);
		for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
		node->SetAttribFlag(7,true);
	}

	GLKMatrixLib::DeleteMatrix(A,3,3);  delete []X;  delete []B;
	GLKMatrixLib::DeleteMatrix(UU,3,3);
	GLKMatrixLib::DeleteMatrix(VV,3,3);
	GLKMatrixLib::DeleteMatrix(UUT,3,3);
	GLKMatrixLib::DeleteMatrix(VVT,3,3);
}

void QSharpener4::_nodeStarCenter(QMeshNode *node, double pp[])
{
	GLKPOSITION PosEdge;
	QMeshNode *linkedNode;
	double xx,yy,zz;

	int num=node->GetEdgeNumber();
	pp[0]=0.0;	pp[1]=0.0;	pp[2]=0.0;
	for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
		QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
		if (edge->GetStartPoint()==node)
			linkedNode=edge->GetEndPoint();
		else
			linkedNode=edge->GetStartPoint();
		linkedNode->GetCoord3D(xx,yy,zz);
		pp[0]+=xx;	pp[1]+=yy;	pp[2]+=zz;
	}

	if (!(node->GetNodeList().IsEmpty())) {
		GLKPOSITION PosNode;
		for(PosNode=node->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *commonNode=(QMeshNode *)(node->GetNodeList().GetNext(PosNode));

			num+=commonNode->GetEdgeNumber();
			for(PosEdge=commonNode->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
				QMeshEdge *edge=(QMeshEdge *)(commonNode->GetEdgeList().GetNext(PosEdge));
				if (edge->GetStartPoint()==commonNode)
					linkedNode=edge->GetEndPoint();
				else
					linkedNode=edge->GetStartPoint();
				linkedNode->GetCoord3D(xx,yy,zz);
				pp[0]+=xx;	pp[1]+=yy;	pp[2]+=zz;
			}
		}
	}

	pp[0]=pp[0]/(double)num;
	pp[1]=pp[1]/(double)num;
	pp[2]=pp[2]/(double)num;
}

bool QSharpener4::_detectAbilityOfNodeRemovementInThinning(QMeshNode *detectedNode)
{
	GLKPOSITION PosEdge;
	GLKPOSITION PosNode;
	QMeshNode *linkedNode;
	QMeshNode **nodeArray;
	GLKObList sharpNodeList;
	bool bFlag;

	sharpNodeList.RemoveAll();

	for(PosEdge=detectedNode->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
		QMeshEdge *edge=(QMeshEdge *)(detectedNode->GetEdgeList().GetNext(PosEdge));
		if (edge->GetStartPoint()==detectedNode)
			linkedNode=edge->GetEndPoint();
		else
			linkedNode=edge->GetStartPoint();
		if (linkedNode->GetAttribFlag(5)) {
			sharpNodeList.AddTail(linkedNode);
		}
	}

//	if (sharpNodeList.GetCount()==1) return false;
	if (sharpNodeList.GetCount()==0) return true;

	//------------------------------------------------------------------------
	//	detect whether broken will happen by the "Warshall's algorithm"
	/*
	Algorithm Warshall
	Input: The adjacency matrix of a relation R on a set with n elements.
	Output: The adjacency matrix T of the transitive closure of R.
	Procedure:
	  Start with T=A.
	  For each j from 1 to n
		  For each i from 1 to n
			 If T(i,j)=1, then form the Boolean or of row i and row j 
							   and replace row i by it.
			 Go on to the next i-value.
		  Once you have processed each i-value, go on to the next j-value.

	The above description of the algorithm and proof of its correctness may be found 
		in "Discrete Mathematics" by Kenneth P. Bogart. 
	*/
	int num=sharpNodeList.GetCount(),i,j,k;
	double **path;

	nodeArray=(QMeshNode **)new long[num];	i=0;
	for(PosNode=sharpNodeList.GetHeadPosition();PosNode!=NULL;i++) {
		QMeshNode *node=(QMeshNode *)(sharpNodeList.GetNext(PosNode));
		nodeArray[i]=node;
	}

	GLKMatrixLib::CreateMatrix(path,num,num);
	for(i=0;i<num;i++) {
		for(PosEdge=(nodeArray[i])->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
			QMeshEdge *edge=(QMeshEdge *)((nodeArray[i])->GetEdgeList().GetNext(PosEdge));
			if (edge->GetStartPoint()==(nodeArray[i]))
				linkedNode=edge->GetEndPoint();
			else
				linkedNode=edge->GetStartPoint();
			for(j=0;j<num;j++) {
				if (i==j) path[i][j]=1.0;
				if (nodeArray[j]==linkedNode) {path[i][j]=1.0;path[j][i]=1.0;}
			}
		}
	}

	for(j=0;j<num;j++) {
		for(i=0;i<num;i++) {
			if(path[i][j]==1.0) {
				for(k=0;k<num;k++) {
					if ((path[j][k] == 1.0)||(path[i][k] == 1.0)) path[i][k]=1.0;
				}
			}
		}
	}

	bFlag=true;
	for(k=1;k<num;k++) {
		for(i=0;i<num;i++) {
			if (path[k][i]!=path[k-1][i]) {bFlag=false;break;}
		}
		if (!bFlag) break;
	}

	GLKMatrixLib::DeleteMatrix(path,num,num);
	delete [](QMeshNode**)nodeArray;

	return bFlag;
}

void QSharpener4::_openLocalLoop(GLKObList* meshList)
{
	GLKPOSITION Pos;
	GLKPOSITION PosFace;

	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=mesh->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(PosFace));

			int shapeEdgeNum=0;
			int edgeNum=face->GetEdgeNum();
			for(int i=0;i<edgeNum;i++) 
				if (face->GetEdgeRecordPtr(i)->GetAttribFlag(1)) shapeEdgeNum++;
			if (shapeEdgeNum==edgeNum) {
				// Criterion: the edge with greatest opposite angle is opened.
				int maxIndex=0;
				double maxAngle=_faceInnerAngle(face,0);
				for(i=1;i<edgeNum;i++) {
					double angle=_faceInnerAngle(face,i);
					if (angle>maxAngle) {maxIndex=i;maxAngle=angle;}
				}
				face->GetEdgeRecordPtr((maxIndex+2)%edgeNum)->SetAttribFlag(1,false);
			}
		}
	}
}

double QSharpener4::_faceInnerAngle(QMeshFace *face, int nIndex)// the angle is returned in rotation
{
	int edgeNum=face->GetEdgeNum();
	double pp[3],p1[3],p2[3],l1,l2,ll;
	GLKGeometry geo;
	
	face->GetNodePos(nIndex,pp[0],pp[1],pp[2]);
	face->GetNodePos((nIndex+1)%edgeNum,p2[0],p2[1],p2[2]);
	face->GetNodePos((nIndex-1+edgeNum)%edgeNum,p1[0],p1[1],p1[2]);

	ll=geo.Distance_to_Point(p1,p2);
	l1=geo.Distance_to_Point(pp,p1);
	l2=geo.Distance_to_Point(pp,p2);

	double cs=(l1*l1+l2*l2-ll*ll)/(2.0*l1*l2);
	if (cs>1.0) cs=1.0;
	if (cs<-1.0) cs=-1.0;

	return acos(cs);
}

void QSharpener4::_findErosionNodeList(GLKObList* meshList, GLKObList* nodeList)
{
	GLKPOSITION Pos;
	GLKPOSITION PosNode;
	GLKPOSITION PosEdge;
	QMeshNode *linkedNode;
	bool bFlag;

	nodeList->RemoveAll();

	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			if (node->GetAttribFlag(0)) continue;
			if (!(node->GetAttribFlag(5))) continue;

			bFlag=false;
			for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
				QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
				if (edge->GetStartPoint()==node)
					linkedNode=edge->GetEndPoint();
				else
					linkedNode=edge->GetStartPoint();
				if (!(linkedNode->GetAttribFlag(5))) {bFlag=true;break;}
			}

			if (bFlag) nodeList->AddTail(node);
		}
	}
}

void QSharpener4::_clearSubRegions()
{
	if (m_xNum==0) return;
	if (m_yNum==0) return;
	if (m_zNum==0) return;

	int i,j,k;
	for(i=0;i<m_xNum;i++) {
		for(j=0;j<m_yNum;j++) {
			for(k=0;k<m_zNum;k++)	{
				delete (m_boxArray[i][j][k]);
			}
			delete [](GLKObList **)(m_boxArray[i][j]);
		}
		delete [](GLKObList ***)(m_boxArray[i]);
	}
	delete [](GLKObList ****)(m_boxArray);

	m_xNum=0;	m_yNum=0;	m_zNum=0;
}
