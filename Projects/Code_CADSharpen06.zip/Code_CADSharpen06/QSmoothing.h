// QSmoothing.h: interface for the QSmoothing class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _QSMOOTHING
#define _QSMOOTHING

class GLKObList;
class QMeshNode;

class QSmoothing  
{
public:
	QSmoothing();
	virtual ~QSmoothing();

	//--------------------------------------------------------------------------------
	//	The G0 continuity between different patches is preserved
	static void LaplacianMeshSmoothing(GLKObList* meshList, int nStep);

	//--------------------------------------------------------------------------------
	//	The algorithm implemented in this function is from the SIGGRAPH2003 paper:
	//		"Non-iterative, feature-preserving mesh smoothing"
	//	The G0 continuity between different patches is preserved
	static void FeaturePreservedMeshSmoothing(GLKObList* meshList, 
										double deltaFscale, double deltaGscale,
										bool bSharpFeatureOnly=false, int nSteps=1,
										bool bByAverageEdgeLength=true);
	static double gaussianErrorNorm(double x, double delta);

	//--------------------------------------------------------------------------------
	//	The algorithm implemented in this function is from the SIGGRAPH2003 paper:
	//		"Bilateral mesh denoising"
	//	The G0 continuity between different patches is preserved
	static void BilateralDenoising(GLKObList* meshList, 
										double deltaFscale, double deltaGscale,
										bool bSharpFeatureOnly=false, int nSteps=1,
										bool bByAverageEdgeLength=true);

	//--------------------------------------------------------------------------------
	//	The algorithm implemented in these two function is from the SIGGRAPH1998 paper:
	//		"Interactive multi-resolution modeling on arbitrary meshes"
	static void OrderTwoUmbrellaFairing(GLKObList* meshList, int nSteps, bool bWithFlag7);
	static void OrderOneUmbrellaFairing(GLKObList* meshList, int nSteps, bool bWithFlag7);

	//--------------------------------------------------------------------------------
	//	The algorithm implemented in this function is from the VisMath2002 paper:
	//		"Discrete differential-geometry operators for triangulated 2-manifolds"
	static void AnisotropicDiffusionSmoothing(GLKObList* meshList);

	//--------------------------------------------------------------------------------
	//	The algorithm implemented in this function is from the CAD paper (vol.33, 2001):
	//		"Mesh regularization and adaptive smoothing"
	static void CreaseEnhancingDiffusion(GLKObList* meshList, double exponentialCoefficient,
												int nSteps);

	//--------------------------------------------------------------------------------
	//	The algorithm implemented in this function is from the SIGGRAPH2003 paper:
	//		"Non-iterative, feature-preserving mesh smoothing"
	static void BilateralFiltering(GLKObList* meshList, double deltaFscale, double deltaGscale,
							bool bMollification, int nSteps, bool bRelativeToMeanEdgeLength,
							bool bOnlySharpRegion=false, bool bWithBoundary=true);
	//	the following version of Bilateral Filtering is with facet subdivision
	static void BilateralFiltering2(GLKObList* meshList, double deltaFscale, double deltaGscale,
							bool bMollification, int nSteps, bool bRelativeToMeanEdgeLength);
	//	the following version of Bilateral Filtering using the ANN library
	static void BilateralFilteringWithANN(GLKObList* meshList, double deltaFscale, double deltaGscale,
							bool bMollification, int nSteps, bool bRelativeToMeanEdgeLength,
							bool bOnlySharpRegion=false, bool bWithBoundary=true);

	static void MeshNoising(GLKObList* meshList,short nNosiyType);
										//	nNoisyType	- 0	: uniform noise
										//				  1 : gaussian noise

private:
	static void deltaF(QMeshNode *node, double up[]);
	static void uniformNoiseGenerator(int sampleNum, double *sample,
										double minRang, double maxRang);
	static void gaussianNoiseGenerator(int sampleNum, double *sample,
										double midValue, double variance);
};

#endif
