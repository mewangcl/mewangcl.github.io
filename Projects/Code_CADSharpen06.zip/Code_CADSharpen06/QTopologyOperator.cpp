// QTopologyOperator.cpp: implementation of the QTopologyOperator class.
//
//////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <math.h>

#include "..\GLKLib\GLKObList.h"
#include "..\GLKLib\GLKGeometry.h"
#include "..\GLKLib\GLKHeap.h"

#include "..\QMeshLib\QMeshPatch.h"
#include "..\QMeshLib\QMeshFace.h"
#include "..\QMeshLib\QMeshEdge.h"
#include "..\QMeshLib\QMeshNode.h"

#include "..\Voxel4DLib\Voxel4DField.h"
#include "..\Voxel4DLib\UniformDistField.h"

#include "QGeometryComputing.h"

#include "QTopologyOperator.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QTopologyOperator::QTopologyOperator()
{

}

QTopologyOperator::~QTopologyOperator()
{

}

//////////////////////////////////////////////////////////////////////
// Implementation
//////////////////////////////////////////////////////////////////////

bool QTopologyOperator::TopologyErrorCheck(GLKObList* meshList)
{
	GLKPOSITION Pos;
	GLKPOSITION PosEdge;
	bool bFlag=false;

//	printf("-------------------------------------------------------------------------\n");
//	printf("Topology check started\n");
//	printf("-------------------------------------------------------------------------\n");

	//-------------------------------------------------------------------------------
	//	Check Invalid Edges
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosEdge=mesh->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
			QMeshEdge *edge=(QMeshEdge *)(mesh->GetEdgeList().GetNext(PosEdge));

			if (edge->GetStartPoint()==edge->GetEndPoint()) {
				printf("Invalid edge is found! Mesh index is No. %d, and Edge index is No.%d\n",mesh->GetIndexNo(),edge->GetIndexNo());
				bFlag=true;
				edge->GetLeftFace()->SetAttribFlag(3);
				edge->GetRightFace()->SetAttribFlag(3);
			}
		}
	}

//	printf("-------------------------------------------------------------------------\n");
//	printf("Topology check finished\n");
//	printf("-------------------------------------------------------------------------\n");

	return bFlag;
}

bool QTopologyOperator::trgledgeSplitByFlags(GLKObList* meshList)
{
	//-----------------------------------------------------------------------------------
	//	Edge Flag - 4 to detect whether the edge needs to be splitted
	GLKPOSITION Pos;
	GLKPOSITION PosMesh;
	GLKPOSITION PosEdge;
	GLKPOSITION PosFace;
	GLKPOSITION PosNode;
	GLKPOSITION PosNode2;
	GLKPOSITION PosEdge2;
	GLKObList nodeList;
	QMeshEdge *edge,*tempEdge;
	QMeshNode *node,*node1,*node2;
	QMeshFace *face;
	double pp[3],pp1[3],pp2[3];
	int i,j,edgeNum;
	int div_num,div_index,faceNum;
	bool bRefined=false;

	fillCoincidentEdgeInfo(meshList);
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;){
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			node->SetAttribFlag(7,false);
		}
		for(PosEdge=mesh->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
			edge=(QMeshEdge*)(mesh->GetEdgeList().GetNext(PosEdge));
			edge->SetAttribFlag(7,false);
		}
	}

	//------------------------------------------------------------------------------------
	//	Create new nodes
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosEdge=mesh->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
			edge=(QMeshEdge*)(mesh->GetEdgeList().GetNext(PosEdge));
			if (!(edge->GetAttribFlag(4))) continue;	// node need to be inserted
			if (edge->GetAttribFlag(7)) continue;		// node has been inserted

			edge->GetStartPoint()->GetCoord3D(pp1[0],pp1[1],pp1[2]);
			edge->GetEndPoint()->GetCoord3D(pp2[0],pp2[1],pp2[2]);
			pp[0]=(pp1[0]+pp2[0])/2.0;	pp[1]=(pp1[1]+pp2[1])/2.0;	pp[2]=(pp1[2]+pp2[2])/2.0;
			
			{
				//-----------------------------------------------------------------------
				//	Create new QMeshNode
				QMeshNode *newNode=new QMeshNode;
				newNode->SetMeshPatchPtr(mesh);
				newNode->SetCoord3D(pp[0],pp[1],pp[2]);
				newNode->SetIndexNo(mesh->GetNodeNumber()+1);
				(mesh->GetNodeList()).AddTail(newNode);
				edge->GetAttachedList().AddTail(newNode);
				edge->SetAttribFlag(7,true);
				newNode->SetAttribFlag(7);
				if (edge->GetAttribFlag(1)) newNode->SetAttribFlag(5);

				bRefined=true;

				nodeList.RemoveAll();	// the list of new inserted nodes for filling sewing info.
				nodeList.AddTail(newNode);

				if (edge->GetAttachedList().GetCount()==1) continue;

				//-----------------------------------------------------------------------
				//	If the edge has coincident edges, insert nodes in those edges
				for(PosEdge2=edge->GetAttachedList().GetHeadPosition();PosEdge2!=NULL;) {
					tempEdge=(QMeshEdge*)(edge->GetAttachedList().GetNext(PosEdge2));
					if (!PosEdge2) break;  // last one in the attached list is the newly inserted node

					QMeshNode *newNode=new QMeshNode;
					newNode->SetMeshPatchPtr(tempEdge->GetMeshPatchPtr());
					newNode->SetCoord3D(pp[0],pp[1],pp[2]);
					newNode->SetIndexNo(tempEdge->GetMeshPatchPtr()->GetNodeNumber()+1);
					(tempEdge->GetMeshPatchPtr()->GetNodeList()).AddTail(newNode);
					tempEdge->GetAttachedList().AddTail(newNode);
					tempEdge->SetAttribFlag(7,true);
					newNode->SetAttribFlag(7);
					if (tempEdge->GetAttribFlag(1)) newNode->SetAttribFlag(5);

					nodeList.AddTail(newNode);
				}
							
				//--------------------------------------------------------------------------------
				//	Fill in the sewing info
				for(PosNode=nodeList.GetHeadPosition();PosNode!=NULL;) {
					node1=(QMeshNode*)(nodeList.GetNext(PosNode));
					node1->GetNodeList().RemoveAll();

					for(PosNode2=nodeList.GetHeadPosition();PosNode2!=NULL;) {
						node2=(QMeshNode*)(nodeList.GetNext(PosNode2));
						if (node1==node2) continue;

						node1->GetNodeList().AddTail(node2);
					}
				}
			}
		}
	}

	////////////////////////////////////////////////////////////////////////////////
	//	Step 2: Scan the one with two edges splited
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=mesh->GetFaceList().GetHeadPosition();PosEdge!=NULL;) {
			face=(QMeshFace*)(mesh->GetFaceList().GetNext(PosEdge));

			div_num=0;
			for(i=0;i<3;i++) if (face->GetEdgeRecordPtr(i)->GetAttribFlag(4)) div_num++;
			if (div_num!=2) continue;

			edge->GetStartPoint()->GetCoord3D(pp1[0],pp1[1],pp1[2]);
			edge->GetEndPoint()->GetCoord3D(pp2[0],pp2[1],pp2[2]);
			pp[0]=(pp1[0]+pp2[0])/2.0;	pp[1]=(pp1[1]+pp2[1])/2.0;	pp[2]=(pp1[2]+pp2[2])/2.0;

				//-----------------------------------------------------------------------
				//	Create new QMeshNode
				QMeshNode *newNode=new QMeshNode;
				newNode->SetMeshPatchPtr(mesh);
				newNode->SetCoord3D(pp[0],pp[1],pp[2]);
				newNode->SetIndexNo(mesh->GetNodeNumber()+1);
				(mesh->GetNodeList()).AddTail(newNode);
				edge->GetAttachedList().AddTail(newNode);
				edge->SetAttribFlag(4,true);

				bRefined=true;

				nodeList.RemoveAll();	// the list of new inserted nodes for filling sewing info.
				nodeList.AddTail(newNode);

				if (edge->GetAttachedList().GetCount()==1) continue;

				//-----------------------------------------------------------------------
				//	If the edge has coincident edges, insert nodes in those edges
				for(PosEdge2=edge->GetAttachedList().GetHeadPosition();PosEdge2!=NULL;) {
					tempEdge=(QMeshEdge*)(edge->GetAttachedList().GetNext(PosEdge2));
					if (!PosEdge2) break;  // last one in the attached list is the newly inserted node

					QMeshNode *newNode=new QMeshNode;
					newNode->SetMeshPatchPtr(tempEdge->GetMeshPatchPtr());
					newNode->SetCoord3D(pp[0],pp[1],pp[2]);
					newNode->SetIndexNo(tempEdge->GetMeshPatchPtr()->GetNodeNumber()+1);
					(tempEdge->GetMeshPatchPtr()->GetNodeList()).AddTail(newNode);
					tempEdge->GetAttachedList().AddTail(newNode);
					tempEdge->SetAttribFlag(4,true);

					nodeList.AddTail(newNode);
				}
							
				//--------------------------------------------------------------------------------
				//	Fill in the sewing info
				for(PosNode=nodeList.GetHeadPosition();PosNode!=NULL;) {
					node1=(QMeshNode*)(nodeList.GetNext(PosNode));
					node1->GetNodeList().RemoveAll();

					for(PosNode2=nodeList.GetHeadPosition();PosNode2!=NULL;) {
						node2=(QMeshNode*)(nodeList.GetNext(PosNode2));
						if (node1==node2) continue;

						node1->GetNodeList().AddTail(node2);
					}
				}
		}
	}

	////////////////////////////////////////////////////////////////////////////////
	//	Step 2: Create new QMeshEdge
	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));

		edgeNum=mesh->GetEdgeNumber();
		Pos=(mesh->GetEdgeList()).GetHeadPosition();
		for(i=0;i<edgeNum;i++)
		{
			edge=(QMeshEdge*)((mesh->GetEdgeList()).GetNext(Pos));
			if (!(edge->GetAttribFlag(4))) continue;

			QMeshEdge *newEdge=new QMeshEdge;
			newEdge->SetMeshPatchPtr(mesh);
			newEdge->SetStartPoint((QMeshNode *)(edge->GetAttachedList().GetTail()));
			newEdge->SetEndPoint(edge->GetEndPoint());
			newEdge->SetIndexNo(mesh->GetEdgeNumber()+1);
			(mesh->GetEdgeList()).AddTail(newEdge);

			edge->SetEndPoint((QMeshNode *)(edge->GetAttachedList().GetTail()));
			edge->GetAttachedList().RemoveAll();
			edge->GetAttachedList().AddTail(newEdge);

			if (edge->GetAttribFlag(1)) newEdge->SetAttribFlag(1);
		}
	}

	////////////////////////////////////////////////////////////////////////////////
	//	Step 3: Create new QMeshFace
	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));

		faceNum=mesh->GetFaceNumber();
		Pos=(mesh->GetFaceList()).GetHeadPosition();
		for(i=0;i<faceNum;i++)
		{
			QMeshFace *face=(QMeshFace *)((mesh->GetFaceList()).GetNext(Pos));
			div_index=0;	div_num=0;
			for(j=1;j<=3;j++)
			{
				QMeshEdge *edge=face->GetEdgeRecordPtr(j-1);
				if (!(edge->GetAttribFlag(4))) continue;
				div_num++;
				if (div_index==0) div_index=j;
			}

			switch(div_num)
			{
			case 1:{	//	One edge needs to be divided

					///////////////////////////////////////////////////////////////////////////
					//	Step 1: create all edges
					QMeshEdge* edges[5];	bool edgeFlag[4];	
					for(j=0;j<3;j++) if (face->GetEdgeRecordPtr(j)->GetAttribFlag(4)) {div_index=j;break;}				
					for(j=0;j<3;j++) {
						edgeFlag[j+1]=face->IsNormalDirection((div_index+j)%3);
						edges[j+1]=face->GetEdgeRecordPtr((div_index+j)%3);
					}
					edgeFlag[0]=edgeFlag[1];
					if (edgeFlag[1]) {
						edges[0]=face->GetEdgeRecordPtr(div_index);
						edges[1]=(QMeshEdge*)(face->GetEdgeRecordPtr(div_index)->GetAttachedList().GetTail());
					}
					else {
						edges[0]=(QMeshEdge*)(face->GetEdgeRecordPtr(div_index)->GetAttachedList().GetTail());
						edges[1]=face->GetEdgeRecordPtr(div_index);
					}
					edges[4]=new QMeshEdge;	edges[4]->SetMeshPatchPtr(mesh);
					edges[4]->SetIndexNo(mesh->GetEdgeNumber()+1);
					(mesh->GetEdgeList()).AddTail(edges[4]);
					if (edgeFlag[1])
						edges[4]->SetStartPoint(edges[1]->GetStartPoint());
					else
						edges[4]->SetStartPoint(edges[1]->GetEndPoint());
					if (edgeFlag[2])
						edges[4]->SetEndPoint(edges[2]->GetEndPoint());
					else
						edges[4]->SetEndPoint(edges[2]->GetStartPoint());

					///////////////////////////////////////////////////////////////////////////
					//	Step 2: create all faces
					QMeshFace* newFace=new QMeshFace;	
					newFace->SetMeshPatchPtr(mesh);	
					newFace->SetEdgeNum(3);
					newFace->SetIndexNo(mesh->GetFaceNumber()+1);
					(mesh->GetFaceList()).AddTail(newFace);

					face->SetEdgeRecordPtr(0,edges[1]);	face->SetDirectionFlag(0,edgeFlag[1]);
					face->SetEdgeRecordPtr(1,edges[2]);	face->SetDirectionFlag(1,edgeFlag[2]);
					face->SetEdgeRecordPtr(2,edges[4]);	face->SetDirectionFlag(2,false);

					newFace->SetEdgeRecordPtr(0,edges[0]);	newFace->SetDirectionFlag(0,edgeFlag[0]);
					newFace->SetEdgeRecordPtr(1,edges[4]);	newFace->SetDirectionFlag(1,true);
					newFace->SetEdgeRecordPtr(2,edges[3]);	newFace->SetDirectionFlag(2,edgeFlag[3]);

				   }break;
			case 2:{	//	Two edge needs to be divided

					///////////////////////////////////////////////////////////////////////////
					//	Step 1: find the order of the edges
					QMeshEdge* edges[7];	bool edgeFlag[5];	
					for(j=0;j<3;j++)
					{
						QMeshEdge *edge1=face->GetEdgeRecordPtr(j);
						QMeshEdge *edge2=face->GetEdgeRecordPtr((j+1)%3);
						if ((edge1->GetAttribFlag(4)) && (edge2->GetAttribFlag(4))) {div_index=j;break;}
					}
					edgeFlag[0]=face->IsNormalDirection(div_index);
					edgeFlag[1]=edgeFlag[0];
					edgeFlag[2]=face->IsNormalDirection((div_index+1)%3);
					edgeFlag[3]=edgeFlag[2];
					edgeFlag[4]=face->IsNormalDirection((div_index+2)%3);
					if (!(edgeFlag[0])) {
						edges[0]=(QMeshEdge*)(face->GetEdgeRecordPtr(div_index)->GetAttachedList().GetTail());
						edges[1]=face->GetEdgeRecordPtr(div_index);
					}
					else {
						edges[1]=(QMeshEdge*)(face->GetEdgeRecordPtr(div_index)->GetAttachedList().GetTail());
						edges[0]=face->GetEdgeRecordPtr(div_index);
					}
					if (!(edgeFlag[2])) {
						edges[2]=(QMeshEdge*)(face->GetEdgeRecordPtr((div_index+1)%3)->GetAttachedList().GetTail());
						edges[3]=face->GetEdgeRecordPtr((div_index+1)%3);
					}
					else {
						edges[3]=(QMeshEdge*)(face->GetEdgeRecordPtr((div_index+1)%3)->GetAttachedList().GetTail());
						edges[2]=face->GetEdgeRecordPtr((div_index+1)%3);
					}
					edges[4]=face->GetEdgeRecordPtr((div_index+2)%3);

					///////////////////////////////////////////////////////////////////////////
					//	Step 2: create all edges
					for(j=0;j<2;j++)
					{
						edges[5+j]=new QMeshEdge;	edges[5+j]->SetMeshPatchPtr(mesh);
						edges[5+j]->SetIndexNo(mesh->GetEdgeNumber()+1);
						(mesh->GetEdgeList()).AddTail(edges[5+j]);
					}
					if (edgeFlag[0]) {
						edges[5]->SetStartPoint(edges[0]->GetStartPoint());
						edges[6]->SetStartPoint(edges[0]->GetEndPoint());
					}
					else {
						edges[5]->SetStartPoint(edges[0]->GetEndPoint());
						edges[6]->SetStartPoint(edges[0]->GetStartPoint());
					}
					if (edgeFlag[2]) {
						edges[5]->SetEndPoint(edges[2]->GetEndPoint());
						edges[6]->SetEndPoint(edges[2]->GetEndPoint());
					}
					else {
						edges[5]->SetEndPoint(edges[2]->GetStartPoint());
						edges[6]->SetEndPoint(edges[2]->GetStartPoint());
					}

					///////////////////////////////////////////////////////////////////////////
					//	Step 3: create all faces
					QMeshFace* faces[4];			faces[1]=face;
					for(j=2;j<=3;j++)
					{
						faces[j]=new QMeshFace;		faces[j]->SetMeshPatchPtr(mesh);
						faces[j]->SetEdgeNum(3);
						faces[j]->SetIndexNo(mesh->GetFaceNumber()+1);
						(mesh->GetFaceList()).AddTail(faces[j]);
					}

					faces[1]->SetEdgeRecordPtr(0,edges[0]);	faces[1]->SetDirectionFlag(0,edgeFlag[0]);
					faces[1]->SetEdgeRecordPtr(1,edges[6]);	faces[1]->SetDirectionFlag(1,true);
					faces[1]->SetEdgeRecordPtr(2,edges[5]);	faces[1]->SetDirectionFlag(2,false);

					faces[2]->SetEdgeRecordPtr(0,edges[1]);	faces[2]->SetDirectionFlag(0,edgeFlag[1]);
					faces[2]->SetEdgeRecordPtr(1,edges[2]);	faces[2]->SetDirectionFlag(1,edgeFlag[2]);
					faces[2]->SetEdgeRecordPtr(2,edges[6]);	faces[2]->SetDirectionFlag(2,false);

					faces[3]->SetEdgeRecordPtr(0,edges[5]);	faces[3]->SetDirectionFlag(0,true);
					faces[3]->SetEdgeRecordPtr(1,edges[3]);	faces[3]->SetDirectionFlag(1,edgeFlag[3]);
					faces[3]->SetEdgeRecordPtr(2,edges[4]);	faces[3]->SetDirectionFlag(2,edgeFlag[4]);

				   }break;
			case 3:{	//	Three edge needs to be divided
				
					///////////////////////////////////////////////////////////////////////////
					//	Step 1: create all edges
					QMeshEdge* edges[9];	bool edgeFlag[6];
					for(j=0;j<3;j++) {
						edgeFlag[j*2]=face->IsNormalDirection(j);
						edgeFlag[j*2+1]=edgeFlag[j*2];

						if (edgeFlag[j*2]) {
							edges[j*2]=face->GetEdgeRecordPtr(j);
							edges[j*2+1]=(QMeshEdge*)(face->GetEdgeRecordPtr(j)->GetAttachedList().GetTail());
						}
						else {
							edges[j*2]=(QMeshEdge*)(face->GetEdgeRecordPtr(j)->GetAttachedList().GetTail());
							edges[j*2+1]=face->GetEdgeRecordPtr(j);
						}
					}
					for(j=0;j<3;j++) {
						edges[6+j]=new QMeshEdge;		edges[6+j]->SetMeshPatchPtr(mesh);
						edges[6+j]->SetIndexNo(mesh->GetEdgeNumber()+1);
						(mesh->GetEdgeList()).AddTail(edges[6+j]);
						if (edgeFlag[j*2])
							edges[6+j]->SetStartPoint(edges[j*2]->GetEndPoint());
						else
							edges[6+j]->SetStartPoint(edges[j*2]->GetStartPoint());
						if (edgeFlag[((j+1)%3)*2])
							edges[6+j]->SetEndPoint(edges[((j+1)%3)*2]->GetEndPoint());
						else
							edges[6+j]->SetEndPoint(edges[((j+1)%3)*2]->GetStartPoint());
					}

					///////////////////////////////////////////////////////////////////////////
					//	Step 2: create all faces
					QMeshFace* faces[5];			faces[1]=face;
					for(j=2;j<=4;j++)
					{
						faces[j]=new QMeshFace;		faces[j]->SetMeshPatchPtr(mesh);
						faces[j]->SetEdgeNum(3);
						faces[j]->SetIndexNo(mesh->GetFaceNumber()+1);
						(mesh->GetFaceList()).AddTail(faces[j]);
					}

					faces[1]->SetEdgeRecordPtr(0,edges[0]);	faces[1]->SetDirectionFlag(0,edgeFlag[0]);
					faces[1]->SetEdgeRecordPtr(1,edges[8]);	faces[1]->SetDirectionFlag(1,false);
					faces[1]->SetEdgeRecordPtr(2,edges[5]);	faces[1]->SetDirectionFlag(2,edgeFlag[5]);

					faces[2]->SetEdgeRecordPtr(0,edges[1]);	faces[2]->SetDirectionFlag(0,edgeFlag[1]);
					faces[2]->SetEdgeRecordPtr(1,edges[2]);	faces[2]->SetDirectionFlag(1,edgeFlag[2]);
					faces[2]->SetEdgeRecordPtr(2,edges[6]);	faces[2]->SetDirectionFlag(2,false);

					faces[3]->SetEdgeRecordPtr(0,edges[6]);	faces[3]->SetDirectionFlag(0,true);
					faces[3]->SetEdgeRecordPtr(1,edges[7]);	faces[3]->SetDirectionFlag(1,true);
					faces[3]->SetEdgeRecordPtr(2,edges[8]);	faces[3]->SetDirectionFlag(2,true);

					faces[4]->SetEdgeRecordPtr(0,edges[3]);	faces[4]->SetDirectionFlag(0,edgeFlag[3]);
					faces[4]->SetEdgeRecordPtr(1,edges[4]);	faces[4]->SetDirectionFlag(1,edgeFlag[4]);
					faces[4]->SetEdgeRecordPtr(2,edges[7]);	faces[4]->SetDirectionFlag(2,false);

				   }break;
			}
		}
	}

	////////////////////////////////////////////////////////////////////////////////
	//	Step 4: Fill in full topological information
	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));

		for(Pos=(mesh->GetFaceList()).GetHeadPosition();Pos!=NULL;) {
			face=(QMeshFace*)((mesh->GetFaceList()).GetNext(Pos));
			face->CalPlaneEquation();
			for(i=0;i<3;i++) {
				edge=face->GetEdgeRecordPtr(i);
				if (face->IsNormalDirection(i))
					edge->SetLeftFace(face);
				else
					edge->SetRightFace(face);
			}
		}
		for(Pos=(mesh->GetNodeList()).GetHeadPosition();Pos!=NULL;) {
			node=(QMeshNode*)((mesh->GetNodeList()).GetNext(Pos));
			node->GetEdgeList().RemoveAll();
			node->GetFaceList().RemoveAll();
		}
		for(Pos=(mesh->GetFaceList()).GetHeadPosition();Pos!=NULL;) {
			face=(QMeshFace*)((mesh->GetFaceList()).GetNext(Pos));
			for(i=0;i<3;i++) face->GetNodeRecordPtr(i)->GetFaceList().AddTail(face);
		}
		for(Pos=mesh->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
			edge=(QMeshEdge*)(mesh->GetEdgeList().GetNext(Pos));
			edge->GetStartPoint()->GetEdgeList().AddTail(edge);
			edge->GetEndPoint()->GetEdgeList().AddTail(edge);
			edge->GetAttachedList().RemoveAll();
			if ( (!(edge->GetLeftFace())) || (!(edge->GetRightFace())) )
			{
				edge->SetAttribFlag(0,true);
				edge->GetStartPoint()->SetAttribFlag(0,true);
				edge->GetEndPoint()->SetAttribFlag(0,true);
			}
		}
		for(Pos=(mesh->GetNodeList()).GetHeadPosition();Pos!=NULL;) {
			node=(QMeshNode*)((mesh->GetNodeList()).GetNext(Pos));
			node->CalNormal();
		}
	}

	return bRefined;
}

void QTopologyOperator::fillCoincidentEdgeInfo(GLKObList* meshList)
{
	GLKPOSITION Pos;
	GLKPOSITION PosEdge;
	GLKPOSITION PosNode;
	GLKPOSITION PosEdge2;
	GLKObList nodeList;
	QMeshEdge *edge,*tempEdge;
	QMeshNode *node,*node1,*node2,*tempNode;

	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosEdge=mesh->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
			edge=(QMeshEdge*)(mesh->GetEdgeList().GetNext(PosEdge));
			edge->GetAttachedList().RemoveAll();
		}
	}

	//------------------------------------------------------------------------------------
	//	Fill in the coincident edge info.
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosEdge=mesh->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
			edge=(QMeshEdge*)(mesh->GetEdgeList().GetNext(PosEdge));
			if (!(edge->GetAttribFlag(0))) continue;

			node1=edge->GetStartPoint();	node2=edge->GetEndPoint();
			for(PosNode=node1->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode*)(node1->GetNodeList().GetNext(PosNode));

				tempNode=NULL;
				for(PosEdge2=node->GetEdgeList().GetHeadPosition();PosEdge2!=NULL;) {
					tempEdge=(QMeshEdge*)(node->GetEdgeList().GetNext(PosEdge2));
					if (!(tempEdge->GetAttribFlag(0))) continue;

					if (tempEdge->GetStartPoint()==node)
						tempNode=tempEdge->GetEndPoint();
					else
						tempNode=tempEdge->GetStartPoint();

					if (node2->IsNodeInNodeList(tempNode)) 
						break;
					else
						tempNode=NULL;
				}
				if (tempNode) edge->GetAttachedList().AddTail(tempEdge);
			}
		}
	}
}

void QTopologyOperator::edgeSwapOperator(QMeshEdge *edge, GLKHeap *swapHeap, 
										 Voxel4DField *vox4DField, double criterion)
{
	int i;

	QMeshNode *startPnt=edge->GetStartPoint();
	QMeshNode *endPnt=edge->GetEndPoint();

	QMeshFace *leftFace=edge->GetLeftFace();
	QMeshFace *rightFace=edge->GetRightFace();

	QMeshNode *pnt1,*pnt2;
	for(i=0;i<3;i++)
	{
		if (rightFace->GetNodeRecordPtr(i)==startPnt) continue;
		if (rightFace->GetNodeRecordPtr(i)==endPnt) continue;
		pnt1=rightFace->GetNodeRecordPtr(i);
	}
	for(i=0;i<3;i++)
	{
		if (leftFace->GetNodeRecordPtr(i)==startPnt) continue;
		if (leftFace->GetNodeRecordPtr(i)==endPnt) continue;
		pnt2=leftFace->GetNodeRecordPtr(i);
	}

	QMeshEdge *e1,*e2,*e3,*e4;
	bool eFlag1,eFlag2,eFlag3,eFlag4;
	for(i=0;i<3;i++) 
	{
		QMeshEdge *tempEdge=rightFace->GetEdgeRecordPtr(i);
		if (tempEdge==edge) continue;
		if (((tempEdge->GetStartPoint())==startPnt) || ((tempEdge->GetEndPoint())==startPnt)) {
			e2=tempEdge;	eFlag2=rightFace->IsNormalDirection(i);
		}
		if (((tempEdge->GetStartPoint())==endPnt) || ((tempEdge->GetEndPoint())==endPnt)) {
			e1=tempEdge;	eFlag1=rightFace->IsNormalDirection(i);
		}
	}
	for(i=0;i<3;i++) 
	{
		QMeshEdge *tempEdge=leftFace->GetEdgeRecordPtr(i);
		if (tempEdge==edge) continue;
		if (((tempEdge->GetStartPoint())==startPnt) || ((tempEdge->GetEndPoint())==startPnt)) {
			e4=tempEdge;	eFlag4=leftFace->IsNormalDirection(i);
		}
		if (((tempEdge->GetStartPoint())==endPnt) || ((tempEdge->GetEndPoint())==endPnt)) {
			e3=tempEdge;	eFlag3=leftFace->IsNormalDirection(i);
		}
	}

	//-------------------------------------------------------------------------------------
	//	Remove the linkage between QuadMesh faces and TrglMesh faces
	if (!(rightFace->GetAttachedList().IsEmpty())) {
		QMeshFace *tempFace=(QMeshFace *)(rightFace->GetAttachedList().GetTail());
		GLKPOSITION PosTemp;
		for(PosTemp=tempFace->GetAttachedList().GetHeadPosition();PosTemp!=NULL;) {
			QMeshFace *tempFace2=(QMeshFace *)(tempFace->GetAttachedList().GetNext(PosTemp));
			tempFace2->GetAttachedList().RemoveAll();
		}
		tempFace->GetAttachedList().RemoveAll();
	}
	if (!(leftFace->GetAttachedList().IsEmpty())) {
		QMeshFace *tempFace=(QMeshFace *)(leftFace->GetAttachedList().GetTail());
		GLKPOSITION PosTemp;
		for(PosTemp=tempFace->GetAttachedList().GetHeadPosition();PosTemp!=NULL;) {
			QMeshFace *tempFace2=(QMeshFace *)(tempFace->GetAttachedList().GetNext(PosTemp));
			tempFace2->GetAttachedList().RemoveAll();
		}
		tempFace->GetAttachedList().RemoveAll();
	}


	/////////////////////////////////////////////////////////////////////////////////
	//	Begin doing swap now
	QMeshFace *f1,*f2;
	//-------------------------------------------------------------------------------
	//	Step 1: Change the endpoints of edge
	edge->SetStartPoint(pnt2);	edge->SetEndPoint(pnt1);

	//-------------------------------------------------------------------------------
	//	Step 2: Revise faces and change left/right face of e1, e2, e3 and e4
	f1=rightFace;	f2=leftFace;

	if (eFlag1) 
		{e1->SetLeftFace(f2); f2->SetEdgeRecordPtr(0,e1); f2->SetDirectionFlag(0,true);}
	else
		{e1->SetRightFace(f2); f2->SetEdgeRecordPtr(0,e1); f2->SetDirectionFlag(0,false);}
	if (eFlag3) 
		{e3->SetLeftFace(f2); f2->SetEdgeRecordPtr(1,e3); f2->SetDirectionFlag(1,true);}
	else
		{e3->SetRightFace(f2); f2->SetEdgeRecordPtr(1,e3); f2->SetDirectionFlag(1,false);}
	edge->SetLeftFace(f2);	f2->SetEdgeRecordPtr(2,edge); 	f2->SetDirectionFlag(2,true);

	if (eFlag4)
		{e4->SetLeftFace(f1); f1->SetEdgeRecordPtr(0,e4); f1->SetDirectionFlag(0,true);}
	else
		{e4->SetRightFace(f1); f1->SetEdgeRecordPtr(0,e4); f1->SetDirectionFlag(0,false);}
	if (eFlag2)
		{e2->SetLeftFace(f1); f1->SetEdgeRecordPtr(1,e2); f1->SetDirectionFlag(1,true);}
	else
		{e2->SetRightFace(f1); f1->SetEdgeRecordPtr(1,e2); f1->SetDirectionFlag(1,false);}
	edge->SetRightFace(f1);		f1->SetEdgeRecordPtr(2,edge);	f1->SetDirectionFlag(2,false);


	//-------------------------------------------------------------------------------
	//	Step 3: Revise "edge" in its old/new endpoints' edge list
	startPnt->GetEdgeList().Remove(edge);
	endPnt->GetEdgeList().Remove(edge);

	(pnt1->GetEdgeList()).AddTail(edge);
	(pnt2->GetEdgeList()).AddTail(edge);

	//-------------------------------------------------------------------------------
	//	Step 4: Revise faces in startPnt, endPnt, pnt1, and pnt2's face list
	startPnt->GetFaceList().Remove(leftFace);
	endPnt->GetFaceList().Remove(rightFace);
	pnt1->GetFaceList().AddTail(f2);
	pnt2->GetFaceList().AddTail(f1);

	//-------------------------------------------------------------------------------
	//	Step 5: Calculation the normal of startPnt, endPnt, pnt1, and pnt2;
	f1->CalPlaneEquation();	f2->CalPlaneEquation();
	startPnt->CalNormal();	endPnt->CalNormal();
	pnt1->CalNormal();	pnt2->CalNormal();

	if ((!vox4DField) && (!swapHeap)) return;

	//-------------------------------------------------------------------------------
	//	Step 6: Prevent over swapped
	if (e1->GetAttachedList().GetCount()!=0) {
		GLKHeapNode *heapNode=(GLKHeapNode *)(e1->GetAttachedList().GetTail());
		heapNode->SetValue((float)(edgeSwapShapeFunc(e1,vox4DField,criterion)));
		swapHeap->AdjustPosition(heapNode);
	}
	if (e2->GetAttachedList().GetCount()!=0) {
		GLKHeapNode *heapNode=(GLKHeapNode *)(e2->GetAttachedList().GetTail());
		heapNode->SetValue((float)(edgeSwapShapeFunc(e2,vox4DField,criterion)));
		swapHeap->AdjustPosition(heapNode);
	}
	if (e3->GetAttachedList().GetCount()!=0) {
		GLKHeapNode *heapNode=(GLKHeapNode *)(e3->GetAttachedList().GetTail());
		heapNode->SetValue((float)(edgeSwapShapeFunc(e3,vox4DField,criterion)));
		swapHeap->AdjustPosition(heapNode);
	}
	if (e4->GetAttachedList().GetCount()!=0) {
		GLKHeapNode *heapNode=(GLKHeapNode *)(e4->GetAttachedList().GetTail());
		heapNode->SetValue((float)(edgeSwapShapeFunc(e4,vox4DField,criterion)));
		swapHeap->AdjustPosition(heapNode);
	}
}

bool QTopologyOperator::edgeSwapProtectTopology(QMeshEdge *edge)
{
	GLKPOSITION Pos;	int i;
	QMeshNode *tempNode;

	QMeshNode *startPnt=edge->GetStartPoint();
	QMeshNode *endPnt=edge->GetEndPoint();

	QMeshFace *leftFace=edge->GetLeftFace();
	QMeshFace *rightFace=edge->GetRightFace();

	QMeshNode *pnt1,*pnt2;
	for(i=0;i<3;i++)
	{
		QMeshNode *tempNode=rightFace->GetNodeRecordPtr(i);
		if ( (tempNode!=startPnt) && (tempNode!=endPnt) ) {pnt1=tempNode;break;}
	}
	for(i=0;i<3;i++)
	{
		QMeshNode *tempNode=leftFace->GetNodeRecordPtr(i);
		if ( (tempNode!=startPnt) && (tempNode!=endPnt) ) {pnt2=tempNode;break;}
	}

	for(Pos=pnt1->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
		QMeshEdge *edge=(QMeshEdge *)(pnt1->GetEdgeList().GetNext(Pos));
		if (edge->GetStartPoint()==pnt1)
			tempNode=edge->GetEndPoint();
		else
			tempNode=edge->GetStartPoint();
		if (tempNode==pnt2) return false;
	}

	return true;
}

bool QTopologyOperator::edgeSwapNormalCheck(QMeshEdge *edge)
{
	int i;
	GLKGeometry geo;

	QMeshNode *startPnt=edge->GetStartPoint();
	QMeshNode *endPnt=edge->GetEndPoint();

	QMeshFace *leftFace=edge->GetLeftFace();
	QMeshFace *rightFace=edge->GetRightFace();

	QMeshNode *pnt1,*pnt2;
	for(i=0;i<3;i++)
	{
		QMeshNode *tempNode=rightFace->GetNodeRecordPtr(i);
		if ( (tempNode!=startPnt) && (tempNode!=endPnt) ) {pnt1=tempNode;break;}
	}
	for(i=0;i<3;i++)
	{
		QMeshNode *tempNode=leftFace->GetNodeRecordPtr(i);
		if ( (tempNode!=startPnt) && (tempNode!=endPnt) ) {pnt2=tempNode;break;}
	}

	double p1[3],p2[3],p3[3],p4[3];
	startPnt->GetCoord3D(p1[0],p1[1],p1[2]);
	endPnt->GetCoord3D(p2[0],p2[1],p2[2]);
	pnt1->GetCoord3D(p3[0],p3[1],p3[2]);
	pnt2->GetCoord3D(p4[0],p4[1],p4[2]);

	///////////////////////////////////////////
	//	Check by normal
	{
		double n1[3],n2[3],n3[3],n4[3];	double D;
		leftFace->GetPlaneEquation(n1[0],n1[1],n1[2],D);
		rightFace->GetPlaneEquation(n2[0],n2[1],n2[2],D);
		double x[3],y[3],z[3];
		x[0]=p1[0];	x[1]=p3[0];	x[2]=p4[0];
		y[0]=p1[1];	y[1]=p3[1];	y[2]=p4[1];
		z[0]=p1[2];	z[1]=p3[2];	z[2]=p4[2];
		geo.CalPlaneEquation(n3[0],n3[1],n3[2],D,x,y,z);
		x[0]=p2[0];	x[1]=p4[0];	x[2]=p3[0];
		y[0]=p2[1];	y[1]=p4[1];	y[2]=p3[1];
		z[0]=p2[2];	z[1]=p4[2];	z[2]=p3[2];
		geo.CalPlaneEquation(n4[0],n4[1],n4[2],D,x,y,z);
		double r;
		r=n3[0]*n1[0]+n3[1]*n1[1]+n3[2]*n1[2];
		if (r<0.0) return false;
		r=n3[0]*n2[0]+n3[1]*n2[1]+n3[2]*n2[2];
		if (r<0.0) return false;
		r=n4[0]*n1[0]+n4[1]*n1[1]+n4[2]*n1[2];
		if (r<0.0) return false;
		r=n4[0]*n2[0]+n4[1]*n2[1]+n4[2]*n2[2]; 
		if (r<0.0) return false;
	}

	return true;
}

double QTopologyOperator::edgeCollapseShapeFunc(QMeshEdge *edge)
{
	double value,pp1[3],pp2[3],pp3[3],pp4[3],ll,l1,l2,l3,l4;
	GLKGeometry geo;	int i;

	QMeshNode *startPnt=edge->GetStartPoint();
	QMeshNode *endPnt=edge->GetEndPoint();

	QMeshFace *leftFace=edge->GetLeftFace();
	QMeshFace *rightFace=edge->GetRightFace();

	QMeshNode *pnt1,*pnt2;
	for(i=0;i<3;i++)
	{
		QMeshNode *tempNode=rightFace->GetNodeRecordPtr(i);
		if ( (tempNode!=startPnt) && (tempNode!=endPnt) ) {pnt1=tempNode;break;}
	}
	for(i=0;i<3;i++)
	{
		QMeshNode *tempNode=leftFace->GetNodeRecordPtr(i);
		if ( (tempNode!=startPnt) && (tempNode!=endPnt) ) {pnt2=tempNode;break;}
	}

	startPnt->GetCoord3D(pp1[0],pp1[1],pp1[2]);
	endPnt->GetCoord3D(pp2[0],pp2[1],pp2[2]);
	pnt2->GetCoord3D(pp3[0],pp3[1],pp3[2]);
	pnt1->GetCoord3D(pp4[0],pp4[1],pp4[2]);

	ll=geo.Distance_to_Point(pp1,pp2);
	l1=geo.Distance_to_Point(pp1,pp3);
	l2=geo.Distance_to_Point(pp1,pp4);
	l3=geo.Distance_to_Point(pp2,pp3);
	l4=geo.Distance_to_Point(pp2,pp4);

	value=ll*4.0/(l1+l2+l3+l4);

	return value;
}

double QTopologyOperator::edgeSwapShapeFunc(QMeshEdge *edge, Voxel4DField *vox4DField, double criterion)
{
	double value;
	int i;

	if (vox4DField) {
		double boxSize=vox4DField->GetBoxSize();
		if (QGeometryComputing::distanceFromMidEdgePntToSurface(edge,vox4DField)
			>(criterion*boxSize)) return 1.0e+32;
	}
	if (edge->GetAttribFlag(0)) return 1.0e+32;

	QMeshNode *startPnt=edge->GetStartPoint();
	QMeshNode *endPnt=edge->GetEndPoint();

	QMeshFace *leftFace=edge->GetLeftFace();
	QMeshFace *rightFace=edge->GetRightFace();

	QMeshNode *pnt1,*pnt2;
	for(i=0;i<3;i++)
	{
		QMeshNode *tempNode=rightFace->GetNodeRecordPtr(i);
		if ( (tempNode!=startPnt) && (tempNode!=endPnt) ) {pnt1=tempNode;break;}
	}
	for(i=0;i<3;i++)
	{
		QMeshNode *tempNode=leftFace->GetNodeRecordPtr(i);
		if ( (tempNode!=startPnt) && (tempNode!=endPnt) ) {pnt2=tempNode;break;}
	}

	double p1[3],p2[3],p3[3],p4[3];
	startPnt->GetCoord3D(p1[0],p1[1],p1[2]);
	endPnt->GetCoord3D(p2[0],p2[1],p2[2]);
	pnt1->GetCoord3D(p3[0],p3[1],p3[2]);
	pnt2->GetCoord3D(p4[0],p4[1],p4[2]);

	///////////////////////////////////////////
	//	Compute the angles
	double min,min1,min2;
	min1=QGeometryComputing::minimumAngleInTrgl(p1,p3,p2);
	min=QGeometryComputing::minimumAngleInTrgl(p1,p2,p4);
	if (min<min1) min1=min;

	min2=QGeometryComputing::minimumAngleInTrgl(p1,p3,p4);
	min=QGeometryComputing::minimumAngleInTrgl(p2,p4,p3);
	if (min<min2) min2=min;

	value=min1/min2;

	///////////////////////////////////////////
	//	Check by normal
	if (!edgeSwapNormalCheck(edge)) value=1.0e+10;
//	if (!edgeSwapProtectTopology(edge)) value=1.0e+10;

	return value;
}

void QTopologyOperator::edgeCollapseOperator(QMeshEdge *edge, GLKHeap *collapseHeap, 
											 double targetLength, bool byLengthOrShapeFunc)
{
	GLKPOSITION Pos;
	double pp[3],pp1[3],pp2[3];	int i;

	////////////////////////////////////////////////////////////////////////////////////
	//	Data preparation stage
	QMeshNode *startPnt=edge->GetStartPoint();
	QMeshNode *endPnt=edge->GetEndPoint();
	QMeshFace *leftFace=edge->GetLeftFace();
	QMeshFace *rightFace=edge->GetRightFace();
	QMeshEdge *e1=NULL,*e2=NULL,*e3=NULL,*e4=NULL;
	//----------------------------------------------------------------------------
	if (rightFace)
	for(i=0;i<3;i++) 
	{
		QMeshEdge *tempEdge=rightFace->GetEdgeRecordPtr(i);
		if (tempEdge==edge) continue;
		if (((tempEdge->GetStartPoint())==startPnt) || ((tempEdge->GetEndPoint())==startPnt))
			e2=tempEdge;
		if (((tempEdge->GetStartPoint())==endPnt) || ((tempEdge->GetEndPoint())==endPnt))
			e1=tempEdge;
	}
	if (leftFace)
	for(i=0;i<3;i++) 
	{
		QMeshEdge *tempEdge=leftFace->GetEdgeRecordPtr(i);
		if (tempEdge==edge) continue;
		if (((tempEdge->GetStartPoint())==startPnt) || ((tempEdge->GetEndPoint())==startPnt))
			e4=tempEdge;
		if (((tempEdge->GetStartPoint())==endPnt) || ((tempEdge->GetEndPoint())==endPnt))
			e3=tempEdge;
	}
	//----------------------------------------------------------------------------
	QMeshFace *f1=NULL,*f2=NULL;
	if (e1)
	{
		if ((e1->GetLeftFace())==rightFace)
			f1=e1->GetRightFace();
		else
			f1=e1->GetLeftFace();
	}
	if (e3)
	{
		if ((e3->GetLeftFace())==leftFace)
			f2=e3->GetRightFace();
		else
			f2=e3->GetLeftFace();
	}
	//----------------------------------------------------------------------------
	QMeshNode *pnt1=NULL,*pnt2=NULL;
	if (rightFace)
	for(i=0;i<3;i++)
	{
		QMeshNode *tempNode=rightFace->GetNodeRecordPtr(i);
		if ( (tempNode!=startPnt) && (tempNode!=endPnt) ) {pnt1=tempNode;break;}
	}
	if (leftFace)
	for(i=0;i<3;i++)
	{
		QMeshNode *tempNode=leftFace->GetNodeRecordPtr(i);
		if ( (tempNode!=startPnt) && (tempNode!=endPnt) ) {pnt2=tempNode;break;}
	}

	//-------------------------------------------------------------------------------------
	//	Remove the linkage between QuadMesh faces and TrglMesh faces
	if (!(rightFace->GetAttachedList().IsEmpty())) {
		QMeshFace *tempFace=(QMeshFace *)(rightFace->GetAttachedList().GetTail());
		GLKPOSITION PosTemp;
		for(PosTemp=tempFace->GetAttachedList().GetHeadPosition();PosTemp!=NULL;) {
			QMeshFace *tempFace2=(QMeshFace *)(tempFace->GetAttachedList().GetNext(PosTemp));
			tempFace2->GetAttachedList().RemoveAll();
		}
		tempFace->GetAttachedList().RemoveAll();
	}
	if (!(leftFace->GetAttachedList().IsEmpty())) {
		QMeshFace *tempFace=(QMeshFace *)(leftFace->GetAttachedList().GetTail());
		GLKPOSITION PosTemp;
		for(PosTemp=tempFace->GetAttachedList().GetHeadPosition();PosTemp!=NULL;) {
			QMeshFace *tempFace2=(QMeshFace *)(tempFace->GetAttachedList().GetNext(PosTemp));
			tempFace2->GetAttachedList().RemoveAll();
		}
		tempFace->GetAttachedList().RemoveAll();
	}
	//-------------------------------------------------------------------------------------
	//	Remove the linkage between QuadMesh nodes and TrglMesh nodes (at endPnt)
	if (!(endPnt->attachedList.IsEmpty())) {
		QMeshNode *tempNode=(QMeshNode *)(endPnt->attachedList.GetTail());
		tempNode->attachedList.RemoveAll();
		endPnt->attachedList.RemoveAll();
	}

	/////////////////////////////////////////////////////////////////////////////////
	//	Begin doing collapse now

	//-------------------------------------------------------------------------------
	//	Step 1: Calculate the new position of the collapsed point and the new 
	startPnt->GetCoord3D(pp1[0],pp1[1],pp1[2]);
	endPnt->GetCoord3D(pp2[0],pp2[1],pp2[2]);
	int num1,num2;	num1=0;	num2=0;
	for(Pos=(endPnt->GetEdgeList()).GetHeadPosition();Pos!=NULL;) {
		QMeshEdge *tempEdge=(QMeshEdge *)((endPnt->GetEdgeList()).GetNext(Pos));
		if (tempEdge->GetStartPoint()==endPnt) {
			if (tempEdge->GetEndPoint()->GetAttribFlag(5)) num1++;
		}
		else {
			if (tempEdge->GetStartPoint()->GetAttribFlag(5)) num1++;
		}
	}
	for(Pos=(startPnt->GetEdgeList()).GetHeadPosition();Pos!=NULL;) {
		QMeshEdge *tempEdge=(QMeshEdge *)((startPnt->GetEdgeList()).GetNext(Pos));
		if (tempEdge->GetStartPoint()==startPnt) {
			if (tempEdge->GetEndPoint()->GetAttribFlag(5)) num2++;
		}
		else {
			if (tempEdge->GetStartPoint()->GetAttribFlag(5)) num2++;
		}
	}
	if (num1>num2) {
		startPnt->SetCoord3D(pp1[0],pp1[1],pp1[2]);
	}
	else if (num2>num1) {
		startPnt->SetCoord3D(pp2[0],pp2[1],pp2[2]);
	}
	else {
		pp[0]=(pp1[0]+pp2[0])/2.0;	pp[1]=(pp1[1]+pp2[1])/2.0;	pp[2]=(pp1[2]+pp2[2])/2.0;
		startPnt->SetCoord3D(pp[0],pp[1],pp[2]);
	}
	if ( (startPnt->GetAttribFlag(0)==true) && (endPnt->GetAttribFlag(0)!=true) ) 
		startPnt->SetCoord3D(pp1[0],pp1[1],pp1[2]);
	if ( (startPnt->GetAttribFlag(0)!=true) && (endPnt->GetAttribFlag(0)==true) ) 
		startPnt->SetCoord3D(pp2[0],pp2[1],pp2[2]);


	//-------------------------------------------------------------------------------
	//	Step 2: Edge Collapse
	bool e2Flag,e4Flag;
	if (e2)
	{
		if ((e2->GetLeftFace())==rightFace)
			{ e2->SetLeftFace(f1); e2Flag=true;	}
		else
			{ e2->SetRightFace(f1); e2Flag=false; }
	}
	if (e4)
	{
		if ((e4->GetLeftFace())==leftFace)
			{ e4->SetLeftFace(f2); e4Flag=true; }
		else
			{ e4->SetRightFace(f2); e4Flag=false; }
	}
	if (f1) {
		for(i=0;i<3;i++) {
			if ((f1->GetEdgeRecordPtr(i))==e1)
			{
				f1->SetEdgeRecordPtr(i,e2);
				f1->SetDirectionFlag(i,e2Flag);
				break;
			}
		}
	}
	if (f2) {
		for(i=0;i<3;i++) {
			if ((f2->GetEdgeRecordPtr(i))==e3)
			{
				f2->SetEdgeRecordPtr(i,e4);
				f2->SetDirectionFlag(i,e4Flag);
				break;
			}
		}
	}

	//-------------------------------------------------------------------------------
	//	Step 3: Remove leftFace and rightFace from triangle lists of startPnt, pnt1, & pnt2
	(startPnt->GetFaceList()).Remove(leftFace);
	(startPnt->GetFaceList()).Remove(rightFace);
	if (pnt1) (pnt1->GetFaceList()).Remove(rightFace);
	if (pnt2) (pnt2->GetFaceList()).Remove(leftFace);

	//-------------------------------------------------------------------------------
	//	Step 4: Remove e1 and e3 from edge lists of pnt1 & pnt2;
	//			Remove edge from edge lists of startPnt & endPnt
	if (pnt1) (pnt1->GetEdgeList()).Remove(e1);
	if (pnt2) (pnt2->GetEdgeList()).Remove(e3);
	(startPnt->GetEdgeList()).Remove(edge);

	//-------------------------------------------------------------------------------
	//	Step 5: Node Collapse
	for(Pos=(endPnt->GetEdgeList()).GetHeadPosition();Pos!=NULL;) {
		QMeshEdge *tempEdge=(QMeshEdge *)((endPnt->GetEdgeList()).GetNext(Pos));
		if ( (tempEdge==edge) || (tempEdge==e1) || (tempEdge==e3) ) continue;
		if ( (tempEdge->GetStartPoint())==endPnt)
			tempEdge->SetStartPoint(startPnt);
		else
			tempEdge->SetEndPoint(startPnt);
		(startPnt->GetEdgeList()).AddTail(tempEdge);
	}
	for(Pos=(endPnt->GetFaceList()).GetHeadPosition();Pos!=NULL;) {
		QMeshFace *tempFace=(QMeshFace *)((endPnt->GetFaceList()).GetNext(Pos));
		if ( (tempFace==leftFace) || (tempFace==rightFace) ) continue;
		(startPnt->GetFaceList()).AddTail(tempFace);
	}

	//-------------------------------------------------------------------------------
	//	Combine Flags of QMeshEdges
	for(i=0;i<8;i++)
	{
		if (rightFace) e2->SetAttribFlag(i,(e1->GetAttribFlag(i) || e2->GetAttribFlag(i)));
		if (leftFace) e4->SetAttribFlag(i,(e3->GetAttribFlag(i) || e4->GetAttribFlag(i)));
	}
	//-------------------------------------------------------------------------------
	//	Combine Flags of QMeshNodes
	for(i=0;i<8;i++) {
		startPnt->SetAttribFlag(i,
			(startPnt->GetAttribFlag(i) || endPnt->GetAttribFlag(i)));
		endPnt->SetAttribFlag(i,
			(startPnt->GetAttribFlag(i) || endPnt->GetAttribFlag(i)));
	}
	//-------------------------------------------------------------------------------
	//	Combine sewing nodes
	startPnt->GetNodeList().AddTail(&(endPnt->GetNodeList()));
	startPnt->GetCoord3D(pp[0],pp[1],pp[2]);
	for(Pos=endPnt->GetNodeList().GetHeadPosition();Pos!=NULL;) {
		QMeshNode *tempNode=(QMeshNode *)(endPnt->GetNodeList().GetNext(Pos));
		tempNode->GetNodeList().Remove(endPnt);
		tempNode->GetNodeList().AddTail(startPnt);
	}
	for(Pos=startPnt->GetNodeList().GetHeadPosition();Pos!=NULL;) {
		QMeshNode *tempNode=(QMeshNode *)(startPnt->GetNodeList().GetNext(Pos));
		tempNode->SetCoord3D(pp[0],pp[1],pp[2]);
	}


	/////////////////////////////////////////////////////////////////////////////////
	//	Delete some QMeshNode, QMeshEdge, and QMeshFace
	endPnt->SetIndexNo(0);	
	edge->SetIndexNo(0);	edge->SetLeftFace(NULL);	edge->SetRightFace(NULL);
	if (rightFace) 
	{
		e1->SetIndexNo(0);	e1->SetLeftFace(NULL);	e1->SetRightFace(NULL);
		if (!(e1->GetAttachedList().IsEmpty())) {
			GLKHeapNode *heapNode=(GLKHeapNode*)(e1->GetAttachedList().GetTail());
			collapseHeap->Remove(heapNode);
			delete heapNode;
			e1->GetAttachedList().RemoveAll();
		}
	}
	if (leftFace) 
	{
		e3->SetIndexNo(0);	e3->SetLeftFace(NULL);	e3->SetRightFace(NULL);
		if (!(e3->GetAttachedList().IsEmpty())) {
			GLKHeapNode *heapNode=(GLKHeapNode*)(e3->GetAttachedList().GetTail());
			collapseHeap->Remove(heapNode);
			delete heapNode;
			e3->GetAttachedList().RemoveAll();
		}
	}
	if (leftFace) leftFace->SetIndexNo(0);
	if (rightFace) rightFace->SetIndexNo(0);

	if (!collapseHeap) return;

	/////////////////////////////////////////////////////////////////////////////////
	//	Update the cost of all valid pairs involving startPnt
	for(Pos=startPnt->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
		QMeshEdge *tempEdge=(QMeshEdge *)(startPnt->GetEdgeList().GetNext(Pos));
		if (tempEdge->GetAttribFlag(0)) continue;
		if (!(tempEdge->GetAttachedList().IsEmpty())) {
			GLKHeapNode *heapNode=(GLKHeapNode*)(tempEdge->GetAttachedList().GetTail());
			if (byLengthOrShapeFunc)
				heapNode->SetValue((float)(tempEdge->CalLength()/targetLength));
			else
				heapNode->SetValue((float)(edgeCollapseShapeFunc(tempEdge)));
			collapseHeap->AdjustPosition(heapNode);
		}
	}
}

bool QTopologyOperator::edgeCollapseProtectTopology(QMeshEdge *edge)
{
	GLKPOSITION PosEdge;
	GLKPOSITION PosEdge2;
	QMeshNode *startNode,*endNode,*node1,*node2;
	int n;

	startNode=edge->GetStartPoint();
	endNode=edge->GetEndPoint();
	n=0;
	for(PosEdge=startNode->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
		QMeshEdge *edge=(QMeshEdge *)(startNode->GetEdgeList().GetNext(PosEdge));
		if (edge->GetStartPoint()==startNode)
			node1=edge->GetEndPoint();
		else
			node1=edge->GetStartPoint();

		for(PosEdge2=endNode->GetEdgeList().GetHeadPosition();PosEdge2!=NULL;) {
			QMeshEdge *edge2=(QMeshEdge *)(endNode->GetEdgeList().GetNext(PosEdge2));
			if (edge2->GetStartPoint()==endNode)
				node2=edge2->GetEndPoint();
			else
				node2=edge2->GetStartPoint();

			if (node1==node2) n++;
		}
	}

	if (n!=2) return false;
	return true;
}
