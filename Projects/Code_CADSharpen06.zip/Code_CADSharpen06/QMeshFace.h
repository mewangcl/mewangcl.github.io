// QMeshFace.h: interface for the QMeshFace class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _CW_QMESHFACE
#define _CW_QMESHFACE

#include "../GLKLib/GLKObList.h"

#define MAX_EDGE_NUM	10

class QMeshPatch;
class QMeshEdge;
class QMeshNode;

class QMeshFace : public GLKObject  
{
public:
	QMeshFace();
	virtual ~QMeshFace();

public:
	bool GetAttribFlag( const int whichBit );
	void SetAttribFlag( const int whichBit, const bool toBe = true );

	int GetIndexNo();		//from 1 to n
	void SetIndexNo( const int _index = 1 );

	bool IsNormalDirection( const int whichEdge );
	void SetDirectionFlag( const int whichEdge, const bool toBe = true );

	QMeshEdge * GetEdgeRecordPtr( const int whichEdge );
	void SetEdgeRecordPtr( const int whichEdge, QMeshEdge * _edge = NULL );
	int GetEdgeNum();
	void SetEdgeNum(int num);
		
	void GetNodePos( const int whichNode, double &xx, double &yy, double &zz);
	QMeshNode * GetNodeRecordPtr( const int whichNode );

	void SetColor(float r, float g, float b);
	void GetColor(float &r, float &g, float &b);

	void GetPlaneEquation( double & A, double & B, double & C, double & D ); 
	void CalPlaneEquation( ); 
						// to calculate the plane equation parameter
	                    // Plane equation:  Ax + By + Cz + D = 0, and
                        // Vector(A,B,C) is positive unit normal vector of this plane
	void SetNormal(double nx, double ny, double nz);
	void SetPlaneEquation( double A, double B, double C, double D ); 

	void CalCenterPos(double &xx, double &yy, double &zz);
	void GetCenterPos(double &xx, double &yy, double &zz) {
		xx=centerPos[0];	yy=centerPos[1];	zz=centerPos[2];
	};
	void CalBoundingBox(double &xmin, double &ymin, double &zmin,
						double &xmax, double &ymax, double &zmax);
	double CalArea();
	double GetArea() {return m_area;};

	void SetMeshPatchPtr(QMeshPatch* _mesh);
	QMeshPatch* GetMeshPatchPtr();

    GLKObList& GetAttachedList() {return attachedList;};
	int nSplittedNode;

	int m_nIdentifiedPatchIndex;
	float m_weight;
//	float m_intrinsicProperty[4];
	double m_GaussArea;

private:
	int indexno;
	bool flags[8];
		// 0 - for boundary faces
		// 1 - for sharp-feature region faces	
		// 2 - ...
		// 3 - for temp use
		// 7 - for temp use	
	
		// 0, 1, 2, 3, ... edges construct an anti-clockwise closed loop
                                      //**********************************
                                      //             point1              *
                                      //              /\                 *
                                      //    1 edge  /    \ _             *
                                      //         |_       |\ 0 edge      *
                                      //        /            \           *
                                      //      /                \         *
                                      //  point2 ------>-------- point0  *
	                                  //              2 edge             *
	                                  //**********************************
	QMeshEdge * edges[MAX_EDGE_NUM];	//	edges
	bool edgeDir[MAX_EDGE_NUM];			//	edge directions
	int edgeNum;

	QMeshPatch *meshSurface;	// MESHSURFACE contain this triangle
	double  abcd[4];	// plane equation
	float	rgb[3];		// the color of the face

	double centerPos[3];
	double m_area;

	GLKObList attachedList;	// a list of attached object
};

#endif
