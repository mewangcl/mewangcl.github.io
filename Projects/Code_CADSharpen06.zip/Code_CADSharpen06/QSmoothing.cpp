// QSmoothing.cpp: implementation of the QSmoothing class.
//
//////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "..\GLKLib\GLKObList.h"
#include "..\GLKLib\GLKGeometry.h"
#include "..\GLKLib\GLKHeap.h"
#include "..\GLKLib\GLKNearestNeighbor.h"

#include "..\QMeshLib\QMeshPatch.h"
#include "..\QMeshLib\QMeshFace.h"
#include "..\QMeshLib\QMeshEdge.h"
#include "..\QMeshLib\QMeshNode.h"

#include "..\Voxel4DLib\Voxel4DField.h"
#include "..\Voxel4DLib\UniformDistField.h"

#include "QMeshIntrinsicPropComputing.h"
#include "QGeometryComputing.h"

#include "QSmoothing.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QSmoothing::QSmoothing()
{

}

QSmoothing::~QSmoothing()
{

}

//////////////////////////////////////////////////////////////////////
// Implementation
//////////////////////////////////////////////////////////////////////

void QSmoothing::AnisotropicDiffusionSmoothing(GLKObList* meshList)
{
	GLKPOSITION Pos;
	GLKPOSITION PosNode;
	GLKPOSITION PosFace;
	QMeshPatch *mesh;
	QMeshFace *face;
	QMeshNode *node;
	double k1,k2,kh,hx,hy,hz,ww,threshold,fx,fy,fz,dT,dx,dy,dz;
	double pp[3],ll;

	LaplacianMeshSmoothing(meshList,2);  // mollification

	ll=QGeometryComputing::computeAverageEdgeLength(meshList);
	threshold=1.0/ll*0.05;
	dT=0.00001;

	//----------------------------------------------------------------------------------
	//	do some preparation work
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->CalPlaneEquation();
		}
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			node->CalNormal();
			node->GetCoord3D(pp[0],pp[1],pp[2]);
			node->SetCoord3D_last(pp[0],pp[1],pp[2]);
		}
	}

	//----------------------------------------------------------------------------------
	//	Anisotropic diffusion of mean curvature normal vector
	for(int iter=0;iter<100;iter++) {
//		if (iter==500) threshold=threshold*2.0;
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			QMeshIntrinsicPropComputing::MeanCurvatureNormalVectorComputing(mesh);
			QMeshIntrinsicPropComputing::GaussianCurvatureValueComputing(mesh);
			QMeshIntrinsicPropComputing::PrincipalCurvatureValueComputing(mesh);
		}

		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
				QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
				if (node->GetAttribFlag(0)) continue;
				node->GetCoord3D_last(pp[0],pp[1],pp[2]);

				k1=node->GetPMaxCurvature();	k2=node->GetPMinCurvature();
				node->GetMeanCurvatureNormalVector(hx,hy,hz);
				kh=sqrt(hx*hx+hy*hy+hz*hz);
				if (fabs(kh)>1.0e-8)
					{hx=hx/kh;	hy=hy/kh;	hz=hz/kh;}
				else
					{hx=0.0;	hy=0.0;		hz=0.0;}
				kh=kh/2.0;

				node->SetAttribFlag(5,true);

				//----------------------------------------------------------------------
				//	determine the anisotropic diffusion weight
				double minK=fabs(k1);
				if (fabs(k2)<=minK) minK=fabs(k2);
				if (kh<minK) minK=kh;
				ww=0.0;
				if ((fabs(k1)<=threshold) && (fabs(k2)<=threshold)) {
					ww=1.0;
					node->SetAttribFlag(5,false);
				}
				else if ((fabs(k1)>threshold) && (fabs(k2)>threshold) && (k1*k2>0.0)) {
					ww=0.0;
				}
				else if (fabs(k1)==minK) {
					ww=k1/kh;
				}
				else if (fabs(k2)==minK) {
					ww=k2/kh;
				}
				else if (kh==minK) {
					ww=1.0;
					node->SetAttribFlag(5,false);
				}
				if (ww<-0.01) ww=-0.01;

				fx=-ww*hx*kh;	fy=-ww*hy*kh;	fz=-ww*hz*kh;
				dx=dT*fx;	dy=dT*fy;	dz=dT*fz;
				node->SetCoord3D(pp[0]+dx,pp[1]+dy,pp[2]+dz);
			}
		}

		//----------------------------------------------------------------------------------
		//	update the normals
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
				face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
				face->CalPlaneEquation();
			}
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
				node->CalNormal();
				node->GetCoord3D(pp[0],pp[1],pp[2]);
				node->SetCoord3D_last(pp[0],pp[1],pp[2]);
			}
		}
	}
}

void QSmoothing::BilateralDenoising(GLKObList* meshList, double deltaFscale, double deltaGscale,
									bool bSharpFeatureOnly, int nSteps, bool bByAverageEdgeLength)
{
	double deltaF,deltaG,ll,sum,tt,hh,normalizer,ws,wc;
	int iter;
	GLKPOSITION Pos;
	GLKPOSITION PosFace;
	GLKPOSITION PosNode;
	GLKPOSITION PosEdge;
	GLKPOSITION PosNode2;
	QMeshPatch *mesh;
	QMeshFace *face;
	QMeshEdge *edge;
	QMeshNode *node,*linkedNode;
	double vPos[3],qPos[3],normal[3];
	GLKGeometry geo;

	//----------------------------------------------------------------------------------
	//	Step 1: compute deltaF and deltaG
	if (bByAverageEdgeLength)
		ll=QGeometryComputing::computeAverageEdgeLength(meshList);
	else
		ll=1.0;
	deltaF=ll*deltaFscale;	deltaG=ll*deltaGscale;

	//----------------------------------------------------------------------------------
	//	do some preparation work
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->CalPlaneEquation();
		}
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			node->CalNormal();
			node->GetCoord3D(vPos[0],vPos[1],vPos[2]);
			node->SetCoord3D_last(vPos[0],vPos[1],vPos[2]);
		}
	}

	//----------------------------------------------------------------------------------
	//	Step 2: Preparing the neighborhood of vertices
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			if (bSharpFeatureOnly && (!(node->GetAttribFlag(5)))) continue;
			node->attachedList.RemoveAll();

			for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
				edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
				if (edge->GetStartPoint()==node)
					linkedNode=edge->GetEndPoint();
				else
					linkedNode=edge->GetStartPoint();

				node->attachedList.AddTail(linkedNode);
			}
		}
	}

	//----------------------------------------------------------------------------------
	//	Step 3: interatively move vertices along their normals
	for(iter=0;iter<nSteps;iter++) {
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
				if (bSharpFeatureOnly && (!(node->GetAttribFlag(5)))) continue;
				if ((!bSharpFeatureOnly) && (node->GetAttribFlag(0))) continue;

				node->GetCoord3D_last(vPos[0],vPos[1],vPos[2]);
				node->GetNormal(normal[0],normal[1],normal[2]);

				sum=0.0;
				normalizer=0.0;

				for(PosNode2=node->attachedList.GetHeadPosition();PosNode2!=NULL;) {
					linkedNode=(QMeshNode *)(node->attachedList.GetNext(PosNode2));
					linkedNode->GetCoord3D(qPos[0],qPos[1],qPos[2]);

					tt=geo.Distance_to_Point(vPos,qPos);
					hh=normal[0]*(vPos[0]-qPos[0])+normal[1]*(vPos[1]-qPos[1])+normal[2]*(vPos[2]-qPos[2]);
					hh=-hh;
					wc=exp(-(tt*tt)/(2.0*deltaF*deltaF));
					ws=exp(-(hh*hh)/(2.0*deltaG*deltaG));

					sum=sum+wc*ws*hh;
					normalizer=normalizer+wc*ws;
				}
				
				sum=sum/normalizer;
				node->SetCoord3D(vPos[0]+normal[0]*sum,vPos[1]+normal[1]*sum,vPos[2]+normal[2]*sum);
			}
		}

		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
				node->GetCoord3D(vPos[0],vPos[1],vPos[2]);
				node->SetCoord3D_last(vPos[0],vPos[1],vPos[2]);
			}
		}
	}

	//----------------------------------------------------------------------------------
	//	Recompute the surface and vertex normal
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->CalPlaneEquation();
		}
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			node->CalNormal();
		}
	}
}

void QSmoothing::BilateralFiltering2(GLKObList* meshList, 
									 double deltaFscale, double deltaGscale,
									 bool bMollification, int nSteps, 
									 bool bRelativeToMeanEdgeLength)
{
	class QFacet : public GLKObject {
		public:
			double m_normal[3];
			double m_pos[3];
			double m_area;
	};
	double deltaF,deltaG;
	double pp[3],pp1[3],pp2[3];
	double dd,ll,xx,yy,zz,kp,cx,cy,cz,xmin,xmax,ymin,ymax,zmin,zmax;
	double boxScale,area,temp,df,dg;
	int xNum,yNum,zNum;
	int i,j,k,ii,jj,kk,i1,i2,j1,j2,k1,k2,n,num,iter;
	double x1,x2,y1,y2,z1,z2;
	GLKPOSITION Pos;
	GLKPOSITION PosFace;
	GLKPOSITION PosNode;
	QMeshPatch *mesh;
	QMeshFace *face;
	QMeshNode *node;
	GLKObList ****boxArray;
	GLKGeometry geo;

	//----------------------------------------------------------------------------------
	//	Step 1: compute deltaF and deltaG
	if (bRelativeToMeanEdgeLength) {
		ll=QGeometryComputing::computeAverageEdgeLength(meshList);
		deltaF=ll*deltaFscale;	deltaG=ll*deltaGscale;	
	}
	else {
		deltaF=deltaFscale;	deltaG=deltaGscale;	
	}
	boxScale=deltaF;
	printf("deltaF=%lf\ndeltaG=%lf\nboxSize=%lf\n",deltaF,deltaG,boxScale);

	//----------------------------------------------------------------------------------
	//	Step 2: malloc the memory and prepare the boxes
	//--------------------------------------------------------------------------------------
	xmin=1.0e+32;	xmax=-1.0e+32;	
	ymin=1.0e+32;	ymax=-1.0e+32;
	zmin=1.0e+32;	zmax=-1.0e+32;
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			n=face->GetIndexNo();
			num=face->GetEdgeNum();
			face->CalCenterPos(cx,cy,cz);

			if (cx>xmax) xmax=cx;
			if (cx<xmin) xmin=cx;
			if (cy>ymax) ymax=cy;
			if (cy<ymin) ymin=cy;
			if (cz>zmax) zmax=cz;
			if (cz<zmin) zmin=cz;

			face->GetAttachedList().RemoveAll();
		}
	}
	//----------------------------------------------------------------------------------
	//	build the boxes array
	xNum=(int)((xmax-xmin)/boxScale)+2;
	yNum=(int)((ymax-ymin)/boxScale)+2;
	zNum=(int)((zmax-zmin)/boxScale)+2;
	boxArray=(GLKObList ****)new long[xNum];
	for(i=0;i<xNum;i++) {
		boxArray[i]=(GLKObList ***)new long[yNum];
		for(j=0;j<yNum;j++) {
			boxArray[i][j]=(GLKObList **)new long[zNum];
			for(k=0;k<zNum;k++) {
				boxArray[i][j][k]=new GLKObList;
				boxArray[i][j][k]->RemoveAll();
			}
		}
	}

	//----------------------------------------------------------------------------------
	//	Step 3: insert facets into boxes
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->CalBoundingBox(x1,y1,z1,x2,y2,z2);
			i1=(int)((x1-xmin)/boxScale);
			j1=(int)((y1-ymin)/boxScale);
			k1=(int)((z1-zmin)/boxScale);
			i2=(int)((x2-xmin)/boxScale)+1;
			j2=(int)((y2-ymin)/boxScale)+1;
			k2=(int)((z2-zmin)/boxScale)+1;
			for(i=i1;i<=i2;i++) {
				for(j=j1;j<=j2;j++) {
					for(k=k1;k<=k2;k++) {
						double*xp,*yp,*zp;	int pntNum=3;
						xp=new double[3];	yp=new double[3];	zp=new double[3];
						face->GetNodePos(0,xp[0],yp[0],zp[0]);
						face->GetNodePos(1,xp[1],yp[1],zp[1]);
						face->GetNodePos(2,xp[2],yp[2],zp[2]);

						geo.ClipPolygonByCube(xp,yp,zp,pntNum,xmin+(double)i*boxScale,
									ymin+(double)j*boxScale,zmin+(double)k*boxScale,boxScale);
						if ((pntNum==1) || (pntNum==2))	printf("WARNING!\n");
						if (pntNum>0) {
							QFacet *ft=new QFacet;

							geo.SpatialPolygonCenter(xp,yp,zp,pntNum,ft->m_pos);
							ft->m_area=geo.SpatialPolygonArea(xp,yp,zp,pntNum);
							face->GetPlaneEquation(ft->m_normal[0],ft->m_normal[1],
																	ft->m_normal[2],dd);

							delete xp;	delete yp;	delete zp;

							boxArray[i][j][k]->AddTail(ft);
							face->GetAttachedList().AddTail(ft);
						}
					}
				}
			}
		}
	}

	//----------------------------------------------------------------------------------
	//	Step 4: search the related polygons of each vertex (in the region of range)
	int timesOfDeltaF=2;
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			//----------------------------------------------------------------------------------
			//	search the related polygons of each vertex (in the region of range)
			(node->attachedList).RemoveAll();
			node->GetCoord3D(pp[0],pp[1],pp[2]);
			i=(int)((pp[0]-xmin)/boxScale);
			j=(int)((pp[1]-ymin)/boxScale);
			k=(int)((pp[2]-zmin)/boxScale);
			for(ii=i-timesOfDeltaF;ii<=i+timesOfDeltaF;ii++) {
				if (ii<0) continue;
				if (ii>=xNum) continue;
				for(jj=j-timesOfDeltaF;jj<=j+timesOfDeltaF;jj++) {
					if (jj<0) continue;
					if (jj>=yNum) continue;
					for(kk=k-timesOfDeltaF;kk<=k+timesOfDeltaF;kk++) {
						if (kk<0) continue;
						if (kk>=zNum) continue;

						for(PosFace=boxArray[ii][jj][kk]->GetHeadPosition();PosFace!=NULL;) {
							QFacet *ft=(QFacet *)(boxArray[ii][jj][kk]->GetNext(PosFace));

							ll=geo.Distance_to_Point(pp,ft->m_pos);
							if (ll<=(2.0*deltaF)) 
								(node->attachedList).AddTail(ft);
						}
					}
				}
			}
		}
	}

	//----------------------------------------------------------------------------------
	//	Step 5: Mollification
	if (bMollification) {
		deltaF=deltaF*0.5;
		//----------------------------------------------------------------------------------
		//	Backup the original coordinates
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
				node->GetCoord3D(pp[0],pp[1],pp[2]);
				node->SetCoord3D_last(pp[0],pp[1],pp[2]);
			}
		}

		//	Filtering the normals
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));

				node->GetCoord3D(pp[0],pp[1],pp[2]);

				xx=0.0;	yy=0.0;	zz=0.0;	kp=0.0;
				for(PosFace=(node->attachedList).GetHeadPosition();PosFace!=NULL;) {
					QFacet* ft=(QFacet*)((node->attachedList).GetNext(PosFace));

					area=ft->m_area;
					pp2[0]=ft->m_pos[0];
					pp2[1]=ft->m_pos[1];
					pp2[2]=ft->m_pos[2];

					df=geo.Distance_to_Point(ft->m_pos,pp);
					temp=area*gaussianErrorNorm(df,deltaF);

					kp=kp+temp;
					xx=xx+temp*pp2[0];
					yy=yy+temp*pp2[1];
					zz=zz+temp*pp2[2];
				}
				if (kp!=0.0) {
					xx=xx/kp;	yy=yy/kp;	zz=zz/kp;
					node->SetCoord3D(xx,yy,zz);
				}
			}
		}
		
		//----------------------------------------------------------------------------------
		//	Compute the new normal vectors
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
				face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
				face->CalPlaneEquation();
			}
		}
		//----------------------------------------------------------------------------------
		//	Restore the original coordinates
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
				node->GetCoord3D_last(pp[0],pp[1],pp[2]);
				node->SetCoord3D(pp[0],pp[1],pp[2]);
			}
		}

		//----------------------------------------------------------------------------------
		//	Re-set the facet' normal
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
				face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
				for(PosNode=face->GetAttachedList().GetHeadPosition();PosNode!=NULL;) {
					QFacet *ft=(QFacet *)(face->GetAttachedList().GetNext(PosNode));
					face->GetPlaneEquation(ft->m_normal[0],ft->m_normal[1],
																ft->m_normal[2],dd);
				}
			}
		}

		//----------------------------------------------------------------------------------
		deltaF=deltaF*2.0;
	}

	//----------------------------------------------------------------------------------
	//	Step 6: Bilateral Filtering
	for(iter=0;iter<nSteps;iter++) {
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));

				node->GetCoord3D(pp[0],pp[1],pp[2]);

				xx=0.0;	yy=0.0;	zz=0.0;	kp=0.0;
				for(PosFace=(node->attachedList).GetHeadPosition();PosFace!=NULL;) {
					QFacet* ft=(QFacet*)((node->attachedList).GetNext(PosFace));

					area=ft->m_area;

					pp1[0]=ft->m_pos[0]-pp[0];
					pp1[1]=ft->m_pos[1]-pp[1];
					pp1[2]=ft->m_pos[2]-pp[2];

					dd=pp1[0]*ft->m_normal[0]+pp1[1]*ft->m_normal[1]+pp1[2]*ft->m_normal[2];

					pp2[0]=dd*ft->m_normal[0]+pp[0];
					pp2[1]=dd*ft->m_normal[1]+pp[1];
					pp2[2]=dd*ft->m_normal[2]+pp[2];

					df=geo.Distance_to_Point(ft->m_pos,pp);
					dg=fabs(dd);

					temp=area*gaussianErrorNorm(df,deltaF)*gaussianErrorNorm(dg,deltaG);

					kp=kp+temp;
					xx=xx+temp*pp2[0];
					yy=yy+temp*pp2[1];
					zz=zz+temp*pp2[2];
				}
				if (kp!=0.0) {
					xx=xx/kp;	yy=yy/kp;	zz=zz/kp;
					node->SetCoord3D(xx,yy,zz);
				}
			}
		}
	}
	//----------------------------------------------------------------------------------
	//  update normal vectors
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->CalPlaneEquation();
		}
	}
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			node->CalNormal();
		}
	}

	//----------------------------------------------------------------------------------
	//	Step 7: free the momery
	for(i=0;i<xNum;i++) {
		for(j=0;j<yNum;j++) {
			for(k=0;k<zNum;k++)	{
				for(Pos=boxArray[i][j][k]->GetHeadPosition();Pos!=NULL;) {
					QFacet *ft=(QFacet *)(boxArray[i][j][k]->GetNext(Pos));
					delete ft;
				}
				delete (boxArray[i][j][k]);
			}
			delete [](GLKObList **)(boxArray[i][j]);
		}
		delete [](GLKObList ***)(boxArray[i]);
	}
	delete [](GLKObList ****)(boxArray);
}

void QSmoothing::BilateralFilteringWithANN(GLKObList* meshList, double deltaFscale, double deltaGscale,
							bool bMollification, int nSteps, bool bRelativeToMeanEdgeLength,
							bool bOnlySharpRegion, bool bWithBoundary)
{
	double deltaF,deltaG;
	double pp[3],pp1[3],pp2[3],normal[3];
	double dd,ll,xx,yy,zz,kp;
	double boxScale,area,temp,df,dg;
	int faceNum;
	int i,n,iter;
	GLKPOSITION Pos;
	GLKPOSITION PosFace;
	GLKPOSITION PosNode;
	QMeshPatch *mesh;
	QMeshFace *face;
	QMeshNode *node;
	GLKGeometry geo;
	QMeshFace **faceArray;
	double *faceArea;
	double **faceCenterPos;

	ll=QGeometryComputing::computeAverageEdgeLength(meshList);
	//----------------------------------------------------------------------------------
	//	Step 1: compute deltaF and deltaG
	if (bRelativeToMeanEdgeLength) {
		deltaF=ll*deltaFscale;	deltaG=ll*deltaGscale;	
	}
	else {
		deltaF=deltaFscale;	deltaG=deltaGscale;	
	}
	boxScale=deltaF;
	printf("deltaF=%lf\ndeltaG=%lf\nboxSize=%lf\n",deltaF,deltaG,boxScale);
	//----------------------------------------------------------------------------------
	//	do some preparation work
	faceNum=0;
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		faceNum+=mesh->GetFaceNumber();
	}
	if (faceNum==0) return;
	faceArea=new double[faceNum];
	faceCenterPos=(double**)new long[faceNum];
	for(i=0;i<faceNum;i++) faceCenterPos[i]=new double[3];
	faceArray=(QMeshFace **)new long[faceNum];
	//----------------------------------------------------------------------------------
	n=0;
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;n++) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->SetIndexNo(n);
			face->CalCenterPos(faceCenterPos[n][0],faceCenterPos[n][1],faceCenterPos[n][2]);
			faceArea[n]=face->CalArea();
			face->GetAttachedList().RemoveAll();
			faceArray[n]=face;
		}
	}

	//----------------------------------------------------------------------------------
	//	create the ANN
	float *xpos,*ypos,*zpos;
	xpos=new float[faceNum];
	ypos=new float[faceNum];
	zpos=new float[faceNum];
	for(n=0;n<faceNum;n++) {
		xpos[n]=(float)(faceCenterPos[n][0]);
		ypos[n]=(float)(faceCenterPos[n][1]);
		zpos[n]=(float)(faceCenterPos[n][2]);
	}
	GLKNearestNeighbor *glkNN;
	glkNN=new GLKNearestNeighbor(faceNum, xpos, ypos, zpos);
	delete []xpos;	delete []ypos;	delete []zpos;

	//----------------------------------------------------------------------------------
	//	Search the related polygons of each vertex (in the region of 2 * deltaF)
	GLKArray *indexArray=new GLKArray(50,50,1);
	float queryPos[3];
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			double xx,yy,zz;
			node->GetCoord3D(xx,yy,zz);
			queryPos[0]=(float)xx;	queryPos[1]=(float)yy;	queryPos[2]=(float)zz;
			indexArray->RemoveAll();
			glkNN->PntsInRange(queryPos,(float)(2.0*deltaF),indexArray);

			node->attachedList.RemoveAll();
			int pntNum=indexArray->GetSize();
			for(i=0;i<pntNum;i++) node->attachedList.AddTail(faceArray[indexArray->GetIntAt(i)]);
		}
	}

	//----------------------------------------------------------------------------------
	//	free the memory for ANN
	delete indexArray;
	delete glkNN;

	//----------------------------------------------------------------------------------
	//	Filtering Process
	for(iter=0;iter<nSteps;iter++) {
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));

				if ((!bWithBoundary) && (node->GetAttribFlag(0))) continue;

				node->GetCoord3D(pp[0],pp[1],pp[2]);

				xx=0.0;	yy=0.0;	zz=0.0;	kp=0.0;
				for(PosFace=(node->attachedList).GetHeadPosition();PosFace!=NULL;) {
					face=(QMeshFace*)((node->attachedList).GetNext(PosFace));
					n=face->GetIndexNo();
					face->GetPlaneEquation(normal[0],normal[1],normal[2],dd);

					area=faceArea[n];

					pp1[0]=faceCenterPos[n][0]-pp[0];
					pp1[1]=faceCenterPos[n][1]-pp[1];
					pp1[2]=faceCenterPos[n][2]-pp[2];

					dd=pp1[0]*normal[0]+pp1[1]*normal[1]+pp1[2]*normal[2];

					pp2[0]=dd*normal[0]+pp[0];
					pp2[1]=dd*normal[1]+pp[1];
					pp2[2]=dd*normal[2]+pp[2];

					df=geo.Distance_to_Point(faceCenterPos[n],pp);
					dg=fabs(dd);

					temp=area*gaussianErrorNorm(df,deltaF)*gaussianErrorNorm(dg,deltaG);

					kp=kp+temp;
					xx=xx+temp*pp2[0];
					yy=yy+temp*pp2[1];
					zz=zz+temp*pp2[2];
				}
				if (kp!=0.0) {
					xx=xx/kp;	yy=yy/kp;	zz=zz/kp;
					node->SetCoord3D(xx,yy,zz);
				}
			}
		}
	}

	//----------------------------------------------------------------------------------
	//  update normal vectors
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->CalPlaneEquation();
		}
	}
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			node->CalNormal();
		}
	}

	//----------------------------------------------------------------------------------
	//	free the memory
	delete [](QMeshFace **)faceArray;
	delete faceArea;
	for(i=0;i<faceNum;i++) delete [](double*)(faceCenterPos[i]);
	delete [](double**)faceCenterPos;
}

void QSmoothing::BilateralFiltering(GLKObList* meshList, double deltaFscale, double deltaGscale, 
									bool bMollification, int nSteps, 
									bool bRelativeToMeanEdgeLength,
									bool bOnlySharpRegion, bool bWithBoundary)
{
	double deltaF,deltaG;
	double pp[3],pp1[3],pp2[3],normal[3];
	double dd,ll,xx,yy,zz,kp,cx,cy,cz,xmin,xmax,ymin,ymax,zmin,zmax;
	double boxScale,area,temp,df,dg;
	int faceNum,xNum,yNum,zNum;
	int i,j,k,ii,jj,kk,n,num,iter;
	GLKPOSITION Pos;
	GLKPOSITION PosFace;
	GLKPOSITION PosNode;
	QMeshPatch *mesh;
	QMeshFace *face;
	QMeshNode *node;
	GLKGeometry geo;
	double *faceArea;
	double **faceCenterPos;
	GLKObList ****boxArray;

	//----------------------------------------------------------------------------------
	//	Step 1: compute deltaF and deltaG
	if (bRelativeToMeanEdgeLength) {
		ll=QGeometryComputing::computeAverageEdgeLength(meshList);
		deltaF=ll*deltaFscale;	deltaG=ll*deltaGscale;	
	}
	else {
		deltaF=deltaFscale;	deltaG=deltaGscale;	
	}
	boxScale=deltaF;
	printf("deltaF=%lf\ndeltaG=%lf\nboxSize=%lf\n",deltaF,deltaG,boxScale);
	//----------------------------------------------------------------------------------
	//	do some preparation work
	n=0;
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;n++) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->SetIndexNo(n);
		}
	}

	//----------------------------------------------------------------------------------
	//	Step 2: malloc the memory and prepare the boxes
	//--------------------------------------------------------------------------------------
	faceNum=0;
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		faceNum+=mesh->GetFaceNumber();
	}
	if (faceNum==0) return;
	faceArea=new double[faceNum];
	faceCenterPos=(double**)new long[faceNum];
	for(i=0;i<faceNum;i++) faceCenterPos[i]=new double[3];
	//----------------------------------------------------------------------------------
	//	build the boxes array
	xmin=1.0e+32;	xmax=-1.0e+32;	
	ymin=1.0e+32;	ymax=-1.0e+32;
	zmin=1.0e+32;	zmax=-1.0e+32;
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			n=face->GetIndexNo();
			num=face->GetEdgeNum();
			face->CalCenterPos(cx,cy,cz);

			if (cx>xmax) xmax=cx;
			if (cx<xmin) xmin=cx;
			if (cy>ymax) ymax=cy;
			if (cy<ymin) ymin=cy;
			if (cz>zmax) zmax=cz;
			if (cz<zmin) zmin=cz;

			faceCenterPos[n][0]=cx;
			faceCenterPos[n][1]=cy;
			faceCenterPos[n][2]=cz;

			faceArea[n]=face->CalArea();
		}
	}
	xNum=(int)((xmax-xmin)/boxScale)+1;
	yNum=(int)((ymax-ymin)/boxScale)+1;
	zNum=(int)((zmax-zmin)/boxScale)+1;
	boxArray=(GLKObList ****)new long[xNum];
	for(i=0;i<xNum;i++) {
		boxArray[i]=(GLKObList ***)new long[yNum];
		for(j=0;j<yNum;j++) {
			boxArray[i][j]=(GLKObList **)new long[zNum];
			for(k=0;k<zNum;k++) {
				boxArray[i][j][k]=new GLKObList;
				boxArray[i][j][k]->RemoveAll();
			}
		}
	}
	//----------------------------------------------------------------------------------
	//	insert faces into boxes
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			n=face->GetIndexNo();
			i=(int)((faceCenterPos[n][0]-xmin)/boxScale);
			j=(int)((faceCenterPos[n][1]-ymin)/boxScale);
			k=(int)((faceCenterPos[n][2]-zmin)/boxScale);
			boxArray[i][j][k]->AddTail(face);
		}
	}

	//----------------------------------------------------------------------------------
	//	Step 3: Mollification
	if (bMollification) {
		deltaF=deltaF*0.5;
		//----------------------------------------------------------------------------------
		//	Backup the original coordinates
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
				node->GetCoord3D(pp[0],pp[1],pp[2]);
				node->SetCoord3D_last(pp[0],pp[1],pp[2]);
			}
		}
		//----------------------------------------------------------------------------------
		//	Search the related polygons of each vertex (in the region of 2 * deltaF)
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
				(node->GetFaceList()).RemoveAll();
				if ((!bWithBoundary) && (node->GetAttribFlag(0))) continue;

				node->GetCoord3D(pp[0],pp[1],pp[2]);
				i=(int)((pp[0]-xmin)/boxScale);
				j=(int)((pp[1]-ymin)/boxScale);
				k=(int)((pp[2]-zmin)/boxScale);
				for(ii=i-1;ii<=i+1;ii++) {
					if (ii<0) continue;
					if (ii>=xNum) continue;
					for(jj=j-1;jj<=j+1;jj++) {
						if (jj<0) continue;
						if (jj>=yNum) continue;
						for(kk=k-1;kk<=k+1;kk++) {
							if (kk<0) continue;
							if (kk>=zNum) continue;

							for(PosFace=boxArray[ii][jj][kk]->GetHeadPosition();PosFace!=NULL;) {
								face=(QMeshFace*)(boxArray[ii][jj][kk]->GetNext(PosFace));
								if ( (face->GetMeshPatchPtr()!=node->GetMeshPatchPtr())
									&& (!(node->GetAttribFlag(0))) ) continue;
								//if (bSharpFeatureOnly && (face->GetAttribFlag(1))) continue;
								n=face->GetIndexNo();
								ll=geo.Distance_to_Point(pp,faceCenterPos[n]);
								if (ll<=(2.0*deltaF)) (node->GetFaceList()).AddTail(face);
							}
						}
					}
				}
			}
		}
		//----------------------------------------------------------------------------------
		//	Mollifying the mesh surfaces
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
				node->GetCoord3D(pp[0],pp[1],pp[2]);
				if ((!bWithBoundary) && (node->GetAttribFlag(0))) continue;

				xx=0.0;	yy=0.0;	zz=0.0;	kp=0.0;
				for(PosFace=(node->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
					face=(QMeshFace*)((node->GetFaceList()).GetNext(PosFace));
					n=face->GetIndexNo();

					area=faceArea[n];

					pp2[0]=faceCenterPos[n][0];
					pp2[1]=faceCenterPos[n][1];
					pp2[2]=faceCenterPos[n][2];

					df=geo.Distance_to_Point(faceCenterPos[n],pp);
					temp=area*gaussianErrorNorm(df,deltaF);

					kp=kp+temp;
					xx=xx+temp*pp2[0];
					yy=yy+temp*pp2[1];
					zz=zz+temp*pp2[2];
				}
				if (kp!=0.0) {
					xx=xx/kp;	yy=yy/kp;	zz=zz/kp;
					node->SetCoord3D(xx,yy,zz);
				}
			}
		}
		//----------------------------------------------------------------------------------
		//	Compute the new normal vectors
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
				face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
				face->CalPlaneEquation();
			}
		}
		//----------------------------------------------------------------------------------
		//	Restore the original coordinates
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
				node->GetCoord3D_last(pp[0],pp[1],pp[2]);
				node->SetCoord3D(pp[0],pp[1],pp[2]);
			}
		}

		deltaF=deltaF*2.0;
	}

	//----------------------------------------------------------------------------------
	//	Step 4: Bilateral Filtering
	//----------------------------------------------------------------------------------
	//	Search the related polygons of each vertex (in the region of 2 * deltaF)
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			(node->GetFaceList()).RemoveAll();

			if ((!bWithBoundary) && (node->GetAttribFlag(0))) continue;
			if ((bOnlySharpRegion) && (!(node->GetAttribFlag(5)))) continue;

			node->GetCoord3D(pp[0],pp[1],pp[2]);
			i=(int)((pp[0]-xmin)/boxScale);
			j=(int)((pp[1]-ymin)/boxScale);
			k=(int)((pp[2]-zmin)/boxScale);
			for(ii=i-2;ii<=i+2;ii++) {
				if (ii<0) continue;
				if (ii>=xNum) continue;
				for(jj=j-2;jj<=j+2;jj++) {
					if (jj<0) continue;
					if (jj>=yNum) continue;
					for(kk=k-2;kk<=k+2;kk++) {
						if (kk<0) continue;
						if (kk>=zNum) continue;

						for(PosFace=boxArray[ii][jj][kk]->GetHeadPosition();PosFace!=NULL;) {
							face=(QMeshFace*)(boxArray[ii][jj][kk]->GetNext(PosFace));
							if ( (face->GetMeshPatchPtr()!=node->GetMeshPatchPtr())
								&& (!(node->GetAttribFlag(0))) ) continue;
							//if (bSharpFeatureOnly && (face->GetAttribFlag(1))) continue;
							n=face->GetIndexNo();
							ll=geo.Distance_to_Point(pp,faceCenterPos[n]);
							if (ll<=(2.0*deltaF)) (node->GetFaceList()).AddTail(face);
						}
					}
				}
			}
		}
	}
	//----------------------------------------------------------------------------------
	//	Filtering Process
	for(iter=0;iter<nSteps;iter++) {
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			mesh=(QMeshPatch *)(meshList->GetNext(Pos));
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));

				if ((!bWithBoundary) && (node->GetAttribFlag(0))) continue;

				node->GetCoord3D(pp[0],pp[1],pp[2]);

				xx=0.0;	yy=0.0;	zz=0.0;	kp=0.0;
				for(PosFace=(node->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
					face=(QMeshFace*)((node->GetFaceList()).GetNext(PosFace));
					n=face->GetIndexNo();
					face->GetPlaneEquation(normal[0],normal[1],normal[2],dd);

					area=faceArea[n];

					pp1[0]=faceCenterPos[n][0]-pp[0];
					pp1[1]=faceCenterPos[n][1]-pp[1];
					pp1[2]=faceCenterPos[n][2]-pp[2];

					dd=pp1[0]*normal[0]+pp1[1]*normal[1]+pp1[2]*normal[2];

					pp2[0]=dd*normal[0]+pp[0];
					pp2[1]=dd*normal[1]+pp[1];
					pp2[2]=dd*normal[2]+pp[2];

					df=geo.Distance_to_Point(faceCenterPos[n],pp);
					dg=fabs(dd);

					temp=area*gaussianErrorNorm(df,deltaF)*gaussianErrorNorm(dg,deltaG);

					kp=kp+temp;
					xx=xx+temp*pp2[0];
					yy=yy+temp*pp2[1];
					zz=zz+temp*pp2[2];
				}
				if (kp!=0.0) {
					xx=xx/kp;	yy=yy/kp;	zz=zz/kp;
					node->SetCoord3D(xx,yy,zz);
				}
			}
		}
	}

	//  update normal vectors
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->CalPlaneEquation();
		}
	}

	//----------------------------------------------------------------------------------
	//	Step 6: free the momery
	delete faceArea;
	for(i=0;i<faceNum;i++) delete [](double*)(faceCenterPos[i]);
	delete [](double**)faceCenterPos;
	for(i=0;i<xNum;i++) {
		for(j=0;j<yNum;j++) {
			for(k=0;k<zNum;k++)	{
				delete (boxArray[i][j][k]);
			}
			delete [](GLKObList **)(boxArray[i][j]);
		}
		delete [](GLKObList ***)(boxArray[i]);
	}
	delete [](GLKObList ****)(boxArray);
}

void QSmoothing::FeaturePreservedMeshSmoothing(GLKObList* meshList,
											   double deltaFscale, double deltaGscale,
											   bool bSharpFeatureOnly, int nSteps,
											   bool bByAverageEdgeLength)
{
	double deltaF,deltaG;
	double pp[3],pp1[3],pp2[3],normal[3];
	double dd,ll,xx,yy,zz,kp,cx,cy,cz,xmin,xmax,ymin,ymax,zmin,zmax;
	double boxScale,area,temp,df,dg;
	int faceNum,xNum,yNum,zNum;
	int i,j,k,ii,jj,kk,n,num,iter;
	GLKPOSITION Pos;
	GLKPOSITION PosFace;
	GLKPOSITION PosNode;
	GLKPOSITION PosNode2;
	QMeshPatch *mesh;
	QMeshFace *face;
	QMeshNode *node;
	GLKGeometry geo;

	double *faceArea;
	double **faceCenterPos;
	GLKObList ****boxArray;


	//----------------------------------------------------------------------------------
	//	Step 1: compute deltaF and deltaG
	if (bByAverageEdgeLength)
		ll=QGeometryComputing::computeAverageEdgeLength(meshList);
	else
		ll=1.0;
	deltaF=ll*deltaFscale;	deltaG=ll*deltaGscale;	boxScale=deltaF;
	printf("deltaF=%lf\n deltaG=%lf\n boxSize=%lf\n",deltaF,deltaG,boxScale);
	//----------------------------------------------------------------------------------
	//	do some preparation work
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		n=0;
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;n++) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->SetIndexNo(n);
		}
	}

	//--------------------------------------------------------------------------------------
	//
	//	Compute the feature-preserved smoothing
	//
	//--------------------------------------------------------------------------------------
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		faceNum=mesh->GetFaceNumber();
		//----------------------------------------------------------------------------------
		//	Step 2: malloc the memory and prepare the boxes
		if (faceNum==0) continue;
		faceArea=new double[faceNum];
		faceCenterPos=(double**)new long[faceNum];
		for(i=0;i<faceNum;i++) faceCenterPos[i]=new double[3];
		//----------------------------------------------------------------------------------
		//	build the boxes array
		xmin=1.0e+32;	xmax=-1.0e+32;	
		ymin=1.0e+32;	ymax=-1.0e+32;
		zmin=1.0e+32;	zmax=-1.0e+32;
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			n=face->GetIndexNo();
			num=face->GetEdgeNum();
			face->CalCenterPos(cx,cy,cz);

			if (cx>xmax) xmax=cx;
			if (cx<xmin) xmin=cx;
			if (cy>ymax) ymax=cy;
			if (cy<ymin) ymin=cy;
			if (cz>zmax) zmax=cz;
			if (cz<zmin) zmin=cz;

			faceCenterPos[n][0]=cx;
			faceCenterPos[n][1]=cy;
			faceCenterPos[n][2]=cz;

			faceArea[n]=face->CalArea();
		}
		xNum=(int)((xmax-xmin)/boxScale)+1;
		yNum=(int)((ymax-ymin)/boxScale)+1;
		zNum=(int)((zmax-zmin)/boxScale)+1;
		boxArray=(GLKObList ****)new long[xNum];
		for(i=0;i<xNum;i++) {
			boxArray[i]=(GLKObList ***)new long[yNum];
			for(j=0;j<yNum;j++) {
				boxArray[i][j]=(GLKObList **)new long[zNum];
				for(k=0;k<zNum;k++) {
					boxArray[i][j][k]=new GLKObList;
					boxArray[i][j][k]->RemoveAll();
				}
			}
		}
		//----------------------------------------------------------------------------------
		//	insert faces into boxes
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			n=face->GetIndexNo();
			i=(int)((faceCenterPos[n][0]-xmin)/boxScale);
			j=(int)((faceCenterPos[n][1]-ymin)/boxScale);
			k=(int)((faceCenterPos[n][2]-zmin)/boxScale);
			boxArray[i][j][k]->AddTail(face);
		}

		//----------------------------------------------------------------------------------
		//	Step 3: search the related polygons of each vertex (in the region of 2 * deltaF)
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			if (bSharpFeatureOnly && (!(node->GetAttribFlag(5)))) continue;

			(node->GetFaceList()).RemoveAll();
			node->GetCoord3D(pp[0],pp[1],pp[2]);
			i=(int)((pp[0]-xmin)/boxScale);
			j=(int)((pp[1]-ymin)/boxScale);
			k=(int)((pp[2]-zmin)/boxScale);
			for(ii=i-2;ii<=i+2;ii++) {
				if (ii<0) continue;
				if (ii>=xNum) continue;
				for(jj=j-2;jj<=j+2;jj++) {
					if (jj<0) continue;
					if (jj>=yNum) continue;
					for(kk=k-2;kk<=k+2;kk++) {
						if (kk<0) continue;
						if (kk>=zNum) continue;

						for(PosFace=boxArray[ii][jj][kk]->GetHeadPosition();PosFace!=NULL;) {
							face=(QMeshFace*)(boxArray[ii][jj][kk]->GetNext(PosFace));
							//if (bSharpFeatureOnly && (face->GetAttribFlag(1))) continue;
							n=face->GetIndexNo();
							ll=geo.Distance_to_Point(pp,faceCenterPos[n]);
							if (ll<=(2.0*deltaF)) (node->GetFaceList()).AddTail(face);
						}
					}
				}
			}
		}

		for(iter=0;iter<nSteps;iter++) {
			//----------------------------------------------------------------------------------
			//	Step 4: feature-preserved smoothing
			for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
				node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
				if (bSharpFeatureOnly && (!(node->GetAttribFlag(5)))) continue;

				node->GetCoord3D(pp[0],pp[1],pp[2]);

				xx=0.0;	yy=0.0;	zz=0.0;	kp=0.0;
				for(PosFace=(node->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
					face=(QMeshFace*)((node->GetFaceList()).GetNext(PosFace));
					n=face->GetIndexNo();
					face->GetPlaneEquation(normal[0],normal[1],normal[2],dd);

					area=faceArea[n];
	//				area=1.0;

					pp1[0]=faceCenterPos[n][0]-pp[0];
					pp1[1]=faceCenterPos[n][1]-pp[1];
					pp1[2]=faceCenterPos[n][2]-pp[2];

					dd=pp1[0]*normal[0]+pp1[1]*normal[1]+pp1[2]*normal[2];

					pp2[0]=dd*normal[0]+pp[0];
					pp2[1]=dd*normal[1]+pp[1];
					pp2[2]=dd*normal[2]+pp[2];

					df=geo.Distance_to_Point(faceCenterPos[n],pp);
					dg=fabs(dd);

					temp=area*gaussianErrorNorm(df,deltaF)*gaussianErrorNorm(dg,deltaG);

					kp=kp+temp;
					xx=xx+temp*pp2[0];
					yy=yy+temp*pp2[1];
					zz=zz+temp*pp2[2];
				}
				if (kp!=0.0) {
					xx=xx/kp;	yy=yy/kp;	zz=zz/kp;
					node->SetCoord3D(xx,yy,zz);
				}
			}
		}
		
		//----------------------------------------------------------------------------------
		//	Step 5: recompute the normals and set the face index back
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			node->GetFaceList().RemoveAll();
		}
		n=1;
		for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;n++) {
			face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));
			face->SetIndexNo(n);
			face->CalPlaneEquation();
			int nodeNum=face->GetEdgeNum();
			for(i=0;i<nodeNum;i++) face->GetNodeRecordPtr(i)->GetFaceList().AddTail(face);
		}
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			(node->attachedList).RemoveAll();
			node->CalNormal();
		}

		//----------------------------------------------------------------------------------
		//	Step 6: free the momery
		delete faceArea;
		for(i=0;i<faceNum;i++) delete [](double*)(faceCenterPos[i]);
		delete [](double**)faceCenterPos;
		for(i=0;i<xNum;i++) {
			for(j=0;j<yNum;j++) {
				for(k=0;k<zNum;k++)	{
					delete (boxArray[i][j][k]);
				}
				delete [](GLKObList **)(boxArray[i][j]);
			}
			delete [](GLKObList ***)(boxArray[i]);
		}
		delete [](GLKObList ****)(boxArray);
	}

	//----------------------------------------------------------------------------------
	//	Make boundary nodes conincident
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			if (!(node->GetAttribFlag(0))) continue;

			int num=node->GetNodeNumber()+1;
			node->GetCoord3D(pp[0],pp[1],pp[2]);
			for(PosNode2=node->GetNodeList().GetHeadPosition();PosNode2!=NULL;) {
				QMeshNode *node2=(QMeshNode *)(node->GetNodeList().GetNext(PosNode2));
				node2->GetCoord3D(xx,yy,zz);
				pp[0]+=xx;	pp[1]+=yy;	pp[2]+=zz;
			}
			pp[0]=pp[0]/(double)num; pp[1]=pp[1]/(double)num; pp[2]=pp[2]/(double)num;

			node->SetCoord3D(pp[0],pp[1],pp[2]);
			for(PosNode2=node->GetNodeList().GetHeadPosition();PosNode2!=NULL;) {
				QMeshNode *node2=(QMeshNode *)(node->GetNodeList().GetNext(PosNode2));
				node2->SetCoord3D(pp[0],pp[1],pp[2]);
			}
		}
	}
}

double QSmoothing::gaussianErrorNorm(double x, double delta)
{
	double value;

//	value=delta*delta-exp(-(x*x)/(2.0*delta*delta));
	value=exp(-(x*x)/(2.0*delta*delta));
	
	return value;
}

void QSmoothing::CreaseEnhancingDiffusion(GLKObList* meshList, double exponentialCoefficient,
												int nSteps)
{
	GLKPOSITION Pos;
	GLKPOSITION PosNode;
	GLKPOSITION PosFace;
	GLKPOSITION PosFace2;
	GLKGeometry geo;
	int k;

	exponentialCoefficient=exponentialCoefficient*QGeometryComputing::computeAverageEdgeLength(meshList);

	for(k=0;k<nSteps;k++) {
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));

			for(PosFace=mesh->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
				QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(PosFace));

				double xx,yy,zz;
				face->CalPlaneEquation();
				face->CalArea();
				face->CalCenterPos(xx,yy,zz);
			}
		}

		//--------------------------------------------------------------------------------
		//	Step 1: normal diffusion
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));

			for(PosFace=mesh->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
				QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(PosFace));

				double mx,my,mz,weight,nx,ny,nz,dd,cp[3],area,cp2[3],area2,nx2,ny2,nz2;
				int edgeNum=face->GetEdgeNum();

				mx=0.0;	my=0.0;	mz=0.0;	weight=0.0;

				face->GetPlaneEquation(nx,ny,nz,dd);
				face->GetCenterPos(cp[0],cp[1],cp[2]);
				area=face->GetArea();

				for(int i=0;i<edgeNum;i++) {
					QMeshNode *node=face->GetNodeRecordPtr(i);
					for(PosFace2=node->GetFaceList().GetHeadPosition();PosFace2!=NULL;) {
						QMeshFace *face2=(QMeshFace *)(node->GetFaceList().GetNext(PosFace2));
						face2->SetAttribFlag(7,true);
					}
				}
				for(i=0;i<edgeNum;i++) {
					QMeshNode *node=face->GetNodeRecordPtr(i);
					for(PosFace2=node->GetFaceList().GetHeadPosition();PosFace2!=NULL;) {
						QMeshFace *face2=(QMeshFace *)(node->GetFaceList().GetNext(PosFace2));
						if (!(face2->GetAttribFlag(7))) continue;

						face2->GetPlaneEquation(nx2,ny2,nz2,dd);
						face2->GetCenterPos(cp2[0],cp2[1],cp2[2]);
						area2=face2->GetArea();

						double K,ww;
						K=nx*nx2+ny*ny2+nz*nz2;
						if (K<-1.0) K=-1.0;
						if (K>1.0) K=1.0;
						dd=geo.Distance_to_Point(cp,cp2);

						K=acos(K)*dd;
						ww=area2*exp(-exponentialCoefficient*K*K);

						weight+=ww;
						mx+=ww*nx2;
						my+=ww*ny2;
						mz+=ww*nz2;

						face2->SetAttribFlag(7,false);
					}
				}

				if (fabs(weight)>1.0e-8) {
					mx=mx/weight;	my=my/weight;	mz=mz/weight;
					weight=sqrt(mx*mx+my*my+mz*mz);
					if (fabs(weight)>1.0e-8) {
						mx=mx/weight;	my=my/weight;	mz=mz/weight;
					}
					else {
						mx=0.0;	my=0.0;	mz=0.0;
					}
				}
				else {
					mx=0.0;	my=0.0;	mz=0.0;
				}
				face->SetColor((float)mx,(float)my,(float)mz);
			}
		}

		//--------------------------------------------------------------------------------
		//	Step 2: vertex diffusion
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		
			for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
				QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));

				double xx,yy,zz,dx,dy,dz,weight,cp[3],vp[3],dd,area;
				float mx,my,mz;
				node->GetCoord3D(xx,yy,zz);
				dx=0.0;	dy=0.0;	dz=0.0;	weight=0.0;

				for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
					QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));

					face->GetColor(mx,my,mz);
					face->GetCenterPos(cp[0],cp[1],cp[2]);
					area=face->GetArea();

					dd=(cp[0]-xx)*mx+(cp[1]-yy)*my+(cp[2]-zz)*mz;
					vp[0]=dd*mx;	vp[1]=dd*my;	vp[2]=dd*mz;

					dx+=vp[0]*area;		dy+=vp[1]*area;		dz+=vp[2]*area;
					weight+=area;
				}

				if (fabs(weight)>1.0e-8) {
					dx=dx/weight;	dy=dy/weight;	dz=dz/weight;
				}
				else {
					dx=0.0;	dy=0.0;	dz=0.0;
				}

				node->SetCoord3D(xx+dx,yy+dy,zz+dz);
			}
		}
	}

	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosFace=mesh->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			node->CalNormal();
		}
	}
}

void QSmoothing::LaplacianMeshSmoothing(GLKObList* meshList, int nStep)
{
	GLKPOSITION Pos;
	GLKPOSITION PosNode;
	GLKPOSITION PosFace;
	GLKPOSITION PosNode2;
	double xx,yy,zz,dx,dy,dz;
	int k;

	for(k=0;k<nStep;k++) {
		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));

			for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
				QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
				node->GetCoord3D(xx,yy,zz);
				node->SetCoord3D_last(xx,yy,zz);
				node->SetAttribFlag(7,false);
			}
		}

		for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
			QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext (Pos));

			for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
				QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
				if (node->GetAttribFlag(7)) continue;
				if (node->GetAttribFlag(0)) continue;
				if (node->GetAttribFlag(5)) continue;
//				if (node->GetAttribFlag(6)) continue;

				node->GetCoord3D(xx,yy,zz);

				QGeometryComputing::computeAveragePositionUpdate(node,dx,dy,dz);

				node->SetCoord3D(xx+dx,yy+dy,zz+dz);
				node->SetAttribFlag(7,true);

				for(PosNode2=node->GetNodeList().GetHeadPosition();PosNode2!=NULL;) {
					QMeshNode *node2=(QMeshNode *)(node->GetNodeList().GetNext(PosNode2));
					node2->SetCoord3D(xx+dx,yy+dy,zz+dz);
					node2->SetAttribFlag(7,true);
				}
			}
		}
	}

	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));

		for(PosFace=mesh->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
		for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));
			node->CalNormal();
		}
	}
}

void QSmoothing::OrderTwoUmbrellaFairing(GLKObList* meshList, int nSteps, bool bWithFlag7)
{
	GLKPOSITION PosMesh;
	GLKPOSITION PosEdge;
	GLKPOSITION Pos;
	int i,iter;
	QMeshNode *node,*othernode;
	QMeshEdge *edge;	
	double p[3],up[3],up2[3],tempup[3];

	for(iter=0;iter<nSteps;iter++) {
		for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
			QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
			for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;)
			{
				node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
				if (node->GetAttribFlag(0)) continue;
				if ((!(node->GetAttribFlag(7))) && (bWithFlag7)) continue;

				node->GetCoord3D(p[0],p[1],p[2]);
				deltaF(node,up);
				for(i=0;i<3;i++) up2[i]=0.0;

				double n,nn;
				n=(double)(node->GetEdgeNumber());	nn=0.0;

				for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;)
				{
					edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
					if ((edge->GetStartPoint())==node)
						othernode=edge->GetEndPoint();
					else
						othernode=edge->GetStartPoint();
					deltaF(othernode,tempup);
					nn+=1.0/(double)(othernode->GetEdgeNumber());

					for(i=0;i<3;i++) up2[i]=up2[i]+(tempup[i]-up[i]);
				}
				for(i=0;i<3;i++) up2[i]=up2[i]/n;

				double v=1.0+nn/n;
				for(i=0;i<3;i++) p[i]=p[i]-up2[i]/v;

				node->SetCoord3D(p[0],p[1],p[2]);
			}
		}
	}

	///////////////////////////////////////////////////////////////////
	//	Re-calculate the normal of each node
	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
		for(Pos=mesh->GetFaceList().GetHeadPosition();Pos!=NULL;)
		{
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
			face->CalPlaneEquation();
		}
		for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;)
		{
			node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
			node->CalNormal();
		}
	}
}

void QSmoothing::OrderOneUmbrellaFairing(GLKObList* meshList, int nSteps, bool bWithFlag7)
{
	GLKPOSITION PosMesh;
	GLKPOSITION Pos;
	int i,iter;
	QMeshNode *node;
	double p[3],up[3];

	for(iter=0;iter<nSteps;iter++) {
		for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
			QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
			for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;) {
				node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
				if (node->GetAttribFlag(0)) continue;
				if ((!(node->GetAttribFlag(7))) && (bWithFlag7)) continue;

				node->GetCoord3D(p[0],p[1],p[2]);
				deltaF(node,up);
				for(i=0;i<3;i++) p[i]=p[i]+up[i];
				node->SetCoord3D(p[0],p[1],p[2]);
			}
		}
	}

	///////////////////////////////////////////////////////////////////
	//	Re-calculate the normal of each node
	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
		for(Pos=mesh->GetFaceList().GetHeadPosition();Pos!=NULL;)
		{
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
			face->CalPlaneEquation();
		}
		for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;)
		{
			node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
			node->CalNormal();
		}
	}
}

void QSmoothing::MeshNoising(GLKObList* meshList, short nNosiyType)
{
	GLKPOSITION PosMesh;
	GLKPOSITION Pos;
	double meanEdgeLength,nx,ny,nz,xx,yy,zz;
	int nodeNum;
	double* noisySamples;

	meanEdgeLength=QGeometryComputing::computeAverageEdgeLength(meshList);

	nodeNum=0;
	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
		nodeNum+=mesh->GetNodeNumber();
	}
	if (nodeNum==0) return;

	noisySamples=new double[nodeNum];
	switch(nNosiyType) {
		case 0:uniformNoiseGenerator(nodeNum,noisySamples,0.0,meanEdgeLength*0.2);
			break;
		case 1:gaussianNoiseGenerator(nodeNum,noisySamples,0.0,meanEdgeLength*0.2);
			break;
	}

	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
		for(Pos=mesh->GetFaceList().GetHeadPosition();Pos!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
			face->CalPlaneEquation();
		}
		for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
			node->CalNormal();
		}
	}

	int n=0;
	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
		for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;n++) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
			if (node->GetAttribFlag(0)) continue;
			node->GetCoord3D(xx,yy,zz);
			node->GetNormal(nx,ny,nz);

			node->SetCoord3D(xx+nx*noisySamples[n],yy+ny*noisySamples[n],zz+nz*noisySamples[n]);
		}
	}

/*	//----------------------------------------------------------------------------------
	//	Make boundary sharp feature nodes conincident
	GLKPOSITION PosNode;
	GLKPOSITION PosNode2;
	double pp[3];
	for(Pos=meshList->GetHeadPosition();Pos!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(Pos));
		for(PosNode=(mesh->GetNodeList()).GetHeadPosition();PosNode!=NULL;) {
			QMeshNode *node=(QMeshNode *)((mesh->GetNodeList()).GetNext(PosNode));
			if (!(node->GetAttribFlag(0))) continue;

			int num=node->GetNodeNumber()+1;
			node->GetCoord3D(pp[0],pp[1],pp[2]);
			for(PosNode2=node->GetNodeList().GetHeadPosition();PosNode2!=NULL;) {
				QMeshNode *node2=(QMeshNode *)(node->GetNodeList().GetNext(PosNode2));
				node2->GetCoord3D(xx,yy,zz);
				pp[0]+=xx;	pp[1]+=yy;	pp[2]+=zz;
			}
			pp[0]=pp[0]/(double)num; pp[1]=pp[1]/(double)num; pp[2]=pp[2]/(double)num;

			node->SetCoord3D(pp[0],pp[1],pp[2]);
			for(PosNode2=node->GetNodeList().GetHeadPosition();PosNode2!=NULL;) {
				QMeshNode *node2=(QMeshNode *)(node->GetNodeList().GetNext(PosNode2));
				node2->SetCoord3D(pp[0],pp[1],pp[2]);
			}
		}
	}
*/
	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		QMeshPatch *mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
		for(Pos=mesh->GetFaceList().GetHeadPosition();Pos!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
			face->CalPlaneEquation();
		}
		for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
			node->CalNormal();
		}
	}

	delete noisySamples;
}

void QSmoothing::uniformNoiseGenerator(int sampleNum, double *sample,
									   double minRang, double maxRang)
{
	srand( (unsigned)time( NULL ) );
	double rang=maxRang-minRang;
	for(int i = 0;i<sampleNum;i++) sample[i]=((double)(rand()))/((double)RAND_MAX)*rang+minRang;
}

void QSmoothing::gaussianNoiseGenerator(int sampleNum, double *sample, 
										double midValue, double variance)
{
	uniformNoiseGenerator(sampleNum,sample,0.0,1.0);
	double scale=sqrt(12.0);
	for(int i = 0;i<sampleNum;i++) {
		sample[i]=sample[i]-0.5;
		sample[i]=sample[i]*scale;
		sample[i]=midValue+sample[i]*variance;
	}
/*
   X=0
   for i = 1 to N
      U = uniform()
      X = X + U
   end
	
   // for uniform randoms in [0,1], mu = 0.5 and var = 1/12 
   // adjust X so mu = 0 and var = 1 
	
   X = X - 0.5                // set mean to 0 
   X = X * sqrt(12)       // adjust variance to 1 

// When the algorithm finishes, X will be our unit normal random. 
// X can be further modified to have a particular mean and variance, e.g.:

  X' = mean + sqrt(variance) * X
*/
}

void QSmoothing::deltaF(QMeshNode *node, double up[])
{
	double p[3],pp[3];
	GLKPOSITION PosEdge;
	int i;

	node->GetCoord3D(p[0],p[1],p[2]);	for(i=0;i<3;i++) up[i]=0.0;
	for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;)
	{
		QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
		if ((edge->GetStartPoint())==node)
			edge->GetEndPoint()->GetCoord3D(pp[0],pp[1],pp[2]);
		else
			edge->GetStartPoint()->GetCoord3D(pp[0],pp[1],pp[2]);

		for(i=0;i<3;i++) up[i]=up[i]+(pp[i]-p[i]);
	}
	for(i=0;i<3;i++) up[i]=up[i]/(double)(node->GetEdgeNumber());
}
