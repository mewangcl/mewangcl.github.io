// QTopologyOperator.h: interface for the QTopologyOperator class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _QTOPOLOGY_OPERATOR
#define _QTOPOLOGY_OPERATOR

class Voxel4DField;

class QTopologyOperator  
{
public:
	QTopologyOperator();
	virtual ~QTopologyOperator();

	static bool TopologyErrorCheck(GLKObList* meshList);

	static void edgeCollapseOperator(QMeshEdge *edge, GLKHeap *collapseHeap, 
										double targetLength=1.0, bool byLengthOrShapeFunc=true);
	static bool edgeCollapseProtectTopology(QMeshEdge *edge);
	static double edgeCollapseShapeFunc(QMeshEdge *edge);

	static void edgeSwapOperator(QMeshEdge *edge, GLKHeap *swapHeap, 
										Voxel4DField *vox4DField=NULL, double criterion=0.75);
	static double edgeSwapShapeFunc(QMeshEdge *edge, Voxel4DField *vox4DField, double criterion);
	static bool edgeSwapNormalCheck(QMeshEdge *edge);
	static bool edgeSwapProtectTopology(QMeshEdge *edge);

	static bool trgledgeSplitByFlags(GLKObList* meshList);

	static void fillCoincidentEdgeInfo(GLKObList* meshList);
};

#endif
