#include <ctime>						// clock
#include <cmath>						// math routines
#include <cstring>						// C string ops
#include <fstream>						// file I/O
#include <vector>

#include "cuda_runtime.h"

#include "SRStree.h"
#include "SRStree_CPU.h"
#include "SRStree_GPU.h"
//#include <windows.h>
//using namespace std;

void _helloExampleOfCSRS_GeneralSearch()
{
    int    ref_nb     = 100000;				// Data point number
    int    query_nb   = 100000;				// Query point number
    const int	dim   = CSRS_PNT_DIM;		// Dimension of points
    int bucket_size   = 20;
    int iterations	  = 200;

	//--------------------------------------------------------------------------------------
    //	Generate data sets
	srand((unsigned int)(time(NULL)));
	//--------------------------------------------------------------------------------------
    float *pos=(float*)malloc(sizeof(float)*ref_nb*dim);		//	Data points
    float *query=(float*)malloc(sizeof(float)*query_nb*dim);	//	Query points
	for (int i=0; i<ref_nb; i++) {for(int j=0; j<dim; j++) {pos[dim*i+j] = ((float)rand()/(float)RAND_MAX)*2.0f-1.0f;}}
	for (int k=0; k<query_nb; k++) {for(int j=0; j<dim; j++) {query[dim*k+j] = ((float)rand()/(float)RAND_MAX)*2.0f-1.0f;}}

	//--------------------------------------------------------------------------------------
	//	Calculate bbx and set query radius - r
	float *bnds_lo=new float[dim];
	float *bnds_hi=new float[dim];
	for (int d = 0; d < dim; d++) {		// find smallest enclosing rectangle
		float lo_bnd = pos[dim*0+d];		// lower bound on dimension d
		float hi_bnd = pos[dim*0+d];;		// upper bound on dimension d
		for (int j = 0; j < ref_nb; j++) {
			if (pos[dim*j+d] < lo_bnd) lo_bnd = pos[dim*j+d];
			else if (pos[dim*j+d] > hi_bnd) hi_bnd = pos[dim*j+d];
		}
		bnds_lo[d] = lo_bnd;	bnds_hi[d] = hi_bnd;
	}
	float sum = 0.0;
	for (int d = 0; d < dim; d++) {
		sum += (bnds_hi[d]-bnds_lo[d])*(bnds_hi[d]-bnds_lo[d]);
	}
	float bbxDiagonalLength = sqrt(sum);
	float query_radius = 0.01f * bbxDiagonalLength;
	printf("BBX-DiagonalL=%.6f   Query-Radius=%.6f\n",bbxDiagonalLength,query_radius);

	//--------------------------------------------------------------------------------------
	//	Create tree structure in CPU and transfer it to GPU	
    SRStree *the_tree = new SRStree(pos,ref_nb,dim,bucket_size);
    SRStree_CPU *the_tree_cpu=new SRStree_CPU;
    the_tree_cpu->Reconstruct(the_tree);//reorganize nodes of the tree
    SRStree_GPU *the_tree_gpu=new SRStree_GPU;
    the_tree_gpu->Construct(the_tree_cpu,the_tree_cpu->GetNumNodes(),pos,ref_nb);	// transfer tree onto GPU
	//--------------------------------------------------------------------------------------
    //	Well align the tree nodes
    the_tree_gpu->SortNodes();
	//--------------------------------------------------------------------------------------
    //	Tight fit the bounding boxes
    the_tree_gpu->RefitAABB();

	//--------------------------------------------------------------------------------------
    //	Allocate memory for query points and output results 
    int maxNeighborNum = 350;	//	for specifying the maximally returned number of neighbors in SRS
								//	When the resultant number of neighbors is greater than this number,
								//		our program will randomly pick this number of neighbors to report as results.
	//--------------------------------------------------------------------------------------
    float *gpu_queries;		//	for query points
    cudaMalloc((void**)&gpu_queries, sizeof(float)*query_nb*dim);
    cudaMemcpy(gpu_queries,query,sizeof(float)*query_nb*dim,cudaMemcpyHostToDevice);
	//--------------------------------------------------------------------------------------
    int *gpu_ret_indexes;	//	for returning indices of resultant points -- index starting from zero
	float *gpu_ret_dist;    //	for returning the squared distances of every neighbor
	int *gpu_neigh;			//	for returning the numbers of neighbors for each query point
    cudaMalloc((void**)&gpu_ret_indexes, sizeof(int)*query_nb*maxNeighborNum);
    cudaMalloc((void**)&gpu_ret_dist, sizeof(float)*query_nb*maxNeighborNum);
    cudaMalloc((void**)&gpu_neigh, sizeof(int)*query_nb);
    cudaMemset(gpu_ret_indexes, 0xffffffff, query_nb*maxNeighborNum*sizeof(int));
    cudaMemset(gpu_neigh, 0xffffffff, query_nb*sizeof(int));

	//--------------------------------------------------------------------------------------
	//	Copy query points onto GPU
	cudaMemcpy(gpu_queries,query,sizeof(float)*query_nb*dim,cudaMemcpyHostToDevice);

	long time=clock();
	printf("Computation is started ... ...\n");
	//--------------------------------------------------------------------------------------
	//	Randomly move points and conduct the queries of SRS
	bool bRes;
	for(int i = 0; i < iterations; i++)	{
		printf("Iteration: %d \n",i);
		bRes = the_tree_gpu->Search(gpu_queries,query_nb,query_radius,maxNeighborNum,gpu_ret_indexes,gpu_ret_dist,gpu_neigh);
		if (!bRes) {printf("Running out of memory!\n");break;}
		
		if (i==(iterations-1)) break;

		//----------------------------------------------------------------------------------
		//	Randomly update the positions of data points
		for(int ii = 0; ii < query_nb; ii++) {
			for(int kk = 0; kk < dim; kk++)	{
				float dist = 5.0f*((((float)rand() / (float)RAND_MAX)*2-1)/1000.0f);
				pos[dim*ii+kk] += dist;
			}
		}
		//----------------------------------------------------------------------------------
		the_tree_gpu->SetDataPoints(pos,ref_nb);		// Assigning new positions of data points (copying from CPU to GPU)
		the_tree_gpu->RefitAABB();						// Updating AABBs of the tree

		if (the_tree_gpu->isRebuildNeeded()) {
			printf("**********************************************\n");
			printf("Tree Re-building is activated!\n");
			printf("**********************************************\n");
			float *devPos=the_tree_gpu->GetDataPoints();							// This is an optional step, which is only needed when the data points
			cudaMemcpy(pos,devPos,sizeof(float)*ref_nb*dim,cudaMemcpyDeviceToHost);	//	are updated inside GPU - e.g., GPU-based particle simulation.

			//------------------------------------------------------------------------------
			delete the_tree_gpu;	delete the_tree_cpu;	delete the_tree;

			the_tree = new SRStree(pos,ref_nb,dim,bucket_size);
			the_tree_cpu=new SRStree_CPU;
			the_tree_cpu->Reconstruct(the_tree);
			the_tree_gpu=new SRStree_GPU;
			the_tree_gpu->Construct(the_tree_cpu,the_tree_cpu->GetNumNodes(),pos,ref_nb);
			the_tree_gpu->SortNodes();
			the_tree_gpu->RefitAABB();
		}
	}
	printf("Computation is completed (in %ld ms)!\n",clock()-time);

	//--------------------------------------------------------------------------------------
	//	Output results to files
	int *ret_indexes=(int*)malloc(sizeof(int)*query_nb*maxNeighborNum);
	float *ret_dists=(float*)malloc(sizeof(float)*query_nb*maxNeighborNum);
	int *ret_neigh=(int*)malloc(sizeof(int)*query_nb);
	cudaMemcpy(ret_indexes, gpu_ret_indexes, sizeof(int)*query_nb*maxNeighborNum, cudaMemcpyDeviceToHost);
	cudaMemcpy(ret_dists, gpu_ret_dist, sizeof(float)*query_nb*maxNeighborNum, cudaMemcpyDeviceToHost);
	cudaMemcpy(ret_neigh, gpu_neigh, sizeof(int)*query_nb, cudaMemcpyDeviceToHost);
	//--------------------------------------------------------------------------------------
	FILE *fp = fopen("CSRS_result.txt","w");
	for(int j=0; j< query_nb; j++) {
		fprintf(fp,"%d ",ret_neigh[j]);
		for(int jj = 0; jj < ret_neigh[j]; jj++) {
			fprintf(fp,"%d %.6f ",(ret_indexes[j*maxNeighborNum+jj]),sqrt(ret_dists[j*maxNeighborNum+jj]));
		}
		fprintf(fp,"\n");
	}
	fclose(fp);
	//--------------------------------------------------------------------------------------
	free(ret_indexes);	free(ret_dists);	free(ret_neigh);
	printf("Finished.\n\n\n");

	//--------------------------------------------------------------------------------------
	//	Free GPU memory
	cudaFree(gpu_queries);
	cudaFree(gpu_ret_indexes);
	cudaFree(gpu_ret_dist);
	cudaFree(gpu_neigh);
	//--------------------------------------------------------------------------------------
	//	Free CPU memory
	free(pos);	free(query);	
	//--------------------------------------------------------------------------------------
	//	Free memeory of trees
	delete the_tree;    delete the_tree_cpu;	delete the_tree_gpu;
}


void _helloExampleOfCSRS_SearchByDataPnts()
{
    int    ref_nb     = 100000;				// Data point number
	int	   query_nb	  = ref_nb;
    const int	dim   = CSRS_PNT_DIM;		// Dimension of points
    int bucket_size   = 20;
    int iterations	  = 200;

	//--------------------------------------------------------------------------------------
    //	Generate data sets
	srand((unsigned int)(time(NULL)));
	//--------------------------------------------------------------------------------------
    float *pos=(float*)malloc(sizeof(float)*ref_nb*dim);		//	Data points
	for (int i=0; i<ref_nb; i++) {for(int j=0; j<dim; j++) {pos[dim*i+j] = ((float)rand()/(float)RAND_MAX)*2.0f-1.0f;}}

	//--------------------------------------------------------------------------------------
	//	Calculate bbx and set query radius - r
	float *bnds_lo=new float[dim];
	float *bnds_hi=new float[dim];
	for (int d = 0; d < dim; d++) {		// find smallest enclosing rectangle
		float lo_bnd = pos[dim*0+d];		// lower bound on dimension d
		float hi_bnd = pos[dim*0+d];;		// upper bound on dimension d
		for (int j = 0; j < ref_nb; j++) {
			if (pos[dim*j+d] < lo_bnd) lo_bnd = pos[dim*j+d];
			else if (pos[dim*j+d] > hi_bnd) hi_bnd = pos[dim*j+d];
		}
		bnds_lo[d] = lo_bnd;	bnds_hi[d] = hi_bnd;
	}
	float sum = 0.0;
	for (int d = 0; d < dim; d++) {
		sum += (bnds_hi[d]-bnds_lo[d])*(bnds_hi[d]-bnds_lo[d]);
	}
	float bbxDiagonalLength = sqrt(sum);
	float query_radius = 0.01f * bbxDiagonalLength;
	printf("BBX-DiagonalL=%.6f   Query-Radius=%.6f\n",bbxDiagonalLength,query_radius);

	//--------------------------------------------------------------------------------------
	//	Create tree structure in CPU and transfer it to GPU	
    SRStree *the_tree = new SRStree(pos,ref_nb,dim,bucket_size);
    SRStree_CPU *the_tree_cpu=new SRStree_CPU;
    the_tree_cpu->Reconstruct(the_tree);//reorganize nodes of the tree
    SRStree_GPU *the_tree_gpu=new SRStree_GPU;
    the_tree_gpu->Construct(the_tree_cpu,the_tree_cpu->GetNumNodes(),pos,ref_nb);	// transfer tree onto GPU
	//--------------------------------------------------------------------------------------
    //	Well align the tree nodes
    the_tree_gpu->SortNodes();
	//--------------------------------------------------------------------------------------
    //	Tight fit the bounding boxes
    the_tree_gpu->RefitAABB();

	//--------------------------------------------------------------------------------------
    //	Allocate memory for query points and output results 
    int maxNeighborNum = 350;	//	for specifying the maximally returned number of neighbors in SRS
								//	When the resultant number of neighbors is greater than this number,
								//		our program will randomly pick this number of neighbors to report as results.
	//--------------------------------------------------------------------------------------
    int *gpu_ret_indexes;	//	for returning indices of resultant points -- index starting from zero
	float *gpu_ret_dist;    //	for returning the squared distances of every neighbor
	int *gpu_neigh;			//	for returning the numbers of neighbors for each query point
    cudaMalloc((void**)&gpu_ret_indexes, sizeof(int)*query_nb*maxNeighborNum);
    cudaMalloc((void**)&gpu_ret_dist, sizeof(float)*query_nb*maxNeighborNum);
    cudaMalloc((void**)&gpu_neigh, sizeof(int)*query_nb);
    cudaMemset(gpu_ret_indexes, 0xffffffff, query_nb*maxNeighborNum*sizeof(int));
    cudaMemset(gpu_neigh, 0xffffffff, query_nb*sizeof(int));

	long time=clock();
	printf("Computation is started ... ...\n");
	//--------------------------------------------------------------------------------------
	//	Randomly move points and conduct the queries of SRS
	bool bRes;
	for(int i = 0; i < iterations; i++)	{
		printf("Iteration: %d \n",i);
		bRes = the_tree_gpu->SearchByDataPoints(query_radius,maxNeighborNum,gpu_ret_indexes,gpu_ret_dist,gpu_neigh);
		if (!bRes) {printf("Running out of memory!\n");break;}
		
		if (i==(iterations-1)) break;

		//----------------------------------------------------------------------------------
		//	Randomly update the positions of data points
		for(int ii = 0; ii < query_nb; ii++) {
			for(int kk = 0; kk < dim; kk++)	{
				float dist = 5.0f*((((float)rand() / (float)RAND_MAX)*2-1)/1000.0f);
				pos[dim*ii+kk] += dist;
			}
		}
		//----------------------------------------------------------------------------------
		the_tree_gpu->SetDataPoints(pos,ref_nb);		// Assigning new positions of data points (copying from CPU to GPU)
		the_tree_gpu->RefitAABB();						// Updating AABBs of the tree

		if (the_tree_gpu->isRebuildNeeded()) {
			printf("**********************************************\n");
			printf("Tree Re-building is activated!\n");
			printf("**********************************************\n");
			float *devPos=the_tree_gpu->GetDataPoints();							// This is an optional step, which is only needed when the data points
			cudaMemcpy(pos,devPos,sizeof(float)*ref_nb*dim,cudaMemcpyDeviceToHost);	//	are updated inside GPU - e.g., GPU-based particle simulation.

			//------------------------------------------------------------------------------
			delete the_tree_gpu;	delete the_tree_cpu;	delete the_tree;

			the_tree = new SRStree(pos,ref_nb,dim,bucket_size);
			the_tree_cpu=new SRStree_CPU;
			the_tree_cpu->Reconstruct(the_tree);
			the_tree_gpu=new SRStree_GPU;
			the_tree_gpu->Construct(the_tree_cpu,the_tree_cpu->GetNumNodes(),pos,ref_nb);
			the_tree_gpu->SortNodes();
			the_tree_gpu->RefitAABB();
		}
	}
	printf("Computation is completed (in %ld ms)!\n",clock()-time);

	//--------------------------------------------------------------------------------------
	//	Output results to files
	int *ret_indexes=(int*)malloc(sizeof(int)*query_nb*maxNeighborNum);
	float *ret_dists=(float*)malloc(sizeof(float)*query_nb*maxNeighborNum);
	int *ret_neigh=(int*)malloc(sizeof(int)*query_nb);
	cudaMemcpy(ret_indexes, gpu_ret_indexes, sizeof(int)*query_nb*maxNeighborNum, cudaMemcpyDeviceToHost);
	cudaMemcpy(ret_dists, gpu_ret_dist, sizeof(float)*query_nb*maxNeighborNum, cudaMemcpyDeviceToHost);
	cudaMemcpy(ret_neigh, gpu_neigh, sizeof(int)*query_nb, cudaMemcpyDeviceToHost);
	//--------------------------------------------------------------------------------------
	FILE *fp = fopen("CSRS_result.txt","w");
	for(int j=0; j< query_nb; j++) {
		fprintf(fp,"%d ",ret_neigh[j]);
		for(int jj = 0; jj < ret_neigh[j]; jj++) {fprintf(fp,"%d %.6f ",(ret_indexes[j*maxNeighborNum+jj]),sqrt(ret_dists[j*maxNeighborNum+jj]));	}
		fprintf(fp,"\n");
	}
	fclose(fp);
	//--------------------------------------------------------------------------------------
	free(ret_indexes);	free(ret_dists);	free(ret_neigh);
	printf("Finished.\n\n\n");

	//--------------------------------------------------------------------------------------
	//	Free GPU memory
	cudaFree(gpu_ret_indexes);
	cudaFree(gpu_ret_dist);
	cudaFree(gpu_neigh);
	//--------------------------------------------------------------------------------------
	//	Free CPU memory
	free(pos);
	//--------------------------------------------------------------------------------------
	//	Free memeory of trees
	delete the_tree;    delete the_tree_cpu;	delete the_tree_gpu;
}


void _helloExampleOfCSRS_NearestNeighborSearch()
{
	int    ref_nb     = 100000;				// Data point number
    int    query_nb   = 100000;				// Query point number
    const int	dim   = CSRS_PNT_DIM;		// Dimension of points
    int bucket_size   = 20;
    int iterations	  = 200;

	//--------------------------------------------------------------------------------------
    //	Generate data sets
	srand((unsigned int)(time(NULL)));
	//--------------------------------------------------------------------------------------
    float *pos=(float*)malloc(sizeof(float)*ref_nb*dim);		//	Data points
    float *query=(float*)malloc(sizeof(float)*query_nb*dim);	//	Query points
	for (int i=0; i<ref_nb; i++) {for(int j=0; j<dim; j++) {pos[dim*i+j] = ((float)rand()/(float)RAND_MAX)*2.0f-1.0f;}}
	for (int k=0; k<query_nb; k++) {for(int j=0; j<dim; j++) {query[dim*k+j] = ((float)rand()/(float)RAND_MAX)*2.0f-1.0f;}}

	//--------------------------------------------------------------------------------------
	//	Calculate bbx and set query radius - r
	float *bnds_lo=new float[dim];
	float *bnds_hi=new float[dim];
	for (int d = 0; d < dim; d++) {		// find smallest enclosing rectangle
		float lo_bnd = pos[dim*0+d];		// lower bound on dimension d
		float hi_bnd = pos[dim*0+d];;		// upper bound on dimension d
		for (int j = 0; j < ref_nb; j++) {
			if (pos[dim*j+d] < lo_bnd) lo_bnd = pos[dim*j+d];
			else if (pos[dim*j+d] > hi_bnd) hi_bnd = pos[dim*j+d];
		}
		bnds_lo[d] = lo_bnd;	bnds_hi[d] = hi_bnd;
	}
	float sum = 0.0;
	for (int d = 0; d < dim; d++) {
		sum += (bnds_hi[d]-bnds_lo[d])*(bnds_hi[d]-bnds_lo[d]);
	}
	float bbxDiagonalLength = sqrt(sum);
	float query_radius = 0.01f * bbxDiagonalLength;
	printf("BBX-DiagonalL=%.6f   Query-Radius=%.6f\n",bbxDiagonalLength,query_radius);

	//--------------------------------------------------------------------------------------
	//	Create tree structure in CPU and transfer it to GPU	
    SRStree *the_tree = new SRStree(pos,ref_nb,dim,bucket_size);
    SRStree_CPU *the_tree_cpu=new SRStree_CPU;
    the_tree_cpu->Reconstruct(the_tree);//reorganize nodes of the tree
    SRStree_GPU *the_tree_gpu=new SRStree_GPU;
    the_tree_gpu->Construct(the_tree_cpu,the_tree_cpu->GetNumNodes(),pos,ref_nb);	// transfer tree onto GPU
	//--------------------------------------------------------------------------------------
    //	Well align the tree nodes
    the_tree_gpu->SortNodes();
	//--------------------------------------------------------------------------------------
    //	Tight fit the bounding boxes
    the_tree_gpu->RefitAABB();

	//--------------------------------------------------------------------------------------
    //	Allocate memory for query points and output results 
    int maxNeighborNum = 1;		//	for specifying the maximally returned number of neighbors in SRS
								//	When the resultant number of neighbors is greater than this number,
								//		our program will randomly pick this number of neighbors to report as results.
								//	If maxNeighborNum=1, NN is conducted.
	//--------------------------------------------------------------------------------------
    float *gpu_queries;		//	for query points
    cudaMalloc((void**)&gpu_queries, sizeof(float)*query_nb*dim);
    cudaMemcpy(gpu_queries,query,sizeof(float)*query_nb*dim,cudaMemcpyHostToDevice);
	//--------------------------------------------------------------------------------------
    int *gpu_ret_indexes;	//	for returning indices of resultant points -- index starting from zero
	float *gpu_ret_dist;    //	for returning the squared distances of every neighbor
	int *gpu_neigh;			//	for returning the numbers of neighbors for each query point
    cudaMalloc((void**)&gpu_ret_indexes, sizeof(int)*query_nb*maxNeighborNum);
    cudaMalloc((void**)&gpu_ret_dist, sizeof(float)*query_nb*maxNeighborNum);
    cudaMalloc((void**)&gpu_neigh, sizeof(int)*query_nb);
    cudaMemset(gpu_ret_indexes, 0xffffffff, query_nb*maxNeighborNum*sizeof(int));
    cudaMemset(gpu_neigh, 0xffffffff, query_nb*sizeof(int));

	//--------------------------------------------------------------------------------------
	//	Copy query points onto GPU
	cudaMemcpy(gpu_queries,query,sizeof(float)*query_nb*dim,cudaMemcpyHostToDevice);

	long time=clock();
	printf("Computation is started ... ...\n");
	//--------------------------------------------------------------------------------------
	//	Randomly move points and conduct the queries of SRS
	bool bRes;
	for(int i = 0; i < iterations; i++)	{
		printf("Iteration: %d \n",i);
		bRes = the_tree_gpu->SearchNN(gpu_queries,query_nb,query_radius,gpu_ret_indexes,gpu_ret_dist);
		if (!bRes) {printf("Running out of memory!\n");break;}
	
		if (i==(iterations-1)) break;

		//----------------------------------------------------------------------------------
		//	Randomly update the positions of data points
		for(int ii = 0; ii < query_nb; ii++) {
			for(int kk = 0; kk < dim; kk++)	{
				float dist = 5.0f*((((float)rand() / (float)RAND_MAX)*2-1)/1000.0f);
				pos[dim*ii+kk] += dist;
			}
		}
		//----------------------------------------------------------------------------------
		the_tree_gpu->SetDataPoints(pos,ref_nb);		// Assigning new positions of data points (copying from CPU to GPU)
		the_tree_gpu->RefitAABB();						// Updating AABBs of the tree

		if (the_tree_gpu->isRebuildNeeded()) {
			printf("**********************************************\n");
			printf("Tree Re-building is activated!\n");
			printf("**********************************************\n");
			float *devPos=the_tree_gpu->GetDataPoints();							// This is an optional step, which is only needed when the data points
			cudaMemcpy(pos,devPos,sizeof(float)*ref_nb*dim,cudaMemcpyDeviceToHost);	//	are updated inside GPU - e.g., GPU-based particle simulation.

			//------------------------------------------------------------------------------
			delete the_tree_gpu;	delete the_tree_cpu;	delete the_tree;

			the_tree = new SRStree(pos,ref_nb,dim,bucket_size);
			the_tree_cpu=new SRStree_CPU;
			the_tree_cpu->Reconstruct(the_tree);
			the_tree_gpu=new SRStree_GPU;
			the_tree_gpu->Construct(the_tree_cpu,the_tree_cpu->GetNumNodes(),pos,ref_nb);
			the_tree_gpu->SortNodes();
			the_tree_gpu->RefitAABB();
		}
	}
	printf("Computation is completed (in %ld ms)!\n",clock()-time);

	//--------------------------------------------------------------------------------------
	//	Output results to files
	int *ret_indexes=(int*)malloc(sizeof(int)*query_nb);
	float *ret_dists=(float*)malloc(sizeof(float)*query_nb);
	cudaMemcpy(ret_indexes, gpu_ret_indexes, sizeof(int)*query_nb, cudaMemcpyDeviceToHost);
	cudaMemcpy(ret_dists, gpu_ret_dist, sizeof(float)*query_nb, cudaMemcpyDeviceToHost);
	//--------------------------------------------------------------------------------------
	FILE *fp = fopen("CSRS_result.txt","w");
	for(int j=0; j< query_nb; j++) {
		fprintf(fp,"%d %.6f\n",ret_indexes[j],sqrt(ret_dists[j]));
	}
	fclose(fp);
	//--------------------------------------------------------------------------------------
	free(ret_indexes);	free(ret_dists);
	printf("Finished.\n\n\n");

	//--------------------------------------------------------------------------------------
	//	Free GPU memory
	cudaFree(gpu_queries);
	cudaFree(gpu_ret_indexes);
	cudaFree(gpu_ret_dist);
	cudaFree(gpu_neigh);
	//--------------------------------------------------------------------------------------
	//	Free CPU memory
	free(pos);	free(query);	
	//--------------------------------------------------------------------------------------
	//	Free memeory of trees
	delete the_tree;    delete the_tree_cpu;	delete the_tree_gpu;
}


int main(int argc, char** argv)
{
	_helloExampleOfCSRS_GeneralSearch();			//	Rank #3 in speed

	_helloExampleOfCSRS_SearchByDataPnts();			//	Rank #2 in speed

	_helloExampleOfCSRS_NearestNeighborSearch();	//	Rank #1 in speed

	return 1;
}
