function [Q1,Q2,R,S,fix_id_expand]=departQ(Q,fix_id,d)
if size(fix_id,1)>1
    fix_id=fix_id';
end
fix_id_expand=(repmat(fix_id,d,1)-1)*d+repmat([1:d]',1,length(fix_id));
fix_id_expand=reshape(fix_id_expand,length(fix_id)*d,1);

Q2=Q(:,fix_id_expand);
Q(:,fix_id_expand)=[];
Q1=Q;
clear Q;

% Q2=Q(:,(fix_id-1)*d+1:(fix_id-1)*d+d);
% Q(:,(fix_id-1)*d+1:(fix_id-1)*d+d)=[];
% Q1=Q;
% clear Q;

%use Cuthill_MCKee algorithm to make chol() to obtail a workable R
%once time rcm
r=symrcm(Q1'*Q1);
P=sparse(r,[1:length(r)],1);
[R,p,S]=chol(P'*Q1'*Q1*P);
S=P*S;