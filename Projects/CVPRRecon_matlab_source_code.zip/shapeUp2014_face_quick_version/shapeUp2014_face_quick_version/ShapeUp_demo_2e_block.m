function [Vxyz]=ShapeUp_demo_2e_block(normal_s,constraints2Vertices,Vxyz,fix_id,update_id,Q2,Q1,R,S,angle_th,d)%col_id,val
%T is row vector: T(1) is projection; T(2) is LS; T(3) resort solution
%based on gaussian_seidel

% blending by LS
m=size(constraints2Vertices,1);
% d=1;
ni=size(constraints2Vertices,2);

%build P
P=zeros(m*ni*d,1);
% demo_P=zeros(m*ni,3);
% demo_constraints=zeros(m,ni);
Ni=eye(ni,ni)-(1/ni).*ones(ni,ni);
Ni=kron(Ni,eye(d,d));

% tempV=zeros(ni,3); %although d==1, but Vxyz have total 3 coordinates id
tempZ=zeros(ni,1);

for i=1:m 
    %projection first
    norV=normal_s(i,:);
    tempV=Vxyz(constraints2Vertices(i,:),:);
    centerV=mean(tempV,1); 
%     tic;
    for k=1:ni
        v1=tempV(k,:);
        tempZ(k)=norm_ProjLS4(norV,v1,centerV,angle_th);
%         tempV(k,3)=tempZ(k);
    end
%     T(1)=T(1)+toc;
    %projection end
    
    %centralize second
%     tic;
    Pi=Ni*tempZ;
    id=(i-1)*ni*d;
    P(id+1:id+ni*d)=Pi;
%     T(2)=T(2)+toc;
%     demo_P(id+1:id+ni*d,:)=tempV;
%     demo_constraints(i,:)=[id+1:id+ni];
end
%build P end

%output update Z
if d==1
    v0=Vxyz(fix_id,3);
else
    v0=reshape(Vxyz(fix_id,:)',length(fix_id)*d,1);
end

B=Q2*v0;
b=Q1'*(P-B);
Z=solveEq_cholDecom2(R,R',S,S',b);
if ~isempty(Z)
    if d>1
        Z=reshape(Z,d,size(Vxyz,1))';
        Vxyz(update_id,:)=Z;
    else
        Vxyz(update_id,3)=Z;
    end
end
    


