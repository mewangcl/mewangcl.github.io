function Main
% the whole reconstruction version by setting blockN=1 in shapeUp_whole

ln=input('please the full folder path of the normal map:\n','s');
fn=input('please name of the normal map including fomrat suffix,like "XX.bmp":\n','s');
%loading normal map
d=1;%dimension of the unkowns, for cvpr2014 version, the depth as the unknowns has one dimension 
angle_th=1;% used to filter the normal vertical to viewing direction (i.e. Z axis)
N=1; % total number used to control the local-global iterations


I=imread(strcat(ln,'\',fn));% normal map loading

tic;
% generate the ROI mask of normal map: mask_nor_0
I=double(I)./255;
mask_nor_0 = im2bw(I, 0);
[rid,cid]=find(mask_nor_0);
I=I(min(rid):max(rid),min(cid):max(cid),:);
mask_nor_0=mask_nor_0(min(rid):max(rid),min(cid):max(cid));

%generate the mapping from pixel xy coordinate to the normal list order: nor_map_mat
height=size(mask_nor_0,1);
width=size(mask_nor_0,2);
nor_id0=find(mask_nor_0);
m=length(nor_id0);
nor_map_mat=zeros(size(mask_nor_0));
clear mask_nor_0;
nor_map_mat(nor_id0)=1:m;

% convert the normal map into vector and record them as an **by3 stack: norm_vector
norm_vector=zeros(m,3);
for k=1:3
    tI=I(:,:,k);
    norm_vector(:,k)=reshape(tI(nor_id0),m,1);
end
clear I;
norm_vector=(norm_vector-0.5).*2;
tn=sqrt(sum(norm_vector.^2,2));
norm_vector(:,1)=norm_vector(:,1)./tn;
norm_vector(:,2)=norm_vector(:,2)./tn;
norm_vector(:,3)=norm_vector(:,3)./tn;

% generate the vertex order vrt_id0
[i1,j1]=ind2sub([height width],nor_id0);
clear nor_id0;
dij=[0 0 1 1;0 1 1 0];    

IJ=repmat([i1';j1'],1,4)+reshape(repmat(dij,length(i1),1),2,4*length(i1));
clear i1;
clear j1;
vrt_id0=unique(sub2ind([height+1 width+1],IJ(1,:)',IJ(2,:)'));
clear IJ;

% build the mapping between vertex order and their xy coordinates: vrt_map_mat
n=length(vrt_id0);
vrt_map_mat=zeros(height+1,width+1);
vrt_map_mat(vrt_id0)=1:n;
vrt_vector=zeros(n,3);

% initialize the xy coordinates for vertexes
[i1,j1]=ind2sub([height+1 width+1],vrt_id0);
vrt_vector(:,1)=j1;%x coord
vrt_vector(:,2)=height-i1+1;%y coord %maybe need invert

%local-global update the vertex
[vrt,vrt_id]=shapeUp_block_mask(nor_map_mat,norm_vector,vrt_map_mat,vrt_vector,d,N,angle_th);
vrt_vector(abs(vrt_id),:)=vrt;
clear vrt
clear vrt_id
t=toc;

%store the vertexes results
display(strcat('The reconstruction is completed, and total "',num2str(t),'" second elapse.'));
display('The reconstructed point cloud is stacked in the matrix of "vrt_vector" as saved in "results.mat".');
save(strcat(ln,'\results.mat'),'nor_map_mat','norm_vector','vrt_map_mat','vrt_vector','t');

while 1
    ss=input('If need to save the results as ".obj" file please enter YES, otherwise enter NO to return:\n','s');
    if strcmp(ss,'YES') || strcmp(ss,'yes')
        writtenIntoObj(ln);
        return;
    elseif strcmp(ss,'NO') || strcmp(ss,'no')
        return;
    end
end
