function [x]=solveEq_cholDecom2(R,R1,S,S1,b)
%b/A = (A'\b')'

b1=S1*b;
z=R1\b1;
y=R\z;
x=S*y;
% try
%     z=R1\b1;
%     y=R\z;
%     x=S*y;
% catch
%     x=[];
% end