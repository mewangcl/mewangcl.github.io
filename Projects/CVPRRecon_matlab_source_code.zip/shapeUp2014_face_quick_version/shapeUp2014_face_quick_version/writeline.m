function writeline(fid,flag,rv,num,format)
if ~isempty(flag)
    fprintf(fid,'%s',flag);
    fprintf(fid,'%s',' ');
end
for i=1:num
    fprintf(fid,format,rv(i));
    fprintf(fid,'%s',' ');
%     if i~=num
%         fprintf(fid,'%s',' ');
%     else
%         fprintf(fid,'%s\r\n','');
%     end
end
fprintf(fid,'%s\r\n','');