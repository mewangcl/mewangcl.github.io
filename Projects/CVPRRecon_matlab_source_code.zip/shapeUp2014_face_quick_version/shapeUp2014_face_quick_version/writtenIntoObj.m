function writtenIntoObj(ln)
A=load(strcat(ln,'\results.mat'));
vrt_map_block=A.vrt_map_mat;
nor_map_block=A.nor_map_mat;
vrt_vector=A.vrt_vector;
norm_vector=A.norm_vector;

vrt_id=find(abs(vrt_map_block)>0);
mask_vrt_id=zeros(size(vrt_map_block));
mask_vrt_id(vrt_id)=1:length(vrt_id);
constraints2Vertices=buildMapping_block_mask(find(nor_map_block>0),mask_vrt_id,size(nor_map_block,1),size(nor_map_block,2));
writeObj3(vrt_vector,[],constraints2Vertices,ln,'surf');

save(strcat(ln,'\results.mat'),'constraints2Vertices','-append');
