function Q=building_Q_block(constraints2Vertices,d)
m=size(constraints2Vertices,1);
ni=4;
Ni=eye(ni,ni)-(1/ni).*ones(ni,ni);
Ni=kron(Ni,eye(d,d));
ri=ni*d;
r1=ni*d^2;
r2=ni^2*d^2;

t_id=(repmat([1:m],ri,1)-1)*ri;
t_id=t_id+repmat([1:ri]',1,m);
t_id=repmat(t_id,d,1);
t_id=repmat(t_id,ni,1);
qr=reshape(t_id,m*r2,1);
clear t_id;

t_id=reshape(constraints2Vertices',m*ni,1)';
t_id=repmat(t_id,ri,1);
t_id=repmat(t_id,d,1);
td=repmat([1:d],ri,1);
td=reshape(td,d*ri,1);
td=repmat(td,1,m*ni);
t_id=(t_id-1)*d+td;
clear td;
qc=reshape(t_id,m*r2,1);
clear t_id;

t_id=repmat([1:ni],d,1);
td=repmat([1:d]',1,ni);
t_id=(t_id-1)*d+td;
clear td;
t_id=reshape(t_id,d*ni,1);
t_id=repmat(t_id,m,1);
qv=reshape(Ni(:,t_id),m*r2,1);
clear t_id;
% 
% 
Q=sparse(qr,qc,qv);




