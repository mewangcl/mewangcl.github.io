function P=proj_depth(V,constraints2Vertices,norm_s,slct_id,Ni)

d=1;%dimension of unkowns, that is the depth
ni=size(constraints2Vertices,2);
m=size(constraints2Vertices,1);% total number of pixels or normals
t_id=reshape(constraints2Vertices',numel(constraints2Vertices),1);

tv0=V(t_id,:);
tv=reshape(tv0',3,ni,m);
cv=mean(tv,2);
clear tv
cv=reshape(cv,3,m)';

t_cnt=repmat(cv,1,ni);
clear cv
t_cnt=reshape(t_cnt',3,ni*m)';

t_nor=repmat(norm_s,1,ni);
t_nor=reshape(t_nor',3,ni*m)';

tv=tv0;
tv(:,3)=0;
t=dot(t_nor,tv-t_cnt,2);
clear t_cnt tv
tv0(slct_id,3)=-1*t(slct_id)./t_nor(slct_id,3);
clear t_nor;

t_vrt=reshape(tv0(:,3)',ni*d,m);

P=Ni*t_vrt;
clear t_vrt
P=reshape(P,m*ni*d,1);
