function constraints2Vertices=buildMapping_block_mask(nor_id,mask_vrt_id,height,width)
%the order are stack in matlab's default order: column first and row next
[i1,j1]=ind2sub([height width],nor_id);
dij=[0 0 1 1;0 1 1 0];
IJ=repmat([i1';j1'],1,4)+reshape(repmat(dij,length(i1),1),2,4*length(i1));
constraints2Vertices=reshape(mask_vrt_id(sub2ind([height+1 width+1],IJ(1,:)',IJ(2,:)')),length(i1),4);


% m0=length(nor_id);
% constraints2Vertices=zeros(m0,4);
% for i=1:m0
%     [i1,j1]=ind2sub([height width],nor_id(i));
%     constraints2Vertices(i,:)=...
%         mask_vrt_id(sub2ind([height+1 width+1],[i1 i1 i1+1 i1+1],[j1 j1+1 j1+1 j1]));  
% end