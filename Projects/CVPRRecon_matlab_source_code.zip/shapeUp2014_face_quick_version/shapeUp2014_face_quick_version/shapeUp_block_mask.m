function [vrt,vrt_id]=shapeUp_block_mask(nor_map_block,norm_vector,vrt_map_block,vrt_vector,d,K,angle_th)
%face_block, size is height*width*3
%V_block, size is height*width*3
%mask_nor, is the normal fabel, size is height*width, background is 0, interested is 1
%mask_vrt, is the vertex label, size is (height+1)*(width+1), background is 0, interested is 1, fix is 2

nor_id=find(nor_map_block>0);
if isempty(nor_id)
    vrt=[];
    vrt_id=[];
    return;
end
m=length(nor_id);
norm_s=norm_vector(nor_map_block(nor_id),:);
clear norm_vector;

% mask_nor_id=zeros(size(nor_map_block));
% mask_nor_id(nor_id)=1:m;

vrt_id=find(abs(vrt_map_block)>0);
n=length(vrt_id);
vrt=vrt_vector(abs(vrt_map_block(vrt_id)),:);

mask_vrt_id=zeros(size(vrt_map_block));
mask_vrt_id(vrt_id)=1:n;
fix_id=mask_vrt_id(find(vrt_map_block<0));
if isempty(fix_id)
    fix_id=1;
end

constraints2Vertices=buildMapping_block_mask(nor_id,mask_vrt_id,size(nor_map_block,1),size(nor_map_block,2));
clear nor_id;
clear mask_vrt_id;
clear nor_map_block;
Q=building_Q_block(constraints2Vertices,d);
[Q1,Q2,R,S]=departQ(Q,fix_id,d);
clear Q;
update_id=1:n;
update_id(fix_id)=[];
v0=reshape(vrt(fix_id,3)',length(fix_id)*d,1);
B=Q2*v0;

ni=size(constraints2Vertices,2);
Ni=eye(ni,ni)-(1/ni).*ones(ni,ni);
Ni=kron(Ni,eye(d,d));
[slct_id]=ini_proj_depth(constraints2Vertices,norm_s,angle_th);


for k=1:K
    P=proj_depth(vrt,constraints2Vertices,norm_s,slct_id,Ni);    
    
    b=Q1'*(P-B);
    td=solveEq_cholDecom2(R,R',S,S',b);
    vrt(update_id,3)=reshape(td,d,length(update_id))';
end
vrt_id=abs(vrt_map_block(vrt_id));



