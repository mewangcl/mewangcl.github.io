function [new_z]=norm_ProjLS4(n,v,c,th)
%n,v, c are row vectors
%n is the normalized normal vector
%v is the vertex position which is needed to be projected
%c is current patch center position, where normal n is placed.
%th is angle degree which is used to limited normal n

if isempty(th)
    new_z=-1*(n(1)*(v(1)-c(1))+n(2)*(v(2)-c(2)))/n(3)+c(3);
    
else
    if n(3)<=1*sin(th/180*pi) %ignore those normal whose angle with z is less than 0.5 angle degree,here n is normalized vector, so its amplitude is 1
        new_z=v(3);
%         1
    else
        new_z=-1*(n(1)*(v(1)-c(1))+n(2)*(v(2)-c(2)))/n(3)+c(3);
    end
end

% %projection by deviate the ill normal
% if isempty(th)
%     new_z=-1*(n(1)*(v(1)-c(1))+n(2)*(v(2)-c(2)))/n(3)+c(3);
% %     if n(3)<=0
% %         new_z=v(3);
% %     else
% %         new_z=-1*(n(1)*(v(1)-c(1))+n(2)*(v(2)-c(2)))/n(3)+c(3);
% %     end
% else
%     if n(3)<=1*sin(th/180*pi) %ignore those normal whose angle with z is less than 0.5 angle degree,here n is normalized vector, so its amplitude is 1
%         n(3)=n(3)+sin(85/180*pi);
%         n=n/norm(n);
%     end
%     new_z=-1*(n(1)*(v(1)-c(1))+n(2)*(v(2)-c(2)))/n(3)+c(3);
% end

