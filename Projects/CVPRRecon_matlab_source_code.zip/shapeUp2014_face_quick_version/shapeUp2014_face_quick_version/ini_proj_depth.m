function [slct_id]=ini_proj_depth(constraints2Vertices,norm_s,th)

ni=size(constraints2Vertices,2);
m=size(constraints2Vertices,1);
% t_id=reshape(constraints2Vertices',numel(constraints2Vertices),1);

t_nor=repmat(norm_s,1,ni);
t_nor=reshape(t_nor',3,ni*m)';

t_Ag=real(asin(t_nor(:,3)))*180/pi;
if isempty(th)
    slct_id=1:size(norm_s,1);
else
    slct_id=find(t_Ag>0 & t_Ag>=th);
end

