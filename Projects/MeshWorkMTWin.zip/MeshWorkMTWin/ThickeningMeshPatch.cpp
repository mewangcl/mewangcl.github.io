#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <memory.h>
#include <time.h>

#if defined (__APPLE__)
#else
#include <omp.h>
#endif

//#include "GLKLib/GLKHeap.h"
#include "GLKLib/GLKObList.h"
#include "GLKLib/GLKGeometry.h"
#include "GLKLib/GLKMatrixLib.h"

#include "QMeshLib/QMeshPatch.h"
#include "QMeshLib/QMeshFace.h"
#include "QMeshLib/QMeshEdge.h"
#include "QMeshLib/QMeshNode.h"

#include "PQPLib/PQP.h"

//#include "CLNarrowBandFieldContouring.h"

#include "ThickeningMeshPatch.h"

#define	_CCL_SVD_THRESHOLD				0.05


const int gridSearchTable[3][4][3] = {
	{ { 0, -1, -1 }, { 0, 0, -1 }, { 0, 0, 0 }, { 0, -1, 0 } },
	{ { -1, 0, -1 }, { -1, 0, 0 }, { 0, 0, 0 }, { 0, 0, -1 } },
	{ { -1, -1, 0 }, { 0, -1, 0 }, { 0, 0, 0 }, { -1, 0, 0 } }
};

ThickeningMeshPatch::ThickeningMeshPatch(void)
{
	m_trglFaceNum = 0;
}

ThickeningMeshPatch::~ThickeningMeshPatch(void)
{
}

void ThickeningMeshPatch::DoPatchThickening(QMeshPatch *mesh, double offset, int res)
{
	GLKPOSITION Pos;	GLKObList originalFaceList, removedFaceList, removedEdgeList;
	long time = clock();

	//-----------------------------------------------------------------------------------------------
	//	Step 1: Initialization
	if (!_isTrglMeshSurface(mesh)) { mesh->outputTrglOBJFile("_temp.tmp"); mesh->inputOBJFile("_temp.tmp"); }
	if (!_isOpenMeshSurface(mesh)) printf("Warning: this is not an open surface!\n");
	if (offset<0.0) { mesh->InverseOrientation();	offset = fabs(offset); }
	_compBndBoxAndUpdateRes(mesh, res, offset);
	_mallocGridNodeArray();		m_offset = offset;
	//-----------------------------------------------------------------------------------------------
	PQP_Model *pqpModel;
	pqpModel = _pqpInitialization(mesh);
	//-----------------------------------------------------------------------------------------------
	printf("Step 1: Initialization - %ld (ms)\n", clock() - time);	time = clock();
//	printf("faceNum=%d\n", mesh->GetFaceList().GetCount());

	//-----------------------------------------------------------------------------------------------
	//	Step 2: Construction the volumetric representation of the thickened solid
#if defined (__APPLE__)
#else
    omp_set_dynamic(8);
	omp_set_num_threads(16);
	printf("Number of Threads Allowed: %d\n", omp_get_max_threads());
#pragma omp parallel for schedule(dynamic)
#endif
	for (int loop = 0; loop<64; loop++) {
		int i = loop % 16;	i = i % 4;
		int j = loop % 16;	j = j / 4;
		int k = loop / 16;	int delta = m_res / 4;
		_fieldValueGeneration(pqpModel, i*delta, j*delta, k*delta, i*delta + delta, j*delta + delta, k*delta + delta);
	}
	printf("Step 2: Grid nodes generation - %ld (ms)\n", clock() - time);	time = clock();

	//-----------------------------------------------------------------------------------------------
	//	Step 3: Partial construction to fit the reconstructed patch onto the existing patch
	_mallocGridEdgeArray();		_mallocGridCellArray();
	_constructionOfBndGridCells(mesh);
	_splittingBoundaryEdgesOnExistingPatch(mesh, &removedFaceList, &removedEdgeList);
	originalFaceList.AddTail(&(mesh->GetFaceList()));
	_constructionOfGridEdges(pqpModel, true);
	_constructionOfGridCells(mesh);
	_dualContouringBasedFaceGeneration(mesh, pqpModel);
	printf("Step 3: Faces generation - %ld (ms)\n", clock() - time);	time = clock();

	//-----------------------------------------------------------------------------------------------
	//	Step 4: Shape optimization -- to form sharp edges by the distance-field
	_shapeOptimization(mesh, 10, 0.25);
	printf("Step 4: Shape optimization - %ld (ms)\n", clock() - time);	time = clock();

	//-----------------------------------------------------------------------------------------------
	//	Step 5: Free the memory 
	delete pqpModel;
	_freeGridNodeArray();		_freeGridEdgeArray();		_freeGridCellArray();
	if (m_trglFaceNum>0) delete (QMeshFace**)m_faceArray;
	for (Pos = removedFaceList.GetHeadPosition(); Pos != NULL;) {
		QMeshFace *face = (QMeshFace *)(removedFaceList.GetNext(Pos));
		delete face;
	}
	for (Pos = removedEdgeList.GetHeadPosition(); Pos != NULL;) {
		QMeshEdge *edge = (QMeshEdge *)(removedEdgeList.GetNext(Pos));
		delete edge;
	}

	//-----------------------------------------------------------------------------------------------
	//	Step 6: Post-processing for repair the problem on reconstructed mesh surface
	_quadMeshToTrglMesh(mesh);
	_refillMeshTopology(mesh);
	_nodeOpeningForHoleTopologyFiltering(mesh);
	_singularRemovalForHoleTopologyFiltering(mesh);
	_holeTriangulation(mesh);
	_fillMeshTopology(mesh);
	printf("Step 5: Post-processing - %ld (ms)\n", clock() - time);	time = clock();
	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL;) {
		QMeshFace *face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		face->m_nIdentifiedPatchIndex = 2;
	}
	for (Pos = originalFaceList.GetHeadPosition(); Pos != NULL;) {
		QMeshFace *face = (QMeshFace *)(originalFaceList.GetNext(Pos));
		face->m_nIdentifiedPatchIndex = -1;
	}
}

void ThickeningMeshPatch::DoHoleTriangulation(QMeshPatch *mesh)
{
    _holeTriangulation(mesh);
    _fillMeshTopology(mesh);
}

bool ThickeningMeshPatch::_removeRegionByFaceFlag(QMeshPatch *_mesh, int whichFlag)
{
	GLKPOSITION Pos;	GLKPOSITION PosLink;
	GLKPOSITION TempPos;
	QMeshEdge *edge;	QMeshFace *face;	QMeshNode *node;
	bool bWithFaceDeleted = false;

	//--------------------------------------------------------------------------
	//	Determine edges to be removed
	for (Pos = (_mesh->GetEdgeList()).GetHeadPosition(); Pos != NULL;) {
		edge = (QMeshEdge *)((_mesh->GetEdgeList()).GetNext(Pos));
		edge->SetAttribFlag(3, true);
	}
	for (Pos = (_mesh->GetFaceList()).GetHeadPosition(); Pos != NULL;) {
		face = (QMeshFace *)((_mesh->GetFaceList()).GetNext(Pos));
		if (face->GetAttribFlag(whichFlag)) continue;
		int i, edgeNum = face->GetEdgeNum();
		for (i = 0; i<edgeNum; i++) face->GetEdgeRecordPtr(i)->SetAttribFlag(3, false);
	}

	//--------------------------------------------------------------------------
	//	Determine nodes to be removed
	for (Pos = (_mesh->GetNodeList()).GetHeadPosition(); Pos != NULL;) {
		node = (QMeshNode *)((_mesh->GetNodeList()).GetNext(Pos));
		node->SetAttribFlag(7, false);
		bool bRemove = true;
		for (PosLink = node->GetFaceList().GetHeadPosition(); PosLink != NULL;) {
			face = (QMeshFace*)(node->GetFaceList().GetNext(PosLink));
			if (face->GetAttribFlag(whichFlag) != true) { bRemove = false; break; }
		}
		if (bRemove) {
			for (PosLink = node->GetEdgeList().GetHeadPosition(); PosLink != NULL;) {
				edge = (QMeshEdge*)(node->GetEdgeList().GetNext(PosLink));
				if (edge->GetAttribFlag(3) != true) { bRemove = false; break; }
			}
		}
		if (bRemove) node->SetAttribFlag(7, true);
	}

	//--------------------------------------------------------------------------
	//	Remove faces
	for (Pos = (_mesh->GetFaceList()).GetHeadPosition(); Pos != NULL;) {
		TempPos = Pos;
		face = (QMeshFace *)((_mesh->GetFaceList()).GetNext(Pos));
		if (face->GetAttribFlag(whichFlag)) {
			int i, edgeNum = face->GetEdgeNum();
			for (i = 0; i<edgeNum; i++) {
				face->GetEdgeRecordPtr(i)->SetAttribFlag(0);
				if (face->GetEdgeRecordPtr(i)->GetLeftFace() == face)
					face->GetEdgeRecordPtr(i)->SetLeftFace(NULL);
				if (face->GetEdgeRecordPtr(i)->GetRightFace() == face)
					face->GetEdgeRecordPtr(i)->SetRightFace(NULL);
				face->GetNodeRecordPtr(i)->GetFaceList().Remove(face);
			}
			_mesh->GetFaceList().RemoveAt(TempPos);
			delete face;	bWithFaceDeleted = true;
		}
	}

	//--------------------------------------------------------------------------
	//	Remove edges
	for (Pos = (_mesh->GetEdgeList()).GetHeadPosition(); Pos != NULL;) {
		TempPos = Pos;
		edge = (QMeshEdge *)((_mesh->GetEdgeList()).GetNext(Pos));
		if (edge->GetAttribFlag(3)) {
			_mesh->GetEdgeList().RemoveAt(TempPos);
			edge->GetStartPoint()->GetEdgeList().Remove(edge);
			edge->GetEndPoint()->GetEdgeList().Remove(edge);
			delete edge;
		}
		else {
			edge->SetAttribFlag(0, false);
			if (edge->GetLeftFace() == NULL || edge->GetRightFace() == NULL){
				edge->SetAttribFlag(0, true);
				edge->GetStartPoint()->SetAttribFlag(0, true);
				edge->GetEndPoint()->SetAttribFlag(0, true);
			}
		}
	}

	//--------------------------------------------------------------------------
	//	Remove nodes
	for (Pos = (_mesh->GetNodeList()).GetHeadPosition(); Pos != NULL;) {
		TempPos = Pos;
		node = (QMeshNode *)((_mesh->GetNodeList()).GetNext(Pos));
		if (node->GetAttribFlag(7)) {
			_mesh->GetNodeList().RemoveAt(TempPos);
			delete node;
		}
	}

	return bWithFaceDeleted;
}

void ThickeningMeshPatch::_holeTriangulation(QMeshPatch *mesh)
{
	GLKObList nodeList, bndEdgeList;
	GLKPOSITION Pos;

	//------------------------------------------------------------------------------
	//	Preparation
	for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL;) {
		QMeshNode *node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->SetAttribFlag(0, false);
		node->SetAttribFlag(7, false);
	}
	bndEdgeList.RemoveAll();
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		QMeshEdge *edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->SetAttribFlag(0, false);
		edge->SetAttribFlag(7, false);
		if ((edge->GetLeftFace() == NULL) || (edge->GetRightFace() == NULL)) {
			edge->SetAttribFlag(0, true);
			bndEdgeList.AddTail(edge);
			edge->GetStartPoint()->SetAttribFlag(0, true);
			edge->GetEndPoint()->SetAttribFlag(0, true);
		}
		if ((edge->GetLeftFace() == NULL) && (edge->GetRightFace() == NULL)) printf("Warning: hanging edge is found!!!\n");
	}

	//------------------------------------------------------------------------------
	//	Search the holes and triangulate them one by one
	printf("Starting to process the holes.\n");	bool bFilled = false;
	do{
		nodeList.RemoveAll();	// the nodes of the current loop

		//--------------------------------------------------------------------------
		//	search out the loop of boundary edges
		QMeshEdge *currentEdge = NULL;
		for (Pos = bndEdgeList.GetHeadPosition(); Pos != NULL;) {
			QMeshEdge *edge = (QMeshEdge *)(bndEdgeList.GetNext(Pos));
			if (edge->GetAttribFlag(7)) continue;
			currentEdge = edge; break;
		}
		if (currentEdge == NULL) {
			if (!bFilled)
				printf("**************************************************\nNote that - No hole filling step is needed!\n**************************************************\n");
			break;
		}
		bFilled = true;
		//--------------------------------------------------------------------------
		QMeshNode *currentNode, *nextNode;
		currentEdge->SetAttribFlag(7);
		if (currentEdge->GetLeftFace() == NULL) {
			nodeList.AddTail(currentEdge->GetStartPoint());
			nodeList.AddTail(currentEdge->GetEndPoint());
			currentNode = currentEdge->GetEndPoint();
		}
		else {
			nodeList.AddTail(currentEdge->GetEndPoint());
			nodeList.AddTail(currentEdge->GetStartPoint());
			currentNode = currentEdge->GetStartPoint();
		}
		do{
			nextNode = NULL;
			for (Pos = currentNode->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
				QMeshEdge *edge = (QMeshEdge *)(currentNode->GetEdgeList().GetNext(Pos));
				if (!(edge->GetAttribFlag(0))) continue;
				if (edge->GetAttribFlag(7)) continue;

				if (((edge->GetLeftFace() == NULL) && (edge->GetEndPoint() == currentNode))
					|| ((edge->GetRightFace() == NULL) && (edge->GetStartPoint() == currentNode)))
					printf("Error: incorrect topology of hole is found!!!\n");
				else {
					edge->SetAttribFlag(7, true);
					if (edge->GetStartPoint() == currentNode) { nextNode = edge->GetEndPoint(); break; }
					if (edge->GetEndPoint() == currentNode) { nextNode = edge->GetStartPoint(); break; }
				}
			}
			if (nextNode != NULL) nodeList.AddTail(nextNode);
			currentNode = nextNode;
		} while (nextNode != NULL);

		if (nodeList.IsEmpty()) break;
		nodeList.RemoveTail();

		//--------------------------------------------------------------------------
		//	hole triangulation
		_minimalAreaHoleTriangulation(&nodeList, mesh, -1);

		for (Pos = nodeList.GetHeadPosition(); Pos != NULL;) {
			QMeshNode *node = (QMeshNode *)(nodeList.GetNext(Pos));
			node->SetAttribFlag(0, false);
		}
	} while (!(nodeList.IsEmpty()));

	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		QMeshEdge *edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->SetAttribFlag(0, false);
		if ((edge->GetLeftFace() == NULL) || (edge->GetRightFace() == NULL)) {
			edge->SetAttribFlag(0, true);
			edge->GetStartPoint()->SetAttribFlag(0, true);
			edge->GetEndPoint()->SetAttribFlag(0, true);
		}
	}
}

void ThickeningMeshPatch::_singularRemovalForHoleTopologyFiltering(QMeshPatch *mesh)
{
	GLKPOSITION Pos;	GLKPOSITION PosEdge;	GLKPOSITION PosEdge2;
	bool bSingularFound = false;

	for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL;) {
		QMeshNode *node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->SetAttribFlag(0, false);
	}
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		QMeshEdge *edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->SetAttribFlag(0, false);
		if ((edge->GetLeftFace() == NULL) || (edge->GetRightFace() == NULL)) {
			edge->SetAttribFlag(0, true);
			edge->GetStartPoint()->SetAttribFlag(0, true);
			edge->GetEndPoint()->SetAttribFlag(0, true);
		}
	}

	do{
		bSingularFound = false;
		for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL;) {
			QMeshNode *node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
			if (!(node->GetAttribFlag(0))) continue;

			int nCount = 0;
			for (PosEdge = node->GetEdgeList().GetHeadPosition(); PosEdge != NULL;) {
				QMeshEdge *edge = (QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
				if (edge->GetAttribFlag(0)) nCount++;
			}
			if (nCount == 0) { node->SetAttribFlag(0, false); continue; }

			if (nCount != 2) {
				//			printf("Warning: a node with %d of boundary edges is found!!! Face Number = %d\n",nCount,node->GetFaceNumber());
				bSingularFound = true;
				GLKPOSITION PosFace;
				for (PosFace = node->GetFaceList().GetHeadPosition(); PosFace != NULL;) {
					QMeshFace *face = (QMeshFace *)(node->GetFaceList().GetNext(PosFace));
					face->SetAttribFlag(5, true);
				}
			}

			for (PosEdge = node->GetEdgeList().GetHeadPosition(); PosEdge != NULL;) {
				QMeshEdge *edge = (QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
				if (!(edge->GetAttribFlag(0))) continue;

				QMeshNode *otherNode;
				if (edge->GetStartPoint() == node) otherNode = edge->GetEndPoint(); else otherNode = edge->GetStartPoint();
				for (PosEdge2 = otherNode->GetEdgeList().GetHeadPosition(); PosEdge2 != NULL;) {
					QMeshEdge *edge2 = (QMeshEdge *)(otherNode->GetEdgeList().GetNext(PosEdge2));
					if (edge2->GetAttribFlag(0) && edge2 != edge) {
						if (edge2->GetStartPoint() == node || edge2->GetEndPoint() == node) {
							bSingularFound = true;
							if (edge->GetLeftFace() != NULL) edge->GetLeftFace()->SetAttribFlag(5);
							if (edge->GetRightFace() != NULL) edge->GetRightFace()->SetAttribFlag(5);
							if (edge2->GetLeftFace() != NULL) edge2->GetLeftFace()->SetAttribFlag(5);
							if (edge2->GetRightFace() != NULL) edge2->GetRightFace()->SetAttribFlag(5);
						}
					}
				}
			}
		}

		if (bSingularFound) _removeRegionByFaceFlag(mesh, 5);
	} while (bSingularFound);
}

void ThickeningMeshPatch::_faceRegionIDPropagate(QMeshFace *seedFace, QMeshNode *aroundNode, int id)
{
	int i, edgeNum = seedFace->GetEdgeNum();

	seedFace->m_nIdentifiedPatchIndex = id;
	for (i = 0; i<edgeNum; i++) {
		QMeshEdge *edge = seedFace->GetEdgeRecordPtr(i);
		if ((edge->GetStartPoint() != aroundNode) && (edge->GetEndPoint() != aroundNode)) continue;
		QMeshFace *otherFace;
		if (seedFace->IsNormalDirection(i))
			otherFace = edge->GetRightFace();
		else
			otherFace = edge->GetLeftFace();
		if (otherFace == NULL) continue;
		if (otherFace->m_nIdentifiedPatchIndex != -1) continue;

		_faceRegionIDPropagate(otherFace, aroundNode, id);
	}
}

void ThickeningMeshPatch::_nodeOpeningForHoleTopologyFiltering(QMeshPatch *mesh)
{
	GLKObList nodeList, edgeList, faceList;
	GLKPOSITION Pos;	GLKPOSITION PosEdge;	GLKPOSITION PosFace;
	double xx, yy, zz;

	//------------------------------------------------------------------------------
	//	Determine the list of nodes to be processed
	for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL;) {
		QMeshNode *node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->SetAttribFlag(0, false);
		node->SetAttribFlag(7, false);
		node->GetFaceList().RemoveAll();
		node->GetEdgeList().RemoveAll();
	}
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		QMeshEdge *edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->SetAttribFlag(0, false);
		edge->SetAttribFlag(7, false);
		edge->GetStartPoint()->GetEdgeList().AddTail(edge);
		edge->GetEndPoint()->GetEdgeList().AddTail(edge);
		if ((edge->GetLeftFace() == NULL) || (edge->GetRightFace() == NULL)) {
			edge->SetAttribFlag(0, true);
			edge->GetStartPoint()->SetAttribFlag(0, true);
			edge->GetEndPoint()->SetAttribFlag(0, true);
		}
		if ((edge->GetLeftFace() == NULL) && (edge->GetRightFace() == NULL))
			printf("Warning: hanging edge is found!!!\n");
	}
	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL;) {
		QMeshFace *face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		face->m_nIdentifiedPatchIndex = -1;
		face->GetNodeRecordPtr(0)->GetFaceList().AddTail(face);
		face->GetNodeRecordPtr(1)->GetFaceList().AddTail(face);
		face->GetNodeRecordPtr(2)->GetFaceList().AddTail(face);
		face->SetAttribFlag(5, false);
	}
	//------------------------------------------------------------------------------
	for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL;) {
		QMeshNode *node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		if (!(node->GetAttribFlag(0))) continue;
		int nCount = 0;
		for (PosEdge = node->GetEdgeList().GetHeadPosition(); PosEdge != NULL;) {
			QMeshEdge *edge = (QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
			if (edge->GetAttribFlag(0)) nCount++;
		}
		if (nCount>2) {
			nodeList.AddTail(node);
			//			if (nCount%2!=0) printf("WARNING: odd number of boundary edges are found - %d!\n",nCount);
			//			printf("%d number of boundary edges are found!\n",nCount);
		}
	}
	if (nodeList.IsEmpty()) return;

	//------------------------------------------------------------------------------
	//	Processing the node opening
	for (Pos = nodeList.GetHeadPosition(); Pos != NULL;) {
		QMeshNode *centerNode = (QMeshNode *)(nodeList.GetNext(Pos));
		centerNode->SetAttribFlag(7, true);

		edgeList.RemoveAll();	edgeList.AddTail(&(centerNode->GetEdgeList()));
		for (PosEdge = edgeList.GetHeadPosition(); PosEdge != NULL;) {
			QMeshEdge *edge = (QMeshEdge *)(edgeList.GetNext(PosEdge));
			edge->SetAttribFlag(7, true);
		}
		faceList.RemoveAll();	faceList.AddTail(&(centerNode->GetFaceList()));
		centerNode->GetEdgeList().RemoveAll();
		centerNode->GetFaceList().RemoveAll();

		//---------------------------------------------------------------------------
		//	Step 1: group the faces
		int i, groupNum = 0;	QMeshFace *seedFace;
		do{
			seedFace = NULL;
			for (PosFace = faceList.GetHeadPosition(); PosFace != NULL;) {
				QMeshFace *face = (QMeshFace *)(faceList.GetNext(PosFace));
				if (face->m_nIdentifiedPatchIndex != -1) continue;
				seedFace = face; break;
			}
			if (seedFace == NULL) break;

			_faceRegionIDPropagate(seedFace, centerNode, groupNum + 1);
			groupNum++;
		} while (seedFace != NULL);

		if (groupNum>1) {
			//			printf("%d ",groupNum);
			//---------------------------------------------------------------------------
			//	Step 2: create new nodes
			QMeshNode **nodeArray;
			nodeArray = (QMeshNode **)new long[groupNum];
			nodeArray[0] = centerNode;	centerNode->GetCoord3D(xx, yy, zz);
			for (i = 1; i<groupNum; i++) {
				nodeArray[i] = new QMeshNode;				nodeArray[i]->SetMeshPatchPtr(mesh);
				nodeArray[i]->SetCoord3D(xx, yy, zz);		mesh->GetNodeList().AddTail(nodeArray[i]);
				nodeArray[i]->SetAttribFlag(0);
			}

			//---------------------------------------------------------------------------
			//	Step 3: replace nodes in the edges and faces
			for (PosFace = faceList.GetHeadPosition(); PosFace != NULL;) {
				QMeshFace *face = (QMeshFace *)(faceList.GetNext(PosFace));
				for (i = 0; i<3; i++) {
					if (!(face->GetNodeRecordPtr(i) == centerNode)) continue;
					nodeArray[face->m_nIdentifiedPatchIndex - 1]->GetFaceList().AddTail(face);
				}
			}
			for (PosEdge = edgeList.GetHeadPosition(); PosEdge != NULL;) {
				QMeshEdge *edge = (QMeshEdge *)(edgeList.GetNext(PosEdge));
				int groupID;
				if (edge->GetLeftFace()) groupID = edge->GetLeftFace()->m_nIdentifiedPatchIndex - 1;
				if (edge->GetRightFace()) groupID = edge->GetRightFace()->m_nIdentifiedPatchIndex - 1;
				if (edge->GetStartPoint() == centerNode) {
					edge->SetStartPoint(nodeArray[groupID]);
					nodeArray[groupID]->GetEdgeList().AddTail(edge);
				}
				else if (edge->GetEndPoint() == centerNode) {
					edge->SetEndPoint(nodeArray[groupID]);
					nodeArray[groupID]->GetEdgeList().AddTail(edge);
				}
			}

			delete[](QMeshNode **)nodeArray;
		}

		//---------------------------------------------------------------------------
		//	Step 4: set the value of variables back
		for (PosFace = faceList.GetHeadPosition(); PosFace != NULL;) {
			QMeshFace *face = (QMeshFace *)(faceList.GetNext(PosFace));
			face->m_nIdentifiedPatchIndex = -1;
		}
		for (PosEdge = edgeList.GetHeadPosition(); PosEdge != NULL;) {
			QMeshEdge *edge = (QMeshEdge *)(edgeList.GetNext(PosEdge));
			edge->SetAttribFlag(7, false);
		}
	}

	//---------------------------------------------------------------------------
	//	Remove the hanging edges
	edgeList.RemoveAll();
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		QMeshEdge *edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		if ((edge->GetLeftFace() == NULL) && (edge->GetRightFace() == NULL))
			delete edge;
		else
			edgeList.AddTail(edge);
	}
	mesh->GetEdgeList().RemoveAll();
	mesh->GetEdgeList().AttachListTail(&edgeList);	edgeList.RemoveAllWithoutFreeMemory();
}

void ThickeningMeshPatch::_refillMeshTopology(QMeshPatch *mesh)
{
	GLKPOSITION Pos;	int i;
	QMeshNode *node;	QMeshEdge *edge;	QMeshFace *face;

	i = 1;
	for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL; i++) {
		node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->SetIndexNo(i);
		node->GetEdgeList().RemoveAll();
		node->GetFaceList().RemoveAll();
		node->GetNodeList().RemoveAll();
		node->SetAttribFlag(0, false);
	}
	i = 1;
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL; i++) {
		edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->SetIndexNo(i);
		edge->SetLeftFace(NULL);	edge->SetRightFace(NULL);
		edge->SetAttribFlag(0, false);
	}
	i = 1;
	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL; i++) {
		face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		face->SetIndexNo(i);
		face->m_nIdentifiedPatchIndex = -1;
		int eNum = face->GetEdgeNum();
		for (int i = 0; i<eNum; i++) {
			if (face->IsNormalDirection(i))
				face->GetEdgeRecordPtr(i)->SetLeftFace(face);
			else
				face->GetEdgeRecordPtr(i)->SetRightFace(face);
			face->GetNodeRecordPtr(i)->AddFace(face);
		}
	}
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->GetStartPoint()->AddEdge(edge);
		edge->GetEndPoint()->AddEdge(edge);
		edge->GetAttachedList().RemoveAll();
		if (edge->GetLeftFace() == NULL || edge->GetRightFace() == NULL) {
			edge->SetAttribFlag(0);
			edge->GetStartPoint()->SetAttribFlag(0);
			edge->GetEndPoint()->SetAttribFlag(0);
		}
	}
}

void ThickeningMeshPatch::_quadMeshToTrglMesh(QMeshPatch *mesh)
{
	GLKPOSITION Pos;	GLKObList newFaceList;
	QMeshEdge *edges[4];	QMeshNode *nodes[4];	bool bEdgeDirs[4];
	int i;		double pos[4][3];
	double d1, d2, dd;	short nCase;
	double nv1[3], nv2[3];	bool bRes;		//double hP[3],hV[3];
	GLKGeometry geo;

	newFaceList.RemoveAll();
	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL;) {
		QMeshFace *face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		//face->CalPlaneEquation();
		face->SetAttribFlag(4, false);
		if (face->GetEdgeNum() == 3) continue;

		//--------------------------------------------------------------------------------
		//	Step 1: data preparation
		for (i = 0; i<4; i++) {
			edges[i] = face->GetEdgeRecordPtr(i);
			nodes[i] = face->GetNodeRecordPtr(i);
			bEdgeDirs[i] = face->IsNormalDirection(i);
			face->GetNodePos(i, pos[i][0], pos[i][1], pos[i][2]);
		}

		//--------------------------------------------------------------------------------
		//	Step 2: detect the optimal triangulation (case 0: linking 0-2; case 1: linking 1-3)
		//--------------------------------------------------------------------------------
		//	evaluate the objective function for normal variation
		double hPos[3], hNormal[3];
		face->GetHermiteData(hPos, hNormal);
		//--------------------------------------------------------------------------------
		bRes = geo.CalPlaneEquation(pos[0], pos[1], pos[2], nv1[0], nv1[1], nv1[2], dd);
		if (!bRes) { nv1[0] = 0.0; nv1[1] = 0.0; nv1[2] = 0.0; }
		bRes = geo.CalPlaneEquation(pos[0], pos[2], pos[3], nv2[0], nv2[1], nv2[2], dd);
		if (!bRes) { nv2[0] = 0.0; nv2[1] = 0.0; nv2[2] = 0.0; }
		d1 = geo.VectorProject(nv1, nv2);
		//--------------------------------------------------------------------------------
		bRes = geo.CalPlaneEquation(pos[0], pos[1], pos[3], nv1[0], nv1[1], nv1[2], dd);
		if (!bRes) { nv1[0] = 0.0; nv1[1] = 0.0; nv1[2] = 0.0; }
		bRes = geo.CalPlaneEquation(pos[1], pos[2], pos[3], nv2[0], nv2[1], nv2[2], dd);
		if (!bRes) { nv2[0] = 0.0; nv2[1] = 0.0; nv2[2] = 0.0; }
		d2 = geo.VectorProject(nv1, nv2);
		//--------------------------------------------------------------------------------
		double normal_threshold = 0.000001;
		if ((d1<d2))// && (fabs(d2-d1)>normal_threshold)) 
			nCase = 1;
		else if ((d1>d2))// && (fabs(d1-d2)>normal_threshold))
			nCase = 0;
		else {
			d1 = geo.Distance_to_Point(pos[0], pos[2]);
			d2 = geo.Distance_to_Point(pos[1], pos[3]);
			if (d1<d2) nCase = 0; else nCase = 1;
		}

		//--------------------------------------------------------------------------------
		//	Step 3: 
		switch (nCase) {
		case 0:{
				   QMeshEdge *newEdge = new QMeshEdge;
				   newEdge->SetMeshPatchPtr(mesh);
				   mesh->GetEdgeList().AddTail(newEdge);
				   newEdge->SetIndexNo(mesh->GetEdgeNumber());
				   newEdge->SetStartPoint(nodes[0]);
				   newEdge->SetEndPoint(nodes[2]);

				   face->SetEdgeNum(3);
				   face->SetEdgeRecordPtr(2, newEdge);
				   face->SetDirectionFlag(2, false);
				   for (i = 0; i<3; i++) {
					   QMeshEdge *edge = face->GetEdgeRecordPtr(i);
					   if (face->IsNormalDirection(i))	edge->SetLeftFace(face); else edge->SetRightFace(face);
				   }

				   QMeshFace *newFace = new QMeshFace;
				   newFace->SetMeshPatchPtr(mesh);
				   newFace->m_nIdentifiedPatchIndex = face->m_nIdentifiedPatchIndex;
				   newFaceList.AddTail(newFace);
				   newFace->SetIndexNo(newFaceList.GetCount() + mesh->GetFaceNumber());
				   newFace->SetEdgeNum(3);
				   newFace->SetEdgeRecordPtr(0, newEdge);
				   newFace->SetDirectionFlag(0, true);
				   newFace->SetEdgeRecordPtr(1, edges[2]);
				   newFace->SetDirectionFlag(1, bEdgeDirs[2]);
				   newFace->SetEdgeRecordPtr(2, edges[3]);
				   newFace->SetDirectionFlag(2, bEdgeDirs[3]);

				   for (i = 0; i<3; i++) {
					   QMeshEdge *edge = newFace->GetEdgeRecordPtr(i);
					   if (newFace->IsNormalDirection(i))	edge->SetLeftFace(newFace); else edge->SetRightFace(newFace);
				   }
				   face->CalPlaneEquation();	newFace->CalPlaneEquation();
		}break;
		case 1:{
				   QMeshEdge *newEdge = new QMeshEdge;
				   newEdge->SetMeshPatchPtr(mesh);
				   mesh->GetEdgeList().AddTail(newEdge);
				   newEdge->SetIndexNo(mesh->GetEdgeNumber());
				   newEdge->SetStartPoint(nodes[1]);
				   newEdge->SetEndPoint(nodes[3]);

				   face->SetEdgeNum(3);
				   face->SetEdgeRecordPtr(0, newEdge);
				   face->SetDirectionFlag(0, false);
				   for (i = 0; i<3; i++) {
					   QMeshEdge *edge = face->GetEdgeRecordPtr(i);
					   if (face->IsNormalDirection(i))	edge->SetLeftFace(face); else edge->SetRightFace(face);
					   if (edge->GetLeftFace() == NULL || edge->GetRightFace() == NULL)
						   edge->SetAttribFlag(0, true);
					   else
						   edge->SetAttribFlag(0, false);
				   }

				   QMeshFace *newFace = new QMeshFace;
				   newFace->SetMeshPatchPtr(mesh);
				   newFace->m_nIdentifiedPatchIndex = face->m_nIdentifiedPatchIndex;
				   newFaceList.AddTail(newFace);
				   newFace->SetIndexNo(newFaceList.GetCount() + mesh->GetFaceNumber());
				   newFace->SetEdgeNum(3);
				   newFace->SetEdgeRecordPtr(0, newEdge);
				   newFace->SetDirectionFlag(0, true);
				   newFace->SetEdgeRecordPtr(1, edges[3]);
				   newFace->SetDirectionFlag(1, bEdgeDirs[3]);
				   newFace->SetEdgeRecordPtr(2, edges[0]);
				   newFace->SetDirectionFlag(2, bEdgeDirs[0]);

				   for (i = 0; i<3; i++) {
					   QMeshEdge *edge = newFace->GetEdgeRecordPtr(i);
					   if (newFace->IsNormalDirection(i))	edge->SetLeftFace(newFace); else edge->SetRightFace(newFace);
					   if (edge->GetLeftFace() == NULL || edge->GetRightFace() == NULL)
						   edge->SetAttribFlag(0, true);
					   else
						   edge->SetAttribFlag(0, false);
				   }
				   face->CalPlaneEquation();	newFace->CalPlaneEquation();
		}break;
		}
	}

	mesh->GetFaceList().AttachListTail(&newFaceList);	newFaceList.RemoveAllWithoutFreeMemory();
}

void ThickeningMeshPatch::_fillMeshTopology(QMeshPatch *mesh)
{
	GLKPOSITION Pos;	int i, index;

	index = 1;
	for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL; index++) {
		QMeshNode *node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->SetIndexNo(index);
		node->GetFaceList().RemoveAll();
		node->GetEdgeList().RemoveAll();
		node->SetAttribFlag(7, false);
	}
	index = 1;
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL; index++) {
		QMeshEdge *edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->SetIndexNo(index);
		edge->GetStartPoint()->GetEdgeList().AddTail(edge);
		edge->GetEndPoint()->GetEdgeList().AddTail(edge);
		edge->SetAttribFlag(0, false);
		if (edge->GetLeftFace() == edge->GetRightFace()) {
			edge->SetAttribFlag(0, true);
			//			printf("Warning: invalid topology is found!\n");
		}
		if ((edge->GetLeftFace() == NULL) || (edge->GetRightFace() == NULL)) {
			edge->GetStartPoint()->SetAttribFlag(0, true);
			edge->GetEndPoint()->SetAttribFlag(0, true);
			edge->SetAttribFlag(0, true);
			//			printf("Warning: boundary edge is found!\n"); 
		}
	}
	index = 1;
	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL; index++) {
		QMeshFace *face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		face->SetIndexNo(index);
		face->CalPlaneEquation();
		int eNum = face->GetEdgeNum();
		for (i = 0; i<eNum; i++) {
			if (face->IsNormalDirection(i))
				face->GetEdgeRecordPtr(i)->SetLeftFace(face);
			else
				face->GetEdgeRecordPtr(i)->SetRightFace(face);
			face->GetNodeRecordPtr(i)->GetFaceList().AddTail(face);
		}
	}
}

void ThickeningMeshPatch::_dualContouringBasedFaceGeneration(QMeshPatch *mesh, PQP_Model *pqpModel, bool bInverseOrientation)
{
	short nAxis;	int i, j, k, ii, jj, kk;
	ThickeningGridEdge *edge;			QMeshNode* nodeArray[4];
	ThickeningGridCell *cell;
	ThickeningGridNode *gridNode;
	double pos[3], nv[3], p1[3], p2[3], dd;
	bool bIsClosestPntOnBnd;

	//----------------------------------------------------------------------------------------------------------------------------
	//	Edge based construction of polygonal faces
	for (nAxis = 0; nAxis<3; nAxis++) {
		for (j = 1; j<m_res; j++) {
			for (i = 1; i<m_res; i++) {
				edge = m_gridEdgeArray[nAxis][i + j*(m_res + 1)];
				while (edge != NULL) {
					k = edge->index;

					switch (nAxis) {
					case 0:{ii = k;	jj = i;	kk = j;   }break;
					case 1:{ii = j;	jj = k;	kk = i;   }break;
					case 2:{ii = i;	jj = j;	kk = k;   }break;
					}

					gridNode = _getGridNode(ii, jj, kk);
					for (int cellIndex = 0; cellIndex<4; cellIndex++) {
						cell = _getGridCell(ii + gridSearchTable[nAxis][cellIndex][0],
							jj + gridSearchTable[nAxis][cellIndex][1],
							kk + gridSearchTable[nAxis][cellIndex][2]);
						if (bInverseOrientation) {
							if (gridNode->bInsideSolid)
								nodeArray[3 - cellIndex] = cell->nodePtr;
							else
								nodeArray[cellIndex] = cell->nodePtr;
						}
						else {
							if (gridNode->bInsideSolid)
								nodeArray[cellIndex] = cell->nodePtr;
							else
								nodeArray[3 - cellIndex] = cell->nodePtr;
						}
					}
					_createMeshFaceByVertices(4, nodeArray, mesh);
					QMeshFace *newFace = (QMeshFace*)(mesh->GetFaceList().GetTail());

					//--------------------------------------------------------------------------------------
					//	Store the accurate intersection point, where the face must pass through
					p2[0] = p1[0] = m_origin[0] + m_gridWidth*(double)ii;
					p2[1] = p1[1] = m_origin[1] + m_gridWidth*(double)jj;
					p2[2] = p1[2] = m_origin[2] + m_gridWidth*(double)kk;
					p2[nAxis] = p2[nAxis] + m_gridWidth;
					pos[0] = (1.0 - edge->interPntAlpha)*p1[0] + edge->interPntAlpha*p2[0];
					pos[1] = (1.0 - edge->interPntAlpha)*p1[1] + edge->interPntAlpha*p2[1];
					pos[2] = (1.0 - edge->interPntAlpha)*p1[2] + edge->interPntAlpha*p2[2];
					if (edge->bCrossOffsetSurf) {					// search the normal by the closest point
						newFace->SetAttribFlag(7, true);				// flag to specify the normal of face been determined
						_distanceToPatch(pqpModel, pos, nv, bIsClosestPntOnBnd);
						nv[0] = pos[0] - nv[0];	nv[1] = pos[1] - nv[1];	nv[2] = pos[2] - nv[2];
						dd = nv[0] * nv[0] + nv[1] * nv[1] + nv[2] * nv[2];
						dd = sqrt(dd);
						if (dd>1.0e-8)
						{
							nv[0] = nv[0] / dd;	nv[1] = nv[1] / dd;	nv[2] = nv[2] / dd;
						}
						else
						{
							newFace->SetAttribFlag(7, false);
						}
					}
					if (!(newFace->GetAttribFlag(7))) newFace->GetPlaneEquation(nv[0], nv[1], nv[2], dd);
					newFace->SetHermiteData(pos, nv);

					edge = edge->next;
				}
			}
		}
	}
}

void ThickeningMeshPatch::_createMeshFaceByVertices(int nodeNum, QMeshNode *nodeArray[], QMeshPatch *mesh)
{
	int i, eNum;	QMeshNode *sNode, *eNode;		QMeshEdge *newEdge, *edge;
	GLKPOSITION Pos;		bool bDir;

	if (nodeNum == 4) {
		QMeshFace *newFace = new QMeshFace;	eNum = 4;
		mesh->GetFaceList().AddTail(newFace);
		newFace->SetIndexNo(mesh->GetFaceNumber());
		newFace->SetMeshPatchPtr(mesh);		newFace->SetEdgeNum(eNum);

		for (i = 0; i<eNum; i++) {
			sNode = nodeArray[i];	eNode = nodeArray[(i + 1) % eNum];
			newEdge = NULL;
			for (Pos = sNode->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
				edge = (QMeshEdge *)(sNode->GetEdgeList().GetNext(Pos));
				if ((edge->GetEndPoint() == eNode) && (edge->GetLeftFace() == NULL)) {
					newEdge = edge;	bDir = true;		break;
				}
				else if ((edge->GetStartPoint() == eNode) && (edge->GetRightFace() == NULL)) {
					newEdge = edge;	bDir = false;		break;
				}
			}

			if (!newEdge) {
				newEdge = new QMeshEdge;	bDir = true;
				newEdge->SetStartPoint(sNode);	newEdge->SetEndPoint(eNode);
				sNode->GetEdgeList().AddTail(newEdge);	eNode->GetEdgeList().AddTail(newEdge);
				newEdge->SetMeshPatchPtr(mesh);
				mesh->GetEdgeList().AddTail(newEdge);	newEdge->SetIndexNo(mesh->GetEdgeNumber());
			}
			newFace->SetEdgeRecordPtr(i, newEdge);
			newFace->SetDirectionFlag(i, bDir);
			if (bDir) newEdge->SetLeftFace(newFace); else newEdge->SetRightFace(newFace);
		}
		newFace->CalPlaneEquation();

		//---------------------------------------------------------------------------------------
		//	Fill the topology information on vertices
		for (i = 0; i<eNum; i++) nodeArray[i]->GetFaceList().AddTail(newFace);
		newFace->m_nIdentifiedPatchIndex = 2;
	}
	else if (nodeNum == 5) {
	}
}

void ThickeningMeshPatch::_constructionOfGridCells(QMeshPatch *mesh)
{
	short nAxis;	int i, j, k, ii, jj, kk;
	ThickeningGridEdge *edge;
	double p1[3], p2[3], alpha, pp[3], xx, yy, zz, dd;

	//----------------------------------------------------------------------------------------------------------------------------
	//	Step 1: Edge based construction of grid cells
	for (nAxis = 0; nAxis<3; nAxis++) {
		for (j = 1; j<m_res; j++) {
			p1[(nAxis + 2) % 3] = m_origin[(nAxis + 2) % 3] + m_gridWidth*(double)j;	p2[(nAxis + 2) % 3] = p1[(nAxis + 2) % 3];
			for (i = 1; i<m_res; i++) {
				p1[(nAxis + 1) % 3] = m_origin[(nAxis + 1) % 3] + m_gridWidth*(double)i;	p2[(nAxis + 1) % 3] = p1[(nAxis + 1) % 3];

				edge = m_gridEdgeArray[nAxis][i + j*(m_res + 1)];
				while (edge != NULL) {
					k = edge->index;		alpha = edge->interPntAlpha;
					p1[nAxis] = m_origin[nAxis] + m_gridWidth*(double)k;	p2[nAxis] = p1[nAxis] + m_gridWidth;

					pp[0] = (1.0 - alpha)*p1[0] + alpha*p2[0];
					pp[1] = (1.0 - alpha)*p1[1] + alpha*p2[1];
					pp[2] = (1.0 - alpha)*p1[2] + alpha*p2[2];

					switch (nAxis) {
					case 0:{ii = k;	jj = i;	kk = j;   }break;
					case 1:{ii = j;	jj = k;	kk = i;   }break;
					case 2:{ii = i;	jj = j;	kk = k;   }break;
					}

					for (int cellIndex = 0; cellIndex<4; cellIndex++) {
						ThickeningGridCell *cell;		QMeshNode *node;
						cell = _getGridCell(ii + gridSearchTable[nAxis][cellIndex][0],
							jj + gridSearchTable[nAxis][cellIndex][1],
							kk + gridSearchTable[nAxis][cellIndex][2]);
						if (cell == NULL) {
							cell = new ThickeningGridCell;		cell->bBoundaryCell = false;
							cell->k = kk + gridSearchTable[nAxis][cellIndex][2];
							node = new QMeshNode;
							node->SetCoord3D(0.0, 0.0, 0.0);		node->SetDensityFuncValue(0.0);
							mesh->GetNodeList().AddTail(node);		node->SetMeshPatchPtr(mesh);
							//node->SetAttribFlag(3);
							cell->nodePtr = node;
							_addHeadGridCell(cell, ii + gridSearchTable[nAxis][cellIndex][0], jj + gridSearchTable[nAxis][cellIndex][1]);
						}
						node = cell->nodePtr;
						if (cell->bBoundaryCell) continue;

						node->GetCoord3D(xx, yy, zz);			node->SetCoord3D(xx + pp[0], yy + pp[1], zz + pp[2]);
						dd = node->GetDensityFuncValue();		node->SetDensityFuncValue(dd + 1.0);	// counting the number of accumulated points
					}

					edge = edge->next;
				}
			}
		}
	}

	//----------------------------------------------------------------------------------------------------------------------------
	//	Step 2: compute the position of vertices in the grid cells
	int arrsize = m_res*m_res;
	for (i = 0; i<arrsize; i++) {
		ThickeningGridCell *cell = m_gridCellArray[i];
		while (cell != NULL) {
			QMeshNode *node = cell->nodePtr;
			node->GetCoord3D(xx, yy, zz);				dd = node->GetDensityFuncValue();
			node->SetCoord3D(xx / dd, yy / dd, zz / dd);

			cell = cell->next;
		}
	}
}

void ThickeningMeshPatch::_constructionOfGridEdges(PQP_Model *pqpModel, bool bAccurate)
{
	short nAxis;	int i, j, kk;
	ThickeningGridNode *stGridNode, *edGridNode;
	double p1[3], p2[3], alpha;

	for (nAxis = 0; nAxis<3; nAxis++) {
		for (j = 0; j <= m_res; j++) {
			p1[(nAxis + 2) % 3] = m_origin[(nAxis + 2) % 3] + m_gridWidth*(double)j;	p2[(nAxis + 2) % 3] = p1[(nAxis + 2) % 3];
			for (i = 0; i <= m_res; i++) {
				p1[(nAxis + 1) % 3] = m_origin[(nAxis + 1) % 3] + m_gridWidth*(double)i;	p2[(nAxis + 1) % 3] = p1[(nAxis + 1) % 3];

				for (kk = 0; kk<m_res; kk++) {
					switch (nAxis) {
					case 0:{stGridNode = _getGridNode(kk, i, j); edGridNode = _getGridNode(kk + 1, i, j);
					}break;
					case 1:{stGridNode = _getGridNode(j, kk, i); edGridNode = _getGridNode(j, kk + 1, i);
					}break;
					case 2:{stGridNode = _getGridNode(i, j, kk); edGridNode = _getGridNode(i, j, kk + 1);
					}break;
					}
					if (stGridNode->bInsideSolid == edGridNode->bInsideSolid) continue;

					if (stGridNode->bFieldValueDefined && stGridNode->signedDist>0.0) continue;
					if (edGridNode->bFieldValueDefined && edGridNode->signedDist>0.0) continue;

					p1[nAxis] = m_origin[nAxis] + m_gridWidth*(double)kk;	p2[nAxis] = p1[nAxis] + m_gridWidth;

					if (!(stGridNode->bFieldValueDefined)) { printf("Warning: a edge-node with no field-value is found!\n"); }
					if (!(edGridNode->bFieldValueDefined)) { printf("Warning: a edge-node with no field-value is found!\n"); }

					bool bInterpolation = false;
					if ((stGridNode->signedDist + m_offset)*(edGridNode->signedDist + m_offset)<0.0) {
						alpha = fabs(stGridNode->signedDist + m_offset) + fabs(edGridNode->signedDist + m_offset);
						if (alpha>1.0e-8) {
							alpha = fabs(stGridNode->signedDist + m_offset) / alpha;		bInterpolation = true;
						}
					}
					if (!bInterpolation) {
						alpha = 0.5;
						if (bAccurate) {
							alpha = _searchAccurateBndPntOnEdge(pqpModel, p1, stGridNode->bInsideSolid, p2, edGridNode->bInsideSolid, 8);
						}
					}

					ThickeningGridEdge *gridEdge = new ThickeningGridEdge;
					gridEdge->index = kk;		gridEdge->interPntAlpha = alpha;
					gridEdge->bCrossOffsetSurf = bInterpolation;
					_addHeadGridEdge(gridEdge, nAxis, i, j);
				}
			}
		}
	}
}

double ThickeningMeshPatch::_searchAccurateBndPntOnEdge(PQP_Model *pqpModel, double sp[], bool spInside,
	double ep[], bool epInside, int nRefinementTimes)
{
	double mp[3], closestPnt[3], spAlpha, mpAlpha, epAlpha, signedDist;
	bool mpInside, bIsClosestPntOnBnd;		int nIter;

	nIter = 0;	spAlpha = 0.0;	epAlpha = 1.0;
	while (nIter<nRefinementTimes) {
		mpAlpha = (spAlpha + epAlpha)*0.5;
		mp[0] = (1.0 - mpAlpha)*sp[0] + mpAlpha*ep[0];
		mp[1] = (1.0 - mpAlpha)*sp[1] + mpAlpha*ep[1];
		mp[2] = (1.0 - mpAlpha)*sp[2] + mpAlpha*ep[2];
		signedDist = _distanceToPatch(pqpModel, mp, closestPnt, bIsClosestPntOnBnd);
		mpInside = _isInsideSolid(signedDist, bIsClosestPntOnBnd);

		if (mpInside == spInside)	{
			spAlpha = mpAlpha;	//spInside=mpInside;
		}
		else{
			epAlpha = mpAlpha;	//epInside=mpInside;
		}
		nIter++;
	}

	return (spAlpha + epAlpha)*0.5;
}

void ThickeningMeshPatch::_minimalAreaHoleTriangulation(GLKObList *nodeList, QMeshPatch *mesh, int id)
{
	//	The implementation of the minimal area hole triangulation is based on the section 6.2 of:
	//		"Filling gaps in the boundary of a polyhedron", G. Barequet and M. Sharir,
	//		Computer Aided Geometric Design, vol.12, pp.207-229, 1995.
	int i, num;
	GLKPOSITION Pos;

	if (nodeList->GetCount() == 3) {	// Fill in the triangle
		QMeshNode *nodeArray[3];
		i = 0;
		for (Pos = nodeList->GetHeadPosition(); Pos != NULL; i++) { nodeArray[i] = (QMeshNode *)(nodeList->GetNext(Pos)); }
		_constructTriangle(nodeArray[0], nodeArray[1], nodeArray[2], mesh, id);
	}
	else if (nodeList->GetCount() == 2) {
		printf("An incorrect hole with only two nodes is found!\n");
		for (Pos = nodeList->GetHeadPosition(); Pos != NULL;) {
			QMeshNode *node = (QMeshNode *)(nodeList->GetNext(Pos));
			GLKPOSITION PosEdge;	int nCount = 0;
			for (PosEdge = node->GetEdgeList().GetHeadPosition(); PosEdge != NULL;) {
				QMeshEdge *edge = (QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
				if (edge->GetAttribFlag(0)) {
					nCount++;	printf("%d ", edge->GetIndexNo());
					if (edge->GetStartPoint() == node) {
						if (edge->GetLeftFace() == NULL) printf("right(%d) ", edge->GetRightFace()->GetIndexNo());
						if (edge->GetRightFace() == NULL) printf("left(%d) ", edge->GetLeftFace()->GetIndexNo());
						printf("%d-%d\n", edge->GetStartPoint()->GetIndexNo(), edge->GetEndPoint()->GetIndexNo());
					}
					else {
						if (edge->GetLeftFace() == NULL) printf("left(%d) ", edge->GetRightFace()->GetIndexNo());
						if (edge->GetRightFace() == NULL) printf("right(%d) ", edge->GetLeftFace()->GetIndexNo());
						printf("%d-%d\n", edge->GetStartPoint()->GetIndexNo(), edge->GetEndPoint()->GetIndexNo());
					}
				}
			}
			printf("%d edges\n", nCount);
		}
		return;
	}
	else if (nodeList->GetCount() == 1) {
		printf("An incorrect hole with only one nodes is found!\n");
		QMeshNode *node = (QMeshNode *)(nodeList->GetHead());
		return;
	}
	else {
		double **WW;	int *O;		int j, k, m;
		num = nodeList->GetCount();
		QMeshNode **nodeArray = (QMeshNode **)new long[num];
		O = new int[num*num];

		WW = (double**)new long[num];
		for (i = 0; i<num; i++) {
			WW[i] = new double[num];
			for (j = 0; j<num; j++) WW[i][j] = 0;
		}

		i = 0;
		for (Pos = nodeList->GetHeadPosition(); Pos != NULL; i++) { nodeArray[i] = (QMeshNode *)(nodeList->GetNext(Pos)); }

		//-----------------------------------------------------------------------------------
		//`Step 1:
		for (i = 0; i <= num - 3; i++) WW[i][i + 2] = _areaFunction(nodeArray[i], nodeArray[i + 1], nodeArray[i + 2]);

		//-----------------------------------------------------------------------------------
		//`Step 2:
		j = 2;
		do{
			j++;
			for (i = 0; i <= num - j - 1; i++) {
				k = i + j;	WW[i][k] = 1.0e+32;
				for (m = i + 1; m<k; m++) {
					double temp = WW[i][m] + WW[m][k]
						+ _areaFunction(nodeArray[i], nodeArray[m], nodeArray[k]);
					if (temp<WW[i][k]) { WW[i][k] = temp; O[i*num + k] = m; }
				}
			}
		} while (j <= num - 1);

		//-----------------------------------------------------------------------------------
		//`Step 3: track back the triangles
		_trackTriangles(0, num - 1, O, num, nodeArray, mesh, id);

		delete[](QMeshNode**)nodeArray;	delete[]O;
		for (i = 0; i<num; i++) delete[](double*)(WW[i]);
		delete[](double**)WW;
	}
}

void ThickeningMeshPatch::_splittingBoundaryEdgesOnExistingPatch(QMeshPatch *mesh, GLKObList *removedFaceList, GLKObList *removedEdgeList)
{
	GLKPOSITION Pos;
	GLKPOSITION PosNode;
	double sp[3], ep[3], tp[3], pp[3], dd;
	QMeshNode *node;	QMeshEdge *edge;	GLKObList nodeList, edgeList, faceList;

	//------------------------------------------------------------------------------------
	//	Step 1: preparation
	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL;) {
		QMeshFace *face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		face->SetAttribFlag(7, false);
	}
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->SetAttribFlag(7, false);
		if (edge->GetAttachedList().IsEmpty()) continue;
		if (edge->GetLeftFace() != NULL) edge->GetLeftFace()->SetAttribFlag(7);
		if (edge->GetRightFace() != NULL) edge->GetRightFace()->SetAttribFlag(7);
		edgeList.AddTail(edge);		edge->SetAttribFlag(7);
	}

	//------------------------------------------------------------------------------------
	//	Step 2: sorting nodes attached to edges
	for (Pos = edgeList.GetHeadPosition(); Pos != NULL;) {
		edge = (QMeshEdge *)(edgeList.GetNext(Pos));
		edge->GetStartPoint()->GetCoord3D(sp[0], sp[1], sp[2]);
		edge->GetEndPoint()->GetCoord3D(ep[0], ep[1], ep[2]);
		tp[0] = ep[0] - sp[0];	tp[1] = ep[1] - sp[1];	tp[2] = ep[2] - sp[2];

		//--------------------------------------------------------------------------------
		//	Re-order the nodes on the edge
		int i, j, nodeNum;	QMeshNode **nodeArray;	double *proj;
		nodeNum = edge->GetAttachedList().GetCount();
		nodeArray = (QMeshNode **)new long[nodeNum];	proj = new double[nodeNum];
		i = 0;
		for (PosNode = edge->GetAttachedList().GetHeadPosition(); PosNode != NULL; i++) {
			node = (QMeshNode*)(edge->GetAttachedList().GetNext(PosNode));
			nodeArray[i] = node;	node->GetCoord3D(pp[0], pp[1], pp[2]);
			proj[i] = (pp[0] - sp[0])*tp[0] + (pp[1] - sp[1])*tp[1] + (pp[2] - sp[2])*tp[2];
			if (node->GetMeshPatchPtr() == NULL) { mesh->GetNodeList().AddTail(node); node->SetMeshPatchPtr(mesh); }
		}

		for (i = 0; i<nodeNum; i++) {
			for (j = i + 1; j<nodeNum; j++) {
				if (proj[j]<proj[i]) {
					node = nodeArray[i]; dd = proj[i];
					nodeArray[i] = nodeArray[j]; proj[i] = proj[j];
					nodeArray[j] = node; proj[j] = dd;
				}
			}
		}

		edge->GetAttachedList().RemoveAll();
		for (i = 0; i<nodeNum; i++) { edge->GetAttachedList().AddTail(nodeArray[i]); }

		delete[](QMeshNode **)nodeArray;	delete[]proj;
	}

	//------------------------------------------------------------------------------------
	//	Step 3: preparation for the re-triangulation
	removedFaceList->RemoveAll();	faceList.RemoveAll();
	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL;) {
		QMeshFace *face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		if (face->GetAttribFlag(7))
			removedFaceList->AddTail(face);
		else
			faceList.AddTail(face);
	}
	mesh->GetFaceList().RemoveAll();	mesh->GetFaceList().AddTail(&faceList);
	//------------------------------------------------------------------------------------
	removedEdgeList->RemoveAll();	edgeList.RemoveAll();
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		if (edge->GetAttribFlag(7))
			removedEdgeList->AddTail(edge);
		else
			edgeList.AddTail(edge);
	}
	mesh->GetEdgeList().RemoveAll();	mesh->GetEdgeList().AddTail(&edgeList);
	//------------------------------------------------------------------------------------
	for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL;) {
		QMeshNode *node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->GetEdgeList().RemoveAll();	node->GetFaceList().RemoveAll();
	}
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->GetStartPoint()->GetEdgeList().AddTail(edge);
		edge->GetEndPoint()->GetEdgeList().AddTail(edge);
		if (edge->GetLeftFace()) { if (edge->GetLeftFace()->GetAttribFlag(7)) edge->SetLeftFace(NULL); }
		if (edge->GetRightFace()) { if (edge->GetRightFace()->GetAttribFlag(7)) edge->SetRightFace(NULL); }
	}
	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL;) {
		QMeshFace *face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		int eNum = face->GetEdgeNum();
		for (int i = 0; i<eNum; i++) face->GetNodeRecordPtr(i)->GetFaceList().AddTail(face);
	}

	//------------------------------------------------------------------------------------
	//	Step 4: re-triangulate the face with edges to be splitted
	for (Pos = removedFaceList->GetHeadPosition(); Pos != NULL;) {
		QMeshFace *face = (QMeshFace *)(removedFaceList->GetNext(Pos));
		int i, edgeNum = face->GetEdgeNum();
		nodeList.RemoveAll();
		for (i = 0; i<edgeNum; i++) {
			edge = face->GetEdgeRecordPtr(i);
			if (face->IsNormalDirection(i)) {
				nodeList.AddTail(edge->GetStartPoint());
				for (PosNode = edge->GetAttachedList().GetHeadPosition(); PosNode != NULL;) {
					node = (QMeshNode*)(edge->GetAttachedList().GetNext(PosNode));
					nodeList.AddTail(node);
				}
			}
			else {
				nodeList.AddTail(edge->GetEndPoint());
				for (PosNode = edge->GetAttachedList().GetTailPosition(); PosNode != NULL;) {
					node = (QMeshNode*)(edge->GetAttachedList().GetPrev(PosNode));
					nodeList.AddTail(node);
				}
			}
			face->GetNodeRecordPtr(i)->GetFaceList().Remove(face);
			if (edge->GetLeftFace() == face) edge->SetLeftFace(NULL);
			if (edge->GetRightFace() == face) edge->SetRightFace(NULL);
		}
		_minimalAreaHoleTriangulation(&nodeList, mesh, 1);
	}
}

void ThickeningMeshPatch::_constructionOfBndGridCells(QMeshPatch *mesh)
{
	GLKPOSITION Pos;
	GLKObList *bndEdgeList = new GLKObList;

	bndEdgeList->RemoveAll();
	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		QMeshEdge *edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		if (edge->GetAttribFlag(0)) bndEdgeList->AddTail(edge);
		edge->GetAttachedList().RemoveAll();
	}
	for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL;) {
		QMeshNode *node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->attachedPointer = NULL;
	}
	_bndGridCellGeneration(mesh, bndEdgeList, 0, 0, 0, m_res, m_res, m_res);
}

void ThickeningMeshPatch::_bndGridCellGeneration(QMeshPatch *mesh, GLKObList *bndEdgeList,
	int iSX, int iSY, int iSZ, int iEX, int iEY, int iEZ)
{
	int i, j, k;	double sp[3], ep[3], boundingBox[6], dd, minD, minDpnt[3];		GLKPOSITION Pos;

	if ((iEX - iSX) == 1) {
		int nodeTable[][3] = { { 0, 0, 0 }, { 1, 0, 0 }, { 0, 1, 0 }, { 1, 1, 0 }, { 0, 0, 1 }, { 1, 0, 1 }, { 0, 1, 1 }, { 1, 1, 1 } };
		double pp[3], xx, yy, zz;		int iStep = iEX - iSX;

		//------------------------------------------------------------------------------------------
		//	Analyze if this is a real boundary cell
		bool bInOut, bCellOnBoundary = false;
		for (int i = 0; i<8; i++) {
			ThickeningGridNode *gridNode = _getGridNode(iSX + nodeTable[i][0], iSY + nodeTable[i][1], iSZ + nodeTable[i][2]);
			if (i == 0) bInOut = gridNode->bInsideSolid;
			if (bInOut != gridNode->bInsideSolid) bCellOnBoundary = true;
		}
		if (!bCellOnBoundary) { delete bndEdgeList; return; }
		if (bndEdgeList->IsEmpty()) { delete bndEdgeList; return; }

		//------------------------------------------------------------------------------------------
		//	Analyze the boundary edges inside
		QMeshNode *activeNode = NULL;	QMeshEdge *activeEdge = NULL;
		//------------------------------------------------------------------------------------------
		boundingBox[0] = m_origin[0] + m_gridWidth*(double)iSX;		boundingBox[3] = boundingBox[0] + m_gridWidth*(double)iStep;
		boundingBox[1] = m_origin[1] + m_gridWidth*(double)iSY;		boundingBox[4] = boundingBox[1] + m_gridWidth*(double)iStep;
		boundingBox[2] = m_origin[2] + m_gridWidth*(double)iSZ;		boundingBox[5] = boundingBox[2] + m_gridWidth*(double)iStep;
		//------------------------------------------------------------------------------------------
		if (bndEdgeList->GetCount()>1) {
			int edgeNum = bndEdgeList->GetCount();	int i, j, k = 0;
			QMeshEdge **edgeArray = (QMeshEdge **)new long[edgeNum];
			for (Pos = bndEdgeList->GetHeadPosition(); Pos != NULL; k++) { edgeArray[k] = (QMeshEdge *)(bndEdgeList->GetNext(Pos)); }
			for (i = 0; i<edgeNum; i++) {
				QMeshEdge *edge1 = edgeArray[i];
				for (j = i + 1; j<edgeNum; j++) {
					QMeshEdge *edge2 = edgeArray[j];
					activeNode = _findSharedVertex(edge1, edge2);
					if (activeNode != NULL) {
						activeNode->GetCoord3D(pp[0], pp[1], pp[2]);
						if (!_isBndBoxHoldingPnt(boundingBox, pp)) activeNode = NULL;
					}
					if (activeNode != NULL) break;
				}
				if (activeNode != NULL) break;
			}
			delete[](QMeshEdge **)edgeArray;
		}

		if (activeNode == NULL) {
			xx = m_origin[0] + m_gridWidth*(0.5 + (double)iSX);
			yy = m_origin[1] + m_gridWidth*(0.5 + (double)iSY);
			zz = m_origin[2] + m_gridWidth*(0.5 + (double)iSZ);
			minD = 1.0e+32;		QMeshEdge *minDEdge = NULL;
			for (Pos = bndEdgeList->GetHeadPosition(); Pos != NULL;) {
				activeEdge = (QMeshEdge *)(bndEdgeList->GetNext(Pos));
				activeEdge->GetStartPoint()->GetCoord3D(sp[0], sp[1], sp[2]);
				activeEdge->GetEndPoint()->GetCoord3D(ep[0], ep[1], ep[2]);
				_compBndBoxLineSegIntersect(boundingBox, sp, ep);
				pp[0] = xx;	pp[1] = yy;	pp[2] = zz;
				_projectPntOntoEdge(pp, sp, ep);
				dd = (xx - pp[0])*(xx - pp[0]) + (yy - pp[1])*(yy - pp[1]) + (zz - pp[2])*(zz - pp[2]);
				if (dd<minD) { minD = dd;	minDpnt[0] = pp[0];	minDpnt[1] = pp[1];	minDpnt[2] = pp[2];	minDEdge = activeEdge; }
				break;
			}
			if (minDEdge != NULL) {
				activeNode = new QMeshNode;	activeNode->SetMeshPatchPtr(mesh);
				activeNode->SetCoord3D(pp[0], pp[1], pp[2]);
				activeNode->SetMeshPatchPtr(mesh);	mesh->GetNodeList().AddTail(activeNode);
				minDEdge->GetAttachedList().AddTail(activeNode);
			}
		}

		//------------------------------------------------------------------------------------------
		//	Generate a boundary cell for this region
		if (activeNode != NULL) {
			ThickeningGridCell *cell = new ThickeningGridCell;
			cell->k = iSZ;
			cell->nodePtr = activeNode;	activeNode->SetDensityFuncValue(1.0);
			cell->bBoundaryCell = true;
			_addHeadGridCell(cell, iSX, iSY);
			//activeNode->SetAttribFlag(3);
		}
		else {
			printf("Invalid boundary cell is found! bndEdgeNum=%d\n", bndEdgeList->GetCount());
		}

		delete bndEdgeList;
	}
	else {	// refinement is needed
		GLKObList *cellBndEdgeList[8];
		for (i = 0; i<8; i++) cellBndEdgeList[i] = NULL;

		int ii, jj, kk, iStep = (iEX - iSX) / 2;
		for (k = 0; k<2; k++) {
			kk = iSZ + k*iStep;
			boundingBox[2] = m_origin[2] + m_gridWidth*(double)kk;
			boundingBox[5] = boundingBox[2] + m_gridWidth*(double)iStep;
			for (j = 0; j<2; j++) {
				jj = iSY + j*iStep;
				boundingBox[1] = m_origin[1] + m_gridWidth*(double)jj;
				boundingBox[4] = boundingBox[1] + m_gridWidth*(double)iStep;
				for (i = 0; i<2; i++) {
					ii = iSX + i*iStep;
					boundingBox[0] = m_origin[0] + m_gridWidth*(double)ii;
					boundingBox[3] = boundingBox[0] + m_gridWidth*(double)iStep;

					//----------------------------------------------------------------------------------------
					// build the new bndEdgeList
					int index = i + j * 2 + k * 4;
					for (Pos = bndEdgeList->GetHeadPosition(); Pos != NULL;) {
						QMeshEdge *edge = (QMeshEdge *)(bndEdgeList->GetNext(Pos));
						edge->GetStartPoint()->GetCoord3D(sp[0], sp[1], sp[2]);
						edge->GetEndPoint()->GetCoord3D(ep[0], ep[1], ep[2]);
						if (_isBndBoxLineSegIntersect(boundingBox, sp, ep)) {
							if (cellBndEdgeList[index] == NULL) cellBndEdgeList[index] = new GLKObList;
							cellBndEdgeList[index]->AddTail(edge);
						}
					}
				}
			}
		}

		delete bndEdgeList;

		for (k = 0; k<2; k++) {
			kk = iSZ + k*iStep;
			for (j = 0; j<2; j++) {
				jj = iSY + j*iStep;
				for (i = 0; i<2; i++) {
					ii = iSX + i*iStep;
					int index = i + j * 2 + k * 4;
					if (cellBndEdgeList[index] == NULL) continue;
					_bndGridCellGeneration(mesh, cellBndEdgeList[index], ii, jj, kk, ii + iStep, jj + iStep, kk + iStep);
				}
			}
		}
	}
}

double ThickeningMeshPatch::_areaFunction(QMeshNode *node1, QMeshNode *node2, QMeshNode *node3)
{
	double x1, y1, z1, x2, y2, z2;
	double ii, jj, kk;
	double area, p0[3], p1[3], p2[3];

	node1->GetCoord3D(p0[0], p0[1], p0[2]);
	node2->GetCoord3D(p1[0], p1[1], p1[2]);
	node3->GetCoord3D(p2[0], p2[1], p2[2]);

	x1 = p1[0] - p0[0];	y1 = p1[1] - p0[1];	z1 = p1[2] - p0[2];
	x2 = p2[0] - p0[0];	y2 = p2[1] - p0[1];	z2 = p2[2] - p0[2];
	ii = y1*z2 - z1*y2;	jj = x2*z1 - x1*z2;	kk = x1*y2 - x2*y1;

	area = sqrt(ii*ii + jj*jj + kk*kk) / 2.0 + (1.0e-8);

	return area;
}

void ThickeningMeshPatch::_trackTriangles(int i, int k, int *O, int num, QMeshNode **nodeArray, QMeshPatch *mesh, int id)
{
	if (i + 2 == k) {
		_constructTriangle(nodeArray[i], nodeArray[i + 1], nodeArray[k], mesh, id);
	}
	else {
		int o = O[i*num + k];
		if (o != i + 1) _trackTriangles(i, o, O, num, nodeArray, mesh, id);
		_constructTriangle(nodeArray[i], nodeArray[o], nodeArray[k], mesh, id);
		if (o != k - 1)	_trackTriangles(o, k, O, num, nodeArray, mesh, id);
	}
}

void ThickeningMeshPatch::_constructTriangle(QMeshNode *node1, QMeshNode *node2, QMeshNode *node3, QMeshPatch *mesh, int id)
{
	QMeshNode *nodeArray[3];	QMeshEdge *edgeArray[3];	bool bEdgeDir[3];
	int i;	GLKPOSITION Pos;

	nodeArray[0] = node1;	nodeArray[1] = node2;	nodeArray[2] = node3;

	for (i = 0; i<3; i++) {
		edgeArray[i] = NULL;
		for (Pos = nodeArray[i]->GetEdgeList().GetTailPosition(); Pos != NULL;) {
			QMeshEdge *edge = (QMeshEdge *)(nodeArray[i]->GetEdgeList().GetPrev(Pos));
			if ((edge->GetEndPoint() == nodeArray[(i + 1) % 3]) && (edge->GetLeftFace() == NULL)) {
				edgeArray[i] = edge;	 bEdgeDir[i] = true;	break;
			}
			if ((edge->GetStartPoint() == nodeArray[(i + 1) % 3]) && (edge->GetRightFace() == NULL)) {
				edgeArray[i] = edge;	 bEdgeDir[i] = false;	break;
			}
		}
		if (edgeArray[i] == NULL) {
			edgeArray[i] = new QMeshEdge;		bEdgeDir[i] = true;
			edgeArray[i]->SetMeshPatchPtr(mesh);	mesh->GetEdgeList().AddTail(edgeArray[i]);
			edgeArray[i]->SetIndexNo(mesh->GetEdgeNumber());
			edgeArray[i]->SetStartPoint(nodeArray[i]);
			nodeArray[i]->GetEdgeList().AddTail(edgeArray[i]);
			edgeArray[i]->SetEndPoint(nodeArray[(i + 1) % 3]);
			nodeArray[(i + 1) % 3]->GetEdgeList().AddTail(edgeArray[i]);

			edgeArray[i]->GetStartPoint()->GetEdgeList().AddTail(edgeArray[i]);
			edgeArray[i]->GetEndPoint()->GetEdgeList().AddTail(edgeArray[i]);
		}
	}

	QMeshFace *face = new QMeshFace;
	face->m_nIdentifiedPatchIndex = id;
	face->SetMeshPatchPtr(mesh);	mesh->GetFaceList().AddTail(face);
	face->SetIndexNo(mesh->GetFaceNumber());
	face->SetEdgeNum(3);
	for (i = 0; i<3; i++) {
		face->SetEdgeRecordPtr(i, edgeArray[i]);
		face->SetDirectionFlag(i, bEdgeDir[i]);
		if (bEdgeDir[i])
			edgeArray[i]->SetLeftFace(face);
		else
			edgeArray[i]->SetRightFace(face);
		nodeArray[i]->GetFaceList().AddTail(face);

		if (edgeArray[i]->GetLeftFace() == NULL || edgeArray[i]->GetRightFace() == NULL)
			edgeArray[i]->SetAttribFlag(0, true);
		else
			edgeArray[i]->SetAttribFlag(0, false);
	}
	face->CalPlaneEquation();
}

QMeshNode* ThickeningMeshPatch::_findSharedVertex(QMeshEdge *edge1, QMeshEdge *edge2)
{
	QMeshNode *node = NULL;

	if (edge1->GetStartPoint() == edge2->GetStartPoint()) node = edge1->GetStartPoint();
	if (edge1->GetStartPoint() == edge2->GetEndPoint()) node = edge1->GetStartPoint();
	if (edge1->GetEndPoint() == edge2->GetStartPoint()) node = edge1->GetEndPoint();
	if (edge1->GetEndPoint() == edge2->GetEndPoint()) node = edge1->GetEndPoint();

	return node;
}

bool ThickeningMeshPatch::_isBndBoxHoldingPnt(double bndBox[]/*(minX,minY,minZ,maxX,maxY,maxZ*/, double pnt[])
{
	if (pnt[0]<bndBox[0]) return false;  if (pnt[1]<bndBox[1]) return false;  if (pnt[2]<bndBox[2]) return false;
	if (pnt[0]>bndBox[3]) return false;  if (pnt[1]>bndBox[4]) return false;  if (pnt[2]>bndBox[5]) return false;
	return true;
}

bool ThickeningMeshPatch::_isBndBoxLineSegIntersect(double bndBox[]/*(minX,minY,minZ,maxX,maxY,maxZ*/,
	double sp[], double ep[])
{
	double cp[3], mp[3], wp[3], xx, yy, zz, tx, ty, tz;

	cp[0] = (bndBox[0] + bndBox[3])*0.5;	cp[1] = (bndBox[1] + bndBox[4])*0.5;	cp[2] = (bndBox[2] + bndBox[5])*0.5;
	sp[0] = sp[0] - cp[0];	sp[1] = sp[1] - cp[1];	sp[2] = sp[2] - cp[2];
	ep[0] = ep[0] - cp[0];	ep[1] = ep[1] - cp[1];	ep[2] = ep[2] - cp[2];
	mp[0] = (sp[0] + ep[0])*0.5;	mp[1] = (sp[1] + ep[1])*0.5;	mp[2] = (sp[2] + ep[2])*0.5;
	wp[0] = ep[0] - mp[0];	wp[1] = ep[1] - mp[1];	wp[2] = ep[2] - mp[2];

	tx = cp[0] - bndBox[0];	ty = cp[1] - bndBox[1];	tz = cp[2] - bndBox[2];
	xx = fabs(wp[0]);	yy = fabs(wp[1]);	zz = fabs(wp[2]);

	if (fabs(mp[0])>(xx + tx)) return false;
	if (fabs(mp[1])>(yy + ty)) return false;
	if (fabs(mp[2])>(zz + tz)) return false;

	if (fabs(mp[1] * wp[2] - mp[2] * wp[1])>(ty*zz + tz*yy)) return false;
	if (fabs(mp[0] * wp[2] - mp[2] * wp[0])>(tx*zz + tz*xx)) return false;
	if (fabs(mp[0] * wp[1] - mp[1] * wp[0])>(tx*yy + ty*xx)) return false;

	return true;
}

void ThickeningMeshPatch::_projectPntOntoEdge(double pp[], double sp[], double ep[])
{
	double vp[3], ll, tt;

	vp[0] = ep[0] - sp[0];	vp[1] = ep[1] - sp[1];	vp[2] = ep[2] - sp[2];
	ll = sqrt(vp[0] * vp[0] + vp[1] * vp[1] + vp[2] * vp[2]);
	if (ll<1.0e-8) { pp[0] = sp[0]; pp[1] = sp[1]; pp[2] = sp[2]; return; }
	vp[0] = vp[0] / ll;		vp[1] = vp[1] / ll;		vp[2] = vp[2] / ll;
	tt = (pp[0] - sp[0])*vp[0] + (pp[1] - sp[1])*vp[1] + (pp[2] - sp[2])*vp[2];

	if (tt <= 0.0)
	{
		pp[0] = sp[0]; pp[1] = sp[1]; pp[2] = sp[2];
	}
	else if (tt >= ll)
	{
		pp[0] = ep[0]; pp[1] = ep[1]; pp[2] = ep[2];
	}
	else
	{
		pp[0] = sp[0] + tt*vp[0]; pp[1] = sp[1] + tt*vp[1]; pp[2] = sp[2] + tt*vp[2];
	}
}

void ThickeningMeshPatch::_compBndBoxLineSegIntersect(double bndBox[]/*(minX,minY,minZ,maxX,maxY,maxZ*/,
	double sp[], double ep[])
{
	double tp[3], alpha;

	//------------------------------------------------------------------------
	//	truncate by x-planes
	if (sp[0]>ep[0]) { tp[0] = sp[0]; tp[1] = sp[1]; tp[2] = sp[2]; sp[0] = ep[0]; sp[1] = ep[1]; sp[2] = ep[2];	ep[0] = tp[0]; ep[1] = tp[1]; ep[2] = tp[2]; }
	if (sp[0] <= bndBox[0] && ep[0] >= bndBox[0] && fabs(ep[0] - sp[0])>1.0e-8) {
		alpha = (bndBox[0] - sp[0]) / (ep[0] - sp[0]);
		sp[0] = (1.0 - alpha)*sp[0] + alpha*ep[0];  sp[1] = (1.0 - alpha)*sp[1] + alpha*ep[1];  sp[2] = (1.0 - alpha)*sp[2] + alpha*ep[2];
	}
	if (sp[0] <= bndBox[3] && ep[0] >= bndBox[3] && fabs(ep[0] - sp[0])>1.0e-8) {
		alpha = (bndBox[3] - sp[0]) / (ep[0] - sp[0]);
		ep[0] = (1.0 - alpha)*sp[0] + alpha*ep[0];  ep[1] = (1.0 - alpha)*sp[1] + alpha*ep[1];  ep[2] = (1.0 - alpha)*sp[2] + alpha*ep[2];
	}

	//------------------------------------------------------------------------
	//	truncate by y-planes
	if (sp[1]>ep[1]) { tp[0] = sp[0]; tp[1] = sp[1]; tp[2] = sp[2]; sp[0] = ep[0]; sp[1] = ep[1]; sp[2] = ep[2];	ep[0] = tp[0]; ep[1] = tp[1]; ep[2] = tp[2]; }
	if (sp[1] <= bndBox[1] && ep[1] >= bndBox[1] && fabs(ep[1] - sp[1])>1.0e-8) {
		alpha = (bndBox[1] - sp[1]) / (ep[1] - sp[1]);
		sp[0] = (1.0 - alpha)*sp[0] + alpha*ep[0];  sp[1] = (1.0 - alpha)*sp[1] + alpha*ep[1];  sp[2] = (1.0 - alpha)*sp[2] + alpha*ep[2];
	}
	if (sp[1] <= bndBox[4] && ep[1] >= bndBox[4] && fabs(ep[1] - sp[1])>1.0e-8) {
		alpha = (bndBox[4] - sp[1]) / (ep[1] - sp[1]);
		ep[0] = (1.0 - alpha)*sp[0] + alpha*ep[0];  ep[1] = (1.0 - alpha)*sp[1] + alpha*ep[1];  ep[2] = (1.0 - alpha)*sp[2] + alpha*ep[2];
	}

	//------------------------------------------------------------------------
	//	truncate by z-planes
	if (sp[2]>ep[2]) { tp[0] = sp[0]; tp[1] = sp[1]; tp[2] = sp[2]; sp[0] = ep[0]; sp[1] = ep[1]; sp[2] = ep[2];	ep[0] = tp[0]; ep[1] = tp[1]; ep[2] = tp[2]; }
	if (sp[2] <= bndBox[2] && ep[2] >= bndBox[2] && fabs(ep[2] - sp[2])>1.0e-8) {
		alpha = (bndBox[2] - sp[2]) / (ep[2] - sp[2]);
		sp[0] = (1.0 - alpha)*sp[0] + alpha*ep[0];  sp[1] = (1.0 - alpha)*sp[1] + alpha*ep[1];  sp[2] = (1.0 - alpha)*sp[2] + alpha*ep[2];
	}
	if (sp[2] <= bndBox[5] && ep[2] >= bndBox[5] && fabs(ep[2] - sp[2])>1.0e-8) {
		alpha = (bndBox[5] - sp[2]) / (ep[2] - sp[2]);
		ep[0] = (1.0 - alpha)*sp[0] + alpha*ep[0];  ep[1] = (1.0 - alpha)*sp[1] + alpha*ep[1];  ep[2] = (1.0 - alpha)*sp[2] + alpha*ep[2];
	}
}

void ThickeningMeshPatch::_fieldValueGeneration(PQP_Model *pqpModel, int iSX, int iSY, int iSZ, int iEX, int iEY, int iEZ)
{
	int i, j, k;									bool bIsClosestPntOnBnd, bFarAway = false;
	double signedDist, radius, closestPnt[3];		ThickeningGridNode *gridNode;

	//----------------------------------------------------------------------------------------------
	//	Step 1: detect if the grid nodes inside this cell are invalid
	if ((iEX - iSX)>1) {
		i = (iSX + iEX) / 2;	j = (iSY + iEY) / 2;	k = (iSZ + iEZ) / 2;
		signedDist = _distanceToPatch(pqpModel, i, j, k, closestPnt, bIsClosestPntOnBnd);

		radius = 0.8661*m_gridWidth*(double)(iEX - iSX);
		if (fabs(signedDist)>(radius + m_offset + m_gridWidth)) {
			bFarAway = true;
		}
		else {
			gridNode = _getGridNode(i, j, k);
			gridNode->bClosestPntOnBnd = bIsClosestPntOnBnd;
			gridNode->bFieldValueDefined = true;
			gridNode->bInsideSolid = _isInsideSolid(signedDist, bIsClosestPntOnBnd);
			gridNode->signedDist = (float)signedDist;
		}
	}

	//----------------------------------------------------------------------------------------------
	//	Step 2: processing the cell according to the testing results
	if (bFarAway) {
		for (i = iSX; i <= iEX; i++) {
			if (i == iSX && i != 0) continue;			// to avoid check grid nodes multiple times
			for (j = iSY; j <= iEY; j++) {
				if (j == iSY && j != 0) continue;		// to avoid check grid nodes multiple times
				for (k = iSZ; k <= iEZ; k++) {
					if (k == iSZ && k != 0) continue;	// to avoid check grid nodes multiple times
					gridNode = _getGridNode(i, j, k);
					gridNode->bInsideSolid = false;
				}
			}
		}
	}
	else {
		if ((iEX - iSX) == 1) {
			for (i = iSX; i <= iEX; i++) {
				if (i == iSX && i != 0) continue;			// to avoid generate grid nodes multiple times
				for (j = iSY; j <= iEY; j++) {
					if (j == iSY && j != 0) continue;		// to avoid generate grid nodes multiple times
					for (k = iSZ; k <= iEZ; k++) {
						if (k == iSZ && k != 0) continue;	// to avoid generate grid nodes multiple times

						gridNode = _getGridNode(i, j, k);
						if (gridNode->bFieldValueDefined) continue;

						signedDist = _distanceToPatch(pqpModel, i, j, k, closestPnt, bIsClosestPntOnBnd);
						gridNode->bClosestPntOnBnd = bIsClosestPntOnBnd;
						gridNode->bFieldValueDefined = true;
						gridNode->bInsideSolid = _isInsideSolid(signedDist, bIsClosestPntOnBnd);
						gridNode->signedDist = (float)signedDist;
					}
				}
			}
		}
		else {	// further refine the grid nodes checking
			_fieldValueGeneration(pqpModel, iSX, iSY, iSZ, (iSX + iEX) / 2, (iSY + iEY) / 2, (iSZ + iEZ) / 2);
			_fieldValueGeneration(pqpModel, (iSX + iEX) / 2, iSY, iSZ, iEX, (iSY + iEY) / 2, (iSZ + iEZ) / 2);
			_fieldValueGeneration(pqpModel, (iSX + iEX) / 2, (iSY + iEY) / 2, iSZ, iEX, iEY, (iSZ + iEZ) / 2);
			_fieldValueGeneration(pqpModel, iSX, (iSY + iEY) / 2, iSZ, (iSX + iEX) / 2, iEY, (iSZ + iEZ) / 2);

			_fieldValueGeneration(pqpModel, iSX, iSY, (iSZ + iEZ) / 2, (iSX + iEX) / 2, (iSY + iEY) / 2, iEZ);
			_fieldValueGeneration(pqpModel, (iSX + iEX) / 2, iSY, (iSZ + iEZ) / 2, iEX, (iSY + iEY) / 2, iEZ);
			_fieldValueGeneration(pqpModel, (iSX + iEX) / 2, (iSY + iEY) / 2, (iSZ + iEZ) / 2, iEX, iEY, iEZ);
			_fieldValueGeneration(pqpModel, iSX, (iSY + iEY) / 2, (iSZ + iEZ) / 2, (iSX + iEX) / 2, iEY, iEZ);
		}
	}
}

bool ThickeningMeshPatch::_isGridNodeCandidate(double signedDist, bool bIsClosestPntOnBnd)
{
	if (fabs(signedDist) <= m_gridWidth) return true;
	if (fabs(signedDist + m_offset) <= m_gridWidth && (!bIsClosestPntOnBnd)) return true;
	return false;
}

bool ThickeningMeshPatch::_isInsideSolid(double signedDist, bool bIsClosestPntOnBnd)
{
	if ((signedDist>0.0) || (bIsClosestPntOnBnd) || (signedDist<(-m_offset))) return false;

	return true;
}

bool ThickeningMeshPatch::_isTrglMeshSurface(QMeshPatch *mesh)
{
	GLKPOSITION Pos;	QMeshFace *face;

	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL;) {
		face = (QMeshFace*)(mesh->GetFaceList().GetNext(Pos));
		if (face->GetEdgeNum() != 3) return false;
	}

	return true;
}

bool ThickeningMeshPatch::_isOpenMeshSurface(QMeshPatch *mesh)
{
	GLKPOSITION Pos;	bool bIsOpenSurface = false;
	QMeshEdge *edge;	QMeshNode *node;

	for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL;) {
		node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->SetAttribFlag(0, false);
	}

	for (Pos = mesh->GetEdgeList().GetHeadPosition(); Pos != NULL;) {
		edge = (QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->SetAttribFlag(0, false);
		if (edge->GetLeftFace() == NULL || edge->GetRightFace() == NULL) {
			edge->SetAttribFlag(0, true);	bIsOpenSurface = true;
			edge->GetStartPoint()->SetAttribFlag(0, true);
			edge->GetEndPoint()->SetAttribFlag(0, true);
		}
	}

	return bIsOpenSurface;
}

void ThickeningMeshPatch::_compBndBoxAndUpdateRes(QMeshPatch *mesh, int res, double offset)
{
	m_res = 1;
	while (m_res<res) { m_res = m_res << 1; }	printf("The resolution of grids is: %d\n", m_res);

	//----------------------------------------------------------------------------------
	GLKPOSITION Pos;
	double xx, yy, zz, ww, boundingBox[6];
	QMeshNode *node;

	boundingBox[0] = boundingBox[2] = boundingBox[4] = 1.0e+32;
	boundingBox[1] = boundingBox[3] = boundingBox[5] = -1.0e+32;

	for (Pos = mesh->GetNodeList().GetHeadPosition(); Pos != NULL;) {
		node = (QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->GetCoord3D(xx, yy, zz);
		if (xx<boundingBox[0]) boundingBox[0] = xx;
		if (xx>boundingBox[1]) boundingBox[1] = xx;
		if (yy<boundingBox[2]) boundingBox[2] = yy;
		if (yy>boundingBox[3]) boundingBox[3] = yy;
		if (zz<boundingBox[4]) boundingBox[4] = zz;
		if (zz>boundingBox[5]) boundingBox[5] = zz;
	}
	boundingBox[0] -= offset;	boundingBox[2] -= offset;	boundingBox[4] -= offset;
	boundingBox[1] += offset;	boundingBox[3] += offset;	boundingBox[5] += offset;

	//----------------------------------------------------------------------------------
	//	To make the bounding box be cubical 
	xx = (boundingBox[0] + boundingBox[1])*0.5;
	yy = (boundingBox[2] + boundingBox[3])*0.5;
	zz = (boundingBox[4] + boundingBox[5])*0.5;
	ww = boundingBox[1] - boundingBox[0];
	if ((boundingBox[3] - boundingBox[2])>ww) ww = boundingBox[3] - boundingBox[2];
	if ((boundingBox[5] - boundingBox[4])>ww) ww = boundingBox[5] - boundingBox[4];
	ww = ww*0.55 + ww / (double)(m_res - 1)*2.0;
	boundingBox[0] = xx - ww;	boundingBox[1] = xx + ww;
	boundingBox[2] = yy - ww;	boundingBox[3] = yy + ww;
	boundingBox[4] = zz - ww;	boundingBox[5] = zz + ww;

	//----------------------------------------------------------------------------------
	m_origin[0] = boundingBox[0];	m_origin[1] = boundingBox[2];	m_origin[2] = boundingBox[4];
	m_gridWidth = (boundingBox[1] - boundingBox[0]) / (double)m_res;

	printf("(%f,%f,%f)-width=%f\n", m_origin[0], m_origin[1], m_origin[2], m_gridWidth);
	printf("(%f,%f,%f)-(%f,%f,%f)- Res:%d\n", boundingBox[0], boundingBox[1], boundingBox[2],
		boundingBox[3], boundingBox[4], boundingBox[5], m_res);
}

PQP_Model* ThickeningMeshPatch::_pqpInitialization(QMeshPatch *mesh)
{
	PQP_Model *pqpModel;
	PQP_REAL p1[3], p2[3], p3[3];
	GLKPOSITION Pos;	QMeshFace *face;	int i;
	double xx, yy, zz;

	pqpModel = new PQP_Model();
	m_trglFaceNum = mesh->GetFaceNumber();	if (m_trglFaceNum>0) m_faceArray = (QMeshFace**)new long[m_trglFaceNum];
	pqpModel->BeginModel();		i = 0;
	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL; i++) {
		face = (QMeshFace*)(mesh->GetFaceList().GetNext(Pos));
		face->SetIndexNo(i);
		m_faceArray[i] = face;

		face->GetNodePos(0, xx, yy, zz);
		p1[0] = (PQP_REAL)(xx);	p1[1] = (PQP_REAL)(yy);	p1[2] = (PQP_REAL)(zz);
		face->GetNodePos(1, xx, yy, zz);
		p2[0] = (PQP_REAL)(xx);	p2[1] = (PQP_REAL)(yy);	p2[2] = (PQP_REAL)(zz);
		face->GetNodePos(2, xx, yy, zz);
		p3[0] = (PQP_REAL)(xx);	p3[1] = (PQP_REAL)(yy);	p3[2] = (PQP_REAL)(zz);

		pqpModel->AddTri(p1, p2, p3, i);
	}
	pqpModel->EndModel();

	return pqpModel;
}

double ThickeningMeshPatch::_distanceToPatch(PQP_Model *pqpModel, int i, int j, int k, double closestPnt[], bool &bIsClosestPntOnBnd)
{
	double queryPnt[3];

	queryPnt[0] = m_origin[0] + m_gridWidth*(double)i;
	queryPnt[1] = m_origin[1] + m_gridWidth*(double)j;
	queryPnt[2] = m_origin[2] + m_gridWidth*(double)k;

	return _distanceToPatch(pqpModel, queryPnt, closestPnt, bIsClosestPntOnBnd);
}

double ThickeningMeshPatch::_distanceToPatch(PQP_Model *pqpModel, double queryPnt[],
	double closestPnt[], bool &bIsClosestPntOnBnd)
{
	PQP_DistanceResult dres;	PQP_REAL p[3];		int minTriIndex;
	double minDist;				double nv[3], aa, bb, cc, dd;
	QMeshEdge *edge;			QMeshNode *node;

	dres.last_tri = pqpModel->last_tri;
	p[0] = queryPnt[0];	p[1] = queryPnt[1];	p[2] = queryPnt[2];
	PQP_Distance(&dres, pqpModel, p, 0.0, 0.0);

	closestPnt[0] = dres.p1[0];	closestPnt[1] = dres.p1[1];	closestPnt[2] = dres.p1[2];
	minTriIndex = dres.last_tri->id;
	minDist = dres.Distance();

	nv[0] = nv[1] = nv[2] = 0.0;
	if (dres.pos_flag == 0) {	// closestPnt is in the triangle
		m_faceArray[minTriIndex]->GetPlaneEquation(nv[0], nv[1], nv[2], dd);
		bIsClosestPntOnBnd = false;
	}
	else if (dres.pos_flag >= 1 && dres.pos_flag <= 3) { // closestPnt is on the edge
		edge = m_faceArray[minTriIndex]->GetEdgeRecordPtr(dres.pos_flag - 1);
		bIsClosestPntOnBnd = edge->GetAttribFlag(0);
		if (edge->GetLeftFace()) {
			edge->GetLeftFace()->GetPlaneEquation(aa, bb, cc, dd);
			nv[0] = aa;	nv[1] = bb;	nv[2] = cc;
		}
		if (edge->GetRightFace()) {
			edge->GetRightFace()->GetPlaneEquation(aa, bb, cc, dd);
			nv[0] += aa;	nv[1] += bb;	nv[2] += cc;
		}
	}
	else if (dres.pos_flag >= 4 && dres.pos_flag <= 6) { // closestPnt is on the vertex
		node = m_faceArray[minTriIndex]->GetNodeRecordPtr(dres.pos_flag - 4);
		bIsClosestPntOnBnd = node->GetAttribFlag(0);
		node->CalNormal(nv);
	}

	dd = (queryPnt[0] - closestPnt[0])*nv[0] + (queryPnt[1] - closestPnt[1])*nv[1] + (queryPnt[2] - closestPnt[2])*nv[2];
	if (dd<0.0) minDist = -minDist;

	return minDist;
}

void ThickeningMeshPatch::_mallocGridNodeArray()
{
	int i, arrsize = (m_res + 1)*(m_res + 1)*(m_res + 1);
	m_gridNodesArray = new ThickeningGridNode[arrsize];
	for (i = 0; i<arrsize; i++) {
		m_gridNodesArray[i].bFieldValueDefined = false;
		m_gridNodesArray[i].bInsideSolid = false;
	}
}

void ThickeningMeshPatch::_freeGridNodeArray()
{
	delete[]m_gridNodesArray;
}

void ThickeningMeshPatch::_mallocGridEdgeArray()
{
	int arrsize = (m_res + 1)*(m_res + 1);

	m_gridEdgeArray[0] = (ThickeningGridEdge**)new long[arrsize];
	m_gridEdgeArray[1] = (ThickeningGridEdge**)new long[arrsize];
	m_gridEdgeArray[2] = (ThickeningGridEdge**)new long[arrsize];
	memset(m_gridEdgeArray[0], NULL, sizeof(long)*arrsize);
	memset(m_gridEdgeArray[1], NULL, sizeof(long)*arrsize);
	memset(m_gridEdgeArray[2], NULL, sizeof(long)*arrsize);
}

void ThickeningMeshPatch::_freeGridEdgeArray()
{
	ThickeningGridEdge *gridEdge, *nextEdge;
	int i, arrsize = (m_res + 1)*(m_res + 1);

	for (short nAxis = 0; nAxis<3; nAxis++) {
		for (i = 0; i<arrsize; i++) {
			gridEdge = m_gridEdgeArray[nAxis][i];
			while (gridEdge != NULL) { nextEdge = gridEdge->next; delete gridEdge; gridEdge = nextEdge; }
		}
		delete[](ThickeningGridEdge**)(m_gridEdgeArray[nAxis]);
	}
}

void ThickeningMeshPatch::_addHeadGridEdge(ThickeningGridEdge *edge, short nAxis, int i, int j)
{
	int k = i + j*(m_res + 1);
	edge->next = m_gridEdgeArray[nAxis][k];
	m_gridEdgeArray[nAxis][k] = edge;
}

ThickeningGridEdge* ThickeningMeshPatch::_getGridEdge(short nAxis, int i, int j, int index)
{
	ThickeningGridEdge *edge;	int k;
	k = i + j*(m_res + 1);	edge = m_gridEdgeArray[nAxis][k];
	while (edge != NULL) {
		if (edge->index == index) return edge;
		edge = edge->next;
	}
	return edge;
}

void ThickeningMeshPatch::_mallocGridCellArray()
{
	int arrsize = m_res*m_res;
	m_gridCellArray = (ThickeningGridCell**)new long[arrsize];
	memset(m_gridCellArray, NULL, sizeof(long)*arrsize);
}

void ThickeningMeshPatch::_freeGridCellArray()
{
	ThickeningGridCell *gridCell, *nextCell;
	int i, arrsize = m_res*m_res;
	for (i = 0; i<arrsize; i++) {
		gridCell = m_gridCellArray[i];
		while (gridCell != NULL) { nextCell = gridCell->next; delete gridCell; gridCell = nextCell; }
	}
	delete[](ThickeningGridCell**)(m_gridCellArray);
}

void ThickeningMeshPatch::_addHeadGridCell(ThickeningGridCell *cell, int i, int j)
{
	int index = i + j*m_res;
	cell->next = m_gridCellArray[index];
	m_gridCellArray[index] = cell;
}

ThickeningGridCell* ThickeningMeshPatch::_getGridCell(int i, int j, int k)
{
	ThickeningGridCell *cell;	int index;
	index = i + j*m_res;	cell = m_gridCellArray[index];
	while (cell != NULL) {
		if (cell->k == k) return cell;
		cell = cell->next;
	}
	return cell;
}

ThickeningGridNode* ThickeningMeshPatch::_getGridNode(int i, int j, int k)
{
	int index = k*(m_res + 1)*(m_res + 1) + j*(m_res + 1) + i;
	return (&(m_gridNodesArray[index]));
}

void ThickeningMeshPatch::_shapeOptimization(QMeshPatch *mesh, int nIterationSteps, double blendingFactor)
{
	int i, j, k, index;	ThickeningGridCell *cell;
	int pntNum;
	double sx[10], sy[10], sz[10], nx[10], ny[10], nz[10], pp[3], aa, bb, cc, dd, hpv[3], hnv[3];
	QMeshNode *node;	QMeshFace *face, *otherFace;		QMeshEdge *edge;
	GLKPOSITION Pos;

	for (int iter = 0; iter<nIterationSteps; iter++) {
		//------------------------------------------------------------------------------------------------------------
		//	Filtering the normal vectors of side-faces
		for (k = 0; k<5; k++)
		for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL;) {
			face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
			if (face->m_nIdentifiedPatchIndex != 2) continue;	// not the newly constructed faces
			if (face->GetAttribFlag(7)) continue;
			aa = bb = cc = 0.0;
			int edgeNum = face->GetEdgeNum();
			for (i = 0; i<edgeNum; i++) {
				edge = face->GetEdgeRecordPtr(i);
				if (edge->GetLeftFace() == face)
					otherFace = edge->GetRightFace();
				else
					otherFace = edge->GetLeftFace();
				if (otherFace == NULL) continue;
				if (otherFace->m_nIdentifiedPatchIndex != 2) continue;	// not the newly constructed faces
				if (otherFace->GetAttribFlag(7)) continue;
				otherFace->GetHermiteData(hpv, hnv);
				aa += hnv[0];	bb += hnv[1];	cc += hnv[2];
			}
			face->GetHermiteData(hpv, hnv);
			aa += hnv[0];	bb += hnv[1];	cc += hnv[2];
			dd = sqrt(aa*aa + bb*bb + cc*cc);
			if (dd>1.0e-8) {
				hnv[0] = aa / dd;	hnv[1] = bb / dd;	hnv[2] = cc / dd;
				face->SetHermiteData(hpv, hnv);
			}
		}

		//------------------------------------------------------------------------------------------------------------
		//	Update the position of vertices NOT locating in boundary cells
		for (i = 0; i<m_res; i++) {
			for (j = 0; j<m_res; j++) {
				index = i + j*m_res;	cell = m_gridCellArray[index];
				while (cell != NULL) {
					k = cell->k;
					if (!(cell->bBoundaryCell)) {
						node = cell->nodePtr;
						node->GetCoord3D(pp[0], pp[1], pp[2]);

						//--------------------------------------------------------------------------------------------
						//	Determine the hermite data set
						pntNum = 0;
						for (Pos = node->GetFaceList().GetHeadPosition(); Pos != NULL;) {
							face = (QMeshFace *)(node->GetFaceList().GetNext(Pos));
							if (face->m_nIdentifiedPatchIndex != 2) continue;	// not the newly constructed faces

							face->GetHermiteData(hpv, hnv);
							sx[pntNum] = hpv[0];	sy[pntNum] = hpv[1];	sz[pntNum] = hpv[2];
							nx[pntNum] = hnv[0];	ny[pntNum] = hnv[1];	nz[pntNum] = hnv[2];
							pntNum++;
							if (pntNum >= 10) break;
						}

						//--------------------------------------------------------------------------------------------
						//	update the position of vertices
						hpv[0] = pp[0];	hpv[1] = pp[1];	hpv[2] = pp[2];
						_compPositionByHermiteData(i, j, k, m_origin, m_gridWidth, pntNum, sx, sy, sz, nx, ny, nz, hpv);
						pp[0] = (1.0 - blendingFactor)*pp[0] + blendingFactor*hpv[0];
						pp[1] = (1.0 - blendingFactor)*pp[1] + blendingFactor*hpv[1];
						pp[2] = (1.0 - blendingFactor)*pp[2] + blendingFactor*hpv[2];
						node->SetCoord3D(pp[0], pp[1], pp[2]);
					}
					cell = cell->next;
				}
			}
		}
		if ((iter + 1) == nIterationSteps) break;

		//------------------------------------------------------------------------------------------------------------
		//	Update the normal vector on side-faces
		for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL;) {
			face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
			if (face->m_nIdentifiedPatchIndex != 2) continue;	// not the newly constructed faces
			if (face->GetAttribFlag(7)) continue;
			face->CalPlaneEquation();
			face->GetHermiteData(hpv, hnv);
			face->GetPlaneEquation(hnv[0], hnv[1], hnv[2], dd);
			face->SetHermiteData(hpv, hnv);
		}
	}

	for (Pos = mesh->GetFaceList().GetHeadPosition(); Pos != NULL;) {
		face = (QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		face->SetAttribFlag(7, false);
		face->CalPlaneEquation();
	}
}

void ThickeningMeshPatch::_compPositionByHermiteData(int ii, int jj, int kk, double origin[], double gwidth,
	int pntNum, double sx[], double sy[], double sz[],
	double nx[], double ny[], double nz[], double pp[])
{
	double proj, scale;
	double criterion = _CCL_SVD_THRESHOLD;	int i, j, k;
	double **A, **UU, **VV, **UUT, **VVT;		double *B, *X;
	double minP[3], maxP[3];

	//---------------------------------------------------------------------------
	//	Preparation
	pp[0] = origin[0] + gwidth*((double)ii + 0.5);
	pp[1] = origin[1] + gwidth*((double)jj + 0.5);
	pp[2] = origin[2] + gwidth*((double)kk + 0.5);
	minP[0] = pp[0] - gwidth*0.5;	minP[1] = pp[1] - gwidth*0.5;	minP[2] = pp[2] - gwidth*0.5;
	maxP[0] = pp[0] + gwidth*0.5;	maxP[1] = pp[1] + gwidth*0.5;	maxP[2] = pp[2] + gwidth*0.5;
	//---------------------------------------------------------------------------
	pp[0] = pp[1] = pp[2] = 0.0;
	for (int index = 0; index<pntNum; index++) { pp[0] += sx[index];	pp[1] += sy[index];	pp[2] += sz[index]; }
	pp[0] = pp[0] / (double)pntNum;
	pp[1] = pp[1] / (double)pntNum;
	pp[2] = pp[2] / (double)pntNum;
	//---------------------------------------------------------------------------
	GLKMatrixLib::CreateMatrix(A, 3, 3);		B = new double[3];	X = new double[3];
	GLKMatrixLib::CreateMatrix(UU, 3, 3);		GLKMatrixLib::CreateMatrix(VV, 3, 3);
	GLKMatrixLib::CreateMatrix(UUT, 3, 3);	GLKMatrixLib::CreateMatrix(VVT, 3, 3);
	//---------------------------------------------------------------------------
	B[0] = B[1] = B[2] = X[0] = X[1] = X[2] = 0.0;
	for (k = 0; k<pntNum; k++) {
		proj = (sx[k] - pp[0])*nx[k] + (sy[k] - pp[1])*ny[k] + (sz[k] - pp[2])*nz[k];
		B[0] += proj*nx[k];	B[1] += proj*ny[k];	B[2] += proj*nz[k];

		A[0][0] += nx[k] * nx[k]; A[0][1] += nx[k] * ny[k]; A[0][2] += nx[k] * nz[k];
		A[1][0] += ny[k] * nx[k]; A[1][1] += ny[k] * ny[k]; A[1][2] += ny[k] * nz[k];
		A[2][0] += nz[k] * nx[k]; A[2][1] += nz[k] * ny[k]; A[2][2] += nz[k] * nz[k];
	}

	//---------------------------------------------------------------------------
	//	Singular Value Decomposition
	GLKMatrixLib::SingularValueDecomposition(A, 3, 3, UU, VVT);
	GLKMatrixLib::Transpose(UU, 3, 3, UUT);
	GLKMatrixLib::Transpose(VVT, 3, 3, VV);
	double maxFactor = (fabs(A[0][0])>fabs(A[1][1])) ? (A[0][0]) : (A[1][1]);
	maxFactor = (fabs(maxFactor)>fabs(A[2][2])) ? (maxFactor) : (A[2][2]);
	if (fabs(maxFactor)<1.0e-6) {
		for (i = 0; i<3; i++) {
			for (j = 0; j<3; j++) {
				A[i][j] = 0.0;
			}
		}
	}
	else {
		for (i = 0; i<3; i++) {
			for (j = 0; j<3; j++) {
				if (i != j) {
					A[i][j] = 0.0;
				}
				else {
					if (fabs(A[i][j] / maxFactor)<criterion)
						A[i][j] = 0.0;
					else
						A[i][j] = 1.0 / A[i][j];
				}
			}
		}
	}
	GLKMatrixLib::Mul(UUT, B, 3, 3, X);
	GLKMatrixLib::Mul(A, X, 3, 3, B);
	GLKMatrixLib::Mul(VV, B, 3, 3, X);
	//-----------------------------------------------------------------
	//	truncate the update vector and update node position
	scale = 1.0;
	if (fabs(X[0])>1.0e-5 && (pp[0] + X[0] * scale)>maxP[0]) scale = (maxP[0] - pp[0]) / X[0];
	if (fabs(X[1])>1.0e-5 && (pp[1] + X[1] * scale)>maxP[1]) scale = (maxP[1] - pp[1]) / X[1];
	if (fabs(X[2])>1.0e-5 && (pp[2] + X[2] * scale)>maxP[2]) scale = (maxP[2] - pp[2]) / X[2];
	if (fabs(X[0])>1.0e-5 && (pp[0] + X[0] * scale)<minP[0]) scale = (minP[0] - pp[0]) / X[0];
	if (fabs(X[1])>1.0e-5 && (pp[1] + X[1] * scale)<minP[1]) scale = (minP[1] - pp[1]) / X[1];
	if (fabs(X[2])>1.0e-5 && (pp[2] + X[2] * scale)<minP[2]) scale = (minP[2] - pp[2]) / X[2];
	pp[0] = pp[0] + X[0] * scale;	pp[1] = pp[1] + X[1] * scale;	pp[2] = pp[2] + X[2] * scale;

	//---------------------------------------------------------------------------
	//	Free the memory
	GLKMatrixLib::DeleteMatrix(A, 3, 3);		delete[]B;	delete[]X;
	GLKMatrixLib::DeleteMatrix(UU, 3, 3);		GLKMatrixLib::DeleteMatrix(VV, 3, 3);
	GLKMatrixLib::DeleteMatrix(UUT, 3, 3);	GLKMatrixLib::DeleteMatrix(VVT, 3, 3);
}
