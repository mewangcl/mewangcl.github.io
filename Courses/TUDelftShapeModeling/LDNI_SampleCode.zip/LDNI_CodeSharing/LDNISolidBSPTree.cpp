#include <stdio.h>
#include <math.h>
#include <time.h>
#include <omp.h>

#include "..\GLKLib\GLKObList.h"
#include "..\GLKLib\GLKMatrixLib.h"
#include "..\GLKLib\GLKGeometry.h"

#include "LDNISolid.h"
#include "LDNISolidBSPTree.h"

#define DYNAMIC_ARRAY_SIZE	50

#ifdef _DEBUG_BSP_DISPLAY
LDNISolid *inputsolid;	int regionID;	
#endif

int maxLevel;

//#ifdef _DEBUG	// for detecting memory leak, using this - you need to use MFC DLL setting in compiling
//#include <afx.h>         // MFC core and standard components
//#define new DEBUG_NEW
//#endif

LDNISolidBSPTreeNode::LDNISolidBSPTreeNode(void)
{
	leftChild=rightChild=NULL;	bSolid=false;
}

LDNISolidBSPTreeNode::~LDNISolidBSPTreeNode(void)
{
	if (leftChild!=NULL) delete leftChild;
	if (rightChild!=NULL) delete rightChild;
}

LDNISolidBSPTreeOperation::LDNISolidBSPTreeOperation(void)
{
}

LDNISolidBSPTreeOperation::~LDNISolidBSPTreeOperation(void)
{
}

void LDNISolidBSPTreeOperation::BSPTreeConstruction(LDNISolid *solid, LDNISolidBSPTreeNode *&root)
{
	int res,halfres,cijk[3];	double gwidth,delta,origin[3],center[3];
	LDNISolidBSPTreeNode *leftNode,*rightNode;
	LDNISolidBSPTreeNode *nodeArray[8],*nodeArray2[4];
	short i;

	maxLevel=0;
	res=solid->GetResolution();		gwidth=solid->GetGridWidth();	solid->GetOrigin(origin);
#ifdef _DEBUG_BSP_DISPLAY
	regionID=1;
#endif

	//-------------------------------------------------------------------------------------------------
	//	Step 1: build the initial eight nodes in the BSP-tree
	halfres=res/2;	delta=gwidth*(double)halfres;	cijk[0]=cijk[1]=cijk[2]=halfres;
	center[0]=origin[0]+delta;	center[1]=origin[1]+delta;	center[2]=origin[2]+delta;
	//-------------------------------------------------------------------------------------------------
	root=new LDNISolidBSPTreeNode;
	root->cp[0]=center[0];	root->cp[1]=center[1];	root->cp[2]=center[2];
	root->np[0]=1.0;	root->np[1]=0.0;	root->np[2]=0.0;
	//-------------------------------------------------------------------------------------------------
	leftNode=new LDNISolidBSPTreeNode;	root->leftChild=leftNode;
	leftNode->cp[0]=center[0];	leftNode->cp[1]=center[1];	leftNode->cp[2]=center[2];
	leftNode->np[0]=0.0;	leftNode->np[1]=1.0;	leftNode->np[2]=0.0;
	rightNode=new LDNISolidBSPTreeNode;	root->rightChild=rightNode;
	rightNode->cp[0]=center[0];	rightNode->cp[1]=center[1];	rightNode->cp[2]=center[2];
	rightNode->np[0]=0.0;	rightNode->np[1]=1.0;	rightNode->np[2]=0.0;
	//-------------------------------------------------------------------------------------------------
	for(i=0;i<4;i++) {
		nodeArray2[i]=new LDNISolidBSPTreeNode;
		nodeArray2[i]->cp[0]=center[0];	nodeArray2[i]->cp[1]=center[1];	nodeArray2[i]->cp[2]=center[2];
		nodeArray2[i]->np[0]=0.0;	nodeArray2[i]->np[1]=0.0;	nodeArray2[i]->np[2]=1.0;

		nodeArray[i*2]=new LDNISolidBSPTreeNode;	nodeArray[i*2+1]=new LDNISolidBSPTreeNode;
		nodeArray2[i]->leftChild=nodeArray[i*2];	nodeArray2[i]->rightChild=nodeArray[i*2+1];
	}
	leftNode->leftChild=nodeArray2[0];	leftNode->rightChild=nodeArray2[1];
	rightNode->leftChild=nodeArray2[2];	rightNode->rightChild=nodeArray2[3];

	//-------------------------------------------------------------------------------------------------
	//	Step 2: refine the BSP-tree by the LDNISolid
	omp_set_dynamic(8);
	omp_set_num_threads(8);
	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
#pragma omp parallel for
	for(short k=0;k<8;k++) {
		int sXYZ[3],eXYZ[3];
		switch(k) {
		case 0:{sXYZ[0]=0;  sXYZ[1]=0;  sXYZ[2]=0;  eXYZ[0]=cijk[0];  eXYZ[1]=cijk[1];  eXYZ[2]=cijk[2];
			   }break;
		case 1:{sXYZ[0]=0;  sXYZ[1]=0;  sXYZ[2]=cijk[2];  eXYZ[0]=cijk[0];  eXYZ[1]=cijk[1];  eXYZ[2]=res-1;
			   }break;
		case 2:{sXYZ[0]=0;  sXYZ[1]=cijk[1];  sXYZ[2]=0;  eXYZ[0]=cijk[0];  eXYZ[1]=res-1;  eXYZ[2]=cijk[2];
			   }break;
		case 3:{sXYZ[0]=0;  sXYZ[1]=cijk[1];  sXYZ[2]=cijk[2];  eXYZ[0]=cijk[0];  eXYZ[1]=res-1;  eXYZ[2]=res-1;
			   }break;
		case 4:{sXYZ[0]=cijk[0];  sXYZ[1]=0;  sXYZ[2]=0;  eXYZ[0]=res-1;  eXYZ[1]=cijk[1];  eXYZ[2]=cijk[2];
			   }break;
		case 5:{sXYZ[0]=cijk[0];  sXYZ[1]=0;  sXYZ[2]=cijk[2];  eXYZ[0]=res-1;  eXYZ[1]=cijk[1];  eXYZ[2]=res-1;
			   }break;
		case 6:{sXYZ[0]=cijk[0];  sXYZ[1]=cijk[1];  sXYZ[2]=0;  eXYZ[0]=res-1;  eXYZ[1]=res-1;  eXYZ[2]=cijk[2];
			   }break;
		case 7:{sXYZ[0]=cijk[0];  sXYZ[1]=cijk[1];  sXYZ[2]=cijk[2];  eXYZ[0]=res-1;  eXYZ[1]=res-1;  eXYZ[2]=res-1;
			   }break;
		}
		_cellConstruction(nodeArray[k],solid,sXYZ,eXYZ,3);
	}

	printf("max level of BSP-tree is: %d \n",maxLevel);

	_debugSolidEmptyCheck(root);
}

bool LDNISolidBSPTreeOperation::PntMembershipClassification(LDNISolidBSPTreeNode *root, double pnt[])
{
	if (!(root->IsLeaveNode())) {
		double dist=(pnt[0]-root->cp[0])*(root->np[0])+(pnt[1]-root->cp[1])*(root->np[1])+(pnt[2]-root->cp[2])*(root->np[2]);
		if (dist>0.0) {
			return (PntMembershipClassification(root->rightChild,pnt));
		}
		else if (dist<0.0) {
			return (PntMembershipClassification(root->leftChild,pnt));
		}
		else {
			printf("on the boundary");
		}
	}

	return root->bSolid;
}

void LDNISolidBSPTreeOperation::LDNISolidSampledFromBSPTree(LDNISolidBSPTreeNode *root, 
															short res, double gwidth, double origin[], 
															LDNISolid *&solid)
{
	short nDir,ix,iy,iz;

	printf("Start\n");

	//--------------------------------------------------------------------------------------------------------
	//	Step 1: preparation the solid is to be reconstructed
	origin[0]+=gwidth*0.1;
	origin[1]+=gwidth*0.1;
	origin[2]+=gwidth*0.1;
	solid=new LDNISolid;
	solid->MallocMemoryOfSolidNodeArray(res);
	solid->SetGridWidth(gwidth);	solid->SetOrigin(origin);
	double tolerance=APPROXIMATION_ERROR*solid->GetGridWidth();

	//--------------------------------------------------------------------------------------------------------
	//	Step 2: for each ray determine its corresponding segments
//	omp_set_dynamic(8);
//	omp_set_num_threads(8);
//	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
	
	double *depth,*nx,*ny,*nz;
	depth=new double[MAX_LDNI_LAYER_NUM]; nx=new double[MAX_LDNI_LAYER_NUM]; ny=new double[MAX_LDNI_LAYER_NUM]; nz=new double[MAX_LDNI_LAYER_NUM];

	int newNum=res*res;
	for(nDir=0;nDir<3;nDir++) {
//#pragma omp parallel for schedule(dynamic) 
		for(int kk=0;kk<newNum;kk++) {
			short i=kk/res;		short j=kk%res;
			
			//-----------------------------------------------------------------------------------------------
			//	slicing the ray into segments
			int sampleNum=0;	double sDepth,eDepth;
			sDepth=-1.0;	eDepth=gwidth*(double)res+1.0;
			
			_compIntersectionsOnRay(root,nDir,i,j,res,gwidth,origin,sDepth,eDepth,0,0,0,0,0,0,sampleNum,depth,nx,ny,nz,tolerance);
			
			if (sampleNum==0) {
//				delete []depth;		delete []nx;	delete []ny;	delete []nz;
				continue;
			}

			//-----------------------------------------------------------------------------------------------
			//	sorting the samples on the ray
			short ii,jj;	double temp,tx,ty,tz;
			for(ii=0;ii<sampleNum;ii++) {
				for(jj=ii+1;jj<sampleNum;jj++) {
					if (depth[ii]>depth[jj]) {
						temp=depth[ii];		tx=nx[ii];	ty=ny[ii];	tz=nz[ii];
						depth[ii]=depth[jj];	nx[ii]=nx[jj];	ny[ii]=ny[jj];	nz[ii]=nz[jj];
						depth[jj]=temp;		nx[jj]=tx;	ny[jj]=ty;	nz[jj]=tz;
					}
				}
			}
			if (sampleNum%2==1) printf("Warning: odd number of intersection is found!\n");
			//sampleNum=1;

			//-----------------------------------------------------------------------------------------------
			//	eliminate the gaps
			short newSampleNum;	
			short *newIndex=new short[sampleNum];
			newIndex[0]=0;	newSampleNum=1;
			for(ii=1;ii<sampleNum-1;ii+=2) {
				if (fabs(depth[ii]-depth[ii+1])<gwidth*APPROXIMATION_ERROR) continue;
				newIndex[newSampleNum]=ii;	newSampleNum++;
				newIndex[newSampleNum]=ii+1;	newSampleNum++;
			}
			newIndex[newSampleNum]=sampleNum-1;	newSampleNum++;
			 
			//-----------------------------------------------------------------------------------------------
			//	create samples
			LDNISolidNode *currentNode=new LDNISolidNode;
			currentNode->MallocSampleArray(newSampleNum);
			for(short k=0;k<newSampleNum;k++) {
				short index=newIndex[k];
				currentNode->SetDepth(k,(float)(depth[index]));
				encodeNormal(nx[index],ny[index],nz[index],ix,iy,iz);
				currentNode->SetNormal(k,ix,iy,iz);
				currentNode->SetID(k,nDir);
			}
			delete []newIndex;
			solid->SetLDNISolidNode(nDir,i,j,currentNode);

			//LDNISolidNode *currentNode=new LDNISolidNode;
			//currentNode->MallocSampleArray(sampleNum);
			//for(short k=0;k<sampleNum;k++) {
			//	currentNode->SetDepth(k,(float)(depth[k]));
			//	encodeNormal(nx[k],ny[k],nz[k],ix,iy,iz);
			//	currentNode->SetNormal(k,ix,iy,iz);
			//	currentNode->SetID(k,nDir);
			//}
			//solid->SetLDNISolidNode(nDir,i,j,currentNode);
		}
	}

	delete []depth;		delete []nx;	delete []ny;	delete []nz;
}

void LDNISolidBSPTreeOperation::_cellConstruction(LDNISolidBSPTreeNode *cell, LDNISolid *solid, int sXYZ[], int eXYZ[], int level)
{
	int res,i;		bool bOrthogonalRefinement;
	double tolerance,gwidth,origin[3],cp[3],np[3];

	res=solid->GetResolution();		gwidth=solid->GetGridWidth();	solid->GetOrigin(origin);
	tolerance=APPROXIMATION_ERROR*solid->GetGridWidth();
//	printf("%lf,%lf,%lf\n",cp[0],cp[1],cp[2]);
	if (level>maxLevel) maxLevel=level;

	//----------------------------------------------------------------------------------------------------------------
	//	step 1: check is the orthogonal refinement is needed. 
	bOrthogonalRefinement=_isOrthogonalRefinementNeeded(solid,sXYZ,eXYZ,tolerance);

	//----------------------------------------------------------------------------------------------------------------
	if (bOrthogonalRefinement) {
		//------------------------------------------------------------------------------------------------------------
		//	Step 2:	if the othorgonal refinement need, determine the cutting plane and refine the node
		int ssXYZ[3],eeXYZ[3],dXYZ,nDir;

		nDir=level%3;	dXYZ=(eXYZ[nDir]+sXYZ[nDir])/2;
		for(i=0;i<3;i++) {cp[i]=origin[i]+gwidth*(double)(sXYZ[i]+eXYZ[i])*0.5;}
		np[0]=np[1]=np[2]=0.0;	np[nDir]=1.0;
		cell->cp[0]=cp[0];	cell->cp[1]=cp[1];	cell->cp[2]=cp[2];	cell->np[0]=np[0];	cell->np[1]=np[1];	cell->np[2]=np[2];

		//------------------------------------------------------------------------------------------------------------
		cell->leftChild=new LDNISolidBSPTreeNode;
		ssXYZ[0]=sXYZ[0];	ssXYZ[1]=sXYZ[1];	ssXYZ[2]=sXYZ[2];
		eeXYZ[0]=eXYZ[0];	eeXYZ[1]=eXYZ[1];	eeXYZ[2]=eXYZ[2];
		eeXYZ[nDir]=dXYZ;
		_cellConstruction(cell->leftChild,solid,ssXYZ,eeXYZ,level+1);

		//------------------------------------------------------------------------------------------------------------
		cell->rightChild=new LDNISolidBSPTreeNode;
		ssXYZ[0]=sXYZ[0];	ssXYZ[1]=sXYZ[1];	ssXYZ[2]=sXYZ[2];
		eeXYZ[0]=eXYZ[0];	eeXYZ[1]=eXYZ[1];	eeXYZ[2]=eXYZ[2];
		ssXYZ[nDir]=dXYZ;
		_cellConstruction(cell->rightChild,solid,ssXYZ,eeXYZ,level+1);
	}
	else {
		//------------------------------------------------------------------------------------------------------------
		//	Step 3:	if the othorgonal refinement is need, build the BSP-node by samples in the cell
		int pntNum;		double **samplePnts;
		bool bSampleFound=_searchSamplesInCell(solid,sXYZ,eXYZ,pntNum,samplePnts);
#ifdef _DEBUG_BSP_DISPLAY	
		if (bSampleFound) regionID++;
#endif

		if (!bSampleFound) {	// check and specify whether this is a solid cell or an empty cell
			cell->bSolid=solid->DetectNodeInOrOut(sXYZ[0],sXYZ[1],sXYZ[2]);
			//bool bNodeIn[8];
			//bNodeIn[0]=solid->DetectNodeInOrOut(sXYZ[0],sXYZ[1],sXYZ[2]);
			//bNodeIn[1]=solid->DetectNodeInOrOut(eXYZ[0],sXYZ[1],sXYZ[2]);
			//bNodeIn[2]=solid->DetectNodeInOrOut(sXYZ[0],eXYZ[1],sXYZ[2]);
			//bNodeIn[3]=solid->DetectNodeInOrOut(eXYZ[0],eXYZ[1],sXYZ[2]);
			//bNodeIn[4]=solid->DetectNodeInOrOut(sXYZ[0],sXYZ[1],eXYZ[2]);
			//bNodeIn[5]=solid->DetectNodeInOrOut(eXYZ[0],sXYZ[1],eXYZ[2]);
			//bNodeIn[6]=solid->DetectNodeInOrOut(sXYZ[0],eXYZ[1],eXYZ[2]);
			//bNodeIn[7]=solid->DetectNodeInOrOut(eXYZ[0],eXYZ[1],eXYZ[2]);
			//if (!(_isEmptyOrSolidCell(bNodeIn))) printf("Error Cell!\n");
		}
		else {
			//printf("%d ", pntNum);
			_nonorthogonalCellConstruction(cell,pntNum,samplePnts,level+1,tolerance);	// This function has problem!!!!
		}
	}
}

bool LDNISolidBSPTreeOperation::_isOrthogonalRefinementNeeded(LDNISolid *solid, int sXYZ[], int eXYZ[], double geoCriterion)
{
	bool bNodeIn[8];

	if (sXYZ[0]==(eXYZ[0]-1) || sXYZ[1]==(eXYZ[1]-1) || sXYZ[2]==(eXYZ[2]-1)) return false;	// already reached the finest resolution of LDNISolid
//	if (sXYZ[0]==(eXYZ[0]-1) && sXYZ[1]==(eXYZ[1]-1) && sXYZ[2]==(eXYZ[2]-1)) return false;	// already reached the finest resolution of LDNISolid

//	return true;

	/////////////////////////////////////////////////////////////////////////////////
	//	Step 1: determine the inside/outside configuration at the corner points
	bNodeIn[0]=solid->DetectNodeInOrOut(sXYZ[0],sXYZ[1],sXYZ[2]);
	bNodeIn[1]=solid->DetectNodeInOrOut(eXYZ[0],sXYZ[1],sXYZ[2]);
	bNodeIn[2]=solid->DetectNodeInOrOut(sXYZ[0],eXYZ[1],sXYZ[2]);
	bNodeIn[3]=solid->DetectNodeInOrOut(eXYZ[0],eXYZ[1],sXYZ[2]);
	bNodeIn[4]=solid->DetectNodeInOrOut(sXYZ[0],sXYZ[1],eXYZ[2]);
	bNodeIn[5]=solid->DetectNodeInOrOut(eXYZ[0],sXYZ[1],eXYZ[2]);
	bNodeIn[6]=solid->DetectNodeInOrOut(sXYZ[0],eXYZ[1],eXYZ[2]);
	bNodeIn[7]=solid->DetectNodeInOrOut(eXYZ[0],eXYZ[1],eXYZ[2]);

	/////////////////////////////////////////////////////////////////////////////////
	//	Step 2: check whether it is a complex cell
	//-------------------------------------------------------------------------------
	//	Check 1 (complex cell) - for the invalid empty or solid cell
	if (_isEmptyOrSolidCell(bNodeIn)) {
		if (_complexCellCheck_InvalidEmptyOrSolidCell(solid,bNodeIn[0],sXYZ,eXYZ)) 
			return true;
		else
			return false;
	}
	//-------------------------------------------------------------------------------
	//	Check 2 & 3 (complex cell) - for the ambiguous face and the ambiguous volume
	if (_complexCellCheck_AmbiguousFaceOrCell(bNodeIn)) return true;
	//-------------------------------------------------------------------------------
	//	Check 4 (complex cell) - for the multiple intersection on edges
	//		(note that the hermite data collection is also collected in this step)
	//
	if (_complexCellCheck_MultipleEdgeIntersections(solid,sXYZ,eXYZ)) return true;

	return true;
	
	/////////////////////////////////////////////////////////////////////////////////
	//	Step 3: compute the position of the vertex in this cell and evaluate the geometry error
	double pos[3];
	_compQEFPntInCell(solid,sXYZ,eXYZ,pos,true);
	if (!_IsGeometryCompatibleInCell(solid,sXYZ,eXYZ,pos,geoCriterion)) return true;

	//-------------------------------------------------------------------------------
	//	Check 6 (complex cell) - for the invalid empty or solid face
	if (_complexCellCheck_InvalidEmptyOrSolidFace(solid,sXYZ,eXYZ,bNodeIn)) return true;

	return false;
}

bool LDNISolidBSPTreeOperation::_isEmptyOrSolidCell(bool bNodeIn[])
{
	int i;	bool bInOrOut,bSame;

	bInOrOut=bNodeIn[0];		bSame=true;
	for(i=1;i<8;i++) {if (bNodeIn[i]!=bInOrOut) {bSame=false;break;} }

	return bSame;
}

bool LDNISolidBSPTreeOperation::_complexCellCheck_InvalidEmptyOrSolidCell(LDNISolid *solid,
																		  bool bSolid, 
																		  int sXYZ[], int eXYZ[])
{
	int i,j,iLower,iUpper,jLower,jUpper,nAxis,res;
	LDNISolidNode *currentNode;					double upper,lower,width;
	double eps=1.0e-5;

	width=solid->GetGridWidth();	res=solid->GetResolution();
	for(nAxis=0;nAxis<3;nAxis++) {
		switch(nAxis) {
		case 0:{lower=width*(double)(sXYZ[0])-eps;	upper=width*(double)(eXYZ[0])+eps;
				iLower=sXYZ[1];	iUpper=eXYZ[1];
				jLower=sXYZ[2];	jUpper=eXYZ[2];
			   }break;
		case 1:{lower=width*(double)(sXYZ[1])-eps;	upper=width*(double)(eXYZ[1])+eps;
				iLower=sXYZ[2];	iUpper=eXYZ[2];
				jLower=sXYZ[0];	jUpper=eXYZ[0];
			   }break;
		case 2:{lower=width*(double)(sXYZ[2])-eps;	upper=width*(double)(eXYZ[2])+eps;
				iLower=sXYZ[0];	iUpper=eXYZ[0];
				jLower=sXYZ[1];	jUpper=eXYZ[1];
			   }break;
		}
		upper+=eps;	lower-=eps;
		for(i=iLower;i<=iUpper;i++) {
			if ((i>=res) || (i<0)) continue;
			for(j=jLower;j<=jUpper;j++) {
				if ((j>=res) || (j<0)) continue;
				currentNode=solid->GetLDNISolidNode(nAxis,i,j);
				if (currentNode==NULL) continue;

				short nNum=currentNode->GetSampleNum();
				for(short k=0;k<nNum;k++) {
					double depth=currentNode->GetDepth(k);
					if (depth>upper) break;
					if (depth<lower) continue;
					return true;
				}
			}
		}
	}

	return false;
}

bool LDNISolidBSPTreeOperation::_complexCellCheck_AmbiguousFaceOrCell(bool bNodeIn[])
{
	int i,nCase;	bool bInOrOut;
	short faceTable[][4]={ {0,4,6,2}, {1,3,7,5}, {0,1,5,4}, {2,6,7,3}, {0,2,3,1}, {4,5,7,6} };
	short cellDiagonalTable[][2]={ {0,7}, {2,5}, {1,6}, {3,4} };

	for(i=0;i<6;i++) {
		if ((bNodeIn[faceTable[i][0]]==bNodeIn[faceTable[i][2]])
			&& (bNodeIn[faceTable[i][1]]==bNodeIn[faceTable[i][3]])
			&& (bNodeIn[faceTable[i][0]]!=bNodeIn[faceTable[i][1]])) 
			return true;
	}
	for(nCase=0;nCase<4;nCase++) {
		if (bNodeIn[cellDiagonalTable[nCase][0]]!=bNodeIn[cellDiagonalTable[nCase][1]]) continue;
		bInOrOut=bNodeIn[cellDiagonalTable[nCase][0]];
		for(i=0;i<8;i++) {
			if (i==cellDiagonalTable[nCase][0]) continue;
			if (i==cellDiagonalTable[nCase][1]) continue;
			if (bNodeIn[i]==bInOrOut) break;
		}
		if (i==8) 
			return true;	// the ambiguous happens
	}

	return false;
}

bool LDNISolidBSPTreeOperation::_complexCellCheck_MultipleEdgeIntersections(LDNISolid *solid,
																			int sXYZ[], int eXYZ[])
{
	LDNISolidNode *currentNode;
	int sX,sY,sZ,eX,eY,eZ,nCase;
	double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3],upper,lower;

	solid->GetOrigin(origin);		width=solid->GetGridWidth();
	sX=sXYZ[0];	sY=sXYZ[1];	sZ=sXYZ[2];	eX=eXYZ[0];	eY=eXYZ[1];	eZ=eXYZ[2];
	xmin=width*(double)sX;	ymin=width*(double)sY;	zmin=width*(double)sZ;
	xmax=width*(double)eX;	ymax=width*(double)eY;	zmax=width*(double)eZ;

	for(nCase=0;nCase<12;nCase++) {
		switch(nCase) {
		case 0:{currentNode=solid->GetLDNISolidNode(0,sY,sZ);	lower=xmin;	upper=xmax;}break;
		case 1:{currentNode=solid->GetLDNISolidNode(0,eY,sZ);	lower=xmin;	upper=xmax;}break;
		case 2:{currentNode=solid->GetLDNISolidNode(0,sY,eZ);	lower=xmin;	upper=xmax;}break;
		case 3:{currentNode=solid->GetLDNISolidNode(0,eY,eZ);	lower=xmin;	upper=xmax;}break;

		case 4:{currentNode=solid->GetLDNISolidNode(1,sZ,sX);	lower=ymin;	upper=ymax;}break;
		case 5:{currentNode=solid->GetLDNISolidNode(1,eZ,sX);	lower=ymin;	upper=ymax;}break;
		case 6:{currentNode=solid->GetLDNISolidNode(1,sZ,eX);	lower=ymin;	upper=ymax;}break;
		case 7:{currentNode=solid->GetLDNISolidNode(1,eZ,eX);	lower=ymin;	upper=ymax;}break;

		case 8:{currentNode=solid->GetLDNISolidNode(2,sX,sY);	lower=zmin;	upper=zmax;}break;
		case 9:{currentNode=solid->GetLDNISolidNode(2,eX,sY);	lower=zmin;	upper=zmax;}break;
		case 10:{currentNode=solid->GetLDNISolidNode(2,sX,eY);	lower=zmin;	upper=zmax;}break;
		case 11:{currentNode=solid->GetLDNISolidNode(2,eX,eY);	lower=zmin;	upper=zmax;}break;
		}
		if (currentNode==NULL) continue;

		int intersectionPntNum=0;
		short k,nNum;
		nNum=currentNode->GetSampleNum();
		for(k=0;k<nNum;k++) {
			double depth=currentNode->GetDepth(k);
			if (depth>=upper) break;
			if (depth<lower) continue;
			intersectionPntNum++;
		}
		if (intersectionPntNum>1) return true;
	}

	return false;

}

bool LDNISolidBSPTreeOperation::_complexCellCheck_InvalidEmptyOrSolidFace(LDNISolid *solid,
																		  int sXYZ[], int eXYZ[], bool bNodeIn[])
{
	int nFace,nAxis,i,j,iUpper,iLower,jUpper,jLower,res;
	bool bSolid,bConsistent;
	double faceDepth,width,depth1,depth2,maxDepth;
	LDNISolidNode *currentNode;
	short faceTable[][4]={ {0,4,6,2}, {1,3,7,5}, {0,1,5,4}, {2,6,7,3}, {0,2,3,1}, {4,5,7,6} };
	double eps=1.0e-5;

	res=solid->GetResolution(); width=solid->GetGridWidth(); maxDepth=width*(double)res;

	for(nFace=0;nFace<6;nFace++) {
		bSolid=bNodeIn[faceTable[nFace][0]];
		bConsistent=true;
		for(i=1;i<4;i++) {
			if (bSolid!=bNodeIn[faceTable[nFace][i]]) {bConsistent=false; break;}
		}
		if (!bConsistent) continue;

		switch(nFace) {
		case 0:{faceDepth=width*(double)(sXYZ[0]);
				iLower=sXYZ[1];	iUpper=eXYZ[1];	jLower=sXYZ[2];	jUpper=eXYZ[2];
				nAxis=0;
			   }break;
		case 1:{faceDepth=width*(double)(eXYZ[0]);
				iLower=sXYZ[1];	iUpper=eXYZ[1];	jLower=sXYZ[2];	jUpper=eXYZ[2];
				nAxis=0;
			   }break;
		case 2:{faceDepth=width*(double)(sXYZ[1]);
				iLower=sXYZ[2];	iUpper=eXYZ[2];	jLower=sXYZ[0];	jUpper=eXYZ[0];
				nAxis=1;
			   }break;
		case 3:{faceDepth=width*(double)(eXYZ[1]);
				iLower=sXYZ[2];	iUpper=eXYZ[2];	jLower=sXYZ[0];	jUpper=eXYZ[0];
				nAxis=1;
			   }break;
		case 4:{faceDepth=width*(double)(sXYZ[2]);
				iLower=sXYZ[0];	iUpper=eXYZ[0];	jLower=sXYZ[1];	jUpper=eXYZ[1];
				nAxis=2;
			   }break;
		case 5:{faceDepth=width*(double)(eXYZ[2]);
				iLower=sXYZ[0];	iUpper=eXYZ[0];	jLower=sXYZ[1];	jUpper=eXYZ[1];
				nAxis=2;
			   }break;
		}

		if (bSolid) {
			for(i=iLower;i<=iUpper;i++) {
				if ((i>=res) || (i<0)) return false;
				for(j=jLower;j<=jUpper;j++) {
					if ((j>=res) || (j<0)) return false;
					currentNode=solid->GetLDNISolidNode(nAxis,i,j);
					if (currentNode==NULL) return false;

					short k,nNum;
					k=0;	nNum=currentNode->GetSampleNum();	depth1=0.0;
					for(;;k++) {
						if (k<nNum) depth2=currentNode->GetDepth(k); else depth2=maxDepth;
						if ((depth1<faceDepth) && (depth2>faceDepth)) return true;
						if (k>=nNum) break;
						k++; depth1=currentNode->GetDepth(k);
						if (depth1>faceDepth+eps) break;
					}
				}
			}
		}
		else {
			for(i=iLower;i<=iUpper;i++) {
				if ((i>=res) || (i<0)) continue;
				for(j=jLower;j<=jUpper;j++) {
					if ((j>=res) || (j<0)) continue;
					currentNode=solid->GetLDNISolidNode(nAxis,i,j);
					if (currentNode==NULL) continue;

					short k,nNum;
					nNum=currentNode->GetSampleNum();
					for(k=0;k<nNum;k+=2) {
						depth1=currentNode->GetDepth(k); depth2=currentNode->GetDepth(k+1);
						if (depth1>=faceDepth+eps) break;
						if (depth2<faceDepth-eps) continue;
						if ((depth1<=faceDepth) && (depth2>=faceDepth)) return true;
					}
				}
			}
		}
	}

	return false;
}

void LDNISolidBSPTreeOperation::_compQEFPntInCell(LDNISolid *solid, int sXYZ[], int eXYZ[], double posQEF[], bool bTruncate)
{
	LDNISolidNode *currentNode;
	int sX,sY,sZ,eX,eY,eZ,ii,jj,is,ie,js,je,res;	short nAxis;
	double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3],upper,lower,scale;
	double eps=1.0e-5;
	double criterion=0.01;					int i,j;
	double **A,**UU,**VV,**UUT,**VVT;		double *B,*X;

	//---------------------------------------------------------------------------
	//	Preparation
	GLKMatrixLib::CreateMatrix(A,3,3);		B=new double[3];	X=new double[3];
	GLKMatrixLib::CreateMatrix(UU,3,3);		GLKMatrixLib::CreateMatrix(VV,3,3);
	GLKMatrixLib::CreateMatrix(UUT,3,3);	GLKMatrixLib::CreateMatrix(VVT,3,3);
	//---------------------------------------------------------------------------
	solid->GetOrigin(origin);		width=solid->GetGridWidth();	res=solid->GetResolution();
	sX=sXYZ[0];	sY=sXYZ[1];	sZ=sXYZ[2];	eX=eXYZ[0];	eY=eXYZ[1];	eZ=eXYZ[2];
	xmin=width*(double)sX;	ymin=width*(double)sY;	zmin=width*(double)sZ;
	xmax=width*(double)eX;	ymax=width*(double)eY;	zmax=width*(double)eZ;
	posQEF[0]=(xmin+xmax)*0.5+origin[0];
	posQEF[1]=(ymin+ymax)*0.5+origin[1];
	posQEF[2]=(zmin+zmax)*0.5+origin[2];
	if (bTruncate) scale=solid->GetGridWidth()*2.0;

	B[0]=B[1]=B[2]=X[0]=X[1]=X[2]=0.0;		int pntNum=0;
	for(nAxis=0;nAxis<3;nAxis++) {
		switch(nAxis) {
		case 0:{lower=xmin-eps;	upper=xmax+eps;	is=sY; ie=eY; js=sZ; je=eZ;}break;
		case 1:{lower=ymin-eps;	upper=ymax+eps;	is=sZ; ie=eZ; js=sX; je=eX;}break;
		case 2:{lower=zmin-eps;	upper=zmax+eps;	is=sX; ie=eX; js=sY; je=eY;}break;
		}
		for(ii=is;ii<=ie;ii++) {
			if ((ii>=res) || (ii<0)) continue;
			for(jj=js;jj<=je;jj++) {
				if ((jj>=res) || (jj<0)) continue;
				currentNode=solid->GetLDNISolidNode(nAxis,ii,jj);
				if (currentNode==NULL) continue;

				short i,nNum=currentNode->GetSampleNum();
				for(i=0;i<nNum;i++) {
					double depth=currentNode->GetDepth(i);
					if (depth>upper) break;
					if (depth<lower) continue;

					double pnt[3],normal[3];
					currentNode->GetNormal(i,normal[0],normal[1],normal[2]);
					switch(nAxis) {
					case 0:{pnt[0]=depth; pnt[1]=width*(double)ii; pnt[2]=width*(double)jj;}break;
					case 1:{pnt[0]=width*(double)jj; pnt[1]=depth; pnt[2]=width*(double)ii;}break;
					case 2:{pnt[0]=width*(double)ii; pnt[1]=width*(double)jj; pnt[2]=depth;}break;
					}
					pnt[0]+=origin[0];	pnt[1]+=origin[1];	pnt[2]+=origin[2];

					/////////////////////////////////////////////////////////////////////////////////
					double proj=(pnt[0]-posQEF[0])*normal[0]+(pnt[1]-posQEF[1])*normal[1]+(pnt[2]-posQEF[2])*normal[2];
					B[0]+=proj*normal[0];	B[1]+=proj*normal[1];	B[2]+=proj*normal[2];	

					A[0][0]+=normal[0]*normal[0]; A[0][1]+=normal[0]*normal[1]; A[0][2]+=normal[0]*normal[2];
					A[1][0]+=normal[1]*normal[0]; A[1][1]+=normal[1]*normal[1]; A[1][2]+=normal[1]*normal[2];
					A[2][0]+=normal[2]*normal[0]; A[2][1]+=normal[2]*normal[1]; A[2][2]+=normal[2]*normal[2];

					pntNum++;
				}
			}
		}
	}

	//---------------------------------------------------------------------------
	//	Singular Value Decomposition
	GLKMatrixLib::SingularValueDecomposition(A,3,3,UU,VVT);
	GLKMatrixLib::Transpose(UU,3,3,UUT);
	GLKMatrixLib::Transpose(VVT,3,3,VV);
	double maxFactor=(fabs(A[0][0])>fabs(A[1][1]))?(A[0][0]):(A[1][1]);
	maxFactor=(fabs(maxFactor)>fabs(A[2][2]))?(maxFactor):(A[2][2]);
	if (fabs(maxFactor)<1.0e-6) {
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				A[i][j]=0.0;
			}
		}
	}
	else {
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				if (i!=j) {
					A[i][j]=0.0;
				}
				else {
					if (fabs(A[i][j]/maxFactor)<criterion) 
//					if (fabs(A[i][j])<criterion) 
						A[i][j]=0.0; 
					else 
						A[i][j]=1.0/A[i][j];
				}
			}
		}
	}
	GLKMatrixLib::Mul(UUT,B,3,3,X);
	GLKMatrixLib::Mul(A,X,3,3,B);
	GLKMatrixLib::Mul(VV,B,3,3,X);
	//-----------------------------------------------------------------
	//	update node position
	if (bTruncate) {
		double dd=(X[0]*X[0]+X[1]*X[1]+X[2]*X[2]);
		if ((dd>scale) && (dd>1.0e-5)) {
			dd=sqrt(dd);	
			X[0]=X[0]/dd*scale;	X[1]=X[1]/dd*scale;	X[2]=X[2]/dd*scale;
		}
	}
	posQEF[0]+=X[0];	posQEF[1]+=X[1];	posQEF[2]+=X[2];

	//---------------------------------------------------------------------------
	//	Free the memory
	GLKMatrixLib::DeleteMatrix(A,3,3);		delete []B;	delete []X;
	GLKMatrixLib::DeleteMatrix(UU,3,3);		GLKMatrixLib::DeleteMatrix(VV,3,3);
	GLKMatrixLib::DeleteMatrix(UUT,3,3);	GLKMatrixLib::DeleteMatrix(VVT,3,3);
}

bool LDNISolidBSPTreeOperation::_IsGeometryCompatibleInCell(LDNISolid *solid, int sXYZ[], int eXYZ[], double posQEF[], double geoCriterion)
{
	LDNISolidNode *currentNode;
	int sX,sY,sZ,eX,eY,eZ,ii,jj,is,ie,js,je,res;	short nAxis;
	double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3],upper,lower;
	double eps=1.0e-5;

	solid->GetOrigin(origin);		width=solid->GetGridWidth();	res=solid->GetResolution();
	sX=sXYZ[0];	sY=sXYZ[1];	sZ=sXYZ[2];	eX=eXYZ[0];	eY=eXYZ[1];	eZ=eXYZ[2];
	xmin=width*(double)sX;	ymin=width*(double)sY;	zmin=width*(double)sZ;
	xmax=width*(double)eX;	ymax=width*(double)eY;	zmax=width*(double)eZ;

	for(nAxis=0;nAxis<3;nAxis++) {
		switch(nAxis) {
		case 0:{lower=xmin-eps;	upper=xmax+eps;	is=sY; ie=eY; js=sZ; je=eZ;}break;
		case 1:{lower=ymin-eps;	upper=ymax+eps;	is=sZ; ie=eZ; js=sX; je=eX;}break;
		case 2:{lower=zmin-eps;	upper=zmax+eps;	is=sX; ie=eX; js=sY; je=eY;}break;
		}
		for(ii=is;ii<=ie;ii++) {
			if ((ii>=res) || (ii<0)) continue;
			for(jj=js;jj<=je;jj++) {
				if ((jj>=res) || (jj<0)) continue;
				currentNode=solid->GetLDNISolidNode(nAxis,ii,jj);
				if (currentNode==NULL) continue;

				short i,nNum=currentNode->GetSampleNum();
				for(i=0;i<nNum;i++) {
					double depth=currentNode->GetDepth(i);
					if (depth>upper) break;
					if (depth<lower) continue;

					double pnt[3],normal[3];
					currentNode->GetNormal(i,normal[0],normal[1],normal[2]);
					switch(nAxis) {
					case 0:{pnt[0]=depth; pnt[1]=width*(double)ii; pnt[2]=width*(double)jj;}break;
					case 1:{pnt[0]=width*(double)jj; pnt[1]=depth; pnt[2]=width*(double)ii;}break;
					case 2:{pnt[0]=width*(double)ii; pnt[1]=width*(double)jj; pnt[2]=depth;}break;
					}
					pnt[0]+=origin[0];	pnt[1]+=origin[1];	pnt[2]+=origin[2];

					double dd=(posQEF[0]-pnt[0])*(normal[0])+(posQEF[1]-pnt[1])*(normal[1])+(posQEF[2]-pnt[2])*(normal[2]);
					if (fabs(dd)>geoCriterion) {return false;}
				}
			}
		}
	}

	return true;
}

bool LDNISolidBSPTreeOperation::_searchSamplesInCell(LDNISolid *solid, int sXYZ[], int eXYZ[], int &pntNum, double** &samplePnts)
{
	LDNISolidNode *currentNode;
	int sX,sY,sZ,eX,eY,eZ,ii,jj,is,ie,js,je,res;	short nAxis;
	double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3],upper,lower;
	double eps=1.0e-8;
	GLKArray *px,*py,*pz,*nx,*ny,*nz;

	solid->GetOrigin(origin);		width=solid->GetGridWidth();	res=solid->GetResolution();
	sX=sXYZ[0];	sY=sXYZ[1];	sZ=sXYZ[2];	eX=eXYZ[0];	eY=eXYZ[1];	eZ=eXYZ[2];
	xmin=width*(double)sX;	ymin=width*(double)sY;	zmin=width*(double)sZ;
	xmax=width*(double)eX;	ymax=width*(double)eY;	zmax=width*(double)eZ;

	if ((eX-sX)<1 || (eY-sY)<1 || (eZ-sZ)<1) printf ("Error(%d,%d,%d,%d,%d,%d) ",sX,sY,sZ,eX,eY,eZ);

	px=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	
	py=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	
	pz=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);
	nx=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	
	ny=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	
	nz=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);

	for(nAxis=0;nAxis<3;nAxis++) {
		switch(nAxis) {
		case 0:{lower=xmin-eps;	upper=xmax+eps;	is=sY; ie=eY; js=sZ; je=eZ;}break;
		case 1:{lower=ymin-eps;	upper=ymax+eps;	is=sZ; ie=eZ; js=sX; je=eX;}break;
		case 2:{lower=zmin-eps;	upper=zmax+eps;	is=sX; ie=eX; js=sY; je=eY;}break;
		}
		for(ii=is;ii<=ie;ii++) {
			if ((ii>=res) || (ii<0)) continue;
			for(jj=js;jj<=je;jj++) {
				if ((jj>=res) || (jj<0)) continue;
				currentNode=solid->GetLDNISolidNode(nAxis,ii,jj);
				if (currentNode==NULL) continue;

				short i,nNum=currentNode->GetSampleNum();
				for(i=0;i<nNum;i++) {
					double depth=currentNode->GetDepth(i);
					if (depth>upper) break;
					if (depth<lower) continue;

					double pnt[3],normal[3];
					currentNode->GetNormal(i,normal[0],normal[1],normal[2]);
					switch(nAxis) {
					case 0:{pnt[0]=depth; pnt[1]=width*(double)ii; pnt[2]=width*(double)jj;}break;
					case 1:{pnt[0]=width*(double)jj; pnt[1]=depth; pnt[2]=width*(double)ii;}break;
					case 2:{pnt[0]=width*(double)ii; pnt[1]=width*(double)jj; pnt[2]=depth;}break;
					}
					pnt[0]+=origin[0];	pnt[1]+=origin[1];	pnt[2]+=origin[2];

					px->Add(pnt[0]);	py->Add(pnt[1]);	pz->Add(pnt[2]);
					nx->Add(normal[0]);	ny->Add(normal[1]);	nz->Add(normal[2]);

#ifdef _DEBUG_BSP_DISPLAY
					currentNode->SetID(i,regionID);
#endif
				}
			}
		}
	}

	pntNum=px->GetSize();
	if (pntNum==0) {
		delete px;	delete py;	delete pz;	delete nx;	delete ny;	delete nz;
		return false;
	}

	samplePnts=(double**)new long[pntNum];
	for(int i=0;i<pntNum;i++) {
		samplePnts[i]=new double[6];
		samplePnts[i][0]=px->GetDoubleAt(i);
		samplePnts[i][1]=py->GetDoubleAt(i);
		samplePnts[i][2]=pz->GetDoubleAt(i);
		samplePnts[i][3]=nx->GetDoubleAt(i);
		samplePnts[i][4]=ny->GetDoubleAt(i);
		samplePnts[i][5]=nz->GetDoubleAt(i);
	}
	delete px;	delete py;	delete pz;	delete nx;	delete ny;	delete nz;

	return true;
}

void LDNISolidBSPTreeOperation::_nonorthogonalCellConstruction(LDNISolidBSPTreeNode *cell, int pntNum, double** samplePnts, 
															   int level, double tolerance)
{
	int i,upperNum,lowerNum;	double cp[3],np[3],dist,dot,dist2;
	GLKArray *px1,*px2,*py1,*py2,*pz1,*pz2,*nx1,*nx2,*ny1,*ny2,*nz1,*nz2;
	const double normalThreshold=0.95;
	double **upperSamples,**lowerSamples;

	//---------------------------------------------------------------------------------------------------------------------
	//	Step 1: find the splitting plane
	cp[0]=samplePnts[0][0];	cp[1]=samplePnts[0][1];	cp[2]=samplePnts[0][2];
	np[0]=samplePnts[0][3];	np[1]=samplePnts[0][4];	np[2]=samplePnts[0][5];
	cell->cp[0]=cp[0];	cell->cp[1]=cp[1];	cell->cp[2]=cp[2];
	cell->np[0]=np[0];	cell->np[1]=np[1];	cell->np[2]=np[2];

	//---------------------------------------------------------------------------------------------------------------------
	//	Step 2: splitting the samples into two groups
	px1=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	py1=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	pz1=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);
	nx1=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	ny1=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	nz1=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);
	px2=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	py2=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	pz2=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);
	nx2=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	ny2=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);	nz2=new GLKArray(DYNAMIC_ARRAY_SIZE,DYNAMIC_ARRAY_SIZE,3);
	//---------------------------------------------------------------------------------------------------------------------
	for(i=1;i<pntNum;i++) {
		dist=(samplePnts[i][0]-cp[0])*np[0]+(samplePnts[i][1]-cp[1])*np[1]+(samplePnts[i][2]-cp[2])*np[2];
		dist2=(cp[0]-samplePnts[i][0])*samplePnts[i][3]+(cp[1]-samplePnts[i][1])*samplePnts[i][4]+(cp[2]-samplePnts[i][2])*samplePnts[i][5];
		dot=samplePnts[i][3]*np[0]+samplePnts[i][4]*np[1]+samplePnts[i][5]*np[2];
		if (dist*dist2<0.0) continue;
		if (fabs(dist)<tolerance) continue;
/*		if (fabs(dist)<1.0e-5) {// && dot<normalThreshold) {
			if (dist2>0.0) {	// add the sample above the plane
				px1->Add(samplePnts[i][0]);	py1->Add(samplePnts[i][1]);	pz1->Add(samplePnts[i][2]);
				nx1->Add(samplePnts[i][3]);	ny1->Add(samplePnts[i][4]);	nz1->Add(samplePnts[i][5]);
			}
			else 
			{	// add the sample below the plane
				px2->Add(samplePnts[i][0]);	py2->Add(samplePnts[i][1]);	pz2->Add(samplePnts[i][2]);
				nx2->Add(samplePnts[i][3]);	ny2->Add(samplePnts[i][4]);	nz2->Add(samplePnts[i][5]);
			}
		}
		else */
		{
			if (dist>0.0) {// && dist2>0.0) {
				px1->Add(samplePnts[i][0]);	py1->Add(samplePnts[i][1]);	pz1->Add(samplePnts[i][2]);
				nx1->Add(samplePnts[i][3]);	ny1->Add(samplePnts[i][4]);	nz1->Add(samplePnts[i][5]);
			}
			else {// && dist2<0.0) {
				px2->Add(samplePnts[i][0]);	py2->Add(samplePnts[i][1]);	pz2->Add(samplePnts[i][2]);
				nx2->Add(samplePnts[i][3]);	ny2->Add(samplePnts[i][4]);	nz2->Add(samplePnts[i][5]);
			}
		}
	}
	upperNum=px1->GetSize();	lowerNum=px2->GetSize();
	if (upperNum>0) {
		upperSamples=(double **)new long[upperNum];
		for(i=0;i<upperNum;i++) {
			upperSamples[i]=new double[6];
			upperSamples[i][0]=px1->GetDoubleAt(i);	upperSamples[i][1]=py1->GetDoubleAt(i);	upperSamples[i][2]=pz1->GetDoubleAt(i);
			upperSamples[i][3]=nx1->GetDoubleAt(i);	upperSamples[i][4]=ny1->GetDoubleAt(i);	upperSamples[i][5]=nz1->GetDoubleAt(i);
		}
	}
	if (lowerNum>0) {
		lowerSamples=(double **)new long[lowerNum];
		for(i=0;i<lowerNum;i++) {
			lowerSamples[i]=new double[6];
			lowerSamples[i][0]=px2->GetDoubleAt(i);	lowerSamples[i][1]=py2->GetDoubleAt(i);	lowerSamples[i][2]=pz2->GetDoubleAt(i);
			lowerSamples[i][3]=nx2->GetDoubleAt(i);	lowerSamples[i][4]=ny2->GetDoubleAt(i);	lowerSamples[i][5]=nz2->GetDoubleAt(i);
		}
	}

	//---------------------------------------------------------------------------------------------------------------------
	//	Step 3: free the memory
	GLKMatrixLib::DeleteMatrix(samplePnts,pntNum,6);
	delete px1;	delete py1;	delete pz1;	delete nx1;	delete ny1;	delete nz1;
	delete px2;	delete py2;	delete pz2;	delete nx2;	delete ny2;	delete nz2;

	//---------------------------------------------------------------------------------------------------------------------
	//	Step 4: construct children of this cell
	LDNISolidBSPTreeNode *leftNode=new LDNISolidBSPTreeNode;
	LDNISolidBSPTreeNode *rightNode=new LDNISolidBSPTreeNode;
	cell->leftChild=leftNode;	cell->rightChild=rightNode;
//	leftNode->bSolid=true; return;
	if (lowerNum==0) leftNode->bSolid=true;
	if (upperNum==0) rightNode->bSolid=false;
	if (lowerNum>0) _nonorthogonalCellConstruction(leftNode,lowerNum,lowerSamples,level+1,tolerance);
	if (upperNum>0) _nonorthogonalCellConstruction(rightNode,upperNum,upperSamples,level+1,tolerance);
	if (level+1>maxLevel) maxLevel=level+1;
}

void LDNISolidBSPTreeOperation::_compIntersectionsOnRay(LDNISolidBSPTreeNode *treeNode, short nDir, short i, short j, 
									int res, double gwidth, double origin[], double sDepth, double eDepth, 
									double sNx, double sNy,	double sNz, double eNx, double eNy,	double eNz,
									int &sampleNum, double *depth, double *nx, double *ny, double *nz, double tolerance)
{
	bool bAbove;	double interDepth;

	//---------------------------------------------------------------------------------------------------------------
	// Step 1: stop the refinement when reaching a solid cell
	if (treeNode->bSolid) {
		if ((eDepth-sDepth)>1.0e-5) 
		{
			depth[sampleNum]=sDepth;	nx[sampleNum]=sNx;	ny[sampleNum]=sNy;	nz[sampleNum]=sNz;	sampleNum++;
			depth[sampleNum]=eDepth;	nx[sampleNum]=eNx;	ny[sampleNum]=eNy;	nz[sampleNum]=eNz;	sampleNum++;
		}
		return;
	}

	//---------------------------------------------------------------------------------------------------------------
	// Step 2: compute intersection point and splitting the segments into two parts
	bool bIntersect=_compSegmentPlaneIntersectionPnt((char)nDir,i,j,sDepth,eDepth,gwidth,origin,treeNode->cp,treeNode->np,interDepth,bAbove);
	if (bIntersect) {
		if (bAbove) {
			if (treeNode->rightChild!=NULL) {
				_compIntersectionsOnRay(treeNode->rightChild, nDir, i, j, res, gwidth, origin, sDepth, interDepth, 
					sNx, sNy, sNz, treeNode->np[0], treeNode->np[1], treeNode->np[2], sampleNum, depth, nx, ny, nz,tolerance);
			}
			if (treeNode->leftChild!=NULL) {
				_compIntersectionsOnRay(treeNode->leftChild, nDir, i, j, res, gwidth, origin, interDepth, eDepth, 
					treeNode->np[0], treeNode->np[1], treeNode->np[2], eNx, eNy, eNz, sampleNum, depth, nx, ny, nz,tolerance);
			}
		}
		else {
			if (treeNode->rightChild!=NULL) {
				_compIntersectionsOnRay(treeNode->rightChild, nDir, i, j, res, gwidth, origin, interDepth, eDepth, 
					treeNode->np[0], treeNode->np[1], treeNode->np[2], eNx, eNy, eNz, sampleNum, depth, nx, ny, nz,tolerance);
			}
			if (treeNode->leftChild!=NULL) {
				_compIntersectionsOnRay(treeNode->leftChild, nDir, i, j, res, gwidth, origin, sDepth, interDepth, 
					sNx, sNy, sNz, treeNode->np[0], treeNode->np[1], treeNode->np[2], sampleNum, depth, nx, ny, nz,tolerance);
			}
		}
	}
	else {
		if (bAbove && treeNode->rightChild!=NULL) {
			_compIntersectionsOnRay(treeNode->rightChild, nDir, i, j, res, gwidth, origin, sDepth, eDepth, 
									sNx, sNy, sNz, eNx, eNy, eNz, sampleNum, depth, nx, ny, nz,tolerance);
		}
		if ((!bAbove) && treeNode->leftChild!=NULL) {
			_compIntersectionsOnRay(treeNode->leftChild, nDir, i, j, res, gwidth, origin, sDepth, eDepth, 
									sNx, sNy, sNz, eNx, eNy, eNz, sampleNum, depth, nx, ny, nz,tolerance);
		}
	}
}

void LDNISolidBSPTreeOperation::encodeNormal(double nx, double ny, double nz, short &ix, short &iy, short &iz)
{
	ix=(short)((nx+1.0)*127.5);
	iy=(short)((ny+1.0)*127.5);
	iz=(short)((nz+1.0)*127.5);
}

bool LDNISolidBSPTreeOperation::_compSegmentPlaneIntersectionPnt(char nDir, short i, short j, double depth1, double depth2, double gwidth, 
									double origin[], double pc[], double np[], double &interDepth, bool &bDir)
{
	double pp1[3],pp2[3],pp[3],dx,dy,dz,dd1,dd2,dd,rr;

	switch(nDir) {
	case 0:{dx=depth1;	dy=gwidth*(double)i;	dz=gwidth*(double)j;   }break;
	case 1:{dy=depth1;	dz=gwidth*(double)i;	dx=gwidth*(double)j;   }break;
	case 2:{dz=depth1;	dx=gwidth*(double)i;	dy=gwidth*(double)j;   }break;
	}
	pp1[0]=dx+origin[0];	pp1[1]=dy+origin[1];	pp1[2]=dz+origin[2];
	switch(nDir) {
	case 0:{dx=depth2;	}break;
	case 1:{dy=depth2;	}break;
	case 2:{dz=depth2;	}break;
	}
	pp2[0]=dx+origin[0];	pp2[1]=dy+origin[1];	pp2[2]=dz+origin[2];

	pp[0]=(pp1[0]+pp2[0])*0.5;	pp[1]=(pp1[1]+pp2[1])*0.5;	pp[2]=(pp1[2]+pp2[2])*0.5;
	dd=(pp[0]-pc[0])*np[0]+(pp[1]-pc[1])*np[1]+(pp[2]-pc[2])*np[2];

	dd1=(pp1[0]-pc[0])*np[0]+(pp1[1]-pc[1])*np[1]+(pp1[2]-pc[2])*np[2];
	dd2=(pp2[0]-pc[0])*np[0]+(pp2[1]-pc[1])*np[1]+(pp2[2]-pc[2])*np[2];

	if (dd1>0.0) bDir=true; else bDir=false;

	if (dd1*dd2>=0.0) return false;

	rr=fabs(dd1)/(fabs(dd1)+fabs(dd2));
	interDepth=(1.0-rr)*depth1+rr*depth2;

	switch(nDir) {
	case 0:{dx=interDepth;	}break;
	case 1:{dy=interDepth;	}break;
	case 2:{dz=interDepth;	}break;
	}
	pp2[0]=dx+origin[0];	pp2[1]=dy+origin[1];	pp2[2]=dz+origin[2];
	pp[0]=(pp1[0]+pp2[0])*0.5;	pp[1]=(pp1[1]+pp2[1])*0.5;	pp[2]=(pp1[2]+pp2[2])*0.5;
	dd=(pp[0]-pc[0])*np[0]+(pp[1]-pc[1])*np[1]+(pp[2]-pc[2])*np[2];
	if (dd>0.0) bDir=true; else bDir=false;

	return true;
}

void LDNISolidBSPTreeOperation::_debugSolidEmptyCheck(LDNISolidBSPTreeNode *root)
{
//	if ((root->leftChild!=NULL) && (root->leftChild->IsEmpty())) printf("Error Empty Node is Found!\n");
//	if ((root->rightChild!=NULL) && (root->rightChild->bSolid)) printf("Error Solid Node is Found!\n");

	if (((root->leftChild!=NULL) && (root->bSolid)) || ((root->rightChild!=NULL) && (root->bSolid))) printf("Error Solid Node is Found!\n");
	if (((root->leftChild!=NULL) && (root->rightChild==NULL)) || ((root->leftChild==NULL) && (root->rightChild!=NULL)) ) printf("Error Node is Found!\n");

	if (root->leftChild!=NULL) _debugSolidEmptyCheck(root->leftChild);
	if (root->rightChild!=NULL) _debugSolidEmptyCheck(root->rightChild);
}
