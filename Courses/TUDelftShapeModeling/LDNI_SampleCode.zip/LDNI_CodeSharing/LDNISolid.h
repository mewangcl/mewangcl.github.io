#ifndef	_CCL_LDNI_SOLID
#define	_CCL_LDNI_SOLID

#define _CCL_LDNICONTOURING_RATE		128
#define _CCL_OCTREE_LEVEL_THRESHOLD		11		
#define _CCL_TOLERANCE_RES				0.1		// actually the scale in terms of the sample width in LDNI
#define _CCL_LDNISAMPLING_RATE			128
#define _CCL_DISCRETE_SUPPORT			3

#define NULL	0

#include <stdio.h>

class LDNISolidNode
{
public:
	LDNISolidNode() {sampleNum=0;};
	virtual ~LDNISolidNode() {ReleaseSampleArray();};

	void MallocSampleArray(short num);
	void ReleaseSampleArray();

	double GetDepth(short index);
	void GetNormal(short index, double &nx, double &ny, double &nz);
	void GetNormal(short index, short &nx, short &ny, short &nz);
	void SetDepth(short index, float value);
	void SetNormal(short index, short nx, short ny, short nz);
	short GetSampleNum() {return sampleNum;};
	int GetID(short index) {return id[index];};
	void SetID(short index, int sampleID) {id[index]=sampleID;};

	void SortSamplesByDepth();

	void WriteSample(FILE *fp);
	void ReadSample(FILE *fp);

private:
	short sampleNum;
	float* depth;
	unsigned char** nv;
	int* id;
};

class LDNISolid
{
public:
	LDNISolid(void);
	virtual ~LDNISolid(void);

public:
	void MallocMemoryOfSolidNodeArray(int res);
	void ReleaseMemoryOfSolidNodeArray();
	void EmptySolidNodeArray();
	void ExpansionByNewBoundingBox(double boundingBox[]);  // boundingBox[] will be updated in this function

	int GetResolution() {return m_res;};
	int GetMaterialTypeNum() {return m_materialTypeNum;};
	void SetMaterialTypeNum(int num) {m_materialTypeNum=num;};
	void SetOrigin(double pp[]) {m_origin[0]=pp[0];m_origin[1]=pp[1];m_origin[2]=pp[2];};
	void GetOrigin(double pp[]) {pp[0]=m_origin[0];pp[1]=m_origin[1];pp[2]=m_origin[2];};
	void SetGridWidth(double width) {m_width=width;};
	double GetGridWidth() {return m_width;};
	LDNISolidNode* GetLDNISolidNode(short nAxis, int iIndex, int jIndex);
	bool SetLDNISolidNode(short nAxis, int iIndex, int jIndex, LDNISolidNode *solidNode);

	bool DetectPointInOrOut(float px, float py, float pz);	// for all direction
	bool DetectNodeInOrOut(int i, int j, int k);			// by the majority voting

	int DetectNodeMaterialType(int i, int j, int k);

	long CompSampleNum();
	long CompMemoryRequired();

	void FileWrite(char *filename);
	void FileRead(char *filename);

	void ImageTmgFileWrite(char *filename);
	void ImageTmgFileRead(char *filename);

private:
	void RGBToDepthConversion(short rr, short gg, short bb, double &depth);
	void DepthToRGBConversion(double depth, short &rr, short &gg, short &bb);

	int m_res;
	LDNISolidNode ***m_xNodeArray,***m_yNodeArray,***m_zNodeArray;
	double m_origin[3],m_width;
	int m_materialTypeNum;
};

#endif
