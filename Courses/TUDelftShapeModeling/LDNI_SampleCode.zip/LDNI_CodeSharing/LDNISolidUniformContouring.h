#ifndef _CCL_LDNISOLID_UNIFORMCONTOURING
#define _CCL_LDNISOLID_UNIFORMCONTOURING

class LDNISolidNode;

struct LDNIRay{
	short i,j;
	LDNISolidNode *headNode;
};

struct LDNIUniformCell{
	short i,j,k;
};

class LDNISolidUniformContouring
{
public:
	LDNISolidUniformContouring(void);
	virtual ~LDNISolidUniformContouring(void);

	static void MeshGeneration(LDNISolid* solid, QMeshPatch* &mesh);

	//-----------------------------------------------------------------------------------------------------------
	//	Functions for step 1
	static void _compactionOfRays(LDNISolid* solid, int &xRayNum, LDNIRay* &xRayArray,
									int &yRayNum, LDNIRay* &yRayArray, int &zRayNum, LDNIRay* &zRayArray);

private:

	//-----------------------------------------------------------------------------------------------------------
	//	Functions for step 2
	static void _setInsideOutsideFlag(int &xRayNum, LDNIRay* &xRayArray, int &yRayNum, LDNIRay* &yRayArray, 
									int &zRayNum, LDNIRay* &zRayArray, int res, bool *bInside, double width);
	
	//-----------------------------------------------------------------------------------------------------------
	//	Functions for step 3
	static bool _compactionOfBoundaryCells(int res, bool *bInside, int* &iBndCellIndex, 
									int &bndCellNum, LDNIUniformCell* &bndCellArray);

	//-----------------------------------------------------------------------------------------------------------
	//	Functions for step 4
	static void _searchHermiteSamplesInCell(int si, int sj, int sk, LDNISolid* solid, 
									int &sampleNum, double sx[], double sy[], double sz[], 
									double nx[], double ny[], double nz[]);
	static void _compPositionByHermiteData(int ii, int jj, int kk, double origin[], double gwidth,
									int sampleNum, double sx[], double sy[], double sz[], 
									double nx[], double ny[], double nz[], double pp[], bool &bSharp);

	//-----------------------------------------------------------------------------------------------------------
	//	Functions for step 5
	static void _facesGeneration(int bndCellNum, LDNIUniformCell* bndCellArray, int *iBndCellIndex, 
									int res, double width, double origin[], bool *bInside, QMeshNode **nodeArray, QMeshPatch* mesh);
	static void _quadTriangulation(int ppIndex[], QMeshNode **nodeArray, double sPP[], double ePP[], 
									int f1Index[], int f2Index[], double criterion);
	static double _determination(double a[][3]);
	static void _createFaceByNodes(QMeshFace* &newFace, QMeshPatch *mesh, 
									QMeshNode *node1, QMeshNode *node2, QMeshNode *node3);
	static void _compEdgePnt(double width, double origin[], int sX, int sY, int sZ, short nDir, 
									double p1[], double p2[], double p3[], double p4[], double edgePnt[]);
};

#endif