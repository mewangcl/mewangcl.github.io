#ifndef _CCL_LDNISOLID_CONTOURING
#define _CCL_LDNISOLID_CONTOURING

class LDNISolidOctreeCell {
public:
	LDNISolidOctreeCell() {
		short i;
		for(i=0;i<8;i++) {m_childOctreeNode[i]=NULL;m_nodeInside[i]=false;} 
		for(i=0;i<4;i++) {vertexAtEdge[i]=NULL;}
		for(i=0;i<12;i++) {edgePntIndex[i]=0;}
		edgePntNum=1;
		sX=sY=sZ=eX=eY=eZ=0;	//bDebugStrange=false;
	};
	virtual ~LDNISolidOctreeCell() {
		for(short i=0;i<8;i++) {
			if (m_childOctreeNode[i]!=NULL) 
				delete (LDNISolidOctreeCell*)(m_childOctreeNode[i]);
		}
	};

	bool IsLeaf() {{if (m_childOctreeNode[0]==NULL) return true;} return false;};
	bool IsAbleToRefine() {{if (((eX-sX)==1) || ((eY-sY)==1) || ((eZ-sZ)==1)) return false;} return true;};

	bool m_nodeInside[8];
	LDNISolidOctreeCell *m_childOctreeNode[8];
	short sX,sY,sZ,eX,eY,eZ;
	QMeshNode *vertexAtEdge[4];		double pnts[4][3];
	char edgePntIndex[12];			char edgePntNum;		//bool bDebugStrange;
};

class LDNISolidContouring
{
public:
	LDNISolidContouring(void);
	virtual ~LDNISolidContouring(void);

	static void MeshGeneration(LDNISolid* solid, QMeshPatch* &mesh);

private:
	//-----------------------------------------------------------------------------------------------
	//	The functions for refinement and octree construction
	static void _cellRefinement(LDNISolid* solid, LDNISolidOctreeCell *cell, double geoCriterion, int level);
	static bool _isCellNeedRefine(LDNISolid *solid, LDNISolidOctreeCell *cell, double geoCriterion);
	static bool _isEmptyOrSolidCell(LDNISolidOctreeCell *cell);
	static bool _complexCellCheck_InvalidEmptyOrSolidCell(LDNISolid *solid, LDNISolidOctreeCell *cell);
	static bool _complexCellCheck_AmbiguousFaceOrCell(LDNISolidOctreeCell *cell);
	static bool _complexCellCheck_MultipleEdgeIntersections(LDNISolid *solid, LDNISolidOctreeCell *cell);
	static bool _complexCellCheck_InvalidEmptyOrSolidFace(LDNISolid *solid, LDNISolidOctreeCell *cell);
	static void _searchHermiteDataSet(LDNISolid *solid, LDNISolidOctreeCell *cell, GLKObList *hermiteDataSet);
	static void _deleteHermiteDataSet(GLKObList *dataSet);
	static void _compPositionByHermiteData(LDNISolid *solid, GLKObList *hermiteDataSet, double pp[], bool bUsingMassPoint=true, bool bTruncate=true);

	//-----------------------------------------------------------------------------------------------
	//	The functions for ambiguous octree leaf-node construction
	static void _ambiguousCellConstruction(LDNISolid *solid, LDNISolidOctreeCell *cell, bool bGapPreferred);
	static void _searchEdgeIntersections(LDNISolid *solid, LDNISolidOctreeCell *cell, GLKObList **hermiteDataEdges);

	//-----------------------------------------------------------------------------------------------
	//	The functions for contouring the octree
	static void _contourCellArray(LDNISolid *solid, LDNISolidOctreeCell ****cellArray, int arrayNum, QMeshPatch *mesh);
	static void _contourCellProc(LDNISolid *solid, LDNISolidOctreeCell *cell, QMeshPatch *mesh);
	static void _contourFaceProc(LDNISolid *solid, LDNISolidOctreeCell *pCell, LDNISolidOctreeCell *qCell, short nAxis, QMeshPatch *mesh);
	static void _contourEdgeProc(LDNISolid *solid, LDNISolidOctreeCell *pCell, LDNISolidOctreeCell *qCell, LDNISolidOctreeCell *rCell, 
									LDNISolidOctreeCell *sCell, short nAxis, bool sPntIn, bool ePntIn, QMeshPatch *mesh);
	static void _createMeshFaceByVertices(QMeshNode *nodeArray[], QMeshPatch *mesh);

	//-----------------------------------------------------------------------------------------------
	//	The functions for post-processing
	static void _nonmanifoldToManifoldCorrection(LDNISolid *solid, QMeshPatch *mesh);
	static void _quadMeshToTrglMesh(QMeshPatch *mesh);
	static void _fillMeshTopology(QMeshPatch *mesh);
	//-----------------------------------------------------------------------------------------------
	static bool _nonmanifoldNodeCheck(QMeshPatch *mesh, int &singularNodeNum, int* &singularNodeTable);
	static void _floodingFacesAroundNode(QMeshNode *node, QMeshFace *seedFace, int nColor);

	//-----------------------------------------------------------------------------------------------
	//	The functions for debugging purpose
	static void _debugManifoldCheck(QMeshPatch *mesh);	
	static void _debugContouringCell(LDNISolid* solid, LDNISolidOctreeCell *cell, QMeshPatch *mesh);
	static void _debugCountNodeNum(LDNISolidOctreeCell *cell, int &nodeNum);
};

class LDNIHermiteData : public GLKObject
{
public:
	LDNIHermiteData() {};
	virtual ~LDNIHermiteData() {};

	double pos[3],normal[3];
};

#endif