// LDNISolidContouring2.cpp: implementation of the LDNISolidContouring2 class.
//
//////////////////////////////////////////////////////////////////////

#include <math.h>
#include <time.h>
#include <omp.h>

#include "..\GLKLib\GLKObList.h"
#include "..\GLKLib\GLKHeap.h"
#include "..\GLKLib\GLKGeometry.h"
#include "..\GLKLib\GLKMatrixLib.h"

#include "..\QMeshLib\QMeshPatch.h"
#include "..\QMeshLib\QMeshNode.h"
#include "..\QMeshLib\QMeshEdge.h"
#include "..\QMeshLib\QMeshFace.h"

#include "LDNISolid.h"

#include "LDNISolidContouring2.h"

/*
#ifdef _DEBUG	// for detecting memory leak, using this - you need to use MFC DLL setting in compiling
#include <afx.h>         // MFC core and standard components
#define new DEBUG_NEW
#endif*/

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

LDNISolidContouring2::LDNISolidContouring2()
{
}

LDNISolidContouring2::~LDNISolidContouring2()
{
}

//////////////////////////////////////////////////////////////////////
// Implementation
//////////////////////////////////////////////////////////////////////

void LDNISolidContouring2::MeshGeneration(LDNISolid* solid, GLKObList *meshList)
{
	int materialTypeNum=solid->GetMaterialTypeNum();
	int res,cellNum,i,j,k,num;
	double tolerance;
	LDNISolidOctreeCell2 ****cellArray;
	LDNISolidOctreeCell2 **cellList;

	//-----------------------------------------------------------------------------
	//	Step 1: Preparation
	printf("There are %d material regions\n",materialTypeNum);
	meshList->RemoveAll();
	res=solid->GetResolution();
	tolerance=_CCL_TOLERANCE_RES_MULTIMATERIAL*solid->GetGridWidth();
	int contouringRate=res;
	contouringRate=(int)(pow(2.0,(int)(log((double)res)/log(2.0)+1.0)));
	contouringRate=(contouringRate<_CCL_LDNICONTOURING_RATE)?contouringRate:_CCL_LDNICONTOURING_RATE;
	cellNum=(res-1)/contouringRate;
	if (cellNum*contouringRate<(res-1)) cellNum++;

	//-----------------------------------------------------------------------------
	//	Step 2: Construct octree cells for the mesh generation
	long time=clock();
	cellArray=(LDNISolidOctreeCell2 ****)new long[cellNum];
	cellList=(LDNISolidOctreeCell2 **)new long[cellNum*cellNum*cellNum*8];
	for(i=0;i<cellNum;i++) {
		cellArray[i]=(LDNISolidOctreeCell2 ***)new long[cellNum];
		for(j=0;j<cellNum;j++) {
			cellArray[i][j]=(LDNISolidOctreeCell2 **)new long[cellNum];
			for(k=0;k<cellNum;k++) {
				cellArray[i][j][k]=new LDNISolidOctreeCell2;
				LDNISolidOctreeCell2 *root=cellArray[i][j][k];
				root->sX=i*contouringRate;
				root->eX=(i+1)*contouringRate;
				root->sY=j*contouringRate;
				root->eY=(j+1)*contouringRate;
				root->sZ=k*contouringRate;
				root->eZ=(k+1)*contouringRate;
				root->m_nodeMaterialType[0]=solid->DetectNodeMaterialType(root->sX,root->sY,root->sZ);
				root->m_nodeMaterialType[1]=solid->DetectNodeMaterialType(root->eX,root->sY,root->sZ);
				root->m_nodeMaterialType[2]=solid->DetectNodeMaterialType(root->sX,root->eY,root->sZ);
				root->m_nodeMaterialType[3]=solid->DetectNodeMaterialType(root->eX,root->eY,root->sZ);
				root->m_nodeMaterialType[4]=solid->DetectNodeMaterialType(root->sX,root->sY,root->eZ);
				root->m_nodeMaterialType[5]=solid->DetectNodeMaterialType(root->eX,root->sY,root->eZ);
				root->m_nodeMaterialType[6]=solid->DetectNodeMaterialType(root->sX,root->eY,root->eZ);
				root->m_nodeMaterialType[7]=solid->DetectNodeMaterialType(root->eX,root->eY,root->eZ);
				_cellRefinement(solid,root,tolerance,0);

				for(int id=0;id<8;id++)	cellList[(i*cellNum*cellNum+j*cellNum+k)*8+id]=root->m_childOctreeNode[id];
			}
		}
	}
	//-----------------------------------------------------------------------------
	//	Refine cells in the task-list
	printf("Number of Processors: %d\n",omp_get_num_procs());
	num=cellNum*cellNum*cellNum*8;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
#pragma omp parallel for schedule(dynamic) 
	for(int id=0;id<num;id++) {_cellRefinement(solid,cellList[id],tolerance,1);}
	printf("Octree Construction Time: %ld ms\n",clock()-time); time=clock();

	//-----------------------------------------------------------------------------
	//	Step 3: Mesh generation
	time=clock();
	QMeshPatch *mesh=new QMeshPatch;
#ifndef	_OCTREE_DISPLAY
	_contourCellArray(solid,cellArray,cellNum,mesh);
#else
	for(i=0;i<cellNum;i++) {for(j=0;j<cellNum;j++) {for(k=0;k<cellNum;k++) {_debugContouringCell(solid,cellArray[i][j][k],mesh);}}}meshList->AddTail(mesh);
#endif

	//-----------------------------------------------------------------------------
	//	Step 4: Post-processing
	//-----------------------------------------------------------------------------
	//	Separate the polygon soup into assembled mesh patches
#ifndef	_OCTREE_DISPLAY
//	_quadMeshToTrglMesh(mesh);
	_generatingAssemblyOfMeshes(mesh,meshList,materialTypeNum);
#endif
	printf("Mesh Generation Time: %ld ms\n",clock()-time);
	printf("%d mesh patches have been generated.\n",meshList->GetCount());

	//-----------------------------------------------------------------------------
	//	Step 5: Free the memory
	time=clock();
	for(i=0;i<cellNum;i++) {
		for(j=0;j<cellNum;j++) {
			for(k=0;k<cellNum;k++) {
				delete (LDNISolidOctreeCell2*)(cellArray[i][j][k]);
			}
			delete [](LDNISolidOctreeCell2 **)(cellArray[i][j]);
		}
		delete [](LDNISolidOctreeCell2 ***)(cellArray[i]);
	}
	delete [](LDNISolidOctreeCell2 ****)(cellArray);
	delete [](LDNISolidOctreeCell2 **)(cellList);
#ifndef	_OCTREE_DISPLAY
	delete mesh;
#endif
	printf("Memory Releasing Time: %ld ms\n",clock()-time);
}

void LDNISolidContouring2::SingleMaterialSolidIDProc(LDNISolid* solid)
{
	int nCase,res;

	res=solid->GetResolution();
	int newNum=res*res;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
//	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
	for(nCase=0;nCase<3;nCase++) {
#pragma omp parallel for schedule(dynamic) 
		for(int kk=0;kk<newNum;kk++) {
			int i=kk/res;	int j=kk%res;

			LDNISolidNode *currentNode=solid->GetLDNISolidNode(nCase,i,j);
			if (!currentNode) continue;

			int sampleNum=currentNode->GetSampleNum();
			for(int k=0;k<sampleNum;k++) {
				if (k%2==0)	currentNode->SetID(k,1); else currentNode->SetID(k,2);
			}
		}
	}
}

void LDNISolidContouring2::_cellRefinement(LDNISolid* solid, LDNISolidOctreeCell2 *cell, double geoCriterion, int level)
{
	double pp[3],gwidth=solid->GetGridWidth();

	if ((cell->sX>=(cell->eX-1)) || (cell->sY>=(cell->eY-1)) || (cell->sZ>=(cell->eZ-1)) 
		|| (level>_CCL_OCTREE_LEVEL_THRESHOLD) 
		|| (gwidth*(double)(cell->eX-cell->sX)<=geoCriterion)) {
		int pntNum;		double** samplePnts;
		_searchHermiteDataSet(solid,cell,pntNum,samplePnts);
		if (pntNum==0) return;
		pp[0]=cell->pnt[0];	pp[1]=cell->pnt[1];	pp[2]=cell->pnt[2];
		_compPositionByHermiteData(solid,pntNum,samplePnts,pp,(cell->eX-cell->sX)*(solid->GetGridWidth()));
		cell->pnt[0]=pp[0];	cell->pnt[1]=pp[1];	cell->pnt[2]=pp[2];
		GLKMatrixLib::DeleteMatrix(samplePnts,pntNum,6);
		return;
	}

	if (level>=2) 
		if (!(_isCellNeedRefine(solid, cell, geoCriterion))) return;

	//-----------------------------------------------------------------------------
	//	Need to refine the cell
	int i,j,k,iX[3],iY[3],iZ[3];	int bPntType[3][3][3];	double origin[3],width;
	solid->GetOrigin(origin);		width=solid->GetGridWidth();
	LDNISolidOctreeCell2 *child;
	iX[0]=cell->sX;	iX[2]=cell->eX;	iY[0]=cell->sY;	iY[2]=cell->eY;	iZ[0]=cell->sZ;	iZ[2]=cell->eZ;
	iX[1]=(iX[0]+iX[2])/2;			iY[1]=(iY[0]+iY[2])/2;			iZ[1]=(iZ[0]+iZ[2])/2;
	bPntType[0][0][0]=cell->m_nodeMaterialType[0];	bPntType[2][0][0]=cell->m_nodeMaterialType[1];
	bPntType[0][2][0]=cell->m_nodeMaterialType[2];	bPntType[2][2][0]=cell->m_nodeMaterialType[3];
	bPntType[0][0][2]=cell->m_nodeMaterialType[4];	bPntType[2][0][2]=cell->m_nodeMaterialType[5];
	bPntType[0][2][2]=cell->m_nodeMaterialType[6];	bPntType[2][2][2]=cell->m_nodeMaterialType[7];
	for(k=0;k<3;k++) {
		for(j=0;j<3;j++) {
			for(i=0;i<3;i++) {
				if (!(i==1 || j==1 || k==1)) continue;
				bPntType[i][j][k]=solid->DetectNodeMaterialType(iX[i],iY[j],iZ[k]);
				if (bPntType[i][j][k]!=0) {
					int yu;
					yu=bPntType[i][j][k];
				}
			}
		}
	}
	//-----------------------------------------------------------------------------
	for(i=0;i<8;i++) {cell->m_childOctreeNode[i]=new LDNISolidOctreeCell2;}
	for(k=0;k<2;k++) {
		for(j=0;j<2;j++) {
			for(i=0;i<2;i++) {
				child=cell->m_childOctreeNode[i+j*2+k*4];
				child->sX=iX[i];	child->sY=iY[j];	child->sZ=iZ[k];
				child->eX=iX[i+1];	child->eY=iY[j+1];	child->eZ=iZ[k+1];

				child->pnt[0]=origin[0]+width*0.5*(double)(iX[i]+iX[i+1]);
				child->pnt[1]=origin[1]+width*0.5*(double)(iY[j]+iY[j+1]);
				child->pnt[2]=origin[2]+width*0.5*(double)(iZ[k]+iZ[k+1]);

				child->m_nodeMaterialType[0]=bPntType[i][j][k];
				child->m_nodeMaterialType[1]=bPntType[i+1][j][k];
				child->m_nodeMaterialType[2]=bPntType[i][j+1][k];
				child->m_nodeMaterialType[3]=bPntType[i+1][j+1][k];
				child->m_nodeMaterialType[4]=bPntType[i][j][k+1];
				child->m_nodeMaterialType[5]=bPntType[i+1][j][k+1];
				child->m_nodeMaterialType[6]=bPntType[i][j+1][k+1];
				child->m_nodeMaterialType[7]=bPntType[i+1][j+1][k+1];
			}
		}
	}

	if (level==0) return;	// for building the task list of cell-refinement

	for(i=0;i<8;i++) _cellRefinement(solid,cell->m_childOctreeNode[i],geoCriterion,level+1);
}

void LDNISolidContouring2::_searchHermiteDataSet(LDNISolid *solid, LDNISolidOctreeCell2 *cell, int &pntNum, double** &samplePnts)
{
	LDNISolidNode *currentNode;
	int sX,sY,sZ,eX,eY,eZ,ii,jj,is,ie,js,je,res;	short nAxis;
	double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3],upper,lower;
	double eps=1.0e-5;
	GLKArray *px,*py,*pz,*nx,*ny,*nz;

	solid->GetOrigin(origin);		width=solid->GetGridWidth();	res=solid->GetResolution();
	sX=cell->sX;	sY=cell->sY;	sZ=cell->sZ;	eX=cell->eX;	eY=cell->eY;	eZ=cell->eZ;
	xmin=width*(double)sX;	ymin=width*(double)sY;	zmin=width*(double)sZ;
	xmax=width*(double)eX;	ymax=width*(double)eY;	zmax=width*(double)eZ;

	px=new GLKArray(200,200,3);	py=new GLKArray(200,200,3);	pz=new GLKArray(200,200,3);
	nx=new GLKArray(200,200,3);	ny=new GLKArray(200,200,3);	nz=new GLKArray(200,200,3);

	for(nAxis=0;nAxis<3;nAxis++) {
		switch(nAxis) {
		case 0:{lower=xmin-eps;	upper=xmax+eps;	is=sY; ie=eY; js=sZ; je=eZ;}break;
		case 1:{lower=ymin-eps;	upper=ymax+eps;	is=sZ; ie=eZ; js=sX; je=eX;}break;
		case 2:{lower=zmin-eps;	upper=zmax+eps;	is=sX; ie=eX; js=sY; je=eY;}break;
		}
		for(ii=is;ii<=ie;ii++) {
			if ((ii>=res) || (ii<0)) continue;
			for(jj=js;jj<=je;jj++) {
				if ((jj>=res) || (jj<0)) continue;
				currentNode=solid->GetLDNISolidNode(nAxis,ii,jj);
				if (currentNode==NULL) continue;

				short i,nNum=currentNode->GetSampleNum();
				for(i=0;i<nNum;i++) {
					double depth=currentNode->GetDepth(i);
					if (depth>upper) break;
					if (depth<lower) continue;

					double pnt[3],normal[3];
					currentNode->GetNormal(i,normal[0],normal[1],normal[2]);
					switch(nAxis) {
					case 0:{pnt[0]=depth; pnt[1]=width*(double)ii; pnt[2]=width*(double)jj;}break;
					case 1:{pnt[0]=width*(double)jj; pnt[1]=depth; pnt[2]=width*(double)ii;}break;
					case 2:{pnt[0]=width*(double)ii; pnt[1]=width*(double)jj; pnt[2]=depth;}break;
					}
					pnt[0]+=origin[0];	pnt[1]+=origin[1];	pnt[2]+=origin[2];

					px->Add(pnt[0]);	py->Add(pnt[1]);	pz->Add(pnt[2]);
					nx->Add(normal[0]);	ny->Add(normal[1]);	nz->Add(normal[2]);
				}
			}
		}
	}

	pntNum=px->GetSize();
	if (pntNum==0) {delete px;	delete py;	delete pz;	delete nx;	delete ny;	delete nz;	return;}

	samplePnts=(double**)new long[pntNum];
	for(int i=0;i<pntNum;i++) {
		samplePnts[i]=new double[6];
		samplePnts[i][0]=px->GetDoubleAt(i);
		samplePnts[i][1]=py->GetDoubleAt(i);
		samplePnts[i][2]=pz->GetDoubleAt(i);
		samplePnts[i][3]=nx->GetDoubleAt(i);
		samplePnts[i][4]=ny->GetDoubleAt(i);
		samplePnts[i][5]=nz->GetDoubleAt(i);
	}
	delete px;	delete py;	delete pz;	delete nx;	delete ny;	delete nz;
}

void LDNISolidContouring2::_compPositionByHermiteData(LDNISolid *solid, int pntNum, double** samplePnts, 
													  double pp[], double cellWidth, bool bUsingMassPoint)
{
	double normal[3],pos[3],proj,scale;
	double criterion=_CCL_SVD_THRESHOLD;	int i,j,k;
	double **A,**UU,**VV,**UUT,**VVT;		double *B,*X;
	double minP[3],maxP[3];

	if (pntNum==0) return;
	cellWidth=cellWidth*0.5;
	minP[0]=pp[0]-cellWidth;	minP[1]=pp[1]-cellWidth;	minP[2]=pp[2]-cellWidth;
	maxP[0]=pp[0]+cellWidth;	maxP[1]=pp[1]+cellWidth;	maxP[2]=pp[2]+cellWidth;

	//---------------------------------------------------------------------------
	//	Preparation
	GLKMatrixLib::CreateMatrix(A,3,3);		B=new double[3];	X=new double[3];
	GLKMatrixLib::CreateMatrix(UU,3,3);		GLKMatrixLib::CreateMatrix(VV,3,3);
	GLKMatrixLib::CreateMatrix(UUT,3,3);	GLKMatrixLib::CreateMatrix(VVT,3,3);
	//---------------------------------------------------------------------------
	if (bUsingMassPoint) {
		pp[0]=0.0;	pp[1]=0.0;	pp[2]=0.0;
		for(k=0;k<pntNum;k++) {
			pp[0]+=samplePnts[k][0];	pp[1]+=samplePnts[k][1];	pp[2]+=samplePnts[k][2];
		}
		pp[0]=pp[0]/(double)(pntNum);
		pp[1]=pp[1]/(double)(pntNum);
		pp[2]=pp[2]/(double)(pntNum);
	}
	//---------------------------------------------------------------------------
	B[0]=B[1]=B[2]=X[0]=X[1]=X[2]=0.0;
	for(k=0;k<pntNum;k++) {
		normal[0]=samplePnts[k][3];	normal[1]=samplePnts[k][4];	normal[2]=samplePnts[k][5];
		pos[0]=samplePnts[k][0];	pos[1]=samplePnts[k][1];	pos[2]=samplePnts[k][2];

		proj=(pos[0]-pp[0])*normal[0]+(pos[1]-pp[1])*normal[1]+(pos[2]-pp[2])*normal[2];
		B[0]+=proj*normal[0];	B[1]+=proj*normal[1];	B[2]+=proj*normal[2];	

		A[0][0]+=normal[0]*normal[0]; A[0][1]+=normal[0]*normal[1]; A[0][2]+=normal[0]*normal[2];
		A[1][0]+=normal[1]*normal[0]; A[1][1]+=normal[1]*normal[1]; A[1][2]+=normal[1]*normal[2];
		A[2][0]+=normal[2]*normal[0]; A[2][1]+=normal[2]*normal[1]; A[2][2]+=normal[2]*normal[2];
	}

	//---------------------------------------------------------------------------
	//	Singular Value Decomposition
	GLKMatrixLib::SingularValueDecomposition(A,3,3,UU,VVT);
	GLKMatrixLib::Transpose(UU,3,3,UUT);
	GLKMatrixLib::Transpose(VVT,3,3,VV);
	double maxFactor=(fabs(A[0][0])>fabs(A[1][1]))?(A[0][0]):(A[1][1]);
	maxFactor=(fabs(maxFactor)>fabs(A[2][2]))?(maxFactor):(A[2][2]);
	if (fabs(maxFactor)<1.0e-6) {
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				A[i][j]=0.0;
			}
		}
	}
	else {
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				if (i!=j) {
					A[i][j]=0.0;
				}
				else {
					if (fabs(A[i][j]/maxFactor)<criterion) 
//					if (fabs(A[i][j])<criterion) 
						A[i][j]=0.0; 
					else 
						A[i][j]=1.0/A[i][j];
				}
			}
		}
	}
	GLKMatrixLib::Mul(UUT,B,3,3,X);
	GLKMatrixLib::Mul(A,X,3,3,B);
	GLKMatrixLib::Mul(VV,B,3,3,X);
	//-----------------------------------------------------------------
	//	truncate the update vector and update node position
	scale=1.0;
	if (fabs(X[0])>1.0e-5 && (pp[0]+X[0]*scale)>maxP[0]) scale=(maxP[0]-pp[0])/X[0];
	if (fabs(X[1])>1.0e-5 && (pp[1]+X[1]*scale)>maxP[1]) scale=(maxP[1]-pp[1])/X[1];
	if (fabs(X[2])>1.0e-5 && (pp[2]+X[2]*scale)>maxP[2]) scale=(maxP[2]-pp[2])/X[2];
	if (fabs(X[0])>1.0e-5 && (pp[0]+X[0]*scale)<minP[0]) scale=(minP[0]-pp[0])/X[0];
	if (fabs(X[1])>1.0e-5 && (pp[1]+X[1]*scale)<minP[1]) scale=(minP[1]-pp[1])/X[1];
	if (fabs(X[2])>1.0e-5 && (pp[2]+X[2]*scale)<minP[2]) scale=(minP[2]-pp[2])/X[2];
//	scale=1.0;
	pp[0]=pp[0]+X[0]*scale;	pp[1]=pp[1]+X[1]*scale;	pp[2]=pp[2]+X[2]*scale;

	//---------------------------------------------------------------------------
	//	Free the memory
	GLKMatrixLib::DeleteMatrix(A,3,3);		delete []B;	delete []X;
	GLKMatrixLib::DeleteMatrix(UU,3,3);		GLKMatrixLib::DeleteMatrix(VV,3,3);
	GLKMatrixLib::DeleteMatrix(UUT,3,3);	GLKMatrixLib::DeleteMatrix(VVT,3,3);
}

bool LDNISolidContouring2::_isCellNeedRefine(LDNISolid *solid, LDNISolidOctreeCell2 *cell, double geoCriterion)
{
	double pp[3];	int pntNum=0;	double **samplePnts;

	/////////////////////////////////////////////////////////////////////////////////
	//	Step 1: check whether it is a complex cell
	//-------------------------------------------------------------------------------
	//	Check 1 (complex cell) - for the invalid empty or solid cell
	if (_isEmptyOrSolidCell(cell)) {
		if (_complexCellCheck_InvalidEmptyOrSolidCell(solid,cell)) 
			return true;
		else
			return false;
	}
	//-------------------------------------------------------------------------------
	//	Check 2 & 3 (complex cell) - for the ambiguous face and the ambiguous volume
	if (_complexCellCheck_AmbiguousFaceOrCell(cell)) return true;
	//-------------------------------------------------------------------------------
	//	Check 4 (complex cell) - for the multiple intersection on edges
	//		(note that the hermite data collection is also collected in this step)
	//
	if (_complexCellCheck_MultipleEdgeIntersections(solid,cell)) return true;

	/////////////////////////////////////////////////////////////////////////////////
	//	Step 2: compute the position of the vertex in this cell and evaluate the error
	_searchHermiteDataSet(solid,cell,pntNum,samplePnts);
	pp[0]=cell->pnt[0];	pp[1]=cell->pnt[1];	pp[2]=cell->pnt[2];
	if (pntNum!=0) {
		_compPositionByHermiteData(solid,pntNum,samplePnts,pp,(cell->eX-cell->sX)*(solid->GetGridWidth()));
		//-----------------------------------------------------------------------------------
		//	the following statements are to check the shape compatibility
		for(int k=0;k<pntNum;k++) {
			double dd=(pp[0]-samplePnts[k][0])*(samplePnts[k][3])
				+(pp[1]-samplePnts[k][1])*(samplePnts[k][4])
				+(pp[2]-samplePnts[k][2])*(samplePnts[k][5]);
			if (fabs(dd)>geoCriterion) {GLKMatrixLib::DeleteMatrix(samplePnts,pntNum,6); return true;}
		}
		cell->pnt[0]=pp[0];	cell->pnt[1]=pp[1];	cell->pnt[2]=pp[2];
	}
	else {
//		printf("Empty cell is found!\n");
		return false;
	}

	/////////////////////////////////////////////////////////////////////////////////
	//	Step 3: free the memeory
	if (pntNum!=0) GLKMatrixLib::DeleteMatrix(samplePnts,pntNum,6);

	return false;
}

bool LDNISolidContouring2::_complexCellCheck_InvalidEmptyOrSolidFace(LDNISolid *solid,
																	 LDNISolidOctreeCell2 *cell)
{
	int nFace,nAxis,i,j,iUpper,iLower,jUpper,jLower,res;
	bool bSolid,bConsistent;	int nType,materialTypeNum=solid->GetMaterialTypeNum();
	double faceDepth,width,depth1,depth2,maxDepth;
	LDNISolidNode *currentNode;
	short faceTable[][4]={ {0,4,6,2}, {1,3,7,5}, {0,1,5,4}, {2,6,7,3}, {0,2,3,1}, {4,5,7,6} };
	double eps=1.0e-5;

	res=solid->GetResolution(); width=solid->GetGridWidth(); maxDepth=width*(double)res;

	for(nFace=0;nFace<6;nFace++) {
		nType=cell->m_nodeMaterialType[faceTable[nFace][0]];
		bConsistent=true;
		for(i=1;i<4;i++) {
			if (nType!=cell->m_nodeMaterialType[faceTable[nFace][i]]) {bConsistent=false; break;}
		}
		if (!bConsistent) continue;
		if (nType!=0) bSolid=false; else bSolid=true;

		switch(nFace) {
		case 0:{faceDepth=width*(double)(cell->sX);
				iLower=cell->sY;	iUpper=cell->eY;	jLower=cell->sZ;	jUpper=cell->eZ;
				nAxis=0;
			   }break;
		case 1:{faceDepth=width*(double)(cell->eX);
				iLower=cell->sY;	iUpper=cell->eY;	jLower=cell->sZ;	jUpper=cell->eZ;
				nAxis=0;
			   }break;
		case 2:{faceDepth=width*(double)(cell->sY);
				iLower=cell->sZ;	iUpper=cell->eZ;	jLower=cell->sX;	jUpper=cell->eX;
				nAxis=1;
			   }break;
		case 3:{faceDepth=width*(double)(cell->eY);
				iLower=cell->sZ;	iUpper=cell->eZ;	jLower=cell->sX;	jUpper=cell->eX;
				nAxis=1;
			   }break;
		case 4:{faceDepth=width*(double)(cell->sZ);
				iLower=cell->sX;	iUpper=cell->eX;	jLower=cell->sY;	jUpper=cell->eY;
				nAxis=2;
			   }break;
		case 5:{faceDepth=width*(double)(cell->eZ);
				iLower=cell->sX;	iUpper=cell->eX;	jLower=cell->sY;	jUpper=cell->eY;
				nAxis=2;
			   }break;
		}

		if (bSolid) {
			for(i=iLower;i<=iUpper;i++) {
				if ((i>=res) || (i<0)) return false;
				for(j=jLower;j<=jUpper;j++) {
					if ((j>=res) || (j<0)) return false;
					currentNode=solid->GetLDNISolidNode(nAxis,i,j);
					if (currentNode==NULL) return false;

					short k,nNum;
					k=0;	nNum=currentNode->GetSampleNum();	depth1=0.0;
					for(;;k++) {
						if (k<nNum) depth2=currentNode->GetDepth(k); else depth2=maxDepth;
						if ((depth1<faceDepth) && (depth2>faceDepth)) {
							int lid=(currentNode->GetID(k))/(materialTypeNum+1);
							if (lid!=nType)	return true;
						}
						if (k>=nNum) break;
						depth1=depth2;
						if (depth1>faceDepth+eps) break;
					}
				}
			}
		}
		else {
			for(i=iLower;i<=iUpper;i++) {
				if ((i>=res) || (i<0)) continue;
				for(j=jLower;j<=jUpper;j++) {
					if ((j>=res) || (j<0)) continue;
					currentNode=solid->GetLDNISolidNode(nAxis,i,j);
					if (currentNode==NULL) continue;

					short k,nNum;
					nNum=currentNode->GetSampleNum();
					for(k=0;k<nNum;k++) {
						depth1=currentNode->GetDepth(k); depth2=currentNode->GetDepth(k+1);
						if (depth1>=faceDepth+eps) break;
						if (depth2<faceDepth-eps) continue;
						if ((depth1<=faceDepth) && (depth2>=faceDepth)) {
							int rid=(currentNode->GetID(k))%(materialTypeNum+1);
							if (rid!=0)	return true;
						}
					}
				}
			}
		}
	}

	return false;
}

bool LDNISolidContouring2::_isEmptyOrSolidCell(LDNISolidOctreeCell2 *cell)
{
	int i,bMaterialType;	bool bSame;

	bMaterialType=cell->m_nodeMaterialType[0];		bSame=true;
	for(i=1;i<8;i++) {if (cell->m_nodeMaterialType[i]!=bMaterialType) {bSame=false;break;} }

	return bSame;
}

bool LDNISolidContouring2::_complexCellCheck_MultipleEdgeIntersections(LDNISolid *solid,
																	   LDNISolidOctreeCell2 *cell)
{
	LDNISolidNode *currentNode;
	int sX,sY,sZ,eX,eY,eZ,nCase;
	double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3],upper,lower;

	solid->GetOrigin(origin);		width=solid->GetGridWidth();
	sX=cell->sX;	sY=cell->sY;	sZ=cell->sZ;	eX=cell->eX;	eY=cell->eY;	eZ=cell->eZ;
	xmin=width*(double)sX;	ymin=width*(double)sY;	zmin=width*(double)sZ;
	xmax=width*(double)eX;	ymax=width*(double)eY;	zmax=width*(double)eZ;

	for(nCase=0;nCase<12;nCase++) {
		switch(nCase) {
		case 0:{currentNode=solid->GetLDNISolidNode(0,sY,sZ);	lower=xmin;	upper=xmax;}break;
		case 1:{currentNode=solid->GetLDNISolidNode(0,eY,sZ);	lower=xmin;	upper=xmax;}break;
		case 2:{currentNode=solid->GetLDNISolidNode(0,sY,eZ);	lower=xmin;	upper=xmax;}break;
		case 3:{currentNode=solid->GetLDNISolidNode(0,eY,eZ);	lower=xmin;	upper=xmax;}break;

		case 4:{currentNode=solid->GetLDNISolidNode(1,sZ,sX);	lower=ymin;	upper=ymax;}break;
		case 5:{currentNode=solid->GetLDNISolidNode(1,eZ,sX);	lower=ymin;	upper=ymax;}break;
		case 6:{currentNode=solid->GetLDNISolidNode(1,sZ,eX);	lower=ymin;	upper=ymax;}break;
		case 7:{currentNode=solid->GetLDNISolidNode(1,eZ,eX);	lower=ymin;	upper=ymax;}break;

		case 8:{currentNode=solid->GetLDNISolidNode(2,sX,sY);	lower=zmin;	upper=zmax;}break;
		case 9:{currentNode=solid->GetLDNISolidNode(2,eX,sY);	lower=zmin;	upper=zmax;}break;
		case 10:{currentNode=solid->GetLDNISolidNode(2,sX,eY);	lower=zmin;	upper=zmax;}break;
		case 11:{currentNode=solid->GetLDNISolidNode(2,eX,eY);	lower=zmin;	upper=zmax;}break;
		}
		if (currentNode==NULL) continue;

		int intersectionPntNum=0;
		short k,nNum;
		nNum=currentNode->GetSampleNum();
		for(k=0;k<nNum;k++) {
			double depth=currentNode->GetDepth(k);
			if (depth>=upper) break;
			if (depth<lower) continue;
			intersectionPntNum++;
		}
		if (intersectionPntNum>1) return true;
	}

	return false;

}

bool LDNISolidContouring2::_complexCellCheck_AmbiguousFaceOrCell(LDNISolidOctreeCell2 *cell)
{
	int i,nCase;	int nType;
	short faceTable[][4]={ {0,4,6,2}, {1,3,7,5}, {0,1,5,4}, {2,6,7,3}, {0,2,3,1}, {4,5,7,6} };
	short cellDiagonalTable[][2]={ {0,7}, {2,5}, {1,6}, {3,4} };

	for(i=0;i<6;i++) {	// diagonal nodes are with the same type, but NOT the same as other nodes on the face
		if ((cell->m_nodeMaterialType[faceTable[i][0]]==cell->m_nodeMaterialType[faceTable[i][2]])
			&& (cell->m_nodeMaterialType[faceTable[i][0]]!=cell->m_nodeMaterialType[faceTable[i][1]])
			&& (cell->m_nodeMaterialType[faceTable[i][0]]!=cell->m_nodeMaterialType[faceTable[i][3]]))
			return true;
		if ((cell->m_nodeMaterialType[faceTable[i][1]]==cell->m_nodeMaterialType[faceTable[i][3]])
			&& (cell->m_nodeMaterialType[faceTable[i][1]]!=cell->m_nodeMaterialType[faceTable[i][0]])
			&& (cell->m_nodeMaterialType[faceTable[i][1]]!=cell->m_nodeMaterialType[faceTable[i][2]]))
			return true;
	}

	for(nCase=0;nCase<4;nCase++) {
		// volumetric diagonal nodes are with the same type, but NOT the same as other nodes on the face
		if (cell->m_nodeMaterialType[cellDiagonalTable[nCase][0]]
			!=cell->m_nodeMaterialType[cellDiagonalTable[nCase][1]]) continue;
		nType=cell->m_nodeMaterialType[cellDiagonalTable[nCase][0]];
		for(i=0;i<8;i++) {
			if (i==cellDiagonalTable[nCase][0]) continue;
			if (i==cellDiagonalTable[nCase][1]) continue;
			if (cell->m_nodeMaterialType[i]==nType) break;
		}
		if (i==8) return true;	// the ambiguous happens
	}

	return false;
}

bool LDNISolidContouring2::_complexCellCheck_InvalidEmptyOrSolidCell(LDNISolid *solid,
																	LDNISolidOctreeCell2 *cell)
{
	int i,j,iLower,iUpper,jLower,jUpper,nAxis,res;
	LDNISolidNode *currentNode;					double upper,lower,width;
	double eps=1.0e-5;

	width=solid->GetGridWidth();	res=solid->GetResolution();
	for(nAxis=0;nAxis<3;nAxis++) {
		switch(nAxis) {
		case 0:{lower=width*(double)(cell->sX)-eps;	upper=width*(double)(cell->eX)+eps;
				iLower=cell->sY;	iUpper=cell->eY;
				jLower=cell->sZ;	jUpper=cell->eZ;
			   }break;
		case 1:{lower=width*(double)(cell->sY)-eps;	upper=width*(double)(cell->eY)+eps;
				iLower=cell->sZ;	iUpper=cell->eZ;
				jLower=cell->sX;	jUpper=cell->eX;
			   }break;
		case 2:{lower=width*(double)(cell->sZ)-eps;	upper=width*(double)(cell->eZ)+eps;
				iLower=cell->sX;	iUpper=cell->eX;
				jLower=cell->sY;	jUpper=cell->eY;
			   }break;
		}
		upper+=eps;	lower-=eps;
		for(i=iLower;i<=iUpper;i++) {
			if ((i>=res) || (i<0)) continue;
			for(j=jLower;j<=jUpper;j++) {
				if ((j>=res) || (j<0)) continue;
				currentNode=solid->GetLDNISolidNode(nAxis,i,j);
				if (currentNode==NULL) continue;

				short nNum=currentNode->GetSampleNum();
				for(short k=0;k<nNum;k++) {
					double depth=currentNode->GetDepth(k);
					if (depth>upper) break;
					if (depth<lower) continue;
					return true;
				}
			}
		}
	}

	return false;
}
	
void LDNISolidContouring2::_contourCellArray(LDNISolid *solid, LDNISolidOctreeCell2 ****cellArray, 
											 int cellNum, QMeshPatch *mesh)
{
	int i,j,k;

	for(i=0;i<cellNum;i++) {
		for(j=0;j<cellNum;j++) {
			for(k=0;k<cellNum;k++) {
				_contourCellProc(solid,cellArray[i][j][k],mesh);
				if (i<cellNum-1) _contourFaceProc(solid,cellArray[i][j][k],cellArray[i+1][j][k],0,mesh);
				if (j<cellNum-1) _contourFaceProc(solid,cellArray[i][j][k],cellArray[i][j+1][k],1,mesh);
				if (k<cellNum-1) _contourFaceProc(solid,cellArray[i][j][k],cellArray[i][j][k+1],2,mesh);

				if ((i<cellNum-1) && (j<cellNum-1))
					_contourEdgeProc(solid,cellArray[i][j][k],cellArray[i+1][j][k],
							cellArray[i+1][j+1][k],cellArray[i][j+1][k],2,
							cellArray[i][j][k]->m_nodeMaterialType[7],cellArray[i][j][k]->m_nodeMaterialType[3],mesh);
				if ((i<cellNum-1) && (k<cellNum-1))
					_contourEdgeProc(solid,cellArray[i+1][j][k],cellArray[i][j][k],
							cellArray[i][j][k+1],cellArray[i+1][j][k+1],1,
							cellArray[i][j][k]->m_nodeMaterialType[5],cellArray[i][j][k]->m_nodeMaterialType[7],mesh);
				if ((j<cellNum-1) && (k<cellNum-1))
					_contourEdgeProc(solid,cellArray[i][j][k],cellArray[i][j+1][k],
							cellArray[i][j+1][k+1],cellArray[i][j][k+1],0,
							cellArray[i][j][k]->m_nodeMaterialType[6],cellArray[i][j][k]->m_nodeMaterialType[7],mesh);
			}
		}
	}
}

void LDNISolidContouring2::_contourCellProc(LDNISolid *solid, LDNISolidOctreeCell2 *cell, QMeshPatch *mesh)
{
	int i;

	if (cell->IsLeaf()) return;

	for(i=0;i<8;i++) _contourCellProc(solid,cell->m_childOctreeNode[i],mesh);

	_contourFaceProc(solid,cell->m_childOctreeNode[0],cell->m_childOctreeNode[1],0,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[2],cell->m_childOctreeNode[3],0,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[4],cell->m_childOctreeNode[5],0,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[6],cell->m_childOctreeNode[7],0,mesh);

	_contourFaceProc(solid,cell->m_childOctreeNode[0],cell->m_childOctreeNode[2],1,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[1],cell->m_childOctreeNode[3],1,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[4],cell->m_childOctreeNode[6],1,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[5],cell->m_childOctreeNode[7],1,mesh);

	_contourFaceProc(solid,cell->m_childOctreeNode[0],cell->m_childOctreeNode[4],2,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[1],cell->m_childOctreeNode[5],2,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[2],cell->m_childOctreeNode[6],2,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[3],cell->m_childOctreeNode[7],2,mesh);

	_contourEdgeProc(solid,cell->m_childOctreeNode[0],cell->m_childOctreeNode[2],
			cell->m_childOctreeNode[6],cell->m_childOctreeNode[4],0,
			cell->m_childOctreeNode[0]->m_nodeMaterialType[6],cell->m_childOctreeNode[0]->m_nodeMaterialType[7],
			mesh);
	_contourEdgeProc(solid,cell->m_childOctreeNode[1],cell->m_childOctreeNode[3],
			cell->m_childOctreeNode[7],cell->m_childOctreeNode[5],0,
			cell->m_childOctreeNode[1]->m_nodeMaterialType[6],cell->m_childOctreeNode[1]->m_nodeMaterialType[7],
			mesh);

	_contourEdgeProc(solid,cell->m_childOctreeNode[1],cell->m_childOctreeNode[0],
			cell->m_childOctreeNode[4],cell->m_childOctreeNode[5],1,
			cell->m_childOctreeNode[1]->m_nodeMaterialType[4],cell->m_childOctreeNode[1]->m_nodeMaterialType[6],
			mesh);
	_contourEdgeProc(solid,cell->m_childOctreeNode[3],cell->m_childOctreeNode[2],
			cell->m_childOctreeNode[6],cell->m_childOctreeNode[7],1,
			cell->m_childOctreeNode[3]->m_nodeMaterialType[4],cell->m_childOctreeNode[3]->m_nodeMaterialType[6],
			mesh);

	_contourEdgeProc(solid,cell->m_childOctreeNode[0],cell->m_childOctreeNode[1],
			cell->m_childOctreeNode[3],cell->m_childOctreeNode[2],2,
			cell->m_childOctreeNode[0]->m_nodeMaterialType[3],cell->m_childOctreeNode[0]->m_nodeMaterialType[7],
			mesh);
	_contourEdgeProc(solid,cell->m_childOctreeNode[4],cell->m_childOctreeNode[5],
			cell->m_childOctreeNode[7],cell->m_childOctreeNode[6],2,
			cell->m_childOctreeNode[4]->m_nodeMaterialType[3],cell->m_childOctreeNode[4]->m_nodeMaterialType[7],
			mesh);
}

void LDNISolidContouring2::_contourFaceProc(LDNISolid *solid, LDNISolidOctreeCell2 *pCell, LDNISolidOctreeCell2 *qCell, 
											short nAxis, QMeshPatch *mesh)
{
	if ((pCell->IsLeaf()) && (qCell->IsLeaf())) return;

	if (pCell->IsLeaf()) {
		switch(nAxis) {
		case 0:{
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[0],0,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[2],0,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[4],0,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[6],0,mesh);

			_contourEdgeProc(solid,qCell->m_childOctreeNode[2],pCell,
							pCell,qCell->m_childOctreeNode[6],1,
							qCell->m_childOctreeNode[6]->m_nodeMaterialType[0],
							qCell->m_childOctreeNode[6]->m_nodeMaterialType[2],
							mesh);
			_contourEdgeProc(solid,qCell->m_childOctreeNode[0],pCell,
							pCell,qCell->m_childOctreeNode[4],1,
							qCell->m_childOctreeNode[4]->m_nodeMaterialType[0],
							qCell->m_childOctreeNode[4]->m_nodeMaterialType[2],
							mesh);
			_contourEdgeProc(solid,pCell,qCell->m_childOctreeNode[0],
							qCell->m_childOctreeNode[2],pCell,2,
							qCell->m_childOctreeNode[0]->m_nodeMaterialType[2],
							qCell->m_childOctreeNode[0]->m_nodeMaterialType[6],
							mesh);
			_contourEdgeProc(solid,pCell,qCell->m_childOctreeNode[4],
							qCell->m_childOctreeNode[6],pCell,2,
							qCell->m_childOctreeNode[4]->m_nodeMaterialType[2],
							qCell->m_childOctreeNode[4]->m_nodeMaterialType[6],
							mesh);
			   }break;
		case 1:{
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[0],1,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[1],1,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[4],1,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[5],1,mesh);

			_contourEdgeProc(solid,pCell,qCell->m_childOctreeNode[0],
							qCell->m_childOctreeNode[4],pCell,0,
							qCell->m_childOctreeNode[0]->m_nodeMaterialType[4],
							qCell->m_childOctreeNode[0]->m_nodeMaterialType[5],
							mesh);
			_contourEdgeProc(solid,pCell,qCell->m_childOctreeNode[1],
							qCell->m_childOctreeNode[5],pCell,0,
							qCell->m_childOctreeNode[1]->m_nodeMaterialType[4],
							qCell->m_childOctreeNode[1]->m_nodeMaterialType[5],
							mesh);
			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[1],qCell->m_childOctreeNode[0],2,
							qCell->m_childOctreeNode[1]->m_nodeMaterialType[0],
							qCell->m_childOctreeNode[1]->m_nodeMaterialType[4],
							mesh);
			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[5],qCell->m_childOctreeNode[4],2,
							qCell->m_childOctreeNode[5]->m_nodeMaterialType[0],
							qCell->m_childOctreeNode[5]->m_nodeMaterialType[4],
							mesh);
			   }break;
		case 2:{
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[0],2,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[1],2,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[2],2,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[3],2,mesh);

			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[3],qCell->m_childOctreeNode[1],0,
							qCell->m_childOctreeNode[3]->m_nodeMaterialType[0],
							qCell->m_childOctreeNode[3]->m_nodeMaterialType[1],
							mesh);
			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[2],qCell->m_childOctreeNode[0],0,
							qCell->m_childOctreeNode[2]->m_nodeMaterialType[0],
							qCell->m_childOctreeNode[2]->m_nodeMaterialType[1],
							mesh);
			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[2],qCell->m_childOctreeNode[3],1,
							qCell->m_childOctreeNode[2]->m_nodeMaterialType[1],
							qCell->m_childOctreeNode[2]->m_nodeMaterialType[3],
							mesh);
			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[0],qCell->m_childOctreeNode[1],1,
							qCell->m_childOctreeNode[0]->m_nodeMaterialType[1],
							qCell->m_childOctreeNode[0]->m_nodeMaterialType[3],
							mesh);
			   }break;
		}
	}
	else if (qCell->IsLeaf()) {
		switch(nAxis) {
		case 0:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[1],qCell,0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[3],qCell,0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[5],qCell,0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell,0,mesh);

			_contourEdgeProc(solid,qCell,pCell->m_childOctreeNode[3],
							pCell->m_childOctreeNode[7],qCell,1,
							pCell->m_childOctreeNode[3]->m_nodeMaterialType[5],
							pCell->m_childOctreeNode[3]->m_nodeMaterialType[7],
							mesh);
			_contourEdgeProc(solid,qCell,pCell->m_childOctreeNode[1],
							pCell->m_childOctreeNode[5],qCell,1,
							pCell->m_childOctreeNode[1]->m_nodeMaterialType[5],
							pCell->m_childOctreeNode[1]->m_nodeMaterialType[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[1],qCell,
							qCell,pCell->m_childOctreeNode[3],2,
							pCell->m_childOctreeNode[3]->m_nodeMaterialType[1],
							pCell->m_childOctreeNode[3]->m_nodeMaterialType[5],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],qCell,
							qCell,pCell->m_childOctreeNode[7],2,
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[1],
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[5],
							mesh);
			   }break;
		case 1:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[2],qCell,1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[3],qCell,1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[6],qCell,1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell,1,mesh);

			_contourEdgeProc(solid,pCell->m_childOctreeNode[2],qCell,
							qCell,pCell->m_childOctreeNode[6],0,
							pCell->m_childOctreeNode[6]->m_nodeMaterialType[2],
							pCell->m_childOctreeNode[6]->m_nodeMaterialType[3],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[3],qCell,
							qCell,pCell->m_childOctreeNode[7],0,
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[2],
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[3],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[2],pCell->m_childOctreeNode[3],
							qCell,qCell,2,
							pCell->m_childOctreeNode[2]->m_nodeMaterialType[3],
							pCell->m_childOctreeNode[2]->m_nodeMaterialType[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[6],pCell->m_childOctreeNode[7],
							qCell,qCell,2,
							pCell->m_childOctreeNode[6]->m_nodeMaterialType[3],
							pCell->m_childOctreeNode[6]->m_nodeMaterialType[7],
							mesh);
			   }break;
		case 2:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[4],qCell,2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[5],qCell,2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[6],qCell,2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell,2,mesh);

			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],pCell->m_childOctreeNode[7],
							qCell,qCell,0,
							pCell->m_childOctreeNode[5]->m_nodeMaterialType[6],
							pCell->m_childOctreeNode[5]->m_nodeMaterialType[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[4],pCell->m_childOctreeNode[6],
							qCell,qCell,0,
							pCell->m_childOctreeNode[4]->m_nodeMaterialType[6],
							pCell->m_childOctreeNode[4]->m_nodeMaterialType[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[7],pCell->m_childOctreeNode[6],
							qCell,qCell,1,
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[4],
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[6],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],pCell->m_childOctreeNode[4],
							qCell,qCell,1,
							pCell->m_childOctreeNode[5]->m_nodeMaterialType[4],
							pCell->m_childOctreeNode[5]->m_nodeMaterialType[6],
							mesh);
			   }break;
		}
	}
	else {	// neither cells are leaf
		switch(nAxis) {
		case 0:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[1],qCell->m_childOctreeNode[0],0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[3],qCell->m_childOctreeNode[2],0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[5],qCell->m_childOctreeNode[4],0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell->m_childOctreeNode[6],0,mesh);

			_contourEdgeProc(solid,qCell->m_childOctreeNode[2],pCell->m_childOctreeNode[3],
							pCell->m_childOctreeNode[7],qCell->m_childOctreeNode[6],1,
							pCell->m_childOctreeNode[3]->m_nodeMaterialType[5],
							pCell->m_childOctreeNode[3]->m_nodeMaterialType[7],
							mesh);
			_contourEdgeProc(solid,qCell->m_childOctreeNode[0],pCell->m_childOctreeNode[1],
							pCell->m_childOctreeNode[5],qCell->m_childOctreeNode[4],1,
							pCell->m_childOctreeNode[1]->m_nodeMaterialType[5],
							pCell->m_childOctreeNode[1]->m_nodeMaterialType[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[1],qCell->m_childOctreeNode[0],
							qCell->m_childOctreeNode[2],pCell->m_childOctreeNode[3],2,
							pCell->m_childOctreeNode[3]->m_nodeMaterialType[1],
							pCell->m_childOctreeNode[3]->m_nodeMaterialType[5],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],qCell->m_childOctreeNode[4],
							qCell->m_childOctreeNode[6],pCell->m_childOctreeNode[7],2,
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[1],
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[5],
							mesh);
			   }break;
		case 1:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[2],qCell->m_childOctreeNode[0],1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[3],qCell->m_childOctreeNode[1],1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[6],qCell->m_childOctreeNode[4],1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell->m_childOctreeNode[5],1,mesh);

			_contourEdgeProc(solid,pCell->m_childOctreeNode[2],qCell->m_childOctreeNode[0],
							qCell->m_childOctreeNode[4],pCell->m_childOctreeNode[6],0,
							pCell->m_childOctreeNode[6]->m_nodeMaterialType[2],
							pCell->m_childOctreeNode[6]->m_nodeMaterialType[3],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[3],qCell->m_childOctreeNode[1],
							qCell->m_childOctreeNode[5],pCell->m_childOctreeNode[7],0,
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[2],
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[3],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[2],pCell->m_childOctreeNode[3],
							qCell->m_childOctreeNode[1],qCell->m_childOctreeNode[0],2,
							pCell->m_childOctreeNode[2]->m_nodeMaterialType[3],
							pCell->m_childOctreeNode[2]->m_nodeMaterialType[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[6],pCell->m_childOctreeNode[7],
							qCell->m_childOctreeNode[5],qCell->m_childOctreeNode[4],2,
							pCell->m_childOctreeNode[6]->m_nodeMaterialType[3],
							pCell->m_childOctreeNode[6]->m_nodeMaterialType[7],
							mesh);
			   }break;
		case 2:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[4],qCell->m_childOctreeNode[0],2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[5],qCell->m_childOctreeNode[1],2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[6],qCell->m_childOctreeNode[2],2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell->m_childOctreeNode[3],2,mesh);

			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],pCell->m_childOctreeNode[7],
							qCell->m_childOctreeNode[3],qCell->m_childOctreeNode[1],0,
							pCell->m_childOctreeNode[5]->m_nodeMaterialType[6],
							pCell->m_childOctreeNode[5]->m_nodeMaterialType[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[4],pCell->m_childOctreeNode[6],
							qCell->m_childOctreeNode[2],qCell->m_childOctreeNode[0],0,
							pCell->m_childOctreeNode[4]->m_nodeMaterialType[6],
							pCell->m_childOctreeNode[4]->m_nodeMaterialType[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[7],pCell->m_childOctreeNode[6],
							qCell->m_childOctreeNode[2],qCell->m_childOctreeNode[3],1,
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[4],
							pCell->m_childOctreeNode[7]->m_nodeMaterialType[6],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],pCell->m_childOctreeNode[4],
							qCell->m_childOctreeNode[0],qCell->m_childOctreeNode[1],1,
							pCell->m_childOctreeNode[5]->m_nodeMaterialType[4],
							pCell->m_childOctreeNode[5]->m_nodeMaterialType[6],
							mesh);
			   }break;
		}
	}
}

void LDNISolidContouring2::_contourEdgeProc(LDNISolid *solid, LDNISolidOctreeCell2 *pCell, LDNISolidOctreeCell2 *qCell, 
											LDNISolidOctreeCell2 *rCell, LDNISolidOctreeCell2 *sCell, 
											short nAxis, int sPntType, int ePntType, QMeshPatch *mesh)
{
	if ((pCell->IsLeaf()) && (qCell->IsLeaf()) && (rCell->IsLeaf()) && (sCell->IsLeaf())) {
		if (sPntType==ePntType) return;

		//-----------------------------------------------------------------------------------
		//	Construct faces
		int i,id,materialNum;		QMeshNode *nodeArray[4];	QMeshNode *vertexNode;
		LDNISolidOctreeCell2 *currentCell;

		materialNum=solid->GetMaterialTypeNum();
		for(i=0;i<4;i++) {
			switch(i) {
			case 0:currentCell=pCell;break;
			case 1:currentCell=qCell;break;
			case 2:currentCell=rCell;break;
			case 3:currentCell=sCell;break;
			}

			if (currentCell->vertex==NULL) {
				vertexNode=new QMeshNode;
				mesh->GetNodeList().AddTail(vertexNode);	vertexNode->SetMeshPatchPtr(mesh);
				vertexNode->SetIndexNo(mesh->GetNodeNumber());
				vertexNode->SetCoord3D(currentCell->pnt[0],currentCell->pnt[1],currentCell->pnt[2]);
				currentCell->vertex=vertexNode;
			}
			vertexNode=currentCell->vertex;

			if (sPntType>ePntType) {
				nodeArray[i]=vertexNode;
				id=ePntType*(materialNum+1)+sPntType;
			}
			else {
				nodeArray[3-i]=vertexNode;
				id=sPntType*(materialNum+1)+ePntType;
			}
		}
		_createMeshFaceByVertices(nodeArray,mesh,id);
	}
	else {
		//-----------------------------------------------------------------------------------
		//	Visit the two sub-edges on this edge
		int ssIn,eeIn;		LDNISolidOctreeCell2	*cells[4];		int i,k;
		LDNISolidOctreeCell2 *currentCell;
		short table[][2][4][3]={
			{{{6,6,7},{4,4,5},{0,0,1},{2,2,3}},{{7,6,7},{5,4,5},{1,0,1},{3,2,3}}},
			{{{4,4,6},{5,5,7},{1,1,3},{0,0,2}},{{6,4,6},{7,5,7},{3,1,3},{2,0,2}}},
			{{{3,3,7},{2,2,6},{0,0,4},{1,1,5}},{{7,3,7},{6,2,6},{4,0,4},{5,1,5}}}
		};
		for(k=0;k<2;k++) {
			for(i=0;i<4;i++) {
				switch(i) {
				case 0:currentCell=pCell;break;
				case 1:currentCell=qCell;break;
				case 2:currentCell=rCell;break;
				case 3:currentCell=sCell;break;
				}
				if (currentCell->IsLeaf()) cells[i]=currentCell;
				else {
					cells[i]=currentCell->m_childOctreeNode[table[nAxis][k][i][0]];
					ssIn=cells[i]->m_nodeMaterialType[table[nAxis][k][i][1]];
					eeIn=cells[i]->m_nodeMaterialType[table[nAxis][k][i][2]];
				}
			}
			_contourEdgeProc(solid,cells[0],cells[1],cells[2],cells[3],nAxis,ssIn,eeIn,mesh);
		}
	}
}

void LDNISolidContouring2::_quadMeshToTrglMesh(QMeshPatch *mesh)
{
	GLKPOSITION Pos;	GLKObList newFaceList;
	QMeshEdge *edges[4];	QMeshNode *nodes[4];	bool bEdgeDirs[4];
	int i;		double pos[4][3];	
	double d1,d2,dd;	short nCase;
	double nv1[3],nv2[3];	bool bRes;		//double hP[3],hV[3];
	GLKGeometry geo;

	newFaceList.RemoveAll();
	for(Pos=mesh->GetFaceList().GetHeadPosition();Pos!=NULL;) {
		QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		if (face->GetEdgeNum()==3) continue;

		//--------------------------------------------------------------------------------
		//	Step 1: data preparation
		for(i=0;i<4;i++) {
			edges[i]=face->GetEdgeRecordPtr(i);
			nodes[i]=face->GetNodeRecordPtr(i);
			bEdgeDirs[i]=face->IsNormalDirection(i);
			face->GetNodePos(i,pos[i][0],pos[i][1],pos[i][2]);
		}

		//--------------------------------------------------------------------------------
		//	Step 2: detect the optimal triangulation (case 0: linking 0-2; case 1: linking 1-3)
		//--------------------------------------------------------------------------------
		//	evaluate the objective function for normal variation
		double hPos[3],hNormal[3];
		face->GetHermiteData(hPos,hNormal);
		//--------------------------------------------------------------------------------
		bRes=geo.CalPlaneEquation(pos[0],pos[1],pos[2],nv1[0],nv1[1],nv1[2],dd);
		if (!bRes) {nv1[0]=0.0; nv1[1]=0.0; nv1[2]=0.0;}
		bRes=geo.CalPlaneEquation(pos[0],pos[2],pos[3],nv2[0],nv2[1],nv2[2],dd);
		if (!bRes) {nv2[0]=0.0; nv2[1]=0.0; nv2[2]=0.0;}
		d1=geo.VectorProject(nv1,nv2);
		//--------------------------------------------------------------------------------
		bRes=geo.CalPlaneEquation(pos[0],pos[1],pos[3],nv1[0],nv1[1],nv1[2],dd);
		if (!bRes) {nv1[0]=0.0; nv1[1]=0.0; nv1[2]=0.0;}
		bRes=geo.CalPlaneEquation(pos[1],pos[2],pos[3],nv2[0],nv2[1],nv2[2],dd);
		if (!bRes) {nv2[0]=0.0; nv2[1]=0.0; nv2[2]=0.0;}
		d2=geo.VectorProject(nv1,nv2);
		//--------------------------------------------------------------------------------
		double normal_threshold=0.000001;
		if ((d1<d2))// && (fabs(d2-d1)>normal_threshold)) 
			nCase=1; 
		else if ((d1>d2))// && (fabs(d1-d2)>normal_threshold))
			nCase=0;
		else {
			d1=geo.Distance_to_Point(pos[0],pos[2]);
			d2=geo.Distance_to_Point(pos[1],pos[3]);
			if (d1<d2) nCase=0; else nCase=1;
		}

		//--------------------------------------------------------------------------------
		//	Step 3: 
		switch(nCase) {
		case 0:{
			QMeshEdge *newEdge=new QMeshEdge;
			newEdge->SetMeshPatchPtr(mesh);
			mesh->GetEdgeList().AddTail(newEdge);
			newEdge->SetIndexNo(mesh->GetEdgeNumber());
			newEdge->SetStartPoint(nodes[0]);	nodes[0]->GetEdgeList().AddTail(newEdge);
			newEdge->SetEndPoint(nodes[2]);		nodes[2]->GetEdgeList().AddTail(newEdge);

			face->SetEdgeNum(3);	
			face->SetEdgeRecordPtr(2,newEdge);
			face->SetDirectionFlag(2,false);
			face->SetHermiteData(hPos,hNormal);

			QMeshFace *newFace=new QMeshFace;
			newFace->SetMeshPatchPtr(mesh);
			newFaceList.AddTail(newFace);
			newFace->SetIndexNo(newFaceList.GetCount()+mesh->GetFaceNumber());
			newFace->SetEdgeNum(3);
			newFace->SetEdgeRecordPtr(0,newEdge);
			newFace->SetDirectionFlag(0,true);
			newFace->SetEdgeRecordPtr(1,edges[2]);
			newFace->SetDirectionFlag(1,bEdgeDirs[2]);
			newFace->SetEdgeRecordPtr(2,edges[3]);
			newFace->SetDirectionFlag(2,bEdgeDirs[3]);
			newFace->SetHermiteData(hPos,hNormal);
			newFace->CalPlaneEquation();
			face->CalPlaneEquation();

			newFace->m_nIdentifiedPatchIndex=face->m_nIdentifiedPatchIndex;
			   }break;
		case 1:{
			QMeshEdge *newEdge=new QMeshEdge;
			newEdge->SetMeshPatchPtr(mesh);
			mesh->GetEdgeList().AddTail(newEdge);
			newEdge->SetIndexNo(mesh->GetEdgeNumber());
			newEdge->SetStartPoint(nodes[1]);	nodes[1]->GetEdgeList().AddTail(newEdge);
			newEdge->SetEndPoint(nodes[3]);		nodes[3]->GetEdgeList().AddTail(newEdge);

			face->SetEdgeNum(3);	
			face->SetEdgeRecordPtr(0,newEdge);
			face->SetDirectionFlag(0,false);
			face->SetHermiteData(hPos,hNormal);

			QMeshFace *newFace=new QMeshFace;
			newFace->SetMeshPatchPtr(mesh);
			newFaceList.AddTail(newFace);
			newFace->SetIndexNo(newFaceList.GetCount()+mesh->GetFaceNumber());
			newFace->SetEdgeNum(3);
			newFace->SetEdgeRecordPtr(0,newEdge);
			newFace->SetDirectionFlag(0,true);
			newFace->SetEdgeRecordPtr(1,edges[3]);
			newFace->SetDirectionFlag(1,bEdgeDirs[3]);
			newFace->SetEdgeRecordPtr(2,edges[0]);
			newFace->SetDirectionFlag(2,bEdgeDirs[0]);
			newFace->SetHermiteData(hPos,hNormal);
			newFace->CalPlaneEquation();
			face->CalPlaneEquation();

			newFace->m_nIdentifiedPatchIndex=face->m_nIdentifiedPatchIndex;
			   }break;
		}
	}

	mesh->GetFaceList().AddTail(&newFaceList);
}

void LDNISolidContouring2::_createMeshFaceByVertices(QMeshNode *nodeArray[], QMeshPatch *mesh, int id, bool bManifoldEnsured)
{
	QMeshNode *nodes[4];		int i,eNum;
	QMeshFace *newFace; 
	QMeshEdge *newEdge,*edge;	bool bDir;
	QMeshNode *sNode,*eNode;	GLKPOSITION Pos;
	GLKGeometry geo;

	//---------------------------------------------------------------------------------------
	//	There may have duplicated QMeshNode in the nodeArray, need to remove them!!!
	//		- the following lines is for this purpose
	eNum=0;
	for(i=0;i<4;i++) {
		if (nodeArray[i]==nodeArray[(i+1)%4]) continue;
		nodes[eNum]=nodeArray[i];	eNum++;
	}

	//---------------------------------------------------------------------------------------
	//	Construct the QMeshFace
	if (eNum==3) 
	{
		newFace=new QMeshFace;
		mesh->GetFaceList().AddTail(newFace);
		newFace->SetIndexNo(mesh->GetFaceNumber());
		newFace->SetMeshPatchPtr(mesh);		newFace->SetEdgeNum(eNum);
		if (bManifoldEnsured) {
			for(i=0;i<eNum;i++) {
				sNode=nodes[i];	eNode=nodes[(i+1)%eNum];
				newEdge=NULL;
				for(Pos=sNode->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
					edge=(QMeshEdge *)(sNode->GetEdgeList().GetNext(Pos));
					if ((edge->GetEndPoint()==eNode) && (edge->GetLeftFace()==NULL)) {
						newEdge=edge;	bDir=true;		break;
					}
					else if ((edge->GetStartPoint()==eNode) && (edge->GetRightFace()==NULL)) {
						newEdge=edge;	bDir=false;		break;
					}
				}
				if (!newEdge) {
					newEdge=new QMeshEdge;	bDir=true;
					newEdge->SetStartPoint(sNode);	newEdge->SetEndPoint(eNode);
					sNode->GetEdgeList().AddTail(newEdge);	eNode->GetEdgeList().AddTail(newEdge);
					newEdge->SetMeshPatchPtr(mesh);	
					mesh->GetEdgeList().AddTail(newEdge);	newEdge->SetIndexNo(mesh->GetEdgeNumber());
				}
				newFace->SetEdgeRecordPtr(i,newEdge);
				newFace->SetDirectionFlag(i,bDir);
				if (bDir) newEdge->SetLeftFace(newFace); else newEdge->SetRightFace(newFace);
			}
		}
		else {
			for(i=0;i<eNum;i++) {
				sNode=nodes[i];	eNode=nodes[(i+1)%eNum];
				newEdge=NULL;
				for(Pos=sNode->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
					edge=(QMeshEdge *)(sNode->GetEdgeList().GetNext(Pos));
					if (edge->GetEndPoint()==eNode) {
						newEdge=edge;	bDir=true;		break;
					}
					else if (edge->GetStartPoint()==eNode) {
						newEdge=edge;	bDir=false;		break;
					}
				}
				if (!newEdge) {
					newEdge=new QMeshEdge;	bDir=true;
					newEdge->SetStartPoint(sNode);	newEdge->SetEndPoint(eNode);
					sNode->GetEdgeList().AddTail(newEdge);	eNode->GetEdgeList().AddTail(newEdge);
					newEdge->SetMeshPatchPtr(mesh);	
					mesh->GetEdgeList().AddTail(newEdge);	newEdge->SetIndexNo(mesh->GetEdgeNumber());
				}
				newFace->SetEdgeRecordPtr(i,newEdge);
				newFace->SetDirectionFlag(i,bDir);
				if (bDir) newEdge->SetLeftFace(newFace); else newEdge->SetRightFace(newFace);
			}	  
		}
		newFace->CalPlaneEquation();

		//---------------------------------------------------------------------------------------
		//	Fill the topology information on vertices
		for(i=0;i<eNum;i++) nodes[i]->GetFaceList().AddTail(newFace);
		if (id!=-1) newFace->m_nIdentifiedPatchIndex=id;
	}
	else {	// eNum==4 two triangles are constructed
		double p1[3],p2[3],d1,d2;	int stIndex=0;
		nodes[0]->GetCoord3D(p1[0],p1[1],p1[2]);	nodes[2]->GetCoord3D(p2[0],p2[1],p2[2]);
		d1=geo.Distance_to_Point(p1,p2);
		nodes[1]->GetCoord3D(p1[0],p1[1],p1[2]);	nodes[3]->GetCoord3D(p2[0],p2[1],p2[2]);
		d2=geo.Distance_to_Point(p1,p2);
		if (d2<d1) stIndex=1;
		for(int k=stIndex;k<4;k+=2) {
			newFace=new QMeshFace;
			mesh->GetFaceList().AddTail(newFace);
			newFace->SetIndexNo(mesh->GetFaceNumber());
			newFace->SetMeshPatchPtr(mesh);		newFace->SetEdgeNum(3);
			if (bManifoldEnsured) {
				for(i=0;i<3;i++) {
					sNode=nodes[(i+k)%4];	eNode=nodes[((i+1)%3+k)%4];
					newEdge=NULL;
					for(Pos=sNode->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
						edge=(QMeshEdge *)(sNode->GetEdgeList().GetNext(Pos));
						if ((edge->GetEndPoint()==eNode) && (edge->GetLeftFace()==NULL)) {
							newEdge=edge;	bDir=true;		break;
						}
						else if ((edge->GetStartPoint()==eNode) && (edge->GetRightFace()==NULL)) {
							newEdge=edge;	bDir=false;		break;
						}
					}
					if (!newEdge) {
						newEdge=new QMeshEdge;	bDir=true;
						newEdge->SetStartPoint(sNode);	newEdge->SetEndPoint(eNode);
						sNode->GetEdgeList().AddTail(newEdge);	eNode->GetEdgeList().AddTail(newEdge);
						newEdge->SetMeshPatchPtr(mesh);	
						mesh->GetEdgeList().AddTail(newEdge);	newEdge->SetIndexNo(mesh->GetEdgeNumber());
					}
					newFace->SetEdgeRecordPtr(i,newEdge);
					newFace->SetDirectionFlag(i,bDir);
					if (bDir) newEdge->SetLeftFace(newFace); else newEdge->SetRightFace(newFace);
				}
			}
			else {
				for(i=0;i<3;i++) {
					sNode=nodes[(i+k)%4];	eNode=nodes[((i+1)%3+k)%4];
					newEdge=NULL;
					for(Pos=sNode->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
						edge=(QMeshEdge *)(sNode->GetEdgeList().GetNext(Pos));
						if (edge->GetEndPoint()==eNode) {
							newEdge=edge;	bDir=true;		break;
						}
						else if (edge->GetStartPoint()==eNode) {
							newEdge=edge;	bDir=false;		break;
						}
					}
					if (!newEdge) {
						newEdge=new QMeshEdge;	bDir=true;
						newEdge->SetStartPoint(sNode);	newEdge->SetEndPoint(eNode);
						sNode->GetEdgeList().AddTail(newEdge);	eNode->GetEdgeList().AddTail(newEdge);
						newEdge->SetMeshPatchPtr(mesh);	
						mesh->GetEdgeList().AddTail(newEdge);	newEdge->SetIndexNo(mesh->GetEdgeNumber());
					}
					newFace->SetEdgeRecordPtr(i,newEdge);
					newFace->SetDirectionFlag(i,bDir);
				}	  
			}
			newFace->CalPlaneEquation();

			//---------------------------------------------------------------------------------------
			//	Fill the topology information on vertices
			for(i=0;i<3;i++) nodes[(i+k)%3]->GetFaceList().AddTail(newFace);
			if (id!=-1) newFace->m_nIdentifiedPatchIndex=id;
		}
	}
}

void LDNISolidContouring2::_generatingAssemblyOfMeshes(QMeshPatch *soupMesh, GLKObList *meshList, int materialNum)
{
	QMeshPatch **meshArray;		int i,id,edgeNum;		QMeshNode *nodeArray[4];	double xx,yy,zz;
	GLKPOSITION Pos;	
	GLKPOSITION PosNode;

	//---------------------------------------------------------------------------------------------------------
	//	Step 1: preparation
	meshArray=(QMeshPatch**)new long[(materialNum+1)*(materialNum+1)];
	for(i=0;i<(materialNum+1)*(materialNum+1);i++) {
		meshArray[i]=new QMeshPatch;
		meshArray[i]->SetMaterial(false,i%(materialNum+1));
		meshArray[i]->SetMaterial(true,i/(materialNum+1));
	}
	for(Pos=soupMesh->GetNodeList().GetHeadPosition();Pos!=NULL;) {
		QMeshNode *node=(QMeshNode *)(soupMesh->GetNodeList().GetNext(Pos));
		node->GetNodeList().RemoveAll();
	}

	//---------------------------------------------------------------------------------------------------------
	//	Step 2: insert polygons into the corresponding mesh patch
	for(Pos=soupMesh->GetFaceList().GetHeadPosition();Pos!=NULL;) {
		QMeshFace *face=(QMeshFace *)(soupMesh->GetFaceList().GetNext(Pos));
		id=face->m_nIdentifiedPatchIndex;
		edgeNum=face->GetEdgeNum();

		//-----------------------------------------------------------------------------------------------------
		//	create related vertices
		for(i=0;i<edgeNum;i++) {
			QMeshNode *currentNode=NULL;
			QMeshNode *centerNode=face->GetNodeRecordPtr(i);
			centerNode->GetCoord3D(xx,yy,zz);
			for(PosNode=centerNode->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
				QMeshNode *node=(QMeshNode *)(centerNode->GetNodeList().GetNext(PosNode));
				if (node->GetIndexNo()==id) {currentNode=node;break;}
			}
			if (currentNode==NULL) {
				currentNode=new QMeshNode;	currentNode->SetIndexNo(id);
				meshArray[id]->GetNodeList().AddTail(currentNode);
				centerNode->GetNodeList().AddTail(currentNode);
				currentNode->SetCoord3D(xx,yy,zz);
			}
			nodeArray[i]=currentNode;
		}
		if (edgeNum==3) nodeArray[3]=nodeArray[2];
		_createMeshFaceByVertices(nodeArray,meshArray[id],true);
		QMeshFace *newFace=(QMeshFace *)(meshArray[id]->GetFaceList().GetTail());
		//newFace->m_nIdentifiedPatchIndex=id;
	}

	//---------------------------------------------------------------------------------------------------------
	//	Step 3: fill the topology information for those non-empty mesh surfaces
	for(i=0;i<(materialNum+1)*(materialNum+1);i++) {
		if (meshArray[i]->GetNodeList().IsEmpty()) {
			delete (meshArray[i]); meshArray[i]=NULL;	continue;
		}
		meshList->AddTail(meshArray[i]);	id=0;
		for(Pos=meshArray[i]->GetNodeList().GetHeadPosition();Pos!=NULL;id++) {
			QMeshNode *node=(QMeshNode *)(meshArray[i]->GetNodeList().GetNext(Pos));
			node->SetIndexNo(id);
			node->SetAttribFlag(0,false);
		}
		for(Pos=meshArray[i]->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
			QMeshEdge *edge=(QMeshEdge *)(meshArray[i]->GetEdgeList().GetNext(Pos));
			edge->SetAttribFlag(0,false);
			if ((edge->GetLeftFace()==NULL) || edge->GetRightFace()==NULL) {
				edge->SetAttribFlag(0,true);
				edge->GetStartPoint()->SetAttribFlag(0,true);
				edge->GetEndPoint()->SetAttribFlag(0,true);
			}
		}
	}

	//---------------------------------------------------------------------------------------------------------
	//	Step 4: free the memeory
	delete [](QMeshPatch**)meshArray;
}

void LDNISolidContouring2::_debugContouringCell(LDNISolid* solid, LDNISolidOctreeCell2 *cell, QMeshPatch *mesh)
{
	QMeshNode *nodeArray[4];	int i,j;
	QMeshNode *nodes[8];		double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3];
	short faceTable[][4]={ {0,4,6,2}, {1,3,7,5}, {0,1,5,4}, {2,6,7,3}, {0,2,3,1}, {4,5,7,6} };

	if (!(cell->IsLeaf())) {
		for(i=0;i<8;i++) _debugContouringCell(solid,cell->m_childOctreeNode[i],mesh);
		return;
	}

	if (_isEmptyOrSolidCell(cell)) return;

	solid->GetOrigin(origin);
	width=solid->GetGridWidth();
	xmin=origin[0]+width*(double)(cell->sX);
	xmax=origin[0]+width*(double)(cell->eX);
	ymin=origin[1]+width*(double)(cell->sY);
	ymax=origin[1]+width*(double)(cell->eY);
	zmin=origin[2]+width*(double)(cell->sZ);
	zmax=origin[2]+width*(double)(cell->eZ);

	for(i=0;i<8;i++) {
		nodes[i]=new QMeshNode;
		mesh->GetNodeList().AddTail(nodes[i]);	nodes[i]->SetMeshPatchPtr(mesh);
		nodes[i]->SetIndexNo(mesh->GetNodeNumber());
		switch(i) {
		case 0:nodes[i]->SetCoord3D(xmin,ymin,zmin);break;
		case 1:nodes[i]->SetCoord3D(xmax,ymin,zmin);break;
		case 2:nodes[i]->SetCoord3D(xmin,ymax,zmin);break;
		case 3:nodes[i]->SetCoord3D(xmax,ymax,zmin);break;
		case 4:nodes[i]->SetCoord3D(xmin,ymin,zmax);break;
		case 5:nodes[i]->SetCoord3D(xmax,ymin,zmax);break;
		case 6:nodes[i]->SetCoord3D(xmin,ymax,zmax);break;
		case 7:nodes[i]->SetCoord3D(xmax,ymax,zmax);break;
		}
	}
	for(i=0;i<6;i++) {
		for(j=0;j<4;j++) {nodeArray[j]=nodes[faceTable[i][j]];}
		_createMeshFaceByVertices(nodeArray,mesh);
		QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetTail());
		int eNum=face->GetEdgeNum();
		for(j=0;j<eNum;j++) face->GetEdgeRecordPtr(j)->SetAttribFlag(0,true);
		face->SetEdgeNum(0);
	}

}
