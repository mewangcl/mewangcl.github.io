#include <stdio.h>
#include <malloc.h>
#include <math.h>
#include <time.h>
#include <omp.h>

#include "..\GLKLib\GLKObList.h"
#include "..\GLKLib\GLKGeometry.h"
#include "..\GLKLib\GLKMatrixLib.h"

#include "..\QMeshLib\QMeshPatch.h"
#include "..\QMeshLib\QMeshNode.h"
#include "..\QMeshLib\QMeshEdge.h"
#include "..\QMeshLib\QMeshFace.h"

#include "LDNISolid.h"
#include "LDNISolidUniformContouring.h"

#define	_CCL_SVD_THRESHOLD				0.01
#define _CCL_SHARPFEATURE_THRESHOLD		0.15
#define _CCL_INTERSECTIONFREE			true

LDNISolidUniformContouring::LDNISolidUniformContouring(void)
{
}

LDNISolidUniformContouring::~LDNISolidUniformContouring(void)
{
}

void LDNISolidUniformContouring::MeshGeneration(LDNISolid* solid, QMeshPatch* &mesh)
{
	int res=solid->GetResolution();
	int delta=res*res;
	double origin[3],width;
	int xRayNum,yRayNum,zRayNum;
	LDNIRay *xRayArray,*yRayArray,*zRayArray;	
	GLKObList freeNodeList;
	long time=clock();

	//-----------------------------------------------------------------------------------------------------------
	//	Step 1: Preparation
	mesh=NULL;
	width=solid->GetGridWidth();	solid->GetOrigin(origin);
	xRayNum=yRayNum=zRayNum=0;
	_compactionOfRays(solid,xRayNum,xRayArray,yRayNum,yRayArray,zRayNum,zRayArray);
	printf("Step 1: Completed - %ld (ms)\n",clock()-time);	time=clock();

	//-----------------------------------------------------------------------------------------------------------
	//	Step 2: Search the boundary cells
	bool *bInside;		// index = z*res*res + y*res + x;
	bInside=(bool *)(malloc(sizeof(bool)*res*res*res));
	_setInsideOutsideFlag(xRayNum,xRayArray,yRayNum,yRayArray,zRayNum,zRayArray,res,bInside,width);
	//{//	for debug purpose
	//	for(int ii=0;ii<res;ii++) {
	//		for(int jj=0;jj<res;jj++) {
	//			for(int kk=0;kk<res;kk++) {
	//				if (solid->DetectNodeInOrOut(ii,jj,kk))	bInside[kk*res*res + jj*res + ii]=true; else bInside[kk*res*res + jj*res + ii]=false;
	//			}}}
	//}
	printf("Step 2: Completed - %ld (ms)\n",clock()-time);	time=clock();

	//-----------------------------------------------------------------------------------------------------------
	//	Step 3: Compaction of boundary cells
	int *iBndCellIndex;
	int bndCellNum;		LDNIUniformCell* bndCellArray;
	bool bBndCellCompaction=_compactionOfBoundaryCells(res, bInside, iBndCellIndex, bndCellNum, bndCellArray);
	if (!bBndCellCompaction) printf("Error: the resolution is too high to process!\n");
	if (bndCellNum==0) printf("No boundary cell is found!\n");
	printf("Num of boundary cells: %d\n",bndCellNum);
	printf("Step 3: Completed - %ld (ms)\n",clock()-time);	time=clock();

	//-----------------------------------------------------------------------------------------------------------
	//	Step 4: Generating vertices in the boundary cells
	QMeshNode **nodeArray;	freeNodeList.RemoveAll();
	if (bBndCellCompaction && (bndCellNum>0)) {
		mesh=new QMeshPatch;
		nodeArray=(QMeshNode **)malloc(sizeof(QMeshNode*)*bndCellNum);
#pragma omp parallel for 
		for(int i=0;i<bndCellNum;i++) {
			QMeshNode *newNode=new QMeshNode;
			double pp[3],sx[12],sy[12],sz[12],nx[12],ny[12],nz[12];	int sampleNum;
			bool bSharp;

			_searchHermiteSamplesInCell(bndCellArray[i].i,bndCellArray[i].j,bndCellArray[i].k,solid,sampleNum,sx,sy,sz,nx,ny,nz);
			if (sampleNum>0) {
				_compPositionByHermiteData(bndCellArray[i].i,bndCellArray[i].j,bndCellArray[i].k,origin,width,sampleNum,sx,sy,sz,nx,ny,nz,pp,bSharp);
				if (bSharp) newNode->SetAttribFlag(1);
			}
			else {
				printf("Warning: boundary cell with no sample is found -- cell(%d,%d,%d)!\n",
					(int)(bndCellArray[i].i),(int)(bndCellArray[i].j),(int)(bndCellArray[i].k));
				pp[0]=origin[0]+((double)(bndCellArray[i].i)+0.5)*width;
				pp[1]=origin[1]+((double)(bndCellArray[i].j)+0.5)*width;
				pp[2]=origin[2]+((double)(bndCellArray[i].k)+0.5)*width;
				newNode->SetAttribFlag(7);
				freeNodeList.AddTail(newNode);

				//int xx=bndCellArray[i].i,yy=bndCellArray[i].j,zz=bndCellArray[i].k;	bool bTemp;
				//bTemp=bInside[zz*res*res+yy*res+xx]; 			if (bTemp) printf("1 "); else printf("0 ");		bTemp=bInside[zz*res*res+yy*res+(xx+1)]; 		if (bTemp) printf("1 "); else printf("0 ");
				//bTemp=bInside[zz*res*res+(yy+1)*res+xx]; 		if (bTemp) printf("1 "); else printf("0 ");		bTemp=bInside[zz*res*res+(yy+1)*res+(xx+1)];	if (bTemp) printf("1 "); else printf("0 ");
				//bTemp=bInside[(zz+1)*res*res+yy*res+xx]; 		if (bTemp) printf("1 "); else printf("0 ");		bTemp=bInside[(zz+1)*res*res+yy*res+(xx+1)];	if (bTemp) printf("1 "); else printf("0 ");
				//bTemp=bInside[(zz+1)*res*res+(yy+1)*res+xx];	if (bTemp) printf("1 "); else printf("0 ");		bTemp=bInside[(zz+1)*res*res+(yy+1)*res+(xx+1)]; if (bTemp) printf("1 "); else printf("0 ");
				//printf("\n");
			}
			newNode->SetCoord3D(pp[0],pp[1],pp[2]);		nodeArray[i]=newNode;
		}
		//------------------------------------------------------------------------------------------------------
		//	Store the constructed vertices into the vertex list of QMeshPatch
		for(int i=0;i<bndCellNum;i++) {
			mesh->GetNodeList().AddTail(nodeArray[i]);	
			nodeArray[i]->SetIndexNo(mesh->GetNodeNumber());
		}
	}
	printf("Step 4: Completed - %ld (ms)\n",clock()-time);	time=clock();

	//-----------------------------------------------------------------------------------------------------------
	//	Step 5: Generating the triangles
	if (bBndCellCompaction && (bndCellNum>0)) {
		_facesGeneration(bndCellNum,bndCellArray,iBndCellIndex,res,width,origin,bInside,nodeArray,mesh);
	}
	GLKPOSITION Pos;
	for(Pos=mesh->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
		QMeshEdge *edge=(QMeshEdge*)(mesh->GetEdgeList().GetNext(Pos));
		if ((edge->GetLeftFace()) && (edge->GetRightFace())) continue;
		edge->SetAttribFlag(0);
		edge->GetStartPoint()->SetAttribFlag(0);
		edge->GetEndPoint()->SetAttribFlag(0);
	}
	for(int iter=0;iter<10;iter++) {
		for(Pos=freeNodeList.GetHeadPosition();Pos!=NULL;) {
			QMeshNode *node=(QMeshNode *)(freeNodeList.GetNext(Pos));
			GLKPOSITION PosEdge;	double pp[3],xx,yy,zz,div;
			pp[0]=pp[1]=pp[2]=0.0;
			for(PosEdge=node->GetEdgeList().GetHeadPosition();PosEdge!=NULL;) {
				QMeshEdge *edge=(QMeshEdge *)(node->GetEdgeList().GetNext(PosEdge));
				if (edge->GetStartPoint()==node)
					edge->GetEndPoint()->GetCoord3D(xx,yy,zz);
				else
					edge->GetStartPoint()->GetCoord3D(xx,yy,zz);
				pp[0]+=xx;	pp[1]+=yy;	pp[2]+=zz;
			}
			div=1.0/(double)(node->GetEdgeNumber());
			node->SetCoord3D(pp[0]*div,pp[1]*div,pp[2]*div);
		}
	}
	for(Pos=freeNodeList.GetHeadPosition();Pos!=NULL;) {
		QMeshNode *node=(QMeshNode *)(freeNodeList.GetNext(Pos));
		GLKPOSITION PosFace;
		for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
	}
	printf("Step 5: Completed - %ld (ms)\n",clock()-time);	time=clock();

	//-----------------------------------------------------------------------------------------------------------
	//	Step 6: Free the memory
	if (xRayNum>0) free(xRayArray);	
	if (yRayNum>0) free(yRayArray);	
	if (zRayNum>0) free(zRayArray);
	free(bInside);		
	if (bBndCellCompaction) {
		free(iBndCellIndex);
		if (bndCellNum>0) {free(bndCellArray);	free(nodeArray);}
	}
	printf("Step 6: Completed - %ld (ms)\n",clock()-time);	time=clock();
}

void LDNISolidUniformContouring::_facesGeneration(int bndCellNum, LDNIUniformCell* bndCellArray, int *iBndCellIndex, 
												  int res, double width, double origin[], 
												  bool *bInside, QMeshNode **nodeArray, QMeshPatch* mesh)
{
	int *faceNodeIndex;		double criterion=width*0.1;

	faceNodeIndex=(int*)malloc(sizeof(int)*bndCellNum*3*3*2);
#pragma omp parallel for 
	for(int kk=0;kk<bndCellNum;kk++) {
		for(int j=0;j<18;j++) faceNodeIndex[kk*18+j]=-1;
	}

	//------------------------------------------------------------------------------------------------------------
	//	Fill in the faceNodeIndex array
#pragma omp parallel for 
	for(int kk=0;kk<bndCellNum;kk++) {
		int sX,sY,sZ,startIndex,endIndex,ppIndex[4],f1Index[3],f2Index[3];		double sPP[3],ePP[3];
		sX=bndCellArray[kk].i;	sY=bndCellArray[kk].j;	sZ=bndCellArray[kk].k;

		//--------------------------------------------------------------------------------------------------------
		//	face intersects x-axis
		startIndex=sZ*res*res+sY*res+sX;	endIndex=sZ*res*res+sY*res+(sX+1);
		if (bInside[startIndex]!=bInside[endIndex]) {

			if (bInside[startIndex]) {
				ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
				ppIndex[1]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
				ppIndex[2]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
				ppIndex[3]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX];
				sPP[0]=origin[0]+width*(double)sX;	sPP[1]=origin[1]+width*(double)sY;	sPP[2]=origin[2]+width*(double)sZ;
				ePP[0]=origin[0]+width*((double)sX+1.0);	ePP[1]=origin[1]+width*(double)sY;	ePP[2]=origin[2]+width*(double)sZ;
			}
			else {
				ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
				ppIndex[1]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX];
				ppIndex[2]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
				ppIndex[3]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
				sPP[0]=origin[0]+width*((double)sX+1.0);	sPP[1]=origin[1]+width*(double)sY;	sPP[2]=origin[2]+width*(double)sZ;
				ePP[0]=origin[0]+width*(double)sX;	ePP[1]=origin[1]+width*(double)sY;	ePP[2]=origin[2]+width*(double)sZ;
			}
			_quadTriangulation(ppIndex,nodeArray,sPP,ePP,f1Index,f2Index,criterion);
			if (f1Index[0]>=0) {
				faceNodeIndex[kk*18+0]=f1Index[0];	faceNodeIndex[kk*18+1]=f1Index[1];	faceNodeIndex[kk*18+2]=f1Index[2];
				faceNodeIndex[kk*18+3]=f2Index[0];	faceNodeIndex[kk*18+4]=f2Index[1];	faceNodeIndex[kk*18+5]=f2Index[2];
			}
			else {
				faceNodeIndex[kk*18+0]=-11;	
				if (bInside[startIndex]) faceNodeIndex[kk*18+1]=1; else faceNodeIndex[kk*18+1]=-1;
				faceNodeIndex[kk*18+2]=sX;	faceNodeIndex[kk*18+3]=sY;	faceNodeIndex[kk*18+4]=sZ;
			}

			//if (sY==66 && sZ==60) {
			//	nodeArray[ppIndex[0]]->SetAttribFlag(0);	nodeArray[ppIndex[1]]->SetAttribFlag(0);
			//	nodeArray[ppIndex[2]]->SetAttribFlag(0);	nodeArray[ppIndex[3]]->SetAttribFlag(0);
			//}
		}

		//--------------------------------------------------------------------------------------------------------
		//	face intersects y-axis
		startIndex=sZ*res*res+sY*res+sX;	endIndex=sZ*res*res+(sY+1)*res+sX;
		if (bInside[startIndex]!=bInside[endIndex]) {
			if (bInside[startIndex]) {
				ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
				ppIndex[1]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX];
				ppIndex[2]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX-1];
				ppIndex[3]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX-1];
				sPP[0]=origin[0]+width*(double)sX;	sPP[1]=origin[1]+width*(double)sY;	sPP[2]=origin[2]+width*(double)sZ;
				ePP[0]=origin[0]+width*(double)sX;	ePP[1]=origin[1]+width*((double)sY+1.0);	ePP[2]=origin[2]+width*(double)sZ;
			}
			else {
				ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
				ppIndex[3]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX];
				ppIndex[2]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX-1];
				ppIndex[1]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX-1];
				ePP[0]=origin[0]+width*(double)sX;	ePP[1]=origin[1]+width*(double)sY;	ePP[2]=origin[2]+width*(double)sZ;
				sPP[0]=origin[0]+width*(double)sX;	sPP[1]=origin[1]+width*((double)sY+1.0);	sPP[2]=origin[2]+width*(double)sZ;
			}
			_quadTriangulation(ppIndex,nodeArray,sPP,ePP,f1Index,f2Index,criterion);
			if (f1Index[0]>=0) {
				faceNodeIndex[kk*18+6]=f1Index[0];	faceNodeIndex[kk*18+7]=f1Index[1];	faceNodeIndex[kk*18+8]=f1Index[2];
				faceNodeIndex[kk*18+9]=f2Index[0];	faceNodeIndex[kk*18+10]=f2Index[1];	faceNodeIndex[kk*18+11]=f2Index[2];
			}
			else {
				faceNodeIndex[kk*18+6]=-12;	
				if (bInside[startIndex]) faceNodeIndex[kk*18+7]=1; else faceNodeIndex[kk*18+7]=-1;
				faceNodeIndex[kk*18+8]=sX;	faceNodeIndex[kk*18+9]=sY;	faceNodeIndex[kk*18+10]=sZ;
			}
		}

		//--------------------------------------------------------------------------------------------------------
		//	face intersects z-axis
		startIndex=sZ*res*res+sY*res+sX;	endIndex=(sZ+1)*res*res+sY*res+sX;
		if (bInside[startIndex]!=bInside[endIndex]) {
			if (bInside[startIndex]) {
				ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
				ppIndex[1]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX-1];
				ppIndex[2]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX-1];
				ppIndex[3]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
				sPP[0]=origin[0]+width*(double)sX;	sPP[1]=origin[1]+width*(double)sY;	sPP[2]=origin[2]+width*(double)sZ;
				ePP[0]=origin[0]+width*(double)sX;	ePP[1]=origin[1]+width*(double)sY;	ePP[2]=origin[2]+width*((double)sZ+1.0);
			}
			else {
				ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
				ppIndex[3]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX-1];
				ppIndex[2]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX-1];
				ppIndex[1]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
				ePP[0]=origin[0]+width*(double)sX;	ePP[1]=origin[1]+width*(double)sY;	ePP[2]=origin[2]+width*(double)sZ;
				sPP[0]=origin[0]+width*(double)sX;	sPP[1]=origin[1]+width*(double)sY;	sPP[2]=origin[2]+width*((double)sZ+1.0);
			}
			_quadTriangulation(ppIndex,nodeArray,sPP,ePP,f1Index,f2Index,criterion);
			if (f1Index[0]>=0) {
				faceNodeIndex[kk*18+12]=f1Index[0];	faceNodeIndex[kk*18+13]=f1Index[1];	faceNodeIndex[kk*18+14]=f1Index[2];
				faceNodeIndex[kk*18+15]=f2Index[0];	faceNodeIndex[kk*18+16]=f2Index[1];	faceNodeIndex[kk*18+17]=f2Index[2];
			}
			else {
				faceNodeIndex[kk*18+12]=-13;	
				if (bInside[startIndex]) faceNodeIndex[kk*18+13]=1; else faceNodeIndex[kk*18+13]=-1;
				faceNodeIndex[kk*18+14]=sX;	faceNodeIndex[kk*18+15]=sY;	faceNodeIndex[kk*18+16]=sZ;
			}
		}
	}

	//------------------------------------------------------------------------------------------------------------
	//	Construct faces in the memory
	for(int kk=0;kk<bndCellNum;kk++) {
		QMeshFace *face;
		for(int j=0;j<6;j+=2) {
			if (faceNodeIndex[kk*18+j*3]==-1) continue;
			if (faceNodeIndex[kk*18+j*3]>=0) {
				_createFaceByNodes(face,mesh,nodeArray[faceNodeIndex[kk*18+j*3]],
					nodeArray[faceNodeIndex[kk*18+j*3+1]],nodeArray[faceNodeIndex[kk*18+j*3+2]]);
				_createFaceByNodes(face,mesh,nodeArray[faceNodeIndex[kk*18+(j+1)*3]],
					nodeArray[faceNodeIndex[kk*18+(j+1)*3+1]],nodeArray[faceNodeIndex[kk*18+(j+1)*3+2]]);
			}
			else {
				int sX,sY,sZ,ppIndex[4];	double p1[3],p2[3],p3[3],p4[3],edgePnt[3];

				sX=faceNodeIndex[kk*18+j*3+2];
				sY=faceNodeIndex[kk*18+j*3+3];
				sZ=faceNodeIndex[kk*18+j*3+4];

				switch(faceNodeIndex[kk*18+j*3]) {
				case (-11):{
					if (faceNodeIndex[kk*18+j*3+1]>0) {
						ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
						ppIndex[1]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
						ppIndex[2]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
						ppIndex[3]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX];
					}
					else {
						ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
						ppIndex[1]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX];
						ppIndex[2]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
						ppIndex[3]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
					}
					nodeArray[ppIndex[0]]->GetCoord3D(p1[0],p1[1],p1[2]);
					nodeArray[ppIndex[1]]->GetCoord3D(p2[0],p2[1],p2[2]);
					nodeArray[ppIndex[2]]->GetCoord3D(p3[0],p3[1],p3[2]);
					nodeArray[ppIndex[3]]->GetCoord3D(p4[0],p4[1],p4[2]);
					_compEdgePnt(width,origin,sX,sY,sZ,0,p1,p2,p3,p4,edgePnt);
						   }break;
				case (-12):{
					if (faceNodeIndex[kk*18+j*3+1]>0) {
						ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
						ppIndex[1]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX];
						ppIndex[2]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX-1];
						ppIndex[3]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX-1];
					}
					else {
						ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
						ppIndex[3]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX];
						ppIndex[2]=iBndCellIndex[(sZ-1)*(res-1)*(res-1)+sY*(res-1)+sX-1];
						ppIndex[1]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX-1];
					}
					nodeArray[ppIndex[0]]->GetCoord3D(p1[0],p1[1],p1[2]);
					nodeArray[ppIndex[1]]->GetCoord3D(p2[0],p2[1],p2[2]);
					nodeArray[ppIndex[2]]->GetCoord3D(p3[0],p3[1],p3[2]);
					nodeArray[ppIndex[3]]->GetCoord3D(p4[0],p4[1],p4[2]);
					_compEdgePnt(width,origin,sX,sY,sZ,1,p1,p2,p3,p4,edgePnt);
						   }break;
				case (-13):{
					if (faceNodeIndex[kk*18+j*3+1]>0) {
						ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
						ppIndex[1]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX-1];
						ppIndex[2]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX-1];
						ppIndex[3]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
					}
					else {
						ppIndex[0]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX];
						ppIndex[3]=iBndCellIndex[sZ*(res-1)*(res-1)+sY*(res-1)+sX-1];
						ppIndex[2]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX-1];
						ppIndex[1]=iBndCellIndex[sZ*(res-1)*(res-1)+(sY-1)*(res-1)+sX];
					}
					nodeArray[ppIndex[0]]->GetCoord3D(p1[0],p1[1],p1[2]);
					nodeArray[ppIndex[1]]->GetCoord3D(p2[0],p2[1],p2[2]);
					nodeArray[ppIndex[2]]->GetCoord3D(p3[0],p3[1],p3[2]);
					nodeArray[ppIndex[3]]->GetCoord3D(p4[0],p4[1],p4[2]);
					_compEdgePnt(width,origin,sX,sY,sZ,2,p1,p2,p3,p4,edgePnt);
						   }break;
				}

				QMeshNode *newNode=new QMeshNode;
				newNode->SetCoord3D(edgePnt[0],edgePnt[1],edgePnt[2]);
				mesh->GetNodeList().AddTail(newNode);
				_createFaceByNodes(face,mesh,nodeArray[ppIndex[0]],nodeArray[ppIndex[1]],newNode);	//face->SetAttribFlag(4);
				_createFaceByNodes(face,mesh,nodeArray[ppIndex[1]],nodeArray[ppIndex[2]],newNode);	//face->SetAttribFlag(4);
				_createFaceByNodes(face,mesh,nodeArray[ppIndex[2]],nodeArray[ppIndex[3]],newNode);	//face->SetAttribFlag(4);
				_createFaceByNodes(face,mesh,nodeArray[ppIndex[3]],nodeArray[ppIndex[0]],newNode);	//face->SetAttribFlag(4);
			}
		}
	}
	free(faceNodeIndex);
}

void LDNISolidUniformContouring::_compEdgePnt(double width, double origin[], int sX, int sY, int sZ, short nDir, 
											  double p1[], double p2[], double p3[], double p4[], double edgePnt[])
{
	double cp[3],sp[3],vt[3],proj;

	sp[0]=origin[0]+width*(double)sX;	sp[1]=origin[1]+width*(double)sY;	sp[2]=origin[2]+width*(double)sZ;
	vt[0]=vt[1]=vt[2]=0.0;	vt[nDir]=1.0;

	cp[0]=(p1[0]+p2[0]+p3[0]+p4[0])*0.25-sp[0];
	cp[1]=(p1[1]+p2[1]+p3[1]+p4[1])*0.25-sp[1];
	cp[2]=(p1[2]+p2[2]+p3[2]+p4[2])*0.25-sp[2];
	proj=cp[0]*vt[0]+cp[1]*vt[1]+cp[2]*vt[2];
	if (proj>width) proj=width;	
	if (proj<0.0) proj=0.0;

	edgePnt[0]=sp[0]+vt[0]*proj;
	edgePnt[1]=sp[1]+vt[1]*proj;
	edgePnt[2]=sp[2]+vt[2]*proj;
}

void LDNISolidUniformContouring::_quadTriangulation(int ppIndex[], QMeshNode **nodeArray, 
													double sPP[], double ePP[], int f1Index[], int f2Index[], double criterion)
{
	int k;	double pp[3],p1[3],p2[3],aa[3][3],det1,det2;

	//------------------------------------------------------------------------------------------------------------
	//	Rule 1: For removing self-intersection
	//------------------------------------------------------------------------------------------------------------
	//	By detecting non-convex vertex
#ifdef _CCL_INTERSECTIONFREE
	int num=0;	bool bConvex[4];
	bConvex[0]=bConvex[1]=bConvex[2]=bConvex[3]=true;
	for(k=0;k<4;k++) {
		nodeArray[ppIndex[k]]->GetCoord3D(pp[0],pp[1],pp[2]);
		nodeArray[ppIndex[(k+3)%4]]->GetCoord3D(p1[0],p1[1],p1[2]);
		nodeArray[ppIndex[(k+1)%4]]->GetCoord3D(p2[0],p2[1],p2[2]);

		aa[0][0]=pp[0]-ePP[0];		aa[0][1]=pp[1]-ePP[1];		aa[0][2]=pp[2]-ePP[2];
		aa[1][0]=p1[0]-ePP[0];		aa[1][1]=p1[1]-ePP[1];		aa[1][2]=p1[2]-ePP[2];
		aa[2][0]=p2[0]-ePP[0];		aa[2][1]=p2[1]-ePP[1];		aa[2][2]=p2[2]-ePP[2];
		det1=_determination(aa);

		aa[0][0]=pp[0]-sPP[0];		aa[0][1]=pp[1]-sPP[1];		aa[0][2]=pp[2]-sPP[2];
		aa[1][0]=p1[0]-sPP[0];		aa[1][1]=p1[1]-sPP[1];		aa[1][2]=p1[2]-sPP[2];
		aa[2][0]=p2[0]-sPP[0];		aa[2][1]=p2[1]-sPP[1];		aa[2][2]=p2[2]-sPP[2];
		det2=_determination(aa);

		if (!((det1>=0.0) && (det2<=0.0))) {bConvex[k]=false; num++;}
	}
	if (num==1) {
		for(k=0;k<4;k++) if (!(bConvex[k])) break;
		f1Index[0]=ppIndex[k];	f1Index[1]=ppIndex[(k+1)%4];	f1Index[2]=ppIndex[(k+2)%4];
		f2Index[0]=ppIndex[k];	f2Index[1]=ppIndex[(k+2)%4];	f2Index[2]=ppIndex[(k+3)%4];
		return;
	}
	else if (num>1) {
//		printf("FOUND %d!!!!!\n",num);
		f1Index[0]=-1; 
		return;
	}
#endif

	//------------------------------------------------------------------------------------------------------------
	//	Rule 2: For preserving sharp-features
	short sharpFeaNodeNum=0;
	for(k=0;k<4;k++) if (nodeArray[ppIndex[k]]->GetAttribFlag(1)) sharpFeaNodeNum++;
	switch(sharpFeaNodeNum) {
	case 1:{
		if ((nodeArray[ppIndex[0]]->GetAttribFlag(1)) || (nodeArray[ppIndex[2]]->GetAttribFlag(1))) {
			f1Index[0]=ppIndex[0];	f1Index[1]=ppIndex[1];	f1Index[2]=ppIndex[2];
			f2Index[0]=ppIndex[0];	f2Index[1]=ppIndex[2];	f2Index[2]=ppIndex[3];
			return;
		}
		else {
			f1Index[0]=ppIndex[0];	f1Index[1]=ppIndex[1];	f1Index[2]=ppIndex[3];
			f2Index[0]=ppIndex[1];	f2Index[1]=ppIndex[2];	f2Index[2]=ppIndex[3];
			return;
		}
		   }break;
	case 2:{
		if ((nodeArray[ppIndex[0]]->GetAttribFlag(1)) && (nodeArray[ppIndex[2]]->GetAttribFlag(1))) {
			f1Index[0]=ppIndex[0];	f1Index[1]=ppIndex[1];	f1Index[2]=ppIndex[2];
			f2Index[0]=ppIndex[0];	f2Index[1]=ppIndex[2];	f2Index[2]=ppIndex[3];
			return;
		}
		if ((nodeArray[ppIndex[1]]->GetAttribFlag(1)) && (nodeArray[ppIndex[3]]->GetAttribFlag(1))) {
			f1Index[0]=ppIndex[0];	f1Index[1]=ppIndex[1];	f1Index[2]=ppIndex[3];
			f2Index[0]=ppIndex[1];	f2Index[1]=ppIndex[2];	f2Index[2]=ppIndex[3];
			return;
		}
		   }break;
	case 3:{
		for(k=0;k<4;k++) {if (!(nodeArray[ppIndex[k]]->GetAttribFlag(1))) break;}
		nodeArray[ppIndex[(k+3)%4]]->GetCoord3D(p1[0],p1[1],p1[2]);
		nodeArray[ppIndex[(k+2)%4]]->GetCoord3D(pp[0],pp[1],pp[2]);
		nodeArray[ppIndex[(k+1)%4]]->GetCoord3D(p2[0],p2[1],p2[2]);
		pp[0]=pp[0]-p2[0];	pp[1]=pp[1]-p2[1];	pp[2]=pp[2]-p2[2];
		p1[0]=p1[0]-p2[0];	p1[1]=p1[1]-p2[1];	p1[2]=p2[2]-p2[2];
		double ll=sqrt(p1[0]*p1[0]+p1[1]*p1[1]+p1[2]*p1[2]);
		if (ll<1.0e-5) break;
		p1[0]=p1[0]/ll;	p1[1]=p1[1]/ll;	p1[2]=p1[2]/ll;
		ll=pp[0]*p1[0]+pp[1]*p1[1]+pp[2]*p1[2];
		pp[0]=pp[0]-ll*p1[0];	pp[1]=pp[1]-ll*p1[1];	pp[2]=pp[2]-ll*p1[2];
		double dd=pp[0]*pp[0]+pp[1]*pp[1]+pp[2]*pp[2];
		if (dd<criterion) break;

		f1Index[0]=ppIndex[(k+1)%4];	f1Index[1]=ppIndex[(k+2)%4];	f1Index[2]=ppIndex[(k+3)%4];
		f2Index[0]=ppIndex[k];			f2Index[1]=ppIndex[(k+1)%4];	f2Index[2]=ppIndex[(k+3)%4];
		return;
		   }break;
	}

	//------------------------------------------------------------------------------------------------------------
	//	Rule 3: For generating 
	double pp1[3],pp2[3],d1,d2;
	nodeArray[ppIndex[0]]->GetCoord3D(pp1[0],pp1[1],pp1[2]);
	nodeArray[ppIndex[2]]->GetCoord3D(pp2[0],pp2[1],pp2[2]);
	d1=(pp1[0]-pp2[0])*(pp1[0]-pp2[0])+(pp1[1]-pp2[1])*(pp1[1]-pp2[1])+(pp1[2]-pp2[2])*(pp1[2]-pp2[2]);
	nodeArray[ppIndex[1]]->GetCoord3D(pp1[0],pp1[1],pp1[2]);
	nodeArray[ppIndex[3]]->GetCoord3D(pp2[0],pp2[1],pp2[2]);
	d2=(pp1[0]-pp2[0])*(pp1[0]-pp2[0])+(pp1[1]-pp2[1])*(pp1[1]-pp2[1])+(pp1[2]-pp2[2])*(pp1[2]-pp2[2]);
	if (d1<d2) {
		f1Index[0]=ppIndex[0];	f1Index[1]=ppIndex[1];	f1Index[2]=ppIndex[2];
		f2Index[0]=ppIndex[0];	f2Index[1]=ppIndex[2];	f2Index[2]=ppIndex[3];
	}
	else {
		f1Index[0]=ppIndex[0];	f1Index[1]=ppIndex[1];	f1Index[2]=ppIndex[3];
		f2Index[0]=ppIndex[1];	f2Index[1]=ppIndex[2];	f2Index[2]=ppIndex[3];
	}
}

double LDNISolidUniformContouring::_determination(double a[][3])
{
	double value;

	value=a[0][0]*a[1][1]*a[2][2]+a[0][1]*a[1][2]*a[2][0]+a[0][2]*a[1][0]*a[2][1]
		-a[0][0]*a[1][2]*a[2][1]-a[0][1]*a[1][0]*a[2][2]-a[0][2]*a[1][1]*a[2][0];
	
	return value;
}

void LDNISolidUniformContouring::_createFaceByNodes(QMeshFace* &newFace, QMeshPatch *mesh,
													QMeshNode *node1, QMeshNode *node2, QMeshNode *node3)
{
	QMeshNode *nodes[3];		int i,eNum=3;
	QMeshEdge *newEdge,*edge;	bool bDir;
	QMeshNode *sNode,*eNode;	GLKPOSITION Pos;

	nodes[0]=node1;	nodes[1]=node2;	nodes[2]=node3;

	//---------------------------------------------------------------------------------------
	//	Construct the QMeshFace
	newFace=new QMeshFace;
	mesh->GetFaceList().AddTail(newFace);
	newFace->SetIndexNo(mesh->GetFaceNumber());
	newFace->SetMeshPatchPtr(mesh);		newFace->SetEdgeNum(eNum);
	for(i=0;i<eNum;i++) {
		sNode=nodes[i];	eNode=nodes[(i+1)%eNum];
		newEdge=NULL;
		for(Pos=sNode->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
			edge=(QMeshEdge *)(sNode->GetEdgeList().GetNext(Pos));
			if ((edge->GetEndPoint()==eNode) && (edge->GetLeftFace()==NULL)) {
				newEdge=edge;	bDir=true;		break;
			}
			else if ((edge->GetStartPoint()==eNode) && (edge->GetRightFace()==NULL)) {
				newEdge=edge;	bDir=false;		break;
			}
		}

		if (!newEdge) {
			newEdge=new QMeshEdge;	bDir=true;
			newEdge->SetStartPoint(sNode);	newEdge->SetEndPoint(eNode);
			sNode->GetEdgeList().AddTail(newEdge);	eNode->GetEdgeList().AddTail(newEdge);
			newEdge->SetMeshPatchPtr(mesh);	
			mesh->GetEdgeList().AddTail(newEdge);	newEdge->SetIndexNo(mesh->GetEdgeNumber());
		}
		else {
			if ((newEdge->GetLeftFace()!=NULL) && (newEdge->GetRightFace()!=NULL)) {
				printf("Non-manifold Edge is Found %d! \n",eNum);
				newEdge->SetAttribFlag(0);
			}
		}

		newFace->SetEdgeRecordPtr(i,newEdge);
		newFace->SetDirectionFlag(i,bDir);
		if (bDir)
			newEdge->SetLeftFace(newFace);
		else
			newEdge->SetRightFace(newFace);
	}
	newFace->CalPlaneEquation();
}

void LDNISolidUniformContouring::_searchHermiteSamplesInCell(int si, int sj, int sk, LDNISolid* solid, 
															 int &sampleNum, double sx[], double sy[], double sz[],
															 double nx[], double ny[], double nz[])
{
	LDNISolidNode *currentNode;
	double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3],upper,lower;
	double eps=.001*solid->GetGridWidth();		short nAxis;	int ii,jj,is,ie,js,je,res;

	solid->GetOrigin(origin);		width=solid->GetGridWidth();	res=solid->GetResolution();
	xmin=width*(double)si;			ymin=width*(double)sj;			zmin=width*(double)sk;
	xmax=width*((double)si+1.0);	ymax=width*((double)sj+1.0);	zmax=width*((double)sk+1.0);
	sampleNum=0;

	for(nAxis=0;nAxis<3;nAxis++) {
		switch(nAxis) {
		case 0:{lower=xmin-eps;	upper=xmax+eps;	is=sj; ie=sj+1; js=sk; je=sk+1;}break;
		case 1:{lower=ymin-eps;	upper=ymax+eps;	is=sk; ie=sk+1; js=si; je=si+1;}break;
		case 2:{lower=zmin-eps;	upper=zmax+eps;	is=si; ie=si+1; js=sj; je=sj+1;}break;
		}

		for(ii=is;ii<=ie;ii++) {
			if ((ii>=res) || (ii<0)) continue;
			for(jj=js;jj<=je;jj++) {
				if ((jj>=res) || (jj<0)) continue;
				currentNode=solid->GetLDNISolidNode(nAxis,ii,jj);
				if (currentNode==NULL) continue;

				short i,nNum=currentNode->GetSampleNum();
				double deltaDepth=1.0e+8;
				for(i=0;i<nNum;i++) {
					double depth=currentNode->GetDepth(i);
					if (depth>upper) break;
					if (depth<lower) continue;

					if (fabs(depth-0.5*(lower+upper))<deltaDepth) {
						deltaDepth=fabs(depth-0.5*(lower+upper));

						currentNode->GetNormal(i,nx[sampleNum],ny[sampleNum],nz[sampleNum]);
						switch(nAxis) {
						case 0:{sx[sampleNum]=depth; sy[sampleNum]=width*(double)ii; sz[sampleNum]=width*(double)jj;}break;
						case 1:{sx[sampleNum]=width*(double)jj; sy[sampleNum]=depth; sz[sampleNum]=width*(double)ii;}break;
						case 2:{sx[sampleNum]=width*(double)ii; sy[sampleNum]=width*(double)jj; sz[sampleNum]=depth;}break;
						}
						sx[sampleNum]+=origin[0];	sy[sampleNum]+=origin[1];	sz[sampleNum]+=origin[2];
					}
				}
				if (deltaDepth<width) sampleNum++;
			}
		}
	}
}

void LDNISolidUniformContouring::_compPositionByHermiteData(int ii, int jj, int kk, double origin[], double gwidth,
															int pntNum, double sx[], double sy[], double sz[], 
															double nx[], double ny[], double nz[], double pp[], bool &bSharp)
{
	double proj,scale;
	double criterion=_CCL_SVD_THRESHOLD;	int i,j,k;
	double **A,**UU,**VV,**UUT,**VVT;		double *B,*X;
	double minP[3],maxP[3];

	//---------------------------------------------------------------------------
	//	Preparation
	pp[0]=origin[0]+gwidth*((double)ii+0.5);
	pp[1]=origin[1]+gwidth*((double)jj+0.5);
	pp[2]=origin[2]+gwidth*((double)kk+0.5);
	minP[0]=pp[0]-gwidth*0.5;	minP[1]=pp[1]-gwidth*0.5;	minP[2]=pp[2]-gwidth*0.5;
	maxP[0]=pp[0]+gwidth*0.5;	maxP[1]=pp[1]+gwidth*0.5;	maxP[2]=pp[2]+gwidth*0.5;
	//---------------------------------------------------------------------------
	pp[0]=pp[1]=pp[2]=0.0;
	for(int index=0;index<pntNum;index++) {pp[0]+=sx[index];	pp[1]+=sy[index];	pp[2]+=sz[index];}
	pp[0]=pp[0]/(double)pntNum;
	pp[1]=pp[1]/(double)pntNum;
	pp[2]=pp[2]/(double)pntNum;
	//---------------------------------------------------------------------------
	GLKMatrixLib::CreateMatrix(A,3,3);		B=new double[3];	X=new double[3];
	GLKMatrixLib::CreateMatrix(UU,3,3);		GLKMatrixLib::CreateMatrix(VV,3,3);
	GLKMatrixLib::CreateMatrix(UUT,3,3);	GLKMatrixLib::CreateMatrix(VVT,3,3);
	//---------------------------------------------------------------------------
	B[0]=B[1]=B[2]=X[0]=X[1]=X[2]=0.0;
	for(k=0;k<pntNum;k++) {
		proj=(sx[k]-pp[0])*nx[k]+(sy[k]-pp[1])*ny[k]+(sz[k]-pp[2])*nz[k];
		B[0]+=proj*nx[k];	B[1]+=proj*ny[k];	B[2]+=proj*nz[k];	

		A[0][0]+=nx[k]*nx[k]; A[0][1]+=nx[k]*ny[k]; A[0][2]+=nx[k]*nz[k];
		A[1][0]+=ny[k]*nx[k]; A[1][1]+=ny[k]*ny[k]; A[1][2]+=ny[k]*nz[k];
		A[2][0]+=nz[k]*nx[k]; A[2][1]+=nz[k]*ny[k]; A[2][2]+=nz[k]*nz[k];
	}

	//---------------------------------------------------------------------------
	//	Sharp Feature Detection
	double *eigenValue=new double[3];	double **AA,**eigenVectors;
	GLKMatrixLib::CreateMatrix(AA,3,3);		GLKMatrixLib::CreateMatrix(eigenVectors,3,3);	
	for(i=0;i<3;i++) {for(j=0;j<3;j++) {AA[i][j]=A[i][j];}}
	GLKMatrixLib::JacobianEigensystemSolver(AA,3,eigenVectors,eigenValue,1.0e-5,100);
	bSharp=false; short vote=0;	double maxEigen=fabs(eigenValue[0]);
	if (fabs(eigenValue[1])>maxEigen) maxEigen=fabs(eigenValue[1]);
	if (fabs(eigenValue[2])>maxEigen) maxEigen=fabs(eigenValue[2]);
	for(i=0;i<3;i++) if (fabs(eigenValue[i]/maxEigen)<_CCL_SHARPFEATURE_THRESHOLD) vote++;
	if (vote<2) {bSharp=true; }
	GLKMatrixLib::DeleteMatrix(AA,3,3);		GLKMatrixLib::DeleteMatrix(eigenVectors,3,3);	
	delete []eigenValue;

	//---------------------------------------------------------------------------
	//	Singular Value Decomposition
	GLKMatrixLib::SingularValueDecomposition(A,3,3,UU,VVT);
	GLKMatrixLib::Transpose(UU,3,3,UUT);
	GLKMatrixLib::Transpose(VVT,3,3,VV);
	double maxFactor=(fabs(A[0][0])>fabs(A[1][1]))?(A[0][0]):(A[1][1]);
	maxFactor=(fabs(maxFactor)>fabs(A[2][2]))?(maxFactor):(A[2][2]);
	if (fabs(maxFactor)<1.0e-6) {
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				A[i][j]=0.0;
			}
		}
	}
	else {
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				if (i!=j) {
					A[i][j]=0.0;
				}
				else {
					if (fabs(A[i][j]/maxFactor)<criterion) 
						A[i][j]=0.0;
					else 
						A[i][j]=1.0/A[i][j];
				}
			}
		}
	}
	GLKMatrixLib::Mul(UUT,B,3,3,X);
	GLKMatrixLib::Mul(A,X,3,3,B);
	GLKMatrixLib::Mul(VV,B,3,3,X);
	//-----------------------------------------------------------------
	//	truncate the update vector and update node position
	scale=1.0;
#ifdef _CCL_INTERSECTIONFREE
	if (fabs(X[0])>1.0e-5 && (pp[0]+X[0]*scale)>maxP[0]) scale=(maxP[0]-pp[0])/X[0];
	if (fabs(X[1])>1.0e-5 && (pp[1]+X[1]*scale)>maxP[1]) scale=(maxP[1]-pp[1])/X[1];
	if (fabs(X[2])>1.0e-5 && (pp[2]+X[2]*scale)>maxP[2]) scale=(maxP[2]-pp[2])/X[2];
	if (fabs(X[0])>1.0e-5 && (pp[0]+X[0]*scale)<minP[0]) scale=(minP[0]-pp[0])/X[0];
	if (fabs(X[1])>1.0e-5 && (pp[1]+X[1]*scale)<minP[1]) scale=(minP[1]-pp[1])/X[1];
	if (fabs(X[2])>1.0e-5 && (pp[2]+X[2]*scale)<minP[2]) scale=(minP[2]-pp[2])/X[2];
#endif
//	scale=1.0;
	pp[0]=pp[0]+X[0]*scale;	pp[1]=pp[1]+X[1]*scale;	pp[2]=pp[2]+X[2]*scale;

	//---------------------------------------------------------------------------
	//	Free the memory
	GLKMatrixLib::DeleteMatrix(A,3,3);		delete []B;	delete []X;
	GLKMatrixLib::DeleteMatrix(UU,3,3);		GLKMatrixLib::DeleteMatrix(VV,3,3);
	GLKMatrixLib::DeleteMatrix(UUT,3,3);	GLKMatrixLib::DeleteMatrix(VVT,3,3);
}

void LDNISolidUniformContouring::_compactionOfRays(LDNISolid* solid, int &xRayNum, LDNIRay* &xRayArray,
												   int &yRayNum, LDNIRay* &yRayArray, int &zRayNum, LDNIRay* &zRayArray)
{
	short nDir;
	int res=solid->GetResolution();
	int newNum=res*res;

	int *rayIndex;	
	int nn=0;
	while((2<<nn)<newNum) nn++;
	nn++;
	int arrayLen=(2<<(nn-1));
	rayIndex=(int *)(malloc(sizeof(int)*arrayLen));

	for(nDir=0;nDir<3;nDir++) {
		//-------------------------------------------------------------------------------
		//	Setting the flags for empty/non-empty
		int rayNum=0;
#pragma omp parallel for 
		for(int kk=0;kk<newNum;kk++) {
			LDNISolidNode *node;
			int i=kk/res;	int j=kk%res;
			node=solid->GetLDNISolidNode(nDir,i,j);	
			rayIndex[kk]=0;
			if (node!=NULL) rayIndex[kk]=1;
		}
#pragma omp parallel for 
		for(int kk=newNum;kk<arrayLen;kk++) rayIndex[kk]=0;

		//-------------------------------------------------------------------------------
		//	Compaction
		int loopNum,stepSize;
		//-------------------------------------------------------------------------------
		//	Step a): up-sweep algorithm	
		loopNum=arrayLen;
		for(int dIter=0;dIter<nn;dIter++) {
			stepSize=(2<<dIter);	loopNum=loopNum/2;
#pragma omp parallel for 
			for(int kk=0;kk<loopNum;kk++) {
				rayIndex[kk*stepSize+stepSize-1]=rayIndex[kk*stepSize+stepSize/2-1]+rayIndex[kk*stepSize+stepSize-1];
			}
		}
		rayNum=rayIndex[arrayLen-1];
		//-------------------------------------------------------------------------------
		//	Step b): down-sweep algorithm
		rayIndex[arrayLen-1]=0;	
		loopNum=1;
		for(int dIter=nn-1;dIter>=0;dIter--) {
			stepSize=(2<<dIter);
#pragma omp parallel for 
			for(int kk=0;kk<loopNum;kk++) {
				int temp=rayIndex[kk*stepSize+stepSize/2-1];
				rayIndex[kk*stepSize+stepSize/2-1]=rayIndex[kk*stepSize+stepSize-1];
				rayIndex[kk*stepSize+stepSize-1]+=temp;
			}
			loopNum=loopNum*2;
		}
		//-------------------------------------------------------------------------------
		//	Step c): collection
		LDNIRay *rayArray=(LDNIRay*)(malloc(sizeof(LDNIRay)*rayNum)); 
#pragma omp parallel for 
		for(int kk=0;kk<newNum;kk++) {
			LDNISolidNode *node;
			int i=kk/res;	int j=kk%res;
			node=solid->GetLDNISolidNode(nDir,i,j);	
			if (node!=NULL) {
				int index=rayIndex[kk];
				rayArray[index].headNode=node;
				rayArray[index].i=i;	rayArray[index].j=j;
			}
		}
		switch(nDir) {
			case 0:{xRayNum=rayNum;	xRayArray=rayArray;	}break;
			case 1:{yRayNum=rayNum;	yRayArray=rayArray;	}break;
			case 2:{zRayNum=rayNum;	zRayArray=rayArray;	}break;
		}
	}

	free(rayIndex);
}

bool LDNISolidUniformContouring::_compactionOfBoundaryCells(int res, bool *bInside, int* &iBndCellIndex,
															int &bndCellNum, LDNIUniformCell* &bndCellArray)
{
	//int *iBndCellIndex;	// index = z*res*res + y*res + x;
	int totalCellNum=(res-1)*(res-1)*(res-1);	int cellDelta=(res-1)*(res-1);
	bool bLastCell;

	int nn=0;
	while((2<<nn)<totalCellNum) nn++;
	nn++;
	int arrayLen=(2<<(nn-1));
	printf("nn=%d  arrayLen=%d\n",nn,arrayLen);
	if (nn>=31) {bndCellNum=0;return false;}
	iBndCellIndex=(int *)(malloc(sizeof(int)*arrayLen));
#pragma omp parallel for 
	for(int kk=0;kk<arrayLen;kk++) iBndCellIndex[kk]=0;

	//-------------------------------------------------------------------------------
	//	Setting the flags for the boundary cells
#pragma omp parallel for 
	for(int kk=0;kk<totalCellNum;kk++) {
		int zz=kk/cellDelta;	int yy=kk%cellDelta;
		int xx=yy%(res-1);		yy=yy/(res-1);

		bool bBnd=false,bTemp=bInside[zz*res*res+yy*res+xx];
		if (bTemp!=bInside[zz*res*res+yy*res+(xx+1)]) bBnd=true;
		else if (bTemp!=bInside[zz*res*res+(yy+1)*res+xx]) bBnd=true;
		else if (bTemp!=bInside[zz*res*res+(yy+1)*res+(xx+1)]) bBnd=true;
		else if (bTemp!=bInside[(zz+1)*res*res+yy*res+xx]) bBnd=true;
		else if (bTemp!=bInside[(zz+1)*res*res+yy*res+(xx+1)]) bBnd=true;
		else if (bTemp!=bInside[(zz+1)*res*res+(yy+1)*res+xx]) bBnd=true;
		else if (bTemp!=bInside[(zz+1)*res*res+(yy+1)*res+(xx+1)]) bBnd=true;

		if (bBnd) iBndCellIndex[kk]=1;
	}
	if (iBndCellIndex[totalCellNum-1]==1) bLastCell=true; else bLastCell=false;

	//-------------------------------------------------------------------------------
	//	Compaction
	int loopNum,stepSize;
	//-------------------------------------------------------------------------------
	//	Step a): up-sweep algorithm	
	loopNum=arrayLen;
	for(int dIter=0;dIter<nn;dIter++) {
		stepSize=(2<<dIter);	loopNum=loopNum/2;
#pragma omp parallel for 
		for(int kk=0;kk<loopNum;kk++) {
			iBndCellIndex[kk*stepSize+stepSize-1]=iBndCellIndex[kk*stepSize+stepSize/2-1]+iBndCellIndex[kk*stepSize+stepSize-1];
		}
	}
	bndCellNum=iBndCellIndex[arrayLen-1];
	//-------------------------------------------------------------------------------
	//	Step b): down-sweep algorithm
	iBndCellIndex[arrayLen-1]=0;	
	loopNum=1;
	for(int dIter=nn-1;dIter>=0;dIter--) {
		stepSize=(2<<dIter);
#pragma omp parallel for 
		for(int kk=0;kk<loopNum;kk++) {
			int temp=iBndCellIndex[kk*stepSize+stepSize/2-1];
			iBndCellIndex[kk*stepSize+stepSize/2-1]=iBndCellIndex[kk*stepSize+stepSize-1];
			iBndCellIndex[kk*stepSize+stepSize-1]+=temp;
		}
		loopNum=loopNum*2;
	}
	//-------------------------------------------------------------------------------
	//	Step c): collection
	if (bndCellNum>0) {
		bndCellArray=(LDNIUniformCell*)(malloc(sizeof(LDNIUniformCell)*bndCellNum));
#pragma omp parallel for 
		for(int kk=0;kk<totalCellNum-1;kk++) {
			int zz=kk/cellDelta;	int yy=kk%cellDelta;
			int xx=yy%(res-1);		yy=yy/(res-1);
			if (iBndCellIndex[kk]!=iBndCellIndex[kk+1]) {
				int index=iBndCellIndex[kk];
				bndCellArray[index].i=(short)xx;
				bndCellArray[index].j=(short)yy;
				bndCellArray[index].k=(short)zz;
			}
		}
		if (bLastCell) {
			int index=iBndCellIndex[totalCellNum-1];
			int zz=(totalCellNum-1)/cellDelta;	int yy=(totalCellNum-1)%cellDelta;
			int xx=yy%(res-1);		yy=yy/(res-1);
			bndCellArray[index].i=(short)xx;
			bndCellArray[index].j=(short)yy;
			bndCellArray[index].k=(short)zz;
		}
	}

	return true;
}

void LDNISolidUniformContouring::_setInsideOutsideFlag(int &xRayNum, LDNIRay* &xRayArray, 
													   int &yRayNum, LDNIRay* &yRayArray, 
													   int &zRayNum, LDNIRay* &zRayArray, 
													   int res, bool *bInside, double width)
{
	int totalNum=res*res*res;			// index = z*res*res + y*res + x;
	int delta=res*res;
	char *nVoting; 

	nVoting=(char *)malloc(totalNum*sizeof(char));

#pragma omp parallel for 
	for(int kk=0;kk<totalNum;kk++) nVoting[kk]=0;

	//------------------------------------------------------------------------------------
	//	set flags by x-rays
#pragma omp parallel for 
	for(int kk=0;kk<xRayNum;kk++) {
		LDNISolidNode *node=xRayArray[kk].headNode;
		int sampleNum=node->GetSampleNum();
		int si,ss,ee,ii,index,yindex,zindex;

		yindex=xRayArray[kk].i;	zindex=xRayArray[kk].j;
		index=zindex*delta+yindex*res;

		for(si=0;si<sampleNum;si+=2) {
			ss=(int)(node->GetDepth(si)/width);
			if (width*(double)ss<node->GetDepth(si)) ss++;
			ee=(int)(node->GetDepth(si+1)/width);
			for(ii=ss;ii<=ee;ii++) nVoting[index+ii]++;
		}
	}

	//------------------------------------------------------------------------------------
	//	set flags by y-rays
#pragma omp parallel for 
	for(int kk=0;kk<yRayNum;kk++) {
		LDNISolidNode *node=yRayArray[kk].headNode;
		int sampleNum=node->GetSampleNum();
		int si,ss,ee,ii,index,xindex,zindex;

		zindex=yRayArray[kk].i;	xindex=yRayArray[kk].j;
		index=zindex*delta+xindex;

		for(si=0;si<sampleNum;si+=2) {
			ss=(int)(node->GetDepth(si)/width);
			if (width*(double)ss<node->GetDepth(si)) ss++;
			ee=(int)(node->GetDepth(si+1)/width);
			for(ii=ss;ii<=ee;ii++) nVoting[index+ii*res]++;
		}
	}

	//------------------------------------------------------------------------------------
	//	set flags by z-rays
#pragma omp parallel for 
	for(int kk=0;kk<zRayNum;kk++) {
		LDNISolidNode *node=zRayArray[kk].headNode;
		int sampleNum=node->GetSampleNum();
		int si,ss,ee,ii,index,xindex,yindex;

		xindex=zRayArray[kk].i;	yindex=zRayArray[kk].j;
		index=yindex*res+xindex;

		for(si=0;si<sampleNum;si+=2) {
			ss=(int)(node->GetDepth(si)/width);
			if (width*(double)ss<node->GetDepth(si)) ss++;
			ee=(int)(node->GetDepth(si+1)/width);
			for(ii=ss;ii<=ee;ii++) bInside[index+ii*delta]++;
		}
	}

#pragma omp parallel for 
	for(int kk=0;kk<totalNum;kk++) bInside[kk]=((nVoting[kk]>1)?true:false);

	free(nVoting);
}
