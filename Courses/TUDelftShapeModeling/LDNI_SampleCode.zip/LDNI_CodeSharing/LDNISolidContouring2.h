// LDNISolidContouring2.h: interface for the LDNISolidContouring2 class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _CCL_LDNISOLID_CONTOURING2
#define _CCL_LDNISOLID_CONTOURING2

#define _CCL_TOLERANCE_RES_MULTIMATERIAL	0.25		// actually the scale in terms of the sample width in LDNI
#define _CCL_SVD_THRESHOLD					0.5
//#define	_OCTREE_DISPLAY		true

class QMeshNode;

class LDNISolidOctreeCell2 {
public:
	LDNISolidOctreeCell2() {
		short i;
		for(i=0;i<8;i++) {m_childOctreeNode[i]=NULL; m_nodeMaterialType[i]=0;} 
		vertex=NULL;
		sX=sY=sZ=eX=eY=eZ=0;
	};
	virtual ~LDNISolidOctreeCell2() {
		for(short i=0;i<8;i++) {
			if (m_childOctreeNode[i]!=NULL) 
				delete (LDNISolidOctreeCell2*)(m_childOctreeNode[i]);
		}
	};

	bool IsLeaf() {{if (m_childOctreeNode[0]==NULL) return true;} return false;};
	bool IsAbleToRefine() {{if (((eX-sX)==1) || ((eY-sY)==1) || ((eZ-sZ)==1)) return false;} return true;};

	short m_nodeMaterialType[8];	// 0 - empty
	LDNISolidOctreeCell2 *m_childOctreeNode[8];
	short sX,sY,sZ,eX,eY,eZ;
	double pnt[3];
	QMeshNode *vertex;
};

class LDNISolidContouring2  // This is the class for contouring a LDNI solid with multiple-material
{
public:
	LDNISolidContouring2();
	virtual ~LDNISolidContouring2();

	static void MeshGeneration(LDNISolid* solid, GLKObList *meshList);
	static void SingleMaterialSolidIDProc(LDNISolid* solid);

private:
	//-----------------------------------------------------------------------------------------------
	//	The functions for refinement and octree construction
	static void _cellRefinement(LDNISolid* solid, LDNISolidOctreeCell2 *cell, double geoCriterion, int level);
	static bool _isCellNeedRefine(LDNISolid *solid, LDNISolidOctreeCell2 *cell, double geoCriterion);
	static bool _complexCellCheck_InvalidEmptyOrSolidCell(LDNISolid *solid, LDNISolidOctreeCell2 *cell);
	static bool _complexCellCheck_AmbiguousFaceOrCell(LDNISolidOctreeCell2 *cell);
	static bool _complexCellCheck_MultipleEdgeIntersections(LDNISolid *solid, LDNISolidOctreeCell2 *cell);
	static bool _complexCellCheck_InvalidEmptyOrSolidFace(LDNISolid *solid, LDNISolidOctreeCell2 *cell);
	static bool _isEmptyOrSolidCell(LDNISolidOctreeCell2 *cell);
	static void _searchHermiteDataSet(LDNISolid *solid, LDNISolidOctreeCell2 *cell, int &pntNum, double** &samplePnts);
	static void _compPositionByHermiteData(LDNISolid *solid, int pntNum, double** samplePnts, double pp[], double cellWidth, bool bUsingMassPoint=true);

	//-----------------------------------------------------------------------------------------------
	//	The functions for contouring the octree
	static void _contourCellArray(LDNISolid *solid, LDNISolidOctreeCell2 ****cellArray, int arrayNum, QMeshPatch *mesh);
	static void _contourCellProc(LDNISolid *solid, LDNISolidOctreeCell2 *cell, QMeshPatch *mesh);
	static void _contourFaceProc(LDNISolid *solid, LDNISolidOctreeCell2 *pCell, LDNISolidOctreeCell2 *qCell, short nAxis, QMeshPatch *mesh);
	static void _contourEdgeProc(LDNISolid *solid, LDNISolidOctreeCell2 *pCell, LDNISolidOctreeCell2 *qCell, LDNISolidOctreeCell2 *rCell, 
									LDNISolidOctreeCell2 *sCell, short nAxis, int sPntType, int ePntType, QMeshPatch *mesh);
	static void _createMeshFaceByVertices(QMeshNode *nodeArray[], QMeshPatch *mesh, int id=-1, bool bManifoldEnsured=false);

	//-----------------------------------------------------------------------------------------------
	//	The functions for post-processing
	static void _quadMeshToTrglMesh(QMeshPatch *mesh);
	static void _generatingAssemblyOfMeshes(QMeshPatch *soupMesh, GLKObList *meshList, int materialNum);

	//-----------------------------------------------------------------------------------------------
	//	The functions for debug
	static void _debugContouringCell(LDNISolid* solid, LDNISolidOctreeCell2 *cell, QMeshPatch *mesh);
};

#endif
