#ifndef _CCL_LDNISOLID_SAMPLING
#define _CCL_LDNISOLID_SAMPLING

class LDNISolid;
class QMeshPatch;

class LDNISolidSampling
{
public:
	LDNISolidSampling();
	virtual ~LDNISolidSampling();

	static void MeshToLDNISolidSampling(QMeshPatch *mesh, LDNISolid* &solid, double boundingBox[], int res=64, bool bWithSortAndCheck=true);

private:
	static int _buildObjectColorNormalDisplayList(QMeshPatch *mesh, double boundingBox[]);
	static void _decompositionOfLDIColorNormal(QMeshPatch *mesh, LDNISolid *solid, 
											double boundingBox[], short nAxis, int displayListIndex, bool bWithSortAndCheck);

	//-------------------------------------------------------------------------------------------------------------------------
	//	The following functions are for using geometry shader to speed up the sampling
	static bool _shaderInitialization();
	static unsigned char* _readShaderFile( const char *fileName );
	static void _texCalProduct(int in,int &outx, int &outy);	//	Function to calulate 2D size texture from 1D texture
};

#endif