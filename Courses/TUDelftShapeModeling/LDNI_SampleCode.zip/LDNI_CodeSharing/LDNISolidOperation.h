#ifndef _CCL_LDNI_SOLID_OPERATION
#define _CCL_LDNI_SOLID_OPERATION

#include <math.h>

class PQP_Model;

class LDNISolidOperation
{
public:
	LDNISolidOperation(void);
	virtual ~LDNISolidOperation(void);

	static void BooleanOperation(QMeshPatch *meshA, QMeshPatch *meshB, int res, short nOperationType, LDNISolid *&outputSolid);
	static void BooleanOperation_Parallel(QMeshPatch *meshA, QMeshPatch *meshB, int res, short nOperationType, LDNISolid *&outputSolid);
	static void BooleanOperation(LDNISolid *inputSolid, QMeshPatch *meshB, short nOperationType, LDNISolid *&outputSolid);
	static void BooleanOperation_Parallel(LDNISolid *inputSolid, QMeshPatch *meshB, short nOperationType, LDNISolid *&outputSolid);

	static void CompBoundingBox(GLKObList* meshList, double boundingBox[], bool bCube, int res); 

	static void ConstructLDNISolidFromVolumeImage(LDNISolid *&solid, int ***indexArray, int xNum, int yNum, int zNum, int materialTypeNum, 
													float xmin, float ymin, float zmin, float gridwidth);

	static void SolidCorrection(LDNISolid* solid);
	static void SolidCorrectionInParallel(LDNISolid* solid);

	static void SolidOffsetting(LDNISolid* solid, LDNISolid* &newSolid, double offset);
	static void ParallelSolidOffsetting(LDNISolid* solid, LDNISolid* &newSolid, double offset);
	static void ParallelMinkowskiSumSuperellipsoid(LDNISolid* solid, LDNISolid* &newSolid, double rx, double ry, double rz, double ePara, double nPara);

	//-----------------------------------------------------------------------------------------------------------------------
	//	The general offsetting will have offset on different intermediate surfaces
	static void ParallelGeneralOffsetting(LDNISolid* solid, LDNISolid* &newSolid, int indexOfProcessingSolid, double *offset);

	static void ParallelComputingNormalOfLDNISolid(LDNISolid *solid);
	static void ParallelProcessingNormalOfLDNISolid(LDNISolid *solid);

	static void ErrorEvaluationForLDNISolid(QMeshPatch *mesh, LDNISolid *solid);

private:
	//-------------------------------------------------------------------------------------------------------------------------
	//	The service functions for Solid correction
	static bool _othorgonalFillingBasedCorrection(short nAxis, int ii, int jj, LDNISolid *solid);
	static bool _isPointOutside(short nAxis, int ii, int jj, int kk, LDNISolid *solid);
	static void _collectingSamples(short nDir, LDNISolidNode *node);

	//-------------------------------------------------------------------------------------------------------------------------
	//	The service functions for Boolean operation
	static void _booleanOfSolidNodeList(LDNISolidNode *&aNode, LDNISolidNode *&bNode, short nOperationType, double criterion);
	static void _booleanOfSolidNodeList(LDNISolidNode *&aNode, LDNISolidNode *&bNode, short nOperationType);
	static bool _detectNodeOverlap(double depth, LDNISolidNode *solidNode);

	//-------------------------------------------------------------------------------------------------------------------------
	//	The service functions for converting volume data into LDNISolid
	static void _processingDepthOfLDNISolid(LDNISolid *solid);
	static void _processingDepthOfLDNISolidParallel(LDNISolid *solid);
	static void _processingNormalOfLDNISolid(LDNISolid *solid);
	static void _approximateNormal(int ***indexArray, int xNum, int yNum, int zNum,
					int xIndex, int yIndex, int zIndex, int xIndex2, int yIndex2, int zIndex2, double normal[]);
	static void _searchNeighboringHermiteDataSet(double pp[], LDNISolid *solid, int discreteDelta, GLKObList *dataSet);
	static void _searchNeighboringHermiteDataSet(double pp[], int id, LDNISolid *solid, int discreteDelta, int &pntNum, double sp[], double hp[]);
	static void _deleteHermiteDataSet(GLKObList *dataSet);
	static double gaussianFunction(double x, double delta) {return exp(-(x*x)/(2.0*delta*delta));};
	static void _encodeNormal(double nx, double ny, double nz, short &ix, short &iy, short &iz);
	static void _normalCorrection(short nDir, bool bEnteringOrLeaving, short &ix, short &iy, short &iz);

	//-------------------------------------------------------------------------------------------------------------------------
	//	The service functions for offsetting
	static void _createSphereSolid(LDNISolid *solid, double cx, double cy, double cz, double rr,
					int &xLow, int &xUp, int &yLow, int &yUp, int &zLow, int &zUp);

	//-------------------------------------------------------------------------------------------------------------------------
	//	The service functions for parallel offsetting
	static bool _detectDepthValidForOffset(int pNum, double pDepth[], double rr, double depth, short nOperationType);
	static void _booleanOnSamples(short &aNum, double aDepth[], short aNx[], short aNy[], short aNz[],
					short bNum, double bDepth[], short bNx[], short bNy[], short bNz[], short nOperationType);

	//-------------------------------------------------------------------------------------------------------------------------
	//	The service functions for parallel Minkowski-Sum with a superellipsoid
	static bool _compRayIntersectSuperellipsoid(double rx, double ry, double rz, double ePara, double nPara, short nDir, double di, double dj, double &dd);
	static bool _compNormalAtSuperellipsoid(double fp[], double rx, double ry, double rz, double ePara, double nPara, double nv[]);

	//-------------------------------------------------------------------------------------------------------------------------
	//	The service functions for error evaluation
	static PQP_Model* _pqpInitialization(QMeshPatch *mesh);
	static double LDNISolidOperation::_distanceToPatch(PQP_Model *pqpModel, double queryPnt[], double closestPnt[]);
};

#endif
