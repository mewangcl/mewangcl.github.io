#include <stdio.h>
#include <malloc.h>
#include <math.h>
#include <time.h>
#include <omp.h>

#include "..\GLKLib\GLKObList.h"
#include "..\GLKLib\GLKMatrixLib.h"
#include "..\GLKLib\GLKGeometry.h"

#include "..\QMeshLib\QMeshPatch.h"
#include "..\QMeshLib\QMeshNode.h"
#include "..\QMeshLib\QMeshEdge.h"
#include "..\QMeshLib\QMeshFace.h"

#include "../PQP/PQP.h"

#include "LDNISolid.h"
#include "LDNISolidSampling.h"
#include "LDNISolidContouring.h"

#include "LDNISolidUniformContouring.h"
#include "LDNISolidOperation.h"

/*
#ifdef _DEBUG	// for detecting memory leak, using this - you need to use MFC DLL setting in compiling
#include <afx.h>         // MFC core and standard components
#define new DEBUG_NEW
#endif
*/

#define LOGIC_UNION(insideA, insideB)	(insideA || insideB)
#define LOGIC_INTER(insideA, insideB)	(insideA && insideB)
#define LOGIC_SUBTR(insideA, insideB)	(insideA && (!insideB))

#define MAX_LDNI_LAYER_NUMBER	512		//	should be at least twice the resolution
#define MAX_NEIGHBOR_NUMBER		100		
#define DELTA_G_OF_GAUSSIAN		0.25

//#define	COMP_NORMALBYEQUATION	true

LDNISolidOperation::LDNISolidOperation(void)
{
}

LDNISolidOperation::~LDNISolidOperation(void)
{
}

void LDNISolidOperation::ParallelMinkowskiSumSuperellipsoid(LDNISolid* solid, LDNISolid* &newSolid, 
															double rx, double ry, double rz, double ePara, double nPara)
{
	int nDir,res=solid->GetResolution();	
	short nOperation;
	double origin[3],rr[3],gwidth=solid->GetGridWidth();
	int nOff[3];

	rr[0]=fabs(rx);	rr[1]=fabs(ry);	rr[2]=fabs(rz);
	for(short index=0;index<3;index++) nOff[index]=(int)(rr[index]/gwidth);

	//--------------------------------------------------------------------------------------------------------
	//	Step 1: preparation where the domain of newSolid is not changed
	solid->GetOrigin(origin);
	newSolid=new LDNISolid;	
	newSolid->MallocMemoryOfSolidNodeArray(res);
	newSolid->SetGridWidth(gwidth);
	newSolid->SetOrigin(origin);
	nOperation=0;	if (rx<0.0 || ry<0.0 || rz<0.0) nOperation=2;

	//--------------------------------------------------------------------------------------------------------
	//	Step 2: for each ray determine its corresponding segments
	int newNum=res*res;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
	for(nDir=0;nDir<3;nDir++) {
#pragma omp parallel for schedule(dynamic) 
		for(int k=0;k<newNum;k++) {
			int i=k/res;	int j=k%res;
			int ii,jj,kk;	short sampleNum;
			double depth,di,dj,dd,nv[3];
			double sampleDepth[2];	short sampleNv[3][2];
			double pDepth[MAX_LDNI_LAYER_NUMBER];	short pNum;	
			short pNx[MAX_LDNI_LAYER_NUMBER],pNy[MAX_LDNI_LAYER_NUMBER],pNz[MAX_LDNI_LAYER_NUMBER];
			
			//------------------------------------------------------------------------------------------------
			//	copy the sample on the overlapped ray
			ii=i;	jj=j;	pNum=0;
			LDNISolidNode *currentNode=solid->GetLDNISolidNode(nDir,ii,jj);
			if (currentNode) {
				pNum=currentNode->GetSampleNum(); 
				for(kk=0;kk<pNum;kk++) {
					pDepth[kk]=currentNode->GetDepth(kk);	
					currentNode->GetNormal(kk,pNx[kk],pNy[kk],pNz[kk]);
				}
			}

			//------------------------------------------------------------------------------------------------
			//	candidate samples on rays along the same direction
			for(ii=i-nOff[(nDir+1)%3];ii<=i+nOff[(nDir+1)%3];ii++) {
				for(jj=j-nOff[(nDir+2)%3];jj<=j+nOff[(nDir+2)%3];jj++) {
					LDNISolidNode *currentNode=solid->GetLDNISolidNode(nDir,ii,jj);
					if (currentNode==NULL) continue;
					sampleNum=currentNode->GetSampleNum(); 
					di=gwidth*(double)(i-ii);	dj=gwidth*(double)(j-jj);
					if (!(_compRayIntersectSuperellipsoid(rr[0],rr[1],rr[2],ePara,nPara,nDir,di,dj,dd))) continue;
					for(kk=0;kk<sampleNum;kk++) {
						depth=currentNode->GetDepth(kk);

						//------------------------------------------------------------------------------------
						//	sample1: depth-dd;
						sampleDepth[0]=depth-dd;
#ifdef COMP_NORMALBYEQUATION
						double fp[3];	fp[nDir]=-dd;	fp[(nDir+1)%3]=di;	fp[(nDir+2)%3]=dj;
						if (!(_compNormalAtSuperellipsoid(fp,rr[0],rr[1],rr[2],ePara,nPara,nv))) {
							nv[0]=nv[1]=nv[2]=0.0;	nv[nDir]=-1.0;
						}
#else
						nv[0]=nv[1]=nv[2]=0.0;	nv[nDir]=-1.0;
#endif
						sampleNv[0][0]=(short)((nv[0]+1.0)*127.5);
						sampleNv[1][0]=(short)((nv[1]+1.0)*127.5);
						sampleNv[2][0]=(short)((nv[2]+1.0)*127.5);

						//------------------------------------------------------------------------------------
						//	sample2: depth+dd;
						sampleDepth[1]=depth+dd;
						nv[nDir]=-nv[nDir];
						sampleNv[0][1]=(short)((nv[0]+1.0)*127.5);
						sampleNv[1][1]=(short)((nv[1]+1.0)*127.5);
						sampleNv[2][1]=(short)((nv[2]+1.0)*127.5);

						//------------------------------------------------------------------------------------
						//	marging into the ray samples
						_booleanOnSamples(pNum,pDepth,pNx,pNy,pNz,
							2,sampleDepth,sampleNv[0],sampleNv[1],sampleNv[2],nOperation);
					}
				}
			}

			//------------------------------------------------------------------------------------------------
			//	candidate samples on perpendicular-rays
			//------------------------------------------------------------------------------------------------
			//	the rays at the (nCase+1) direction
			for(ii=j-nOff[(nDir+2)%3];ii<=j+nOff[(nDir+2)%3];ii++) {
				for(jj=0;jj<res;jj++) {
					LDNISolidNode *currentNode=solid->GetLDNISolidNode((nDir+1)%3,ii,jj);
					if (currentNode==NULL) continue;
					depth=gwidth*(double)jj;
					if (!_detectDepthValidForOffset(pNum,pDepth,rr[nDir],depth,nOperation)) continue;

					sampleNum=currentNode->GetSampleNum(); 
					for(kk=0;kk<sampleNum;kk++) {
						double di=currentNode->GetDepth(kk);
						di=(gwidth*(double)i)-di;		dj=gwidth*(double)(j-ii);
						if (!(_compRayIntersectSuperellipsoid(rr[0],rr[1],rr[2],ePara,nPara,nDir,di,dj,dd))) continue;

						//------------------------------------------------------------------------------------
						//	sample1: depth-dd;
						sampleDepth[0]=depth-dd;
#ifdef COMP_NORMALBYEQUATION
						double fp[3];	fp[nDir]=-dd;	fp[(nDir+1)%3]=di;	fp[(nDir+2)%3]=dj;
						if (!(_compNormalAtSuperellipsoid(fp,rr[0],rr[1],rr[2],ePara,nPara,nv))) {
							nv[0]=nv[1]=nv[2]=0.0;	nv[nDir]=-1.0;
						}
#else
						nv[0]=nv[1]=nv[2]=0.0;	nv[nDir]=-1.0;
#endif
						sampleNv[0][0]=(short)((nv[0]+1.0)*127.5);
						sampleNv[1][0]=(short)((nv[1]+1.0)*127.5);
						sampleNv[2][0]=(short)((nv[2]+1.0)*127.5);

						//------------------------------------------------------------------------------------
						//	sample2: depth+dd;
						sampleDepth[1]=depth+dd;
						nv[nDir]=-nv[nDir];
						sampleNv[0][1]=(short)((nv[0]+1.0)*127.5);
						sampleNv[1][1]=(short)((nv[1]+1.0)*127.5);
						sampleNv[2][1]=(short)((nv[2]+1.0)*127.5);

						//------------------------------------------------------------------------------------
						//	marging into the ray samples
						_booleanOnSamples(pNum,pDepth,pNx,pNy,pNz,
							2,sampleDepth,sampleNv[0],sampleNv[1],sampleNv[2],nOperation);
					}
				}
			}

			//------------------------------------------------------------------------------------------------
			//	candidate samples on perpendicular-rays
			//------------------------------------------------------------------------------------------------
			//	the rays at the (nCase+2) direction
			for(ii=0;ii<res;ii++) {
				for(jj=i-nOff[(nDir+1)%3];jj<=i+nOff[(nDir+1)%3];jj++) {
					LDNISolidNode *currentNode=solid->GetLDNISolidNode((nDir+2)%3,ii,jj);
					if (currentNode==NULL) continue;
					depth=gwidth*(double)ii;
					if (!_detectDepthValidForOffset(pNum,pDepth,rr[nDir],depth,nOperation)) continue;

					sampleNum=currentNode->GetSampleNum(); 
					for(kk=0;kk<sampleNum;kk++) {
						double dj=currentNode->GetDepth(kk);
						dj=(gwidth*(double)j)-dj;		di=gwidth*(double)(i-jj);
						if (!(_compRayIntersectSuperellipsoid(rr[0],rr[1],rr[2],ePara,nPara,nDir,di,dj,dd))) continue;

						//------------------------------------------------------------------------------------
						//	sample1: depth-dd;
						sampleDepth[0]=depth-dd;
#ifdef COMP_NORMALBYEQUATION
						double fp[3];	fp[nDir]=-dd;	fp[(nDir+1)%3]=di;	fp[(nDir+2)%3]=dj;
						if (!(_compNormalAtSuperellipsoid(fp,rr[0],rr[1],rr[2],ePara,nPara,nv))) {
							nv[0]=nv[1]=nv[2]=0.0;	nv[nDir]=-1.0;
						}
#else
						nv[0]=nv[1]=nv[2]=0.0;	nv[nDir]=-1.0;
#endif
						sampleNv[0][0]=(short)((nv[0]+1.0)*127.5);
						sampleNv[1][0]=(short)((nv[1]+1.0)*127.5);
						sampleNv[2][0]=(short)((nv[2]+1.0)*127.5);

						//------------------------------------------------------------------------------------
						//	sample2: depth+dd;
						sampleDepth[1]=depth+dd;
						nv[nDir]=-nv[nDir];
						sampleNv[0][1]=(short)((nv[0]+1.0)*127.5);
						sampleNv[1][1]=(short)((nv[1]+1.0)*127.5);
						sampleNv[2][1]=(short)((nv[2]+1.0)*127.5);

						//------------------------------------------------------------------------------------
						//	marging into the ray samples
						_booleanOnSamples(pNum,pDepth,pNx,pNy,pNz,
							2,sampleDepth,sampleNv[0],sampleNv[1],sampleNv[2],nOperation);
					}
				}
			}

			//------------------------------------------------------------------------------------------------
			//	create the LDNISolidNode for this ray
			if (pNum>0) {
				//--------------------------------------------------------------------------------------------
				//	elliminating the gaps whose size is less than gwidth
				short pNewNum,pIndex[MAX_LDNI_LAYER_NUMBER];
				pNewNum=1;	pIndex[0]=0;
				for(kk=1;kk<pNum-1;kk+=2) {
					if ((pDepth[kk+1]-pDepth[kk])<gwidth) continue;
					pIndex[pNewNum]=kk;			pNewNum++;
					pIndex[pNewNum]=kk+1;		pNewNum++;
				}
				pIndex[pNewNum]=pNum-1;	pNewNum++;

				//--------------------------------------------------------------------------------------------
				//	copying into the LDNISolidNode
				LDNISolidNode *newNode=new LDNISolidNode;
				newNode->MallocSampleArray(pNewNum);
				for(kk=0;kk<pNewNum;kk++) {
					newNode->SetDepth(kk,(float)(pDepth[pIndex[kk]]));
					newNode->SetNormal(kk,pNx[pIndex[kk]],pNy[pIndex[kk]],pNz[pIndex[kk]]);
				}
				newSolid->SetLDNISolidNode(nDir,i,j,newNode);

				//LDNISolidNode *newNode=new LDNISolidNode;
				//newNode->MallocSampleArray(pNum);
				//for(kk=0;kk<pNum;kk++) {
				//	newNode->SetDepth(kk,(float)(pDepth[kk]));
				//	newNode->SetNormal(kk,pNx[kk],pNy[kk],pNz[kk]);
				//}
				//newSolid->SetLDNISolidNode(nDir,i,j,newNode);
			}
		}
	}

#ifndef COMP_NORMALBYEQUATION
	ParallelComputingNormalOfLDNISolid(newSolid);
#endif
}

void LDNISolidOperation::ParallelGeneralOffsetting(LDNISolid* solid, LDNISolid* &newSolid, 
												   int indexOfProcessingSolid, double *offset)
{
	int nCase,nOff,materialTypeNum,index,res=solid->GetResolution();	
	double origin[3],gwidth=solid->GetGridWidth();
	short nOperation;

	materialTypeNum=solid->GetMaterialTypeNum();
	double maxR=0.0;
	for(index=0;index<=materialTypeNum;index++) {if (fabs(offset[index])>maxR) maxR=fabs(offset[index]);}

	solid->GetOrigin(origin);	double boundingBox[6];
	boundingBox[0]=origin[0]-maxR-gwidth;
	boundingBox[1]=origin[0]+maxR+gwidth*(double)res;
	boundingBox[2]=origin[1]-maxR-gwidth;
	boundingBox[3]=origin[1]+maxR+gwidth*(double)res;
	boundingBox[4]=origin[2]-maxR-gwidth;
	boundingBox[5]=origin[2]+maxR+gwidth*(double)res;
	solid->ExpansionByNewBoundingBox(boundingBox);
	res=solid->GetResolution();

	//--------------------------------------------------------------------------------------------------------
	//	Step 1: preparation where the domain of newSolid is not changed
	solid->GetOrigin(origin);
	newSolid=new LDNISolid;	
	newSolid->MallocMemoryOfSolidNodeArray(res);
	newSolid->SetGridWidth(gwidth);
	newSolid->SetOrigin(origin);	newSolid->SetMaterialTypeNum(1);
	nOff=(int)(maxR/gwidth);

	nOperation=0;
	if (offset[0]<0.0) nOperation=2;

	//--------------------------------------------------------------------------------------------------------
	//	Step 2: for each ray determine its corresponding segments
	int newNum=res*res;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
	for(nCase=0;nCase<3;nCase++) {
#pragma omp parallel for schedule(dynamic) 
		for(int k=0;k<newNum;k++) {
			int i=k/res;	int j=k%res;
			int ii,jj,kk;	short sampleNum;
			double depth,di,dj,dd,rr2,rr;
			double sampleDepth[2];	short sampleNv[3][2];
			double pDepth[MAX_LDNI_LAYER_NUMBER];	short pNum;	
			short pNx[MAX_LDNI_LAYER_NUMBER],pNy[MAX_LDNI_LAYER_NUMBER],pNz[MAX_LDNI_LAYER_NUMBER];
			
			//------------------------------------------------------------------------------------------------
			//	copy the sample on the overlapped ray
			ii=i;	jj=j;	pNum=0;
			LDNISolidNode *currentNode=solid->GetLDNISolidNode(nCase,ii,jj);
			if (currentNode) {
				int num=currentNode->GetSampleNum(); 
				for(kk=0;kk<num;kk++) {
					int id=currentNode->GetID(kk);		int iID,jID;
					iID=id/(materialTypeNum+1);	jID=id%(materialTypeNum+1);
					if (iID==indexOfProcessingSolid || jID==indexOfProcessingSolid) {
						pDepth[pNum]=currentNode->GetDepth(kk);	
						currentNode->GetNormal(kk,pNx[pNum],pNy[pNum],pNz[pNum]);
						pNum++;
					}
				}
			}

			//------------------------------------------------------------------------------------------------
			//	candidate samples on rays along the same direction
			for(ii=i-nOff;ii<=i+nOff;ii++) {
				for(jj=j-nOff;jj<=j+nOff;jj++) {
					LDNISolidNode *currentNode=solid->GetLDNISolidNode(nCase,ii,jj);
					if (currentNode==NULL) continue;
					sampleNum=currentNode->GetSampleNum(); 
					di=gwidth*(double)(i-ii);	dj=gwidth*(double)(j-jj);
					for(kk=0;kk<sampleNum;kk++) {
						int id=currentNode->GetID(kk);		int iID,jID,otherID;
						iID=id/(materialTypeNum+1);	jID=id%(materialTypeNum+1);
						if (!(iID==indexOfProcessingSolid || jID==indexOfProcessingSolid)) continue;
						if (iID==indexOfProcessingSolid) otherID=jID; else otherID=iID;
						rr=fabs(offset[otherID]);	rr2=rr*rr;

						depth=currentNode->GetDepth(kk);
						dd=rr2-di*di-dj*dj;
						if (dd<=0.0) continue;
						dd=sqrt(dd);

						//------------------------------------------------------------------------------------
						//	sample1: depth-dd;
						sampleDepth[0]=depth-dd;
						sampleNv[nCase][0]=(short)((-dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][0]=(short)((di/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][0]=(short)((dj/rr+1.0)*127.5);

						//------------------------------------------------------------------------------------
						//	sample2: depth+dd;
						sampleDepth[1]=depth+dd;
						sampleNv[nCase][1]=(short)((dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][1]=(short)((di/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][1]=(short)((dj/rr+1.0)*127.5);

						//------------------------------------------------------------------------------------
						//	marging into the ray samples
						_booleanOnSamples(pNum,pDepth,pNx,pNy,pNz,
							2,sampleDepth,sampleNv[0],sampleNv[1],sampleNv[2],nOperation);
					}
				}
			}

			//------------------------------------------------------------------------------------------------
			//	candidate samples on perpendicular-rays
			//------------------------------------------------------------------------------------------------
			//	the rays at the (nCase+1) direction
			for(ii=j-nOff;ii<=j+nOff;ii++) {
				for(jj=0;jj<res;jj++) {
					LDNISolidNode *currentNode=solid->GetLDNISolidNode((nCase+1)%3,ii,jj);
					if (currentNode==NULL) continue;
					depth=gwidth*(double)jj;
//					if (!_detectDepthValidForOffset(pNum,pDepth,maxR,depth,nOperation)) continue;

					sampleNum=currentNode->GetSampleNum(); 
					for(kk=0;kk<sampleNum;kk++) {
						int id=currentNode->GetID(kk);		int iID,jID,otherID;
						iID=id/(materialTypeNum+1);	jID=id%(materialTypeNum+1);
						if (!(iID==indexOfProcessingSolid || jID==indexOfProcessingSolid)) continue;
						if (iID==indexOfProcessingSolid) otherID=jID; else otherID=iID;
						rr=fabs(offset[otherID]);	rr2=rr*rr;

						double ddd=currentNode->GetDepth(kk);
						ddd=(gwidth*(double)i)-ddd;		dj=gwidth*(double)(j-ii);
						dd=rr2-ddd*ddd-dj*dj;
						if (dd<=0.0) continue;
						dd=sqrt(dd);

						//------------------------------------------------------------------------------------
						//	sample1: depth-dd;
						sampleDepth[0]=depth-dd;
						sampleNv[nCase][0]=(short)((-dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][0]=(short)((ddd/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][0]=(short)((dj/rr+1.0)*127.5);
						//sampleNv[nCase][0]=(short)((-1.0+1.0)*127.5);	sampleNv[(nCase+1)%3][0]=sampleNv[(nCase+2)%3][0]=127;

						//------------------------------------------------------------------------------------
						//	sample2: depth+dd;
						sampleDepth[1]=depth+dd;
						sampleNv[nCase][1]=(short)((dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][1]=(short)((ddd/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][1]=(short)((dj/rr+1.0)*127.5);
						//sampleNv[nCase][1]=(short)((1.0+1.0)*127.5);	sampleNv[(nCase+1)%3][1]=sampleNv[(nCase+2)%3][1]=127;

						//------------------------------------------------------------------------------------
						//	marging into the ray samples
						_booleanOnSamples(pNum,pDepth,pNx,pNy,pNz,
							2,sampleDepth,sampleNv[0],sampleNv[1],sampleNv[2],nOperation);
					}
				}
			}

			//------------------------------------------------------------------------------------------------
			//	candidate samples on perpendicular-rays
			//------------------------------------------------------------------------------------------------
			//	the rays at the (nCase+2) direction
			for(ii=0;ii<res;ii++) {
				for(jj=i-nOff;jj<=i+nOff;jj++) {
					LDNISolidNode *currentNode=solid->GetLDNISolidNode((nCase+2)%3,ii,jj);
					if (currentNode==NULL) continue;
					depth=gwidth*(double)ii;
//					if (!_detectDepthValidForOffset(pNum,pDepth,maxR,depth,nOperation)) continue;

					sampleNum=currentNode->GetSampleNum(); 
					for(kk=0;kk<sampleNum;kk++) {
						int id=currentNode->GetID(kk);		int iID,jID,otherID;
						iID=id/(materialTypeNum+1);	jID=id%(materialTypeNum+1);
						if (!(iID==indexOfProcessingSolid || jID==indexOfProcessingSolid)) continue;
						if (iID==indexOfProcessingSolid) otherID=jID; else otherID=iID;
						rr=fabs(offset[otherID]);	rr2=rr*rr;

						double ddd=currentNode->GetDepth(kk);
						ddd=(gwidth*(double)j)-ddd;		di=gwidth*(double)(i-jj);
						dd=rr2-ddd*ddd-di*di;
						if (dd<=0.0) continue;
						dd=sqrt(dd);

						//------------------------------------------------------------------------------------
						//	sample1: depth-dd;
						sampleDepth[0]=depth-dd;
						sampleNv[nCase][0]=(short)((-dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][0]=(short)((di/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][0]=(short)((ddd/rr+1.0)*127.5);
						//sampleNv[nCase][0]=(short)((-1.0+1.0)*127.5);	sampleNv[(nCase+1)%3][0]=sampleNv[(nCase+2)%3][0]=127;

						//------------------------------------------------------------------------------------
						//	sample2: depth+dd;
						sampleDepth[1]=depth+dd;
						sampleNv[nCase][1]=(short)((dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][1]=(short)((di/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][1]=(short)((ddd/rr+1.0)*127.5);
						//sampleNv[nCase][1]=(short)((1.0+1.0)*127.5);	sampleNv[(nCase+1)%3][1]=sampleNv[(nCase+2)%3][1]=127;

						//------------------------------------------------------------------------------------
						//	marging into the ray samples
						_booleanOnSamples(pNum,pDepth,pNx,pNy,pNz,
							2,sampleDepth,sampleNv[0],sampleNv[1],sampleNv[2],nOperation);
					}
				}
			}

			//------------------------------------------------------------------------------------------------
			//	create the LDNISolidNode for this ray
			if (pNum>0) {
				LDNISolidNode *newNode=new LDNISolidNode;
				newNode->MallocSampleArray(pNum);
				for(kk=0;kk<pNum;kk++) {
					newNode->SetDepth(kk,(float)(pDepth[kk]));
					newNode->SetNormal(kk,pNx[kk],pNy[kk],pNz[kk]);
					if (kk%2==0)
						newNode->SetID(kk,1);
					else
						newNode->SetID(kk,2);
				}
				newSolid->SetLDNISolidNode(nCase,i,j,newNode);

			}
		}
	}	
}

void LDNISolidOperation::ParallelSolidOffsetting(LDNISolid* solid, LDNISolid* &newSolid, double offset)
{
	int nCase,res=solid->GetResolution();	
	double origin[3],gwidth=solid->GetGridWidth(),rr2,rr=fabs(offset);
	int nOff=(int)(rr/gwidth);
	short nOperation;

	//--------------------------------------------------------------------------------------------------------
	//	Step 1: preparation where the domain of newSolid is not changed
	solid->GetOrigin(origin);
	newSolid=new LDNISolid;	
	newSolid->MallocMemoryOfSolidNodeArray(res);
	newSolid->SetGridWidth(gwidth);
	newSolid->SetOrigin(origin);
	rr2=offset*offset;

	nOperation=0;
	if (offset<0.0) nOperation=2;

	//--------------------------------------------------------------------------------------------------------
	//	Step 2: for each ray determine its corresponding segments
	int newNum=res*res;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
	for(nCase=0;nCase<3;nCase++) {
#pragma omp parallel for schedule(dynamic) 
		for(int k=0;k<newNum;k++) {
			int i=k/res;	int j=k%res;
			int ii,jj,kk;	short sampleNum;
			double depth,di,dj,dd;
			double sampleDepth[2];	short sampleNv[3][2];
			double pDepth[MAX_LDNI_LAYER_NUMBER];	short pNum;	
			short pNx[MAX_LDNI_LAYER_NUMBER],pNy[MAX_LDNI_LAYER_NUMBER],pNz[MAX_LDNI_LAYER_NUMBER];
			
			//------------------------------------------------------------------------------------------------
			//	copy the sample on the overlapped ray
			ii=i;	jj=j;	pNum=0;
			LDNISolidNode *currentNode=solid->GetLDNISolidNode(nCase,ii,jj);
			if (currentNode) {
				pNum=currentNode->GetSampleNum(); 
				for(kk=0;kk<pNum;kk++) {
					pDepth[kk]=currentNode->GetDepth(kk);	
					currentNode->GetNormal(kk,pNx[kk],pNy[kk],pNz[kk]);
				}
			}

			//------------------------------------------------------------------------------------------------
			//	candidate samples on rays along the same direction
			for(ii=i-nOff;ii<=i+nOff;ii++) {
				for(jj=j-nOff;jj<=j+nOff;jj++) {
					LDNISolidNode *currentNode=solid->GetLDNISolidNode(nCase,ii,jj);
					if (currentNode==NULL) continue;
					sampleNum=currentNode->GetSampleNum(); 
					di=gwidth*(double)(i-ii);	dj=gwidth*(double)(j-jj);
					dd=rr2-di*di-dj*dj;
					if (dd<=0.0) continue;
					dd=sqrt(dd);
					for(kk=0;kk<sampleNum;kk++) {
						depth=currentNode->GetDepth(kk);
//						if (!_detectDepthValidForOffset(pNum,pDepth,rr,depth,nOperation)) continue;

						//------------------------------------------------------------------------------------
						//	sample1: depth-dd;
						sampleDepth[0]=depth-dd;
						sampleNv[nCase][0]=(short)((-dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][0]=(short)((di/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][0]=(short)((dj/rr+1.0)*127.5);

						//------------------------------------------------------------------------------------
						//	sample2: depth+dd;
						sampleDepth[1]=depth+dd;
						sampleNv[nCase][1]=(short)((dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][1]=(short)((di/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][1]=(short)((dj/rr+1.0)*127.5);

						//------------------------------------------------------------------------------------
						//	marging into the ray samples
						_booleanOnSamples(pNum,pDepth,pNx,pNy,pNz,
							2,sampleDepth,sampleNv[0],sampleNv[1],sampleNv[2],nOperation);
					}
				}
			}

			//------------------------------------------------------------------------------------------------
			//	candidate samples on perpendicular-rays
			//------------------------------------------------------------------------------------------------
			//	the rays at the (nCase+1) direction
			for(jj=0;jj<res;jj++) {
				depth=gwidth*(double)jj;
				if (!_detectDepthValidForOffset(pNum,pDepth,rr,depth,nOperation)) continue;
				for(ii=j-nOff;ii<=j+nOff;ii++) {
					LDNISolidNode *currentNode=solid->GetLDNISolidNode((nCase+1)%3,ii,jj);
					if (currentNode==NULL) continue;

					sampleNum=currentNode->GetSampleNum(); 
					for(kk=0;kk<sampleNum;kk++) {
						double ddd=currentNode->GetDepth(kk);
						ddd=(gwidth*(double)i)-ddd;		dj=gwidth*(double)(j-ii);
						dd=rr2-ddd*ddd-dj*dj;
						if (dd<=0.0) continue;
						dd=sqrt(dd);

						//------------------------------------------------------------------------------------
						//	sample1: depth-dd;
						sampleDepth[0]=depth-dd;
						sampleNv[nCase][0]=(short)((-dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][0]=(short)((ddd/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][0]=(short)((dj/rr+1.0)*127.5);
						//sampleNv[nCase][0]=(short)((-1.0+1.0)*127.5);	sampleNv[(nCase+1)%3][0]=sampleNv[(nCase+2)%3][0]=127;

						//------------------------------------------------------------------------------------
						//	sample2: depth+dd;
						sampleDepth[1]=depth+dd;
						sampleNv[nCase][1]=(short)((dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][1]=(short)((ddd/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][1]=(short)((dj/rr+1.0)*127.5);
						//sampleNv[nCase][1]=(short)((1.0+1.0)*127.5);	sampleNv[(nCase+1)%3][1]=sampleNv[(nCase+2)%3][1]=127;

						//------------------------------------------------------------------------------------
						//	marging into the ray samples
						_booleanOnSamples(pNum,pDepth,pNx,pNy,pNz,
							2,sampleDepth,sampleNv[0],sampleNv[1],sampleNv[2],nOperation);
					}
				}
			}

			//------------------------------------------------------------------------------------------------
			//	candidate samples on perpendicular-rays
			//------------------------------------------------------------------------------------------------
			//	the rays at the (nCase+2) direction
			for(ii=0;ii<res;ii++) {
				depth=gwidth*(double)ii;
				if (!_detectDepthValidForOffset(pNum,pDepth,rr,depth,nOperation)) continue;
				for(jj=i-nOff;jj<=i+nOff;jj++) {
					LDNISolidNode *currentNode=solid->GetLDNISolidNode((nCase+2)%3,ii,jj);
					if (currentNode==NULL) continue;

					sampleNum=currentNode->GetSampleNum(); 
					for(kk=0;kk<sampleNum;kk++) {
						double ddd=currentNode->GetDepth(kk);
						ddd=(gwidth*(double)j)-ddd;		di=gwidth*(double)(i-jj);
						dd=rr2-ddd*ddd-di*di;
						if (dd<=0.0) continue;
						dd=sqrt(dd);

						//------------------------------------------------------------------------------------
						//	sample1: depth-dd;
						sampleDepth[0]=depth-dd;
						sampleNv[nCase][0]=(short)((-dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][0]=(short)((di/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][0]=(short)((ddd/rr+1.0)*127.5);
						//sampleNv[nCase][0]=(short)((-1.0+1.0)*127.5);	sampleNv[(nCase+1)%3][0]=sampleNv[(nCase+2)%3][0]=127;

						//------------------------------------------------------------------------------------
						//	sample2: depth+dd;
						sampleDepth[1]=depth+dd;
						sampleNv[nCase][1]=(short)((dd/rr+1.0)*127.5);
						sampleNv[(nCase+1)%3][1]=(short)((di/rr+1.0)*127.5);
						sampleNv[(nCase+2)%3][1]=(short)((ddd/rr+1.0)*127.5);
						//sampleNv[nCase][1]=(short)((1.0+1.0)*127.5);	sampleNv[(nCase+1)%3][1]=sampleNv[(nCase+2)%3][1]=127;

						//------------------------------------------------------------------------------------
						//	marging into the ray samples
						_booleanOnSamples(pNum,pDepth,pNx,pNy,pNz,
							2,sampleDepth,sampleNv[0],sampleNv[1],sampleNv[2],nOperation);
					}
				}
			}

			//------------------------------------------------------------------------------------------------
			//	create the LDNISolidNode for this ray
			if (pNum>0) {
				LDNISolidNode *newNode=new LDNISolidNode;
				newNode->MallocSampleArray(pNum);
				for(kk=0;kk<pNum;kk++) {
					newNode->SetDepth(kk,(float)(pDepth[kk]));
					newNode->SetNormal(kk,pNx[kk],pNy[kk],pNz[kk]);
				}
				newSolid->SetLDNISolidNode(nCase,i,j,newNode);
			}
		}
	}	
}

void LDNISolidOperation::ParallelComputingNormalOfLDNISolid(LDNISolid *solid)
{
	int nCase,res;		short discreteDelta=_CCL_DISCRETE_SUPPORT;
	double gwidth,origin[3];

	//--------------------------------------------------------------------------------------------------------
	//	Step 1: preparation where the domain of newSolid is not changed
	gwidth=solid->GetGridWidth();	res=solid->GetResolution();
	solid->GetOrigin(origin);

	//--------------------------------------------------------------------------------------------------------
	//	Step 2: for each ray determine its corresponding segments
	int newNum=res*res;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
	for(nCase=0;nCase<3;nCase++) {
#pragma omp parallel for schedule(dynamic) 
		for(int kk=0;kk<newNum;kk++) {
			int i=kk/res;	int j=kk%res;

			LDNISolidNode *currentNode=solid->GetLDNISolidNode(nCase,i,j);
			if (!currentNode) continue;

			int num=currentNode->GetSampleNum();
			double normal[3],pp[3];
			int pntNum;	double sp[MAX_NEIGHBOR_NUMBER*3];	double hp[MAX_NEIGHBOR_NUMBER*3];
			int ii;	short snx,sny,snz;
			double cx,cy,cz,div,nx,ny,nz;
			for(int k=0;k<num;k++) {
				double depth=currentNode->GetDepth(k);
//				currentNode->GetNormal(k,normal[0],normal[1],normal[2]);
					
				switch(nCase) {
					case 0:{pp[0]=depth; pp[1]=gwidth*(double)i; pp[2]=gwidth*(double)j;
						   }break;
					case 1:{pp[0]=gwidth*(double)j; pp[1]=depth; pp[2]=gwidth*(double)i;
						   }break;
					case 2:{pp[0]=gwidth*(double)i; pp[1]=gwidth*(double)j; pp[2]=depth;
						   }break;
				}
				pp[0]+=origin[0];	pp[1]+=origin[1];	pp[2]+=origin[2];
				_searchNeighboringHermiteDataSet(pp,currentNode->GetID(k),solid,discreteDelta,pntNum,sp,hp);
				if (pntNum==0) continue;

				normal[0]=normal[1]=normal[2]=0;
				if (k%2==1) normal[nCase]=1.0; else normal[nCase]=-1.0;

				//--------------------------------------------------------------------------------
				//	Computing the normal vector by the eigenvalue decomposition of the covariant matrix
				cx=cy=cz=0.0;
				for(ii=0;ii<pntNum;ii++) {cx+=sp[ii*3];	cy+=sp[ii*3+1];	cz+=sp[ii*3+2];}
				div=1.0/(double)(pntNum);	cx=cx*div;	cy=cy*div;	cz=cz*div;
				
				double **covariantM,**eigenvectors,*eigenvalues;
				
				GLKMatrixLib::CreateMatrix(covariantM,3,3);
				GLKMatrixLib::CreateMatrix(eigenvectors,3,3);
				eigenvalues=new double[3];
				for(ii=0;ii<pntNum;ii++) {
					covariantM[0][0]+=(sp[ii*3]-cx)*(sp[ii*3]-cx);		covariantM[0][1]+=(sp[ii*3]-cx)*(sp[ii*3+1]-cy);	covariantM[0][2]+=(sp[ii*3]-cx)*(sp[ii*3+2]-cz);
					covariantM[1][1]+=(sp[ii*3+1]-cy)*(sp[ii*3+1]-cy);	covariantM[1][2]+=(sp[ii*3+1]-cy)*(sp[ii*3+2]-cz);
					covariantM[2][2]+=(sp[ii*3+2]-cz)*(sp[ii*3+2]-cz);
				}
				covariantM[1][0]=covariantM[0][1];	covariantM[2][0]=covariantM[0][2]; 	covariantM[2][1]=covariantM[1][2];		

				if (GLKMatrixLib::JacobianEigensystemSolver(covariantM,3,eigenvectors,eigenvalues,1.0e-7,100)) {
					int minIndex=0;		double minValue=fabs(eigenvalues[0]);
					if (fabs(eigenvalues[1])<minValue) {minValue=fabs(eigenvalues[1]);minIndex=1;}
					if (fabs(eigenvalues[2])<minValue) minIndex=2;
					nx=eigenvectors[0][minIndex];
					ny=eigenvectors[1][minIndex];
					nz=eigenvectors[2][minIndex];
					double dd=sqrt(nx*nx+ny*ny+nz*nz);
					if (dd>1.0e-5) {nx=nx/dd; ny=ny/dd; nz=nz/dd;} else {nx=ny=nz=0.0;}
					dd=nx*normal[0]+ny*normal[1]+nz*normal[2];
					if (dd>=0.0) {
						normal[0]=nx; normal[1]=ny; normal[2]=nz;
					}
					else {
						normal[0]=-nx; normal[1]=-ny; normal[2]=-nz;
					}
					snx=(short)((normal[0]+1.0)*127.5);
					sny=(short)((normal[1]+1.0)*127.5);
					snz=(short)((normal[2]+1.0)*127.5);
					currentNode->SetNormal(k,snx,sny,snz);
				}
				
				GLKMatrixLib::DeleteMatrix(covariantM,3,3);
				GLKMatrixLib::DeleteMatrix(eigenvectors,3,3);
				delete []eigenvalues;
			}
		}
	}
}

void LDNISolidOperation::ParallelProcessingNormalOfLDNISolid(LDNISolid *solid)
{
	int nCase,res;		short discreteDelta=_CCL_DISCRETE_SUPPORT;
	double gwidth,origin[3];

	//--------------------------------------------------------------------------------------------------------
	//	Step 1: preparation where the domain of newSolid is not changed
	gwidth=solid->GetGridWidth();	res=solid->GetResolution();
	solid->GetOrigin(origin);

	//--------------------------------------------------------------------------------------------------------
	//	Step 2: for each ray determine its corresponding segments
	int newNum=res*res;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
//	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
	for(nCase=0;nCase<3;nCase++) {
#pragma omp parallel for schedule(dynamic) 
		for(int kk=0;kk<newNum;kk++) {
			int i=kk/res;	int j=kk%res;

			LDNISolidNode *currentNode=solid->GetLDNISolidNode(nCase,i,j);
			if (!currentNode) continue;

			int num=currentNode->GetSampleNum();
			double normal[3],pp[3];
			int pntNum;	double sp[MAX_NEIGHBOR_NUMBER*3];	double hp[MAX_NEIGHBOR_NUMBER*3];
			for(int k=0;k<num;k++) {
				double depth=currentNode->GetDepth(k);
				currentNode->GetNormal(k,normal[0],normal[1],normal[2]);
					
				switch(nCase) {
					case 0:{pp[0]=depth; pp[1]=gwidth*(double)i; pp[2]=gwidth*(double)j;
						   }break;
					case 1:{pp[0]=gwidth*(double)j; pp[1]=depth; pp[2]=gwidth*(double)i;
						   }break;
					case 2:{pp[0]=gwidth*(double)i; pp[1]=gwidth*(double)j; pp[2]=depth;
						   }break;
				}
				pp[0]+=origin[0];	pp[1]+=origin[1];	pp[2]+=origin[2];
				_searchNeighboringHermiteDataSet(pp,currentNode->GetID(k),solid,discreteDelta,pntNum,sp,hp);

				//--------------------------------------------------------------------------------
				//	Processing the normal by using the Bilateral filtering
				double hh[3],kk,tt,ff,gg,dd;	short snx,sny,snz;
				hh[0]=hh[1]=hh[2]=kk=0.0;
				double deltaC=1.5*gwidth;	double deltaG=DELTA_G_OF_GAUSSIAN;//0.1;//25;
				for(int ii=0;ii<pntNum;ii++) {
					dd=sqrt((pp[0]-sp[ii*3])*(pp[0]-sp[ii*3])+(pp[1]-sp[ii*3+1])*(pp[1]-sp[ii*3+1])+(pp[2]-sp[ii*3+2])*(pp[2]-sp[ii*3+2]));
					tt=normal[0]*(normal[0]-hp[ii*3])+normal[1]*(normal[1]-hp[ii*3+1])+normal[2]*(normal[2]-hp[ii*3+2]);

					ff=gaussianFunction(dd,deltaC);	
					gg=gaussianFunction(tt,deltaG);

					hh[0]+=ff*gg*(hp[ii*3]);
					hh[1]+=ff*gg*(hp[ii*3+1]);
					hh[2]+=ff*gg*(hp[ii*3+2]);
					kk+=ff*gg;
				}

				if (fabs(kk)>1.0e-5) {hh[0]=hh[0]/kk; hh[1]=hh[1]/kk; hh[2]=hh[2]/kk;} else {hh[0]=hh[1]=hh[2]=0.0;}
				dd=sqrt(hh[0]*hh[0]+hh[1]*hh[1]+hh[2]*hh[2]);
				if (dd<1.0e-5) {hh[0]=hh[1]=hh[2]=0.0;} else {hh[0]=hh[0]/dd; hh[1]=hh[1]/dd; hh[2]=hh[2]/dd;}
				_encodeNormal(hh[0],hh[1],hh[2],snx,sny,snz);
				currentNode->SetNormal(k,snx,sny,snz);
			}
		}
	}
}

void LDNISolidOperation::_booleanOnSamples(short &aNum, double aDepth[], short aNx[], short aNy[], short aNz[],
										   short bNum, double bDepth[], short bNx[], short bNy[], short bNz[], short nOperationType)
{
	if (aNum>0 && bNum>0) {
		bool bInsideA,bInsideB,last_op,op;
		short aIndex,bIndex;
		short resultSampleNum=0;
		double lastDepth;	short lastNx,lastNy,lastNz;
		double resultDepth[MAX_LDNI_LAYER_NUMBER];	
		short resultNx[MAX_LDNI_LAYER_NUMBER],resultNy[MAX_LDNI_LAYER_NUMBER],resultNz[MAX_LDNI_LAYER_NUMBER];

//		printf("(%d %d %d) - (%d %d %d)\n",bNx[0],bNy[0],bNz[0],bNx[1],bNy[1],bNz[1]);

		bInsideA = bInsideB = false;
		switch(nOperationType) {
		case 0:{last_op=LOGIC_UNION(bInsideA,bInsideB); }break;	// Union		- "A U B"
		case 1:{last_op=LOGIC_INTER(bInsideA,bInsideB); }break;	// Intersection - "A n B"
		case 2:{last_op=LOGIC_SUBTR(bInsideA,bInsideB); }break;	// Substraction - "A \ B"
		}
		aIndex = bIndex = 0;

		while( (aIndex<aNum) || (bIndex<bNum) ) {
			if ((aIndex<aNum) && ((bIndex==bNum) || (aDepth[aIndex]<bDepth[bIndex]))) {
				lastDepth=aDepth[aIndex];	
				lastNx=aNx[aIndex];	lastNy=aNy[aIndex];	lastNz=aNz[aIndex];
				bInsideA=((aIndex%2)==0);	aIndex++;
			}
			else {
				lastDepth=bDepth[bIndex];	
				lastNx=bNx[bIndex];	lastNy=bNy[bIndex];	lastNz=bNz[bIndex];
				if (nOperationType==2) {lastNx=255-lastNx; lastNy=255-lastNy; lastNz=255-lastNz;}
				bInsideB=((bIndex%2)==0);	bIndex++;
			}

			switch(nOperationType) {
			case 0:{op=LOGIC_UNION(bInsideA,bInsideB); }break;
			case 1:{op=LOGIC_INTER(bInsideA,bInsideB); }break;
			case 2:{op=LOGIC_SUBTR(bInsideA,bInsideB); }break;
			}
			if (op!=last_op) {
				if (resultSampleNum>0 && fabs(lastDepth-resultDepth[resultSampleNum-1])<1.0e-5) {
					resultSampleNum--;
				}
				else {
					resultDepth[resultSampleNum]=lastDepth;	
					resultNx[resultSampleNum]=lastNx; resultNy[resultSampleNum]=lastNy; resultNz[resultSampleNum]=lastNz; 
					resultSampleNum++;
				}
				last_op=op;
			}
		}

		//---------------------------------------------------------------------------------------------------
		//	update the result samples
		if (resultSampleNum>0) {
			for(short k=0;k<resultSampleNum;k++) {
				aDepth[k]=resultDepth[k];
				aNx[k]=resultNx[k];		aNy[k]=resultNy[k];		aNz[k]=resultNz[k];
			}
		}
		aNum=resultSampleNum;
	}
	else if ((aNum==0) && (bNum>0)) {
		if (nOperationType==0) { // union
			aNum=bNum;
			for(short k=0;k<bNum;k++) {
				aDepth[k]=bDepth[k];	aNx[k]=bNx[k];	aNy[k]=bNy[k];	aNz[k]=bNz[k];
			}
		}
		// for "intersect" and "difference", keeping NULL will be fine
	}
	else if ((aNum>0) && (bNum==0)) {
		if (nOperationType==1) { // intersection
			aNum=0;
		}
	}
}

bool LDNISolidOperation::_compNormalAtSuperellipsoid(double fp[], double rx, double ry, double rz, double ePara, double nPara, double nv[])
{
	double xx,yy,tt,x2,y2,z2,rx2,ry2,rz2;

	rx2=rx*rx;				ry2=ry*ry;				rz2=rz*rz;	
	x2=fp[0]*fp[0]/rx2;		y2=fp[1]*fp[1]/ry2;		z2=fp[2]*fp[2]/rz2;
	xx=pow(x2,1.0/ePara);	yy=pow(y2,1.0/ePara);
	tt=pow(xx+yy,ePara/nPara-1.0);

	if (x2==0.0 && ePara>1.0) 
		nv[0]=0.0;
	else 
		nv[0]=2.0*fp[0]*pow(x2,1.0/ePara-1.0)*tt/(nPara*rx2); 
	if (y2==0.0 && ePara>1.0)
		nv[1]=0.0;
	else
		nv[1]=2.0*fp[1]*pow(y2,1.0/ePara-1.0)*tt/(nPara*ry2);
	if (z2==0.0 && nPara>1.0)
		nv[2]=0.0;
	else
		nv[2]=2.0*fp[2]*pow(z2,1.0/nPara-1.0)/(nPara*rz2);
	tt=nv[0]*nv[0]+nv[1]*nv[1]+nv[2]*nv[2];	tt=sqrt(tt);
	if (tt<1.0e-32) {
		nv[0]=fp[0];	nv[1]=fp[1];	nv[2]=fp[2];	
		tt=nv[0]*nv[0]+nv[1]*nv[1]+nv[2]*nv[2];	tt=sqrt(tt);
	}
	nv[0]=nv[0]/tt; nv[1]=nv[1]/tt; nv[2]=nv[2]/tt;

	return true;
}

bool LDNISolidOperation::_compRayIntersectSuperellipsoid(double rx, double ry, double rz, double ePara, double nPara, 											  
														 short nDir, double di, double dj, double &dd)
{
	switch(nDir) {
	case 0:{
		double yy,zz;
		yy=di/ry;	zz=dj/rz;	
		zz=1.0-pow(fabs(zz),2.0/nPara);	if (zz<0.0) return false;
		dd=pow(zz,nPara/ePara)-pow(fabs(yy),2.0/ePara);
		if (dd<0.0) return false;
		dd=rx*pow(dd,ePara*0.5);
	}break;
	case 1:{
		double zz,xx;
		zz=di/rz;	xx=dj/rx;
		zz=1.0-pow(fabs(zz),2.0/nPara);	if (zz<0.0) return false;
		dd=pow(zz,nPara/ePara)-pow(fabs(xx),2.0/ePara);
		if (dd<0.0) return false;
		dd=ry*pow(dd,ePara*0.5);
	}break;
	case 2:{
		double xx,yy,ed;
		xx=di/rx;	yy=dj/ry;	xx=xx*xx;	yy=yy*yy;
		ed=1.0/ePara;	xx=pow(xx,ed);	yy=pow(yy,ed);
		dd=1.0-pow(xx+yy,ePara/nPara);
		if (dd<0.0) return false;
		dd=rz*pow(dd,nPara*0.5);
	}break;
	}

	return true;
}

bool LDNISolidOperation::_detectDepthValidForOffset(int pNum, double pDepth[], double rr, double depth, short nOperationType)
{
	if (nOperationType==0) {	// for positive offsetting
		for(int k=0;k<pNum;k+=2) {
			if ((depth>pDepth[k]+rr) && (depth<pDepth[k+1]-rr)) return false;
		}
	}
	if (nOperationType==2) {	// for negative offsetting
		if ((pNum>0) && (depth<pDepth[0]-rr)) return false;
		for(int k=1;k<pNum;k+=2) {
			if ((depth>pDepth[k]+rr) && (depth<pDepth[k+1]-rr)) return false;
		}
	}

	return true;
}

void LDNISolidOperation::SolidOffsetting(LDNISolid* solid, LDNISolid* &newSolid, double offset)
{
	int nCase,res=solid->GetResolution();	
	double origin[3],delta,gwidth=solid->GetGridWidth();
	int nOff=(int)(fabs(offset)/gwidth);
	int xLow,xUp,yLow,yUp,zLow,zUp;
	LDNISolid *tempSolid;
	short nOperation;

	//--------------------------------------------------------------------------------------------------------
	//	Step 1: preparation
	solid->GetOrigin(origin);
	newSolid=new LDNISolid;	
	newSolid->MallocMemoryOfSolidNodeArray(res+nOff+nOff);
	newSolid->SetGridWidth(gwidth);
	delta=gwidth*(double)nOff;	origin[0]-=delta;	origin[1]-=delta;	origin[2]-=delta;
	newSolid->SetOrigin(origin);
	//--------------------------------------------------------------------------------------------------------
	tempSolid=new LDNISolid;
	tempSolid->MallocMemoryOfSolidNodeArray(res+nOff+nOff);
	tempSolid->SetGridWidth(gwidth);
	tempSolid->SetOrigin(origin);
	printf("nOff=%d\n",nOff);

	//--------------------------------------------------------------------------------------------------------
	//	Step 2: copy the solid
	for(nCase=0;nCase<3;nCase++) {
		for(int i=0;i<res;i++) {
			for(int j=0;j<res;j++) {
				LDNISolidNode *currentNode=solid->GetLDNISolidNode(nCase,i,j);
				if (currentNode==NULL) continue;

				short sampleNum=currentNode->GetSampleNum();
				if (sampleNum==0) continue;

				LDNISolidNode *newNode=new LDNISolidNode;
				newNode->MallocSampleArray(sampleNum);
				short nx,ny,nz;	double depth;
				for(int k=0;k<sampleNum;k++) {
					depth=currentNode->GetDepth(k);
					currentNode->GetNormal(k,nx,ny,nz);
					newNode->SetDepth(k,(float)(delta+depth));
					newNode->SetNormal(k,nx,ny,nz);
				}
				newSolid->SetLDNISolidNode(nCase,i+nOff,j+nOff,newNode);
			}
		}
	}

	//--------------------------------------------------------------------------------------------------------
	//	Step 3: for each sample in solid create a sphere and merging into newSolid
	nOperation=0;
	if (offset<0.0) nOperation=2;
	for(nCase=0;nCase<3;nCase++) {
		for(int i=0;i<res;i++) {
			for(int j=0;j<res;j++) {
				LDNISolidNode *currentNode=solid->GetLDNISolidNode(nCase,i,j);
				if (currentNode==NULL) continue;

				short sampleNum=currentNode->GetSampleNum();
				if (sampleNum==0) continue;
				for(int k=0;k<sampleNum;k++) {
					double cx,cy,cz;
					double depth=currentNode->GetDepth(k);
					switch(nCase) {
						case 0:{cx=origin[0]+delta+depth;
								cy=origin[1]+delta+gwidth*(double)i;
								cz=origin[2]+delta+gwidth*(double)j;
							   }break;
						case 1:{cx=origin[0]+delta+gwidth*(double)j;
								cy=origin[1]+delta+depth;
								cz=origin[2]+delta+gwidth*(double)i;
							   }break;
						case 2:{cx=origin[0]+delta+gwidth*(double)i;
								cy=origin[1]+delta+gwidth*(double)j;
								cz=origin[2]+delta+depth;
							   }break;
					}

					//--------------------------------------------------------------
					//	create solid sphere
					_createSphereSolid(tempSolid,cx,cy,cz,fabs(offset),xLow,xUp,yLow,yUp,zLow,zUp);

					//--------------------------------------------------------------
					//	merge solid spheres
					int ii,jj;
					for(ii=yLow;ii<=yUp;ii++) {
						for(jj=zLow;jj<=zUp;jj++) {
							LDNISolidNode *aNode=newSolid->GetLDNISolidNode(0,ii,jj);
							LDNISolidNode *bNode=tempSolid->GetLDNISolidNode(0,ii,jj);
							_booleanOfSolidNodeList(aNode,bNode,nOperation);
							newSolid->SetLDNISolidNode(0,ii,jj,aNode);
							tempSolid->SetLDNISolidNode(0,ii,jj,bNode);
						}
					}
					for(ii=zLow;ii<=zUp;ii++) {
						for(jj=xLow;jj<=xUp;jj++) {
							LDNISolidNode *aNode=newSolid->GetLDNISolidNode(1,ii,jj);
							LDNISolidNode *bNode=tempSolid->GetLDNISolidNode(1,ii,jj);
							_booleanOfSolidNodeList(aNode,bNode,nOperation);
							newSolid->SetLDNISolidNode(1,ii,jj,aNode);
							tempSolid->SetLDNISolidNode(1,ii,jj,bNode);
						}
					}
					for(ii=xLow;ii<=xUp;ii++) {
						for(jj=yLow;jj<=yUp;jj++) {
							LDNISolidNode *aNode=newSolid->GetLDNISolidNode(2,ii,jj);
							LDNISolidNode *bNode=tempSolid->GetLDNISolidNode(2,ii,jj);
							_booleanOfSolidNodeList(aNode,bNode,nOperation);
							newSolid->SetLDNISolidNode(2,ii,jj,aNode);
							tempSolid->SetLDNISolidNode(2,ii,jj,bNode);
						}
					}

					//--------------------------------------------------------------
					//	delete the LDNISolidNode
					for(ii=yLow;ii<=yUp;ii++) {
						for(jj=zLow;jj<=zUp;jj++) {
							LDNISolidNode *node=tempSolid->GetLDNISolidNode(0,ii,jj);
							if (node) {delete node;	tempSolid->SetLDNISolidNode(0,ii,jj,NULL);}
						}
					}
					for(ii=zLow;ii<=zUp;ii++) {
						for(jj=xLow;jj<=xUp;jj++) {
							LDNISolidNode *node=tempSolid->GetLDNISolidNode(1,ii,jj);
							if (node) {delete node;	tempSolid->SetLDNISolidNode(1,ii,jj,NULL);}
						}
					}
					for(ii=xLow;ii<=xUp;ii++) {
						for(jj=yLow;jj<=yUp;jj++) {
							LDNISolidNode *node=tempSolid->GetLDNISolidNode(2,ii,jj);
							if (node) {delete node;	tempSolid->SetLDNISolidNode(2,ii,jj,NULL);}
						}
					}
				}
			}
		}		
	}

	//--------------------------------------------------------------------------------------------------------
	//	Step 3: free the memory
	delete tempSolid;

//	_processingNormalOfLDNISolid(newSolid);
}

void LDNISolidOperation::_createSphereSolid(LDNISolid *solid, double cx, double cy, double cz, double rr,
											int &xLow, int &xUp, int &yLow, int &yUp, int &zLow, int &zUp)
{
	double origin[3],width;		int res;	double xx,yy,zz,dd,r2;		int i,j;	short nDir;

	solid->GetOrigin(origin);	width=solid->GetGridWidth();	res=solid->GetResolution();
	r2=rr*rr;

	//------------------------------------------------------------------------------------------
	//	step 1: determine the range of nodes
	xLow=(int)(((double)(cx-rr)-origin[0])/width)-1;	
	if (xLow<0) xLow=0;		if (xLow>=res) xLow=res-1;
	xUp=(int)(((double)(cx+rr)-origin[0])/width)+1;
	if (xUp<0) xUp=0;		if (xUp>=res) xUp=res-1;
	//------------------------------------------------------------------------------------------
	yLow=(int)(((double)(cy-rr)-origin[1])/width)-1;	
	if (yLow<0) yLow=0;		if (yLow>=res) yLow=res-1;
	yUp=(int)(((double)(cy+rr)-origin[1])/width)+1;
	if (yUp<0) yUp=0;		if (yUp>=res) yUp=res-1;
	//------------------------------------------------------------------------------------------
	zLow=(int)(((double)(cz-rr)-origin[2])/width)-1;	
	if (zLow<0) zLow=0;		if (zLow>=res) zLow=res-1;
	zUp=(int)(((double)(cz+rr)-origin[2])/width)+1;
	if (zUp<0) zUp=0;		if (zUp>=res) zUp=res-1;

	//------------------------------------------------------------------------------------------
	//	step 2: fill in the LDNISolidNode
	//glColor3f(, (float)((ny+1.0)*0.5), (float)((nz+1.0)*0.5));
	//------------------------------------------------------------------------------------------
	//	xNodeArray
	nDir=0;
	for(i=yLow;i<=yUp;i++) {
		yy=origin[1]+width*(double)i-(double)cy;
		for(j=zLow;j<=zUp;j++) {
			zz=origin[2]+width*(double)j-(double)cz;
			dd=yy*yy+zz*zz;	if (dd>r2) continue;
			xx=sqrt(r2-dd);

			LDNISolidNode *node=new LDNISolidNode;
			node->MallocSampleArray(2);
			node->SetDepth(0,(float)(cx-origin[0]-xx));
			node->SetDepth(1,(float)(cx-origin[0]+xx));
			node->SetNormal(0,(short)((-xx/rr+1.0)*127.5),(short)((yy/rr+1.0)*127.5),(short)((zz/rr+1.0)*127.5));
			node->SetNormal(1,(short)((xx/rr+1.0)*127.5),(short)((yy/rr+1.0)*127.5),(short)((zz/rr+1.0)*127.5));
			solid->SetLDNISolidNode(nDir,i,j,node);
		}
	}
	//------------------------------------------------------------------------------------------
	//	yNodeArray
	nDir=1;
	for(i=zLow;i<=zUp;i++) {
		zz=origin[2]+width*(double)i-(double)cz;
		for(j=xLow;j<=xUp;j++) {
			xx=origin[0]+width*(double)j-(double)cx;
			dd=xx*xx+zz*zz;	if (dd>r2) continue;
			yy=sqrt(r2-dd);

			LDNISolidNode *node=new LDNISolidNode;
			node->MallocSampleArray(2);
			node->SetDepth(0,(float)(cy-origin[1]-yy));
			node->SetDepth(1,(float)(cy-origin[1]+yy));
			node->SetNormal(0,(short)((xx/rr+1.0)*127.5),(short)((-yy/rr+1.0)*127.5),(short)((zz/rr+1.0)*127.5));
			node->SetNormal(1,(short)((xx/rr+1.0)*127.5),(short)((yy/rr+1.0)*127.5),(short)((zz/rr+1.0)*127.5));
			solid->SetLDNISolidNode(nDir,i,j,node);
		}
	}
	//------------------------------------------------------------------------------------------
	//	zNodeArray
	nDir=2;
	for(i=xLow;i<=xUp;i++) {
		xx=origin[0]+width*(double)i-(double)cx;
		for(j=yLow;j<=yUp;j++) {
			yy=origin[1]+width*(double)j-(double)cy;
			dd=xx*xx+yy*yy;	if (dd>r2) continue;
			zz=sqrt(r2-dd);

			LDNISolidNode *node=new LDNISolidNode;
			node->MallocSampleArray(2);
			node->SetDepth(0,(float)(cz-origin[2]-zz));
			node->SetDepth(1,(float)(cz-origin[2]+zz));
			node->SetNormal(0,(short)((xx/rr+1.0)*127.5),(short)((yy/rr+1.0)*127.5),(short)((-zz/rr+1.0)*127.5));
			node->SetNormal(1,(short)((xx/rr+1.0)*127.5),(short)((yy/rr+1.0)*127.5),(short)((zz/rr+1.0)*127.5));
			solid->SetLDNISolidNode(nDir,i,j,node);
		}
	}
}

void LDNISolidOperation::SolidCorrection(LDNISolid* solid)
{
	int res,num;	short nDir;
	double fullDepth;

	res=solid->GetResolution();	num=res*res;
	fullDepth=((double)res)*(solid->GetGridWidth());

	//---------------------------------------------------------------------------------------------------------
	//	Step 1: sorting the samples and set the last sample to be the leaving-sample and all the rest as the entering-samples
	for(nDir=0;nDir<3;nDir++) {
		for(int kk=0;kk<num;kk++) {
			int i=kk/res;	int j=kk%res;
			//printf("%d-%d  ",i,j);
			LDNISolidNode *currentNode=solid->GetLDNISolidNode(nDir,i,j);
			if (currentNode==NULL) continue;
			int sampleNum=currentNode->GetSampleNum();
			if (sampleNum<2) {delete currentNode;	solid->SetLDNISolidNode(nDir,i,j,NULL);	continue;}

			currentNode->SortSamplesByDepth();
			currentNode->SetDepth(sampleNum-1,-(float)(currentNode->GetDepth(sampleNum-1)));
		}
	}
		
	//---------------------------------------------------------------------------------------------------------
	//	Step 2: orthorgonal flooding
	bool bFilled;	int iter;
	for(iter=0;iter<100;iter++){
		bFilled=false;
		for(nDir=0;nDir<3;nDir++) {
			for(int kk=0;kk<num;kk++) {
				int i=kk/res;	int j=kk%res;
				if (solid->GetLDNISolidNode(nDir,i,j)==NULL) continue;

				if (_othorgonalFillingBasedCorrection(nDir,i,j,solid)) bFilled=true;
			}
		}
		if (!bFilled) break;
	}
	printf("The iteration number of flooding is: %d\n",(iter+1));
	
	//---------------------------------------------------------------------------------------------------------
	//	Step 3: collecting all samples and reset the depth values and the normal vectors at the samples
	for(nDir=0;nDir<3;nDir++) {
		for(int kk=0;kk<num;kk++) {
			int i=kk/res;	int j=kk%res;
			LDNISolidNode *currentNode=solid->GetLDNISolidNode(nDir,i,j);
			if (currentNode==NULL) continue;
			_collectingSamples(nDir, currentNode);
			if (currentNode->GetSampleNum()==0) {delete currentNode; solid->SetLDNISolidNode(nDir,i,j,NULL);}
		}
	}
	printf("-----------------------------------\nRepair Completed\n");
}

void LDNISolidOperation::SolidCorrectionInParallel(LDNISolid* solid)
{
	int res,num,k;
	int xRayNum,yRayNum,zRayNum;
	LDNIRay *xRayArray,*yRayArray,*zRayArray;
	double gWidth=solid->GetGridWidth();

	//---------------------------------------------------------------------------------------------------------
	//	Step 1: Initialization
	printf("\n-----------------------------------\nNumber of Processors: %d\n",omp_get_num_procs());
	omp_set_dynamic(8);
	omp_set_num_threads(8);
	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
	res=solid->GetResolution();	num=res*res;
	xRayNum=yRayNum=zRayNum=0;
	LDNISolidUniformContouring::_compactionOfRays(solid,xRayNum,xRayArray,yRayNum,yRayArray,zRayNum,zRayArray);

	//---------------------------------------------------------------------------------------------------------
	//	Step 2: sorting of depth value (i.e., boundary voxelization)
	//---------------------------------------------------------------------------------------------------------
#pragma omp parallel for //schedule(dynamic) 
	for(k=0;k<xRayNum;k++) {
		LDNISolidNode *currentNode=xRayArray[k].headNode;
		short sampleNum=currentNode->GetSampleNum();
		currentNode->SortSamplesByDepth();
		currentNode->SetDepth(sampleNum-1,-(float)(currentNode->GetDepth(sampleNum-1)));
	}
	//---------------------------------------------------------------------------------------------------------
#pragma omp parallel for //schedule(dynamic) 
	for(k=0;k<yRayNum;k++) {
		LDNISolidNode *currentNode=yRayArray[k].headNode;
		short sampleNum=currentNode->GetSampleNum();
		currentNode->SortSamplesByDepth();
		currentNode->SetDepth(sampleNum-1,-(float)(currentNode->GetDepth(sampleNum-1)));
	}
	//---------------------------------------------------------------------------------------------------------
#pragma omp parallel for //schedule(dynamic) 
	for(k=0;k<zRayNum;k++) {
		LDNISolidNode *currentNode=zRayArray[k].headNode;
		short sampleNum=currentNode->GetSampleNum();
		currentNode->SortSamplesByDepth();
		currentNode->SetDepth(sampleNum-1,-(float)(currentNode->GetDepth(sampleNum-1)));
	}

	//---------------------------------------------------------------------------------------------------------
	//	Step 3: othorgonal filling of voxels
	bool bFilled;	int iter;
	for(iter=0;iter<100;iter++){
		bFilled=false;

#pragma omp parallel for reduction( || : bFilled) schedule(dynamic)
		for(k=0;k<xRayNum;k++) {
			bool bTemp=false;
			if (_othorgonalFillingBasedCorrection(0,xRayArray[k].i,xRayArray[k].j,solid)) bTemp=true;
			bFilled = bFilled || bTemp;
		}
#pragma omp parallel for reduction( || : bFilled) schedule(dynamic)
		for(k=0;k<yRayNum;k++) {
			bool bTemp=false;
			if (_othorgonalFillingBasedCorrection(1,yRayArray[k].i,yRayArray[k].j,solid)) bTemp=true;
			bFilled = bFilled || bTemp;
		}
#pragma omp parallel for reduction( || : bFilled) schedule(dynamic)
		for(k=0;k<zRayNum;k++) {
			bool bTemp=false;
			if (_othorgonalFillingBasedCorrection(2,zRayArray[k].i,zRayArray[k].j,solid)) bTemp=true;
			bFilled = bFilled || bTemp;
		}
		if (!bFilled) break;
	}
	printf("The iteration number of flooding is: %d\n",(iter+1));

	//---------------------------------------------------------------------------------------------------------
	//	Step 4: collecting all samples and reset the depth values and the normal vectors at the samples
	//---------------------------------------------------------------------------------------------------------
#pragma omp parallel for schedule(dynamic)
	for(k=0;k<xRayNum;k++) {
		LDNISolidNode *currentNode=xRayArray[k].headNode;
		_collectingSamples(0, currentNode);
		if (currentNode->GetSampleNum()==0) {
			delete currentNode;		xRayArray[k].headNode=NULL;
			solid->SetLDNISolidNode(0,xRayArray[k].i,xRayArray[k].j,NULL);
		}
	}
	//---------------------------------------------------------------------------------------------------------
#pragma omp parallel for schedule(dynamic)
	for(k=0;k<yRayNum;k++) {
		LDNISolidNode *currentNode=yRayArray[k].headNode;
		_collectingSamples(1, currentNode);
		if (currentNode->GetSampleNum()==0) {
			delete currentNode;		yRayArray[k].headNode=NULL;
			solid->SetLDNISolidNode(1,yRayArray[k].i,yRayArray[k].j,NULL);
		}
	}
	//---------------------------------------------------------------------------------------------------------
#pragma omp parallel for schedule(dynamic)
	for(k=0;k<zRayNum;k++) {
		LDNISolidNode *currentNode=zRayArray[k].headNode;
		_collectingSamples(2, currentNode);
		if (currentNode->GetSampleNum()==0) {
			delete currentNode;		zRayArray[k].headNode=NULL;
			solid->SetLDNISolidNode(2,zRayArray[k].i,zRayArray[k].j,NULL);
		}
	}
	printf("-----------------------------------\nRepair Completed\n");

	//---------------------------------------------------------------------------------------------------------
	//	Step X: Free the memeory
	if (xRayNum>0) {free(xRayArray);}
	if (yRayNum>0) {free(yRayArray);}
	if (zRayNum>0) {free(zRayArray);}
}

void LDNISolidOperation::ConstructLDNISolidFromVolumeImage(LDNISolid *&solid, int ***indexArray, 
														   int xNum, int yNum, int zNum, int materialTypeNum, 
														   float xmin, float ymin, float zmin, float gridwidth)
{
#define MAXSAMPLE_ON_RAY	500
	int res,newNum,nIter;		double origin[3];

	//--------------------------------------------------------------------------------------------------------
	//	Step 1: preparation
	solid=new LDNISolid;
	res=(xNum>yNum)?xNum:yNum;	res=(res>zNum)?res:zNum;
	solid->MallocMemoryOfSolidNodeArray(res);
	origin[0]=xmin;		origin[1]=ymin;		origin[2]=zmin;		// note that: we assume that the origion is located 
																//		at the center of the voxel (0,0,0).
	solid->SetOrigin(origin);	solid->SetGridWidth(gridwidth);		solid->SetMaterialTypeNum(materialTypeNum);
	omp_set_dynamic(8);
	omp_set_num_threads(8);

	//--------------------------------------------------------------------------------------------------------
	//	Step 2: conversion voxel data into LDNISolid
	long time=clock();
	//--------------------------------------------------------------------------------------------------------
	//	x-Direction
	newNum=yNum*zNum;
#pragma omp parallel for schedule(dynamic) 
	for(nIter=0;nIter<newNum;nIter++) {
		int j=nIter/zNum;	int k=nIter%zNum;
		double value,normal[3];		int id[MAXSAMPLE_ON_RAY];		short size,snx,sny,snz;
		double depth[MAXSAMPLE_ON_RAY],nx[MAXSAMPLE_ON_RAY],ny[MAXSAMPLE_ON_RAY],nz[MAXSAMPLE_ON_RAY];
		LDNISolidNode *currentNode;
		{
			size=0;
			for(int i=0;i<xNum-1;i++) {
				if (indexArray[i][j][k]!=indexArray[i+1][j][k]) {
					value=((double)i+0.5)*(double)gridwidth;	
					_approximateNormal(indexArray,xNum,yNum,zNum,i+1,j,k,i,j,k,normal);
					id[size]=indexArray[i][j][k]*(materialTypeNum+1)+indexArray[i+1][j][k];
					depth[size]=value;	nx[size]=normal[0];	ny[size]=normal[1];	nz[size]=normal[2];	size++;
				}
			}
			if (size==0) continue;

			currentNode=new LDNISolidNode;
			solid->SetLDNISolidNode(0,j,k,currentNode);
			currentNode->MallocSampleArray(size);
			for(int kk=0;kk<size;kk++) {
				currentNode->SetDepth(kk,(float)(depth[kk]));
				_encodeNormal(nx[kk], ny[kk], nz[kk], snx, sny, snz);
				currentNode->SetNormal(kk,snx,sny,snz);	currentNode->SetID(kk,id[kk]);
			}
		}
	}
	//--------------------------------------------------------------------------------------------------------
	//	y-Direction
	newNum=xNum*zNum;
#pragma omp parallel for schedule(dynamic) 
	for(nIter=0;nIter<newNum;nIter++) {
		int i=nIter/zNum;	int k=nIter%zNum;
		double value,normal[3];		int id[MAXSAMPLE_ON_RAY];		short size,snx,sny,snz;
		double depth[MAXSAMPLE_ON_RAY],nx[MAXSAMPLE_ON_RAY],ny[MAXSAMPLE_ON_RAY],nz[MAXSAMPLE_ON_RAY];
		LDNISolidNode *currentNode;
		{
			size=0;
			for(int j=0;j<yNum-1;j++) {
				if (indexArray[i][j][k]!=indexArray[i][j+1][k]) {
					value=((double)j+0.5)*(double)gridwidth;
					_approximateNormal(indexArray,xNum,yNum,zNum,i,j,k,i,j+1,k,normal);
					id[size]=indexArray[i][j][k]*(materialTypeNum+1)+indexArray[i][j+1][k];
					depth[size]=value;	nx[size]=normal[0];	ny[size]=normal[1];	nz[size]=normal[2];	size++;
				}
			}
			if (size==0) continue;

			currentNode=new LDNISolidNode;
			solid->SetLDNISolidNode(1,k,i,currentNode);
			currentNode->MallocSampleArray(size);
			for(int kk=0;kk<size;kk++) {
				currentNode->SetDepth(kk,(float)(depth[kk]));
				_encodeNormal(nx[kk], ny[kk], nz[kk], snx, sny, snz);
				currentNode->SetNormal(kk,snx,sny,snz);	currentNode->SetID(kk,id[kk]);
			}
		}
	}
	//--------------------------------------------------------------------------------------------------------
	//	z-Direction
	newNum=xNum*yNum;
#pragma omp parallel for schedule(dynamic) 
	for(nIter=0;nIter<newNum;nIter++) {
		int i=nIter/yNum;	int j=nIter%yNum;
		double value,normal[3];		int id[MAXSAMPLE_ON_RAY];		short size,snx,sny,snz;
		double depth[MAXSAMPLE_ON_RAY],nx[MAXSAMPLE_ON_RAY],ny[MAXSAMPLE_ON_RAY],nz[MAXSAMPLE_ON_RAY];
		LDNISolidNode *currentNode;
		{
			size=0;
			for(int k=0;k<zNum-1;k++) {
				if (indexArray[i][j][k]!=indexArray[i][j][k+1]) {
					value=((double)k+0.5)*(double)gridwidth;
					_approximateNormal(indexArray,xNum,yNum,zNum,i,j,k,i,j,k+1,normal);
					id[size]=indexArray[i][j][k]*(materialTypeNum+1)+indexArray[i][j][k+1];
					depth[size]=value;	nx[size]=normal[0];	ny[size]=normal[1];	nz[size]=normal[2];	size++;
				}
			}
			if (size==0) continue;

			currentNode=new LDNISolidNode;
			solid->SetLDNISolidNode(2,i,j,currentNode);
			currentNode->MallocSampleArray(size);
			for(int kk=0;kk<size;kk++) {
				currentNode->SetDepth(kk,(float)(depth[kk]));
				_encodeNormal(nx[kk], ny[kk], nz[kk], snx, sny, snz);
				currentNode->SetNormal(kk,snx,sny,snz);	currentNode->SetID(kk,id[kk]);
			}
		}
	}
	printf("hRay-rep Construction Time: %ld ms \n",clock()-time);	time=clock();

	//--------------------------------------------------------------------------------------------------------
	//	Step 3: processing of LDNISolid
	ParallelProcessingNormalOfLDNISolid(solid);
	_processingDepthOfLDNISolidParallel(solid);
	ParallelProcessingNormalOfLDNISolid(solid);		
	printf("hRay-rep Filtering Time: %ld ms \n",clock()-time);	time=clock();
}

void LDNISolidOperation::BooleanOperation(LDNISolid *inputSolid, QMeshPatch *meshB, 
										  short nOperationType, LDNISolid *&outputSolid)
{
	QMeshNode *node;
	double xx,yy,zz,boundingBox[6];
	GLKPOSITION Pos;	int res;
	double criterion;
	short nDir;

	//-----------------------------------------------------------------------------------
	//	Step 1: compute the bounding box of meshB
	boundingBox[0]=boundingBox[2]=boundingBox[4]=1.0e+32;
	boundingBox[1]=boundingBox[3]=boundingBox[5]=-1.0e+32;
	for(Pos=meshB->GetNodeList().GetHeadPosition();Pos!=NULL;) {
		node=(QMeshNode *)(meshB->GetNodeList().GetNext(Pos));
		node->GetCoord3D(xx,yy,zz);
		if (xx<boundingBox[0]) boundingBox[0]=xx;
		if (xx>boundingBox[1]) boundingBox[1]=xx;
		if (yy<boundingBox[2]) boundingBox[2]=yy;
		if (yy>boundingBox[3]) boundingBox[3]=yy;
		if (zz<boundingBox[4]) boundingBox[4]=zz;
		if (zz>boundingBox[5]) boundingBox[5]=zz;
	}

	//-----------------------------------------------------------------------------------
	//	Step 2: expand the LDNISolid and sample the mesh by the updated boundingBox[]
	inputSolid->ExpansionByNewBoundingBox(boundingBox);
	res=inputSolid->GetResolution();
	LDNISolidSampling::MeshToLDNISolidSampling(meshB,outputSolid,boundingBox,res);

	//-----------------------------------------------------------------------------------
	//	Step 3: computing the Boolean operation results on LDNIs
	long time=clock();
	criterion=1.0e-5;	// as the depth value is stored as single precision float only

	int newNum=res*res;
	int emptyNum=0;
	for(nDir=0;nDir<3;nDir++) {
		for(int kk=0;kk<newNum;kk++) {
			int i=kk/res;	int j=kk%res;
			{
				LDNISolidNode *aNode,*bNode;
				aNode=inputSolid->GetLDNISolidNode(nDir,i,j);	
				bNode=outputSolid->GetLDNISolidNode(nDir,i,j);
//				bNode=inputSolid->GetLDNISolidNode(nDir,i,j);	
//				aNode=outputSolid->GetLDNISolidNode(nDir,i,j);
				if (aNode==NULL && bNode==NULL) emptyNum++;
				_booleanOfSolidNodeList(aNode,bNode,nOperationType,criterion);
				outputSolid->SetLDNISolidNode(nDir,i,j,aNode);
				inputSolid->SetLDNISolidNode(nDir,i,j,bNode);	// the memory will be released outside this function
			}
		}
	}
	printf("Boolean Operation Time (ms): %ld\n",clock()-time);
	printf("Empty rays percentage: %lf %%\n",(double)emptyNum/((double)newNum*3.0)*100.0);
}

void LDNISolidOperation::BooleanOperation(QMeshPatch *meshA, QMeshPatch *meshB, int res, 
										  short nOperationType, LDNISolid *&outputSolid)
{
	GLKObList meshList;		double boundingBox[6]; 
	LDNISolid *solidB;	
	double criterion;
	short nDir;

	//-----------------------------------------------------------------------------------
	//	Step 1: converting mesh surfaces into LDNIs
	meshList.RemoveAll();	meshList.AddTail(meshA);	meshList.AddTail(meshB);
	CompBoundingBox(&meshList, boundingBox, true, res);
	LDNISolidSampling::MeshToLDNISolidSampling(meshA, outputSolid, boundingBox, res);
	LDNISolidSampling::MeshToLDNISolidSampling(meshB, solidB, boundingBox, res);

	//-----------------------------------------------------------------------------------
	//	Step 2: computing the Boolean operation results on LDNIs
	long time=clock();
	criterion=1.0e-5;	// as the depth value is stored as single precision float only

	int newNum=res*res;
	int emptyNum=0;
	for(nDir=0;nDir<3;nDir++) {
		for(int kk=0;kk<newNum;kk++) {
			int i=kk/res;	int j=kk%res;
			{
				LDNISolidNode *aNode,*bNode;
				aNode=outputSolid->GetLDNISolidNode(nDir,i,j);	
				bNode=solidB->GetLDNISolidNode(nDir,i,j);
				if (aNode==NULL && bNode==NULL) emptyNum++;
				_booleanOfSolidNodeList(aNode,bNode,nOperationType,criterion);
				outputSolid->SetLDNISolidNode(nDir,i,j,aNode);
				solidB->SetLDNISolidNode(nDir,i,j,bNode);
			}
		}
	}
	printf("Boolean Operation Time (ms): %ld\n",clock()-time);
	printf("Empty rays percentage: %lf %%\n",(double)emptyNum/((double)newNum*3.0)*100.0);

	//-----------------------------------------------------------------------------------
	//	Step 3: free the memory
	delete solidB;
}

struct LDNIRayPair{
	int i,j;
	LDNISolidNode *aNode,*bNode;
};

void LDNISolidOperation::BooleanOperation_Parallel(LDNISolid *inputSolid, QMeshPatch *meshB, 
												   short nOperationType, LDNISolid *&outputSolid)
{
	QMeshNode *node;
	LDNIRayPair *rayPairArray;
	double xx,yy,zz,boundingBox[6];
	GLKPOSITION Pos;	int res;
	double criterion;
	short nDir;

	//-----------------------------------------------------------------------------------
	//	Step 1: compute the bounding box of meshB
	boundingBox[0]=boundingBox[2]=boundingBox[4]=1.0e+32;
	boundingBox[1]=boundingBox[3]=boundingBox[5]=-1.0e+32;
	for(Pos=meshB->GetNodeList().GetHeadPosition();Pos!=NULL;) {
		node=(QMeshNode *)(meshB->GetNodeList().GetNext(Pos));
		node->GetCoord3D(xx,yy,zz);
		if (xx<boundingBox[0]) boundingBox[0]=xx;
		if (xx>boundingBox[1]) boundingBox[1]=xx;
		if (yy<boundingBox[2]) boundingBox[2]=yy;
		if (yy>boundingBox[3]) boundingBox[3]=yy;
		if (zz<boundingBox[4]) boundingBox[4]=zz;
		if (zz>boundingBox[5]) boundingBox[5]=zz;
	}

	//-----------------------------------------------------------------------------------
	//	Step 2: expand the LDNISolid and sample the mesh by the updated boundingBox[]
	inputSolid->ExpansionByNewBoundingBox(boundingBox);
	res=inputSolid->GetResolution();
	LDNISolidSampling::MeshToLDNISolidSampling(meshB,outputSolid,boundingBox,res);

	//-----------------------------------------------------------------------------------
	//	Step 3: computing the Boolean operation results on LDNIs
	long time=clock();
	criterion=1.0e-5;	// as the depth value is stored as single precision float only
	int newNum=res*res;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());

	int *rayIndex;	int nn=(int)(log((double)newNum)/log(2.0)); 
	if ((int)(pow(2.0,(double)nn))<newNum) nn++;
	int arrayLen=(int)(pow(2.0,(double)nn));
	rayIndex=new int[arrayLen];
	rayPairArray=(LDNIRayPair*)(malloc(sizeof(LDNIRayPair)*newNum)); 
	for(nDir=0;nDir<3;nDir++) {
		//-------------------------------------------------------------------------------
		//	Setting the flags for empty/non-empty
		int rayNum=0;
#pragma omp parallel for 
		for(int kk=0;kk<newNum;kk++) {
			LDNISolidNode *aNode,*bNode;
			int i=kk/res;	int j=kk%res;
			aNode=inputSolid->GetLDNISolidNode(nDir,i,j);
			bNode=outputSolid->GetLDNISolidNode(nDir,i,j);	
			rayIndex[kk]=0;
			if (aNode!=NULL || bNode!=NULL) rayIndex[kk]=1;
		}
#pragma omp parallel for 
		for(int kk=newNum;kk<arrayLen;kk++) rayIndex[kk]=0;

//		arrayLen=8;	nn=3;	rayIndex[0]=0;	rayIndex[1]=0;	rayIndex[2]=1;	rayIndex[3]=0;	rayIndex[4]=1;	rayIndex[5]=0;	rayIndex[6]=0;	rayIndex[7]=0;
		//-------------------------------------------------------------------------------
		//	Compaction
		int loopNum,stepSize;
		//-------------------------------------------------------------------------------
		//	Step a): up-sweep algorithm	
		loopNum=arrayLen;
		for(int dIter=0;dIter<nn;dIter++) {
			stepSize=(2<<dIter);	loopNum=loopNum/2;
#pragma omp parallel for 
			for(int kk=0;kk<loopNum;kk++) {
				rayIndex[kk*stepSize+stepSize-1]=rayIndex[kk*stepSize+stepSize/2-1]+rayIndex[kk*stepSize+stepSize-1];
			}
		}
		rayNum=rayIndex[arrayLen-1];
		//-------------------------------------------------------------------------------
		//	Step b): down-sweep algorithm
		rayIndex[arrayLen-1]=0;	
		loopNum=1;
		for(int dIter=nn-1;dIter>=0;dIter--) {
			stepSize=(2<<dIter);
#pragma omp parallel for 
			for(int kk=0;kk<loopNum;kk++) {
				int temp=rayIndex[kk*stepSize+stepSize/2-1];
				rayIndex[kk*stepSize+stepSize/2-1]=rayIndex[kk*stepSize+stepSize-1];
				rayIndex[kk*stepSize+stepSize-1]+=temp;
			}
			loopNum=loopNum*2;
		}
		//-------------------------------------------------------------------------------
		//	Step c): collection
#pragma omp parallel for 
		for(int kk=0;kk<newNum;kk++) {
			LDNISolidNode *aNode,*bNode;
			int i=kk/res;	int j=kk%res;
			aNode=inputSolid->GetLDNISolidNode(nDir,i,j);
			bNode=outputSolid->GetLDNISolidNode(nDir,i,j);	
			if (aNode!=NULL || bNode!=NULL) {
				int index=rayIndex[kk];
				rayPairArray[index].aNode=aNode;
				rayPairArray[index].bNode=bNode;
				rayPairArray[index].i=i;
				rayPairArray[index].j=j;
			}
		}

		//-------------------------------------------------------------------------------
		// Boolean operation on non-empty rays
#pragma omp parallel for schedule(dynamic)
		for(int kk=0;kk<rayNum;kk++) {
			LDNISolidNode *aNode=rayPairArray[kk].aNode;
			LDNISolidNode *bNode=rayPairArray[kk].bNode;
			int i=rayPairArray[kk].i;
			int j=rayPairArray[kk].j;
			_booleanOfSolidNodeList(aNode,bNode,nOperationType,criterion);
			outputSolid->SetLDNISolidNode(nDir,i,j,aNode);
			inputSolid->SetLDNISolidNode(nDir,i,j,bNode);
		}
	}
	delete []rayIndex;
	free(rayPairArray);

	printf("Boolean Operation Time (ms): %ld\n",clock()-time);
}

void LDNISolidOperation::BooleanOperation_Parallel(QMeshPatch *meshA, QMeshPatch *meshB, 
												   int res, short nOperationType, LDNISolid *&outputSolid)
{
	GLKObList meshList;		double boundingBox[6]; 
	LDNISolid *solidB;	
	LDNIRayPair *rayPairArray;
	double criterion;
	short nDir;

	//-----------------------------------------------------------------------------------
	//	Step 1: converting mesh surfaces into LDNIs
	meshList.RemoveAll();	meshList.AddTail(meshA);	meshList.AddTail(meshB);
	CompBoundingBox(&meshList, boundingBox, true, res);
	LDNISolidSampling::MeshToLDNISolidSampling(meshA, outputSolid, boundingBox, res);
	LDNISolidSampling::MeshToLDNISolidSampling(meshB, solidB, boundingBox, res);

	//-----------------------------------------------------------------------------------
	//	Step 2: computing the Boolean operation results on LDNIs
	long time=clock();
	criterion=1.0e-5;	// as the depth value is stored as single precision float only
	int newNum=res*res;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());

	int *rayIndex;	int nn=(int)(log((double)newNum)/log(2.0)); 
	if ((int)(pow(2.0,(double)nn))<newNum) nn++;
	int arrayLen=(int)(pow(2.0,(double)nn));
	rayIndex=new int[arrayLen];
	rayPairArray=(LDNIRayPair*)(malloc(sizeof(LDNIRayPair)*newNum)); 
	for(nDir=0;nDir<3;nDir++) {
		//-------------------------------------------------------------------------------
		//	Setting the flags for empty/non-empty
		int rayNum=0;
#pragma omp parallel for 
		for(int kk=0;kk<newNum;kk++) {
			LDNISolidNode *aNode,*bNode;
			int i=kk/res;	int j=kk%res;
			aNode=outputSolid->GetLDNISolidNode(nDir,i,j);	
			bNode=solidB->GetLDNISolidNode(nDir,i,j);
			rayIndex[kk]=0;
			if (aNode!=NULL || bNode!=NULL) rayIndex[kk]=1;
		}
#pragma omp parallel for 
		for(int kk=newNum;kk<arrayLen;kk++) rayIndex[kk]=0;

//		arrayLen=8;	nn=3;	rayIndex[0]=0;	rayIndex[1]=0;	rayIndex[2]=1;	rayIndex[3]=0;	rayIndex[4]=1;	rayIndex[5]=0;	rayIndex[6]=0;	rayIndex[7]=0;
		//-------------------------------------------------------------------------------
		//	Compaction
		int loopNum,stepSize;
		//-------------------------------------------------------------------------------
		//	Step a): up-sweep algorithm	
		loopNum=arrayLen;
		for(int dIter=0;dIter<nn;dIter++) {
			stepSize=(2<<dIter);	loopNum=loopNum/2;
#pragma omp parallel for 
			for(int kk=0;kk<loopNum;kk++) {
				rayIndex[kk*stepSize+stepSize-1]=rayIndex[kk*stepSize+stepSize/2-1]+rayIndex[kk*stepSize+stepSize-1];
			}
		}
		rayNum=rayIndex[arrayLen-1];
		//-------------------------------------------------------------------------------
		//	Step b): down-sweep algorithm
		rayIndex[arrayLen-1]=0;	
		loopNum=1;
		for(int dIter=nn-1;dIter>=0;dIter--) {
			stepSize=(2<<dIter);
#pragma omp parallel for 
			for(int kk=0;kk<loopNum;kk++) {
				int temp=rayIndex[kk*stepSize+stepSize/2-1];
				rayIndex[kk*stepSize+stepSize/2-1]=rayIndex[kk*stepSize+stepSize-1];
				rayIndex[kk*stepSize+stepSize-1]+=temp;
			}
			loopNum=loopNum*2;
		}
		//-------------------------------------------------------------------------------
		//	Step c): collection
#pragma omp parallel for 
		for(int kk=0;kk<newNum;kk++) {
			LDNISolidNode *aNode,*bNode;
			int i=kk/res;	int j=kk%res;
			aNode=outputSolid->GetLDNISolidNode(nDir,i,j);	
			bNode=solidB->GetLDNISolidNode(nDir,i,j);
			if (aNode!=NULL || bNode!=NULL) {
				int index=rayIndex[kk];
				rayPairArray[index].aNode=aNode;
				rayPairArray[index].bNode=bNode;
				rayPairArray[index].i=i;
				rayPairArray[index].j=j;
			}
		}

		//-------------------------------------------------------------------------------
		// Boolean operation on non-empty rays
#pragma omp parallel for schedule(dynamic)
		for(int kk=0;kk<rayNum;kk++) {
			LDNISolidNode *aNode=rayPairArray[kk].aNode;
			LDNISolidNode *bNode=rayPairArray[kk].bNode;
			int i=rayPairArray[kk].i;
			int j=rayPairArray[kk].j;
			_booleanOfSolidNodeList(aNode,bNode,nOperationType,criterion);
			outputSolid->SetLDNISolidNode(nDir,i,j,aNode);
			solidB->SetLDNISolidNode(nDir,i,j,bNode);
		}
	}
	delete []rayIndex;
	free(rayPairArray);

	printf("Boolean Operation Time (ms): %ld\n",clock()-time);

	//-----------------------------------------------------------------------------------
	//	Step 3: free the memory
	delete solidB;
}

void LDNISolidOperation::CompBoundingBox(GLKObList* meshList, double boundingBox[], 
										 bool bCube, int res)
{
	GLKPOSITION Pos;
	GLKPOSITION PosMesh;
	double xx,yy,zz,ww;
	QMeshPatch *mesh;
	QMeshNode *node;

	boundingBox[0]=boundingBox[2]=boundingBox[4]=1.0e+32;
	boundingBox[1]=boundingBox[3]=boundingBox[5]=-1.0e+32;

	for(PosMesh=meshList->GetHeadPosition();PosMesh!=NULL;) {
		mesh=(QMeshPatch *)(meshList->GetNext(PosMesh));
		for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;) {
			node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
			node->GetCoord3D(xx,yy,zz);
			if (xx<boundingBox[0]) boundingBox[0]=xx;
			if (xx>boundingBox[1]) boundingBox[1]=xx;
			if (yy<boundingBox[2]) boundingBox[2]=yy;
			if (yy>boundingBox[3]) boundingBox[3]=yy;
			if (zz<boundingBox[4]) boundingBox[4]=zz;
			if (zz>boundingBox[5]) boundingBox[5]=zz;
		}
	}
	printf("Origin:(%lf,%lf,%lf)---width:(%lf,%lf,%lf)\n",boundingBox[0],boundingBox[2],boundingBox[4],
		boundingBox[1]-boundingBox[0],boundingBox[3]-boundingBox[2],boundingBox[5]-boundingBox[4]);

	if (bCube) {
		xx=(boundingBox[0]+boundingBox[1])*0.5;
		yy=(boundingBox[2]+boundingBox[3])*0.5;
		zz=(boundingBox[4]+boundingBox[5])*0.5;
		ww=boundingBox[1]-boundingBox[0];
		if ((boundingBox[3]-boundingBox[2])>ww) ww=boundingBox[3]-boundingBox[2];
		if ((boundingBox[5]-boundingBox[4])>ww) ww=boundingBox[5]-boundingBox[4];
		ww=ww*0.55+ww/(double)(res-1)*2.0;
//		ww=ww+ww;
		boundingBox[0]=xx-ww;	boundingBox[1]=xx+ww;
		boundingBox[2]=yy-ww;	boundingBox[3]=yy+ww;
		boundingBox[4]=zz-ww;	boundingBox[5]=zz+ww;
	}
}

void LDNISolidOperation::ErrorEvaluationForLDNISolid(QMeshPatch *mesh/*the reference model*/, LDNISolid *solid)
{
	LDNISolidNode *currentNode;	int i,j,res,pntNum=0;	
	long time=clock();	
	double origin[3],gwidth,dist,minErr=1.0e+8,maxErr=-1.0e+8,avgErr=0.0;
	double queryPnt[3],closestPnt[3];
	short k,num;
	double standardDist;

	//-----------------------------------------------------------------------------------------------
	//	Step 1: Initialization
	PQP_Model *pqpModel;
	pqpModel=_pqpInitialization(mesh);	
	res=solid->GetResolution();		solid->GetOrigin(origin);	gwidth=solid->GetGridWidth();
	standardDist=16.0*gwidth;
	printf("Initialization is completed - %ld (ms)\n", clock()-time);	time=clock();

	//-----------------------------------------------------------------------------------------------
	//	Step 2: Evaluation of the error
	for(short nAxis=0;nAxis<3;nAxis++) {
		for(i=0;i<res;i++) {	// column
			for(j=0;j<res;j++) {	// row
				currentNode=solid->GetLDNISolidNode(nAxis,i,j);
				if (currentNode==NULL) continue;
				queryPnt[(nAxis+1)%3]=origin[(nAxis+1)%3]+gwidth*(double)i;
				queryPnt[(nAxis+2)%3]=origin[(nAxis+2)%3]+gwidth*(double)j;
				num=currentNode->GetSampleNum();
				for(k=0;k<num;k++) {
					queryPnt[nAxis]=origin[nAxis]+currentNode->GetDepth(k);
					dist=fabs(_distanceToPatch(pqpModel,queryPnt,closestPnt)-standardDist);
					if (dist>maxErr) maxErr=dist;
					if (dist<minErr) minErr=dist;
					avgErr+=dist;	pntNum++;
				}
			}
		}
	}
	if (pntNum>0) avgErr=avgErr/(double)pntNum;
	printf("----------------------------------------------------------\n");
	printf("Total number of points: %ld \n",pntNum);
	printf("Minimum error: %lf \n",minErr);
	printf("Maximum error: %lf \n",maxErr);
	printf("Average error: %lf \n",avgErr);
	printf("Sampling width: %lf \n",gwidth);
	printf("d-covering: %lf \n",gwidth*sqrt(3.0));
	printf("----------------------------------------------------------\n");
	printf("Standard distance: %lf \n",standardDist);
	printf("Avg-Error/Sample-width ratio: %lf \n",avgErr/gwidth);
	printf("Max-Error/Sample-width ratio: %lf \n",maxErr/gwidth);

	//-----------------------------------------------------------------------------------------------
	//	Step 3: Free the memory
	delete pqpModel;
}

PQP_Model* LDNISolidOperation::_pqpInitialization(QMeshPatch *mesh)
{
	PQP_Model *pqpModel;
	PQP_REAL p1[3], p2[3], p3[3];
	GLKPOSITION Pos;	QMeshFace *face;	int i;
	double xx,yy,zz;

	pqpModel = new PQP_Model();
	pqpModel->BeginModel();		i=0;
	for(Pos=mesh->GetFaceList().GetHeadPosition();Pos!=NULL;i++) {
		face=(QMeshFace*)(mesh->GetFaceList().GetNext(Pos));
		face->SetIndexNo(i);	

		face->GetNodePos(0,xx,yy,zz);	p1[0]=(PQP_REAL)(xx);	p1[1]=(PQP_REAL)(yy);	p1[2]=(PQP_REAL)(zz);
		face->GetNodePos(1,xx,yy,zz);	p2[0]=(PQP_REAL)(xx);	p2[1]=(PQP_REAL)(yy);	p2[2]=(PQP_REAL)(zz);
		face->GetNodePos(2,xx,yy,zz);	p3[0]=(PQP_REAL)(xx);	p3[1]=(PQP_REAL)(yy);	p3[2]=(PQP_REAL)(zz);

		pqpModel->AddTri(p1,p2,p3,i);
	}
	pqpModel->EndModel();

	return pqpModel;
}

double LDNISolidOperation::_distanceToPatch(PQP_Model *pqpModel, double queryPnt[], double closestPnt[])
{
	PQP_DistanceResult dres;	
	PQP_REAL p[3];	
	double minDist;

	dres.last_tri = pqpModel->last_tri;
	p[0]=queryPnt[0];	p[1]=queryPnt[1];	p[2]=queryPnt[2];
	PQP_Distance(&dres, pqpModel, p, 0.0 , 0.0);
	minDist = dres.Distance();		

	return minDist;
}
void LDNISolidOperation::_booleanOfSolidNodeList(LDNISolidNode *&aNode, LDNISolidNode *&bNode, short nOperationType)
{
	double criterion=1.0e-5;

	if ((aNode!=NULL) && (bNode!=NULL)) {
		bool bInsideA,bInsideB,last_op,op;
		short aIndex,bIndex,aNum,bNum;
		double *resultDepth;	short *resultNx,*resultNy,*resultNz;	short k,resultSampleNum=0;
		double lastDepth;	short lastNx,lastNy,lastNz;

		aNum = aNode->GetSampleNum();	bNum = bNode->GetSampleNum();
		resultDepth=new double[aNum+bNum];	
		resultNx=new short[aNum+bNum];	resultNy=new short[aNum+bNum];	resultNz=new short[aNum+bNum];

		bInsideA = bInsideB = false;
		switch(nOperationType) {
		case 0:{last_op=LOGIC_UNION(bInsideA,bInsideB); }break;	// Union		- "A U B"
		case 1:{last_op=LOGIC_INTER(bInsideA,bInsideB); }break;	// Intersection - "A n B"
		case 2:{last_op=LOGIC_SUBTR(bInsideA,bInsideB); }break;	// Substraction - "A \ B"
		}
		aIndex = bIndex = 0;

		while( (aIndex<aNum) || (bIndex<bNum) ) {
			//----------------------------------------------------------------------------------------------
			//	old version does not consider about the overlapped samples
			if ((aIndex<aNum) && ((bIndex==bNum) || (aNode->GetDepth(aIndex)<bNode->GetDepth(bIndex)))) {
				lastDepth=aNode->GetDepth(aIndex);	
				aNode->GetNormal(aIndex,lastNx,lastNy,lastNz);
				bInsideA=((aIndex%2)==0);	aIndex++;
			}
			else {
				lastDepth=bNode->GetDepth(bIndex);	
				bNode->GetNormal(bIndex,lastNx,lastNy,lastNz);
				if (nOperationType==2) {lastNx=255-lastNx; lastNy=255-lastNy; lastNz=255-lastNz;}
				bInsideB=((bIndex%2)==0);	bIndex++;
			}

			switch(nOperationType) {
			case 0:{op=LOGIC_UNION(bInsideA,bInsideB); }break;
			case 1:{op=LOGIC_INTER(bInsideA,bInsideB); }break;
			case 2:{op=LOGIC_SUBTR(bInsideA,bInsideB); }break;
			}
			if (op!=last_op) {
				if ((resultSampleNum>0) && (fabs(lastDepth-resultDepth[resultSampleNum-1])<criterion)) {
					/*if (((resultSampleNum%2==1) && (last_op)) || ((resultSampleNum%2==0) && (!last_op)))*/ resultSampleNum--;
				}
				else {
					resultDepth[resultSampleNum]=lastDepth;	
					resultNx[resultSampleNum]=lastNx; resultNy[resultSampleNum]=lastNy; resultNz[resultSampleNum]=lastNz; 
					resultSampleNum++;
				}
				last_op=op;
			}
		}

		//---------------------------------------------------------------------------------------------------
		//	update node and free memory
		delete aNode;	delete bNode;
		aNode = bNode = NULL;
		if (resultSampleNum>0) {
			aNode=new LDNISolidNode;
			aNode->MallocSampleArray(resultSampleNum);
			for(k=0;k<resultSampleNum;k++) {
				aNode->SetDepth(k,(float)(resultDepth[k]));	
				aNode->SetNormal(k,resultNx[k],resultNy[k],resultNz[k]);
			}
			if (resultSampleNum>(aNum+bNum)) printf("ERROR FOUND! ");
		}

		delete []resultDepth;	delete []resultNx;	delete []resultNy;	delete []resultNz;
	}
	else if ((aNode==NULL) && (bNode!=NULL)) {
		if (nOperationType==0) { // union
			aNode=bNode;	bNode=NULL;
		}
		// for "intersect" and "difference", keeping NULL will be fine
	}
	else if ((aNode!=NULL) && (bNode==NULL)) {
		if (nOperationType==1) { // intersection
			delete aNode;	aNode=NULL;
		}
	}
}

void LDNISolidOperation::_booleanOfSolidNodeList(LDNISolidNode *&aNode, LDNISolidNode *&bNode, 
												 short nOperationType, double criterion)
{
	GLKArray *ptrNxArray,*ptrNyArray,*ptrNzArray,*ptrDepthArray,*dirArray,*indexArray;
	short i,j,k,iNum,jNum;	short nx,ny,nz;		double depth,depth2;

	if ((aNode!=NULL) && (bNode!=NULL)) {
		ptrNxArray=new GLKArray(50,50,1); 
		ptrNyArray=new GLKArray(50,50,1); 
		ptrNzArray=new GLKArray(50,50,1);
		ptrDepthArray=new GLKArray(50,50,3); 
		dirArray=new GLKArray(50,50,1);
		indexArray=new GLKArray(50,50,1);

		//----------------------------------------------------------------------------------------
		//	Step 1: subdivide the sets in solidA into segments
		iNum=aNode->GetSampleNum();		jNum=bNode->GetSampleNum();
		for(i=0;i<iNum;i+=2) {
			depth=aNode->GetDepth(i);
			depth2=aNode->GetDepth(i+1);

			aNode->GetNormal(i,nx,ny,nz);
			ptrNxArray->Add((int)nx);	ptrNyArray->Add((int)ny);	ptrNzArray->Add((int)nz);
			ptrDepthArray->Add(depth);		dirArray->Add((int)1);
			//------------------------------------------------------------------------------------
			//	search the intersecting nodes (excluding those intersect on endpoints)
			for(j=0;j<jNum;j++) {
				if (bNode->GetDepth(j)>=depth2) break;
				if ((bNode->GetDepth(j)>depth) && (bNode->GetDepth(j)<depth2)) {
					bNode->GetNormal(j,nx,ny,nz);
					ptrNxArray->Add((int)nx);	ptrNyArray->Add((int)ny);	ptrNzArray->Add((int)nz);
					ptrDepthArray->Add(bNode->GetDepth(j));		dirArray->Add((int)2);
					ptrNxArray->Add((int)nx);	ptrNyArray->Add((int)ny);	ptrNzArray->Add((int)nz);
					ptrDepthArray->Add(bNode->GetDepth(j));		dirArray->Add((int)2);
				}
			}
			aNode->GetNormal(i+1,nx,ny,nz);
			ptrNxArray->Add((int)nx);	ptrNyArray->Add((int)ny);	ptrNzArray->Add((int)nz);
			ptrDepthArray->Add(depth2);		dirArray->Add((int)1);
		}

		//----------------------------------------------------------------------------------------
		//	Step 2: process the segments
		if (nOperationType==0) { // for union
			GLKArray *remainArray,*ptrNxArray2,*ptrNyArray2,*ptrNzArray2,*ptrDepthArray2;
			int nNum,nNum2;

			remainArray=new GLKArray(50,50,1);	ptrDepthArray2=new GLKArray(50,50,3); 
			ptrNxArray2=new GLKArray(50,50,1);	ptrNyArray2=new GLKArray(50,50,1);	ptrNzArray2=new GLKArray(50,50,1);
			
			nNum=ptrDepthArray->GetSize();
			for(k=0;k<nNum;k+=2) {
				depth=(ptrDepthArray->GetDoubleAt(k)+ptrDepthArray->GetDoubleAt(k+1))*0.5;
				if (_detectNodeOverlap(depth,bNode)) continue;
				remainArray->Add(k);	remainArray->Add(k+1);
			}

			nNum=remainArray->GetSize();	nNum2=bNode->GetSampleNum();
			i=0;	j=0;
			for(;;) {
				double depthA,depthB;
				if (i>=nNum) {
					for(;j<nNum2;j+=2) {
						depth=bNode->GetDepth(j);	bNode->GetNormal(j,nx,ny,nz);
						ptrDepthArray2->Add(depth);	ptrNxArray2->Add(nx); ptrNyArray2->Add(ny); ptrNzArray2->Add(nz);
						depth=bNode->GetDepth(j+1);	bNode->GetNormal(j+1,nx,ny,nz);
						ptrDepthArray2->Add(depth);	ptrNxArray2->Add(nx); ptrNyArray2->Add(ny); ptrNzArray2->Add(nz);
					}
					break;
				}
				if (j>=nNum2) {
					for(;i<nNum;i+=2) {
						ptrDepthArray2->Add(ptrDepthArray->GetDoubleAt(remainArray->GetIntAt(i)));
						ptrNxArray2->Add(ptrNxArray->GetIntAt(remainArray->GetIntAt(i)));
						ptrNyArray2->Add(ptrNyArray->GetIntAt(remainArray->GetIntAt(i)));
						ptrNzArray2->Add(ptrNzArray->GetIntAt(remainArray->GetIntAt(i)));
						ptrDepthArray2->Add(ptrDepthArray->GetDoubleAt(remainArray->GetIntAt(i+1)));
						ptrNxArray2->Add(ptrNxArray->GetIntAt(remainArray->GetIntAt(i+1)));
						ptrNyArray2->Add(ptrNyArray->GetIntAt(remainArray->GetIntAt(i+1)));
						ptrNzArray2->Add(ptrNzArray->GetIntAt(remainArray->GetIntAt(i+1)));
					}break;
				}

				depthA=(ptrDepthArray->GetDoubleAt(remainArray->GetIntAt(i))
							+ptrDepthArray->GetDoubleAt(remainArray->GetIntAt(i+1)))*0.5;
				depthB=(bNode->GetDepth(j)+bNode->GetDepth(j+1))*0.5;

				if (depthA<depthB) {
					ptrDepthArray2->Add(ptrDepthArray->GetDoubleAt(remainArray->GetIntAt(i)));
					ptrNxArray2->Add(ptrNxArray->GetIntAt(remainArray->GetIntAt(i)));
					ptrNyArray2->Add(ptrNyArray->GetIntAt(remainArray->GetIntAt(i)));
					ptrNzArray2->Add(ptrNzArray->GetIntAt(remainArray->GetIntAt(i)));
					ptrDepthArray2->Add(ptrDepthArray->GetDoubleAt(remainArray->GetIntAt(i+1)));
					ptrNxArray2->Add(ptrNxArray->GetIntAt(remainArray->GetIntAt(i+1)));
					ptrNyArray2->Add(ptrNyArray->GetIntAt(remainArray->GetIntAt(i+1)));
					ptrNzArray2->Add(ptrNzArray->GetIntAt(remainArray->GetIntAt(i+1)));
					i+=2;
				}
				else {
					depth=bNode->GetDepth(j);	bNode->GetNormal(j,nx,ny,nz);
					ptrDepthArray2->Add(depth);	ptrNxArray2->Add(nx); ptrNyArray2->Add(ny); ptrNzArray2->Add(nz);
					depth=bNode->GetDepth(j+1);	bNode->GetNormal(j+1,nx,ny,nz);
					ptrDepthArray2->Add(depth);	ptrNxArray2->Add(nx); ptrNyArray2->Add(ny); ptrNzArray2->Add(nz);
					j+=2;
				}
			}
			delete ptrNxArray;	delete ptrNyArray;	delete ptrNzArray;	delete ptrDepthArray;	
			delete remainArray;
			ptrNxArray=ptrNxArray2;	ptrNyArray=ptrNyArray2;	ptrNzArray=ptrNzArray2;	ptrDepthArray=ptrDepthArray2;
			nNum=ptrDepthArray->GetSize();
			for(k=0;k<nNum;k++) indexArray->Add(k);
		}
		else if (nOperationType==1) { // for intersect
			int nNum=ptrDepthArray->GetSize();
			for(int k=0;k<nNum;k+=2) {
				depth=(ptrDepthArray->GetDoubleAt(k)+ptrDepthArray->GetDoubleAt(k+1))*0.5;
				if (_detectNodeOverlap(depth,bNode)) {
					indexArray->Add(k);	indexArray->Add(k+1);
				}
			}
		}
		else if (nOperationType==2) { // for difference (the nodes in solidB will not be effected)
			int nNum=ptrDepthArray->GetSize();
			for(int k=0;k<nNum;k+=2) {
				depth=(ptrDepthArray->GetDoubleAt(k)+ptrDepthArray->GetDoubleAt(k+1))*0.5;
				if (!(_detectNodeOverlap(depth,bNode))) {
					indexArray->Add(k);	indexArray->Add(k+1);
					if (dirArray->GetIntAt(k)==2) {
						ptrNxArray->SetAt(k,255-ptrNxArray->GetIntAt(k));
						ptrNyArray->SetAt(k,255-ptrNyArray->GetIntAt(k));
						ptrNzArray->SetAt(k,255-ptrNzArray->GetIntAt(k));
					}
					if (dirArray->GetIntAt(k+1)==2) {
						ptrNxArray->SetAt(k+1,255-ptrNxArray->GetIntAt(k+1));
						ptrNyArray->SetAt(k+1,255-ptrNyArray->GetIntAt(k+1));
						ptrNzArray->SetAt(k+1,255-ptrNzArray->GetIntAt(k+1));
					}
				}
			}
		}

		//----------------------------------------------------------------------------------------
		//	Setp 3: Robust processing
		GLKArray *remainArray;
		remainArray=new GLKArray(50,50,1);
		//------------------------------------------------------------------------------------
		//	Remove small gaps
		iNum=(short)(indexArray->GetSize());
		if (iNum>0) {
			remainArray->Add(indexArray->GetIntAt(0));
			for(i=1;i<iNum-1;i+=2) {
				depth=ptrDepthArray->GetDoubleAt(indexArray->GetIntAt(i));
				depth2=ptrDepthArray->GetDoubleAt(indexArray->GetIntAt(i+1));
				if ((depth2-depth)<criterion) continue;
				remainArray->Add(indexArray->GetIntAt(i));
				remainArray->Add(indexArray->GetIntAt(i+1));
			}
			remainArray->Add(indexArray->GetIntAt(iNum-1));
		}
		//------------------------------------------------------------------------------------
		//	Remove small intervals
		indexArray->RemoveAll();
		jNum=(short)(remainArray->GetSize());
		if (jNum>0) {
			for(j=0;j<jNum;j+=2) {
				depth=ptrDepthArray->GetDoubleAt(remainArray->GetIntAt(j));
				depth2=ptrDepthArray->GetDoubleAt(remainArray->GetIntAt(j+1));
				if ((depth2-depth)<criterion) continue;
				indexArray->Add(remainArray->GetIntAt(j));
				indexArray->Add(remainArray->GetIntAt(j+1));
			}
		}
		delete remainArray;

		//----------------------------------------------------------------------------------------
		//	Step 4: Create the resultant sets
		iNum=(short)(indexArray->GetSize());
		if (iNum>0) {
			aNode->MallocSampleArray(iNum);
			for(i=0;i<iNum;i++) {
				int index=indexArray->GetIntAt(i);
				aNode->SetDepth(i,(float)(ptrDepthArray->GetDoubleAt(index)));
				aNode->SetNormal(i,(short)(ptrNxArray->GetIntAt(index)),
							(short)(ptrNyArray->GetIntAt(index)),(short)(ptrNzArray->GetIntAt(index)));
			}
			if (iNum%2==1) printf("ERROR!!! ");
		}
		else {
			delete aNode;	aNode=NULL;
		}

		//----------------------------------------------------------------------------------------
		//	Step 5: Free the memory
		delete ptrNxArray;	delete ptrNyArray;	delete ptrNzArray;	delete ptrDepthArray;	
		delete dirArray;	delete indexArray;
	}
	else if ((aNode==NULL) && (bNode!=NULL)) {
		if (nOperationType==0) { // union
			aNode=bNode;	bNode=NULL;
		}
		// for "intersect" and "difference", keeping NULL will be fine
	}
	else if ((aNode!=NULL) && (bNode==NULL)) {
		if (nOperationType==1) { // intersection
			delete aNode;	aNode=NULL;
		}
	}
}

bool LDNISolidOperation::_detectNodeOverlap(double depth, LDNISolidNode *solidNode)
{
	short i,num;

	if (solidNode==NULL) return false;

	num=solidNode->GetSampleNum();
	for(i=0;i<num;i+=2) {
		if ((depth>=solidNode->GetDepth(i)) && (depth<=solidNode->GetDepth(i+1))) return true;
		if (depth<solidNode->GetDepth(i)) return false;
	}
	return false;
}

void LDNISolidOperation::_processingDepthOfLDNISolidParallel(LDNISolid *solid)
{
	int nCase,res;		short discreteDelta=_CCL_DISCRETE_SUPPORT;
	double gwidth,origin[3],rayDir[3];
	const double truncate=0.5;

	//--------------------------------------------------------------------------------------------------------
	//	Step 1: preparation where the domain of newSolid is not changed
	gwidth=solid->GetGridWidth();	res=solid->GetResolution();
	solid->GetOrigin(origin);

	//--------------------------------------------------------------------------------------------------------
	//	Step 2: for each ray, processing its corresponding segments
	int newNum=res*res;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
//	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
	for(nCase=0;nCase<3;nCase++) {
		rayDir[0]=rayDir[1]=rayDir[2]=0.0;	rayDir[nCase]=1.0;
#pragma omp parallel for schedule(dynamic) 
		for(int kk=0;kk<newNum;kk++) {
			int i=kk/res;	int j=kk%res;

			LDNISolidNode *currentNode=solid->GetLDNISolidNode(nCase,i,j);
			if (!currentNode) continue;

			int num=currentNode->GetSampleNum();
			double normal[3],pp[3];
			int pntNum;	double sp[MAX_NEIGHBOR_NUMBER*3];	double hp[MAX_NEIGHBOR_NUMBER*3];
			for(int k=0;k<num;k++) {
				double depth=currentNode->GetDepth(k);
				currentNode->GetNormal(k,normal[0],normal[1],normal[2]);
					
				switch(nCase) {
					case 0:{pp[0]=depth; pp[1]=gwidth*(double)i; pp[2]=gwidth*(double)j;
						   }break;
					case 1:{pp[0]=gwidth*(double)j; pp[1]=depth; pp[2]=gwidth*(double)i;
						   }break;
					case 2:{pp[0]=gwidth*(double)i; pp[1]=gwidth*(double)j; pp[2]=depth;
						   }break;
				}
				pp[0]+=origin[0];	pp[1]+=origin[1];	pp[2]+=origin[2];
				_searchNeighboringHermiteDataSet(pp,currentNode->GetID(k),solid,discreteDelta,pntNum,sp,hp);

				//--------------------------------------------------------------------------------
				//	Processing the depth by using the Bilateral filtering
				double kk,tt,ff,gg,dd,alpha;
				alpha=kk=0.0;	
				double deltaC=1.5*gwidth;	double deltaG=DELTA_G_OF_GAUSSIAN;//0.1;//25;	
				for(int ii=0;ii<pntNum;ii++) {
					dd=sqrt((pp[0]-sp[ii*3])*(pp[0]-sp[ii*3])+(pp[1]-sp[ii*3+1])*(pp[1]-sp[ii*3+1])+(pp[2]-sp[ii*3+2])*(pp[2]-sp[ii*3+2]));
					tt=normal[0]*(normal[0]-hp[ii*3])+normal[1]*(normal[1]-hp[ii*3+1])+normal[2]*(normal[2]-hp[ii*3+2]);

					ff=gaussianFunction(dd,deltaC);	
					gg=gaussianFunction(tt,deltaG);

					alpha+=ff*gg*((sp[ii*3]-pp[0])*rayDir[0]+(sp[ii*3+1]-pp[1])*rayDir[1]+(sp[ii*3+2]-pp[2])*rayDir[2]);
					kk+=ff*gg;
				}

				if (fabs(kk)>1.0e-5) alpha=alpha/kk; else alpha=0.0;
				if (alpha>(truncate*gwidth)) alpha=truncate*gwidth;
				if (alpha<(-truncate*gwidth)) alpha=-truncate*gwidth;
				currentNode->SetDepth(k,(float)(depth+alpha));
			}
		}
	}
}

void LDNISolidOperation::_processingDepthOfLDNISolid(LDNISolid *solid)
{
	int i,j,nAxis,res;		
	short k,num,discreteDelta=_CCL_DISCRETE_SUPPORT;	
	LDNISolidNode *currentNode;
	double gwidth,depth,normal[3],origin[3],pp[3],dd,rayDir[3];
	double deltaC,deltaG;
	GLKObList hermiteDataSet,tempList;
	GLKPOSITION Pos;
	double truncate=0.2;

	gwidth=solid->GetGridWidth();	res=solid->GetResolution();
	solid->GetOrigin(origin);

	for(nAxis=0;nAxis<3;nAxis++) {
		for(i=0;i<res;i++) {
			for(j=0;j<res;j++) {
				currentNode=solid->GetLDNISolidNode(nAxis,i,j);
				if (!currentNode) continue;

				num=currentNode->GetSampleNum();
				for(k=0;k<num;k++) {
					depth=currentNode->GetDepth(k);
					currentNode->GetNormal(k,normal[0],normal[1],normal[2]);
					
					switch(nAxis) {
					case 0:{pp[0]=depth; pp[1]=gwidth*(double)i; pp[2]=gwidth*(double)j;
							rayDir[0]=1.0;	rayDir[1]=rayDir[2]=0.0;
						   }break;
					case 1:{pp[0]=gwidth*(double)j; pp[1]=depth; pp[2]=gwidth*(double)i;
							rayDir[1]=1.0;	rayDir[0]=rayDir[2]=0.0;
						   }break;
					case 2:{pp[0]=gwidth*(double)i; pp[1]=gwidth*(double)j; pp[2]=depth;
							rayDir[2]=1.0;	rayDir[0]=rayDir[1]=0.0;
						   }break;
					}
					pp[0]+=origin[0];	pp[1]+=origin[1];	pp[2]+=origin[2];
					_searchNeighboringHermiteDataSet(pp,solid,discreteDelta,&hermiteDataSet);

					//--------------------------------------------------------------------------------
					//	Processing the depth by using the Bilateral filtering
					double hh,kk,alpha,tt,ff,gg;
					hh=kk=0.0;
					deltaC=1.5*gwidth;	deltaG=0.25*gwidth;
					for(Pos=hermiteDataSet.GetHeadPosition();Pos!=NULL;) {
						LDNIHermiteData *data=(LDNIHermiteData *)(tempList.GetNext(Pos));
						dd=sqrt((pp[0]-data->pos[0])*(pp[0]-data->pos[0])+(pp[1]-data->pos[1])*(pp[1]-data->pos[1])+(pp[2]-data->pos[2])*(pp[2]-data->pos[2]));

						tt=rayDir[0]*data->normal[0]+rayDir[1]*data->normal[1]+rayDir[2]*data->normal[2];
						if (fabs(tt)<1.0e-5) continue;
						alpha=(data->pos[0]-pp[0])*data->normal[0]+(data->pos[1]-pp[1])*data->normal[1]+(data->pos[2]-pp[2])*data->normal[2];
						alpha=alpha/tt;

						ff=gaussianFunction(dd,deltaC);	
						gg=gaussianFunction(fabs(alpha),deltaG);

						hh+=ff*gg*alpha;
						kk+=ff*gg;
					}
					if (fabs(kk)>1.0e-5) alpha=hh/kk; else alpha=0.0;
					if (alpha>(truncate*gwidth)) alpha=truncate*gwidth;
					if (alpha<(-truncate*gwidth)) alpha=-truncate*gwidth;
					currentNode->SetDepth(k,(float)(depth+alpha));

					_deleteHermiteDataSet(&hermiteDataSet);
				}
			}
		}
	}
}

void LDNISolidOperation::_processingNormalOfLDNISolid(LDNISolid *solid)
{
	int i,j,nAxis,res;		
	short k,num,snx,sny,snz,discreteDelta=_CCL_DISCRETE_SUPPORT;	
	LDNISolidNode *currentNode;
	double gwidth,depth,normal[3],origin[3],pp[3],dd,rayDir[3];
	double deltaC,deltaG;
	GLKObList hermiteDataSet,tempList;
	GLKPOSITION Pos;

	gwidth=solid->GetGridWidth();	res=solid->GetResolution();
	solid->GetOrigin(origin);

	for(nAxis=0;nAxis<3;nAxis++) {
		for(i=0;i<res;i++) {
			for(j=0;j<res;j++) {
				currentNode=solid->GetLDNISolidNode(nAxis,i,j);
				if (!currentNode) continue;

				num=currentNode->GetSampleNum();
				for(k=0;k<num;k++) {
					depth=currentNode->GetDepth(k);
					currentNode->GetNormal(k,normal[0],normal[1],normal[2]);
					
					switch(nAxis) {
					case 0:{pp[0]=depth; pp[1]=gwidth*(double)i; pp[2]=gwidth*(double)j;
							rayDir[0]=1.0;	rayDir[1]=rayDir[2]=0.0;
						   }break;
					case 1:{pp[0]=gwidth*(double)j; pp[1]=depth; pp[2]=gwidth*(double)i;
							rayDir[1]=1.0;	rayDir[0]=rayDir[2]=0.0;
						   }break;
					case 2:{pp[0]=gwidth*(double)i; pp[1]=gwidth*(double)j; pp[2]=depth;
							rayDir[2]=1.0;	rayDir[0]=rayDir[1]=0.0;
						   }break;
					}
					pp[0]+=origin[0];	pp[1]+=origin[1];	pp[2]+=origin[2];
					_searchNeighboringHermiteDataSet(pp,solid,discreteDelta,&hermiteDataSet);

					//--------------------------------------------------------------------------------
					//	Processing the normal by using the Bilateral filtering
					double hh[3],kk,tt,ff,gg;
					hh[0]=hh[1]=hh[2]=kk=0.0;
					deltaC=1.5*gwidth;	deltaG=0.15;
					for(Pos=hermiteDataSet.GetHeadPosition();Pos!=NULL;) {
						LDNIHermiteData *data=(LDNIHermiteData *)(tempList.GetNext(Pos));
						dd=sqrt((pp[0]-data->pos[0])*(pp[0]-data->pos[0])+(pp[1]-data->pos[1])*(pp[1]-data->pos[1])+(pp[2]-data->pos[2])*(pp[2]-data->pos[2]));
						tt=normal[0]*(normal[0]-data->normal[0])+normal[1]*(normal[1]-data->normal[1])+normal[2]*(normal[2]-data->normal[2]);

						ff=gaussianFunction(dd,deltaC);	
						gg=gaussianFunction(tt,deltaG);

						hh[0]+=ff*gg*(data->normal[0]);
						hh[1]+=ff*gg*(data->normal[1]);
						hh[2]+=ff*gg*(data->normal[2]);
						kk+=ff*gg;
					}
					if (fabs(kk)>1.0e-5) {hh[0]=hh[0]/kk; hh[1]=hh[1]/kk; hh[2]=hh[2]/kk;} else {hh[0]=hh[1]=hh[2]=0.0;}
					dd=sqrt(hh[0]*hh[0]+hh[1]*hh[1]+hh[2]*hh[2]);
					if (dd<1.0e-5) {hh[0]=hh[1]=hh[2]=0.0;} else {hh[0]=hh[0]/dd; hh[1]=hh[1]/dd; hh[2]=hh[2]/dd;}
					snx=(short)((hh[0]+1.0)*255.0/2.0);
					sny=(short)((hh[1]+1.0)*255.0/2.0);
					snz=(short)((hh[2]+1.0)*255.0/2.0);
					currentNode->SetNormal(k,snx,sny,snz);

					_deleteHermiteDataSet(&hermiteDataSet);
				}
			}
		}
	}
}

void LDNISolidOperation::_searchNeighboringHermiteDataSet(double pp[], int id, LDNISolid *solid, int discreteDelta, 
														  int &pntNum, double sp[], double hp[])
{
	int i,j,k,lid,rid,lid2,rid2,xIndex,yIndex,zIndex,res,num,materialTypeNum=solid->GetMaterialTypeNum();
	double gwidth,origin[3],upper,lower,depth;
	LDNISolidNode *currentNode;

	gwidth=solid->GetGridWidth();	solid->GetOrigin(origin);	res=solid->GetResolution();
	xIndex=(int)((pp[0]-origin[0])/gwidth);	yIndex=(int)((pp[1]-origin[1])/gwidth);	zIndex=(int)((pp[2]-origin[2])/gwidth);
	pntNum=0;	lid=id/(materialTypeNum+1);		rid=id%(materialTypeNum+1);

	//---------------------------------------------------------------------------------------------------------------------
	//	x-direction
	if (pntNum<MAX_NEIGHBOR_NUMBER) {
		upper=pp[0]-origin[0]+gwidth*(double)discreteDelta;
		lower=pp[0]-origin[0]-gwidth*(double)discreteDelta;
		for(i=yIndex-discreteDelta;i<=yIndex+discreteDelta;i++) {
			if ((i<0) || (i>=res)) continue;
			for(j=zIndex-discreteDelta;j<=zIndex+discreteDelta;j++) {
				if ((j<0) || (j>=res)) continue;
				currentNode=solid->GetLDNISolidNode(0,i,j);
				if (!currentNode) continue;

				num=currentNode->GetSampleNum();
				for(k=0;k<num;k++) {
					depth=currentNode->GetDepth(k);
					if (depth<lower) continue;
					if (depth>upper) break;
					id=currentNode->GetID(k);	lid2=id/(materialTypeNum+1);	rid2=id%(materialTypeNum+1);
					if (!((lid==lid2 && rid==rid2) || (rid==lid2 && lid==rid2))) continue;

					sp[pntNum*3]=origin[0]+depth;
					sp[pntNum*3+1]=origin[1]+gwidth*(double)i;
					sp[pntNum*3+2]=origin[2]+gwidth*(double)j;
					currentNode->GetNormal(k,hp[pntNum*3],hp[pntNum*3+1],hp[pntNum*3+2]);
					pntNum++;
					if (pntNum>=MAX_NEIGHBOR_NUMBER) break;
				}
				if (pntNum>=MAX_NEIGHBOR_NUMBER) break;
			}
			if (pntNum>=MAX_NEIGHBOR_NUMBER) break;
		}
	}

	//---------------------------------------------------------------------------------------------------------------------
	//	y-direction
	if (pntNum<MAX_NEIGHBOR_NUMBER) {
		upper=pp[1]-origin[1]+gwidth*(double)discreteDelta;
		lower=pp[1]-origin[1]-gwidth*(double)discreteDelta;
		for(i=zIndex-discreteDelta;i<=zIndex+discreteDelta;i++) {
			if ((i<0) || (i>=res)) continue;
			for(j=xIndex-discreteDelta;j<=xIndex+discreteDelta;j++) {
				if ((j<0) || (j>=res)) continue;
				currentNode=solid->GetLDNISolidNode(1,i,j);
				if (!currentNode) continue;

				num=currentNode->GetSampleNum();
				for(k=0;k<num;k++) {
					depth=currentNode->GetDepth(k);
					if (depth<lower) continue;
					if (depth>upper) break;
					id=currentNode->GetID(k);	lid2=id/(materialTypeNum+1);	rid2=id%(materialTypeNum+1);
					if (!((lid==lid2 && rid==rid2) || (rid==lid2 && lid==rid2))) continue;

					sp[pntNum*3]=origin[0]+gwidth*(double)j;
					sp[pntNum*3+1]=origin[1]+depth;
					sp[pntNum*3+2]=origin[2]+gwidth*(double)i;
					currentNode->GetNormal(k,hp[pntNum*3],hp[pntNum*3+1],hp[pntNum*3+2]);
					pntNum++;
					if (pntNum>=MAX_NEIGHBOR_NUMBER) break;
				}
				if (pntNum>=MAX_NEIGHBOR_NUMBER) break;
			}
			if (pntNum>=MAX_NEIGHBOR_NUMBER) break;
		}
	}

	//---------------------------------------------------------------------------------------------------------------------
	//	z-direction
	if (pntNum<MAX_NEIGHBOR_NUMBER) {
		upper=pp[2]-origin[2]+gwidth*(double)discreteDelta;
		lower=pp[2]-origin[2]-gwidth*(double)discreteDelta;
		for(i=xIndex-discreteDelta;i<=xIndex+discreteDelta;i++) {
			if ((i<0) || (i>=res)) continue;
			for(j=yIndex-discreteDelta;j<=yIndex+discreteDelta;j++) {
				if ((j<0) || (j>=res)) continue;
				currentNode=solid->GetLDNISolidNode(2,i,j);
				if (!currentNode) continue;

				num=currentNode->GetSampleNum();
				for(k=0;k<num;k++) {
					depth=currentNode->GetDepth(k);
					if (depth<lower) continue;
					if (depth>upper) break;
					id=currentNode->GetID(k);	lid2=id/(materialTypeNum+1);	rid2=id%(materialTypeNum+1);
					if (!((lid==lid2 && rid==rid2) || (rid==lid2 && lid==rid2))) continue;

					sp[pntNum*3]=origin[0]+gwidth*(double)i;
					sp[pntNum*3+1]=origin[1]+gwidth*(double)j;
					sp[pntNum*3+2]=origin[2]+depth;
					currentNode->GetNormal(k,hp[pntNum*3],hp[pntNum*3+1],hp[pntNum*3+2]);
					pntNum++;
					if (pntNum>=MAX_NEIGHBOR_NUMBER) break;
				}
				if (pntNum>=MAX_NEIGHBOR_NUMBER) break;
			}
			if (pntNum>=MAX_NEIGHBOR_NUMBER) break;
		}
	}
}

void LDNISolidOperation::_searchNeighboringHermiteDataSet(double pp[], LDNISolid *solid, int discreteDelta, GLKObList *dataSet)
{
	int i,j,k,xIndex,yIndex,zIndex,res,num;
	double gwidth,origin[3],upper,lower,depth;
	LDNISolidNode *currentNode;

	gwidth=solid->GetGridWidth();	solid->GetOrigin(origin);	res=solid->GetResolution();
	xIndex=(int)((pp[0]-origin[0])/gwidth);	yIndex=(int)((pp[1]-origin[1])/gwidth);	zIndex=(int)((pp[2]-origin[2])/gwidth);
	dataSet->RemoveAll();

	//---------------------------------------------------------------------------------------------------------------------
	//	x-direction
	upper=pp[0]-origin[0]+gwidth*(double)discreteDelta;
	lower=pp[0]-origin[0]-gwidth*(double)discreteDelta;
	for(i=yIndex-discreteDelta;i<=yIndex+discreteDelta;i++) {
		if ((i<0) || (i>=res)) continue;
		for(j=zIndex-discreteDelta;j<=zIndex+discreteDelta;j++) {
			if ((j<0) || (j>=res)) continue;
			currentNode=solid->GetLDNISolidNode(0,i,j);
			if (!currentNode) continue;

			num=currentNode->GetSampleNum();
			for(k=0;k<num;k++) {
				depth=currentNode->GetDepth(k);
				if (depth<lower) continue;
				if (depth>upper) break;

				LDNIHermiteData *data=new LDNIHermiteData;
				currentNode->GetNormal(k,data->normal[0],data->normal[1],data->normal[2]);
				data->pos[0]=origin[0]+depth;
				data->pos[1]=origin[1]+gwidth*(double)i;
				data->pos[2]=origin[2]+gwidth*(double)j;
				dataSet->AddTail(data);
			}
		}
	}

	//---------------------------------------------------------------------------------------------------------------------
	//	y-direction
	upper=pp[1]-origin[1]+gwidth*(double)discreteDelta;
	lower=pp[1]-origin[1]-gwidth*(double)discreteDelta;
	for(i=zIndex-discreteDelta;i<=zIndex+discreteDelta;i++) {
		if ((i<0) || (i>=res)) continue;
		for(j=xIndex-discreteDelta;j<=xIndex+discreteDelta;j++) {
			if ((j<0) || (j>=res)) continue;
			currentNode=solid->GetLDNISolidNode(1,i,j);
			if (!currentNode) continue;

			num=currentNode->GetSampleNum();
			for(k=0;k<num;k++) {
				depth=currentNode->GetDepth(k);
				if (depth<lower) continue;
				if (depth>upper) break;

				LDNIHermiteData *data=new LDNIHermiteData;
				currentNode->GetNormal(k,data->normal[0],data->normal[1],data->normal[2]);
				data->pos[0]=origin[0]+gwidth*(double)j;
				data->pos[1]=origin[1]+depth;
				data->pos[2]=origin[2]+gwidth*(double)i;
				dataSet->AddTail(data);
			}
		}
	}

	//---------------------------------------------------------------------------------------------------------------------
	//	z-direction
	upper=pp[2]-origin[2]+gwidth*(double)discreteDelta;
	lower=pp[2]-origin[2]-gwidth*(double)discreteDelta;
	for(i=xIndex-discreteDelta;i<=xIndex+discreteDelta;i++) {
		if ((i<0) || (i>=res)) continue;
		for(j=yIndex-discreteDelta;j<=yIndex+discreteDelta;j++) {
			if ((j<0) || (j>=res)) continue;
			currentNode=solid->GetLDNISolidNode(2,i,j);
			if (!currentNode) continue;

			num=currentNode->GetSampleNum();
			for(k=0;k<num;k++) {
				depth=currentNode->GetDepth(k);
				if (depth<lower) continue;
				if (depth>upper) break;

				LDNIHermiteData *data=new LDNIHermiteData;
				currentNode->GetNormal(k,data->normal[0],data->normal[1],data->normal[2]);
				data->pos[0]=origin[0]+gwidth*(double)i;
				data->pos[1]=origin[1]+gwidth*(double)j;
				data->pos[2]=origin[2]+depth;
				dataSet->AddTail(data);
			}
		}
	}
}

void LDNISolidOperation::_approximateNormal(int ***indexArray, int xNum, int yNum, int zNum,
											int xIndex, int yIndex, int zIndex, 
											int xIndex2, int yIndex2, int zIndex2, 
											double normal[])
{
	//{	// Naive normal estimation
	//	double dir[3],dd;	
	//
	//	dir[0]=xIndex2-xIndex;	dir[1]=yIndex2-yIndex;	dir[2]=zIndex2-zIndex;
	//	dd=dir[0]*dir[0]+dir[1]*dir[1]+dir[2]*dir[2];	dd=sqrt(dd);
	//	normal[0]=normal[1]=normal[2]=0.0;
	//	if (dd>1.0e-5) {normal[0]=dir[0]/dd; normal[1]=dir[1]/dd; normal[2]=dir[2]/dd;}
	//	if (indexArray[xIndex][yIndex][zIndex]<indexArray[xIndex2][yIndex2][zIndex2]) {
	//		normal[0]=-normal[0];	normal[1]=-normal[1];	normal[2]=-normal[2];
	//	}
	//	return;
	//}

	double px[53],py[53],pz[53],cx,cy,cz,div,dir[3],dir2[3],dd,nx,ny,nz;		int pntNum;
	int support=_CCL_DISCRETE_SUPPORT;	int i,j,k,csID,ceID,sID,eID;
	double **covariantM;
	double **eigenvectors;	 double *eigenvalues;	int minIndex;	double minValue;

	dir[0]=xIndex2-xIndex;	dir[1]=yIndex2-yIndex;	dir[2]=zIndex2-zIndex;
	dd=dir[0]*dir[0]+dir[1]*dir[1]+dir[2]*dir[2];	dd=sqrt(dd);
	normal[0]=normal[1]=normal[2]=0.0;
	if (dd>1.0e-5) {normal[0]=dir[0]/dd; normal[1]=dir[1]/dd; normal[2]=dir[2]/dd;} 
	if (indexArray[xIndex][yIndex][zIndex]<indexArray[xIndex2][yIndex2][zIndex2]) {
		normal[0]=-normal[0];	normal[1]=-normal[1];	normal[2]=-normal[2];	// the point direct should be inversed
		dir[0]=-dir[0];	dir[1]=-dir[1];	dir[2]=-dir[2];
		csID=indexArray[xIndex][yIndex][zIndex];	ceID=indexArray[xIndex2][yIndex2][zIndex2];
	}
	else {
		csID=indexArray[xIndex2][yIndex2][zIndex2];	ceID=indexArray[xIndex][yIndex][zIndex];	
	}

	pntNum=0;
	for(i=xIndex-support;i<xIndex2+support;i++) {
		if ((i<0) || (i>(xNum-2))) continue;
		for(j=yIndex-support;j<yIndex2+support;j++) {
			if ((j<0) || (j>(yNum-2))) continue;
			for(k=zIndex-support;k<zIndex2+support;k++) {
				if ((k<0) || (k>(zNum-2))) continue;

				if (indexArray[i][j][k]!=indexArray[i+1][j][k]) {
					dir2[2]=dir2[1]=0.0;
					if (indexArray[i][j][k]>indexArray[i+1][j][k]) {
						dir2[0]=1.0;	sID=indexArray[i+1][j][k];	eID=indexArray[i][j][k];
					}
					else {
						dir2[0]=-1.0;	eID=indexArray[i+1][j][k];	sID=indexArray[i][j][k];
					}
					if (sID==csID && eID==ceID) {
						dd=dir[0]*dir2[0]+dir[1]*dir2[1]+dir[2]*dir2[2];
						if (dd>0.0) {px[pntNum]=(double)i+0.5;	py[pntNum]=(double)j;	pz[pntNum]=(double)k;	pntNum++;} 
					}
				}
				if (indexArray[i][j][k]!=indexArray[i][j+1][k]) {
					dir2[2]=dir2[0]=0.0;
					if (indexArray[i][j][k]>indexArray[i][j+1][k]) {
						dir2[1]=1.0; 	sID=indexArray[i][j+1][k];	eID=indexArray[i][j][k];
					}
					else {
						dir2[1]=-1.0; 	eID=indexArray[i][j+1][k];	sID=indexArray[i][j][k];
					}
					if (sID==csID && eID==ceID) {
						dd=dir[0]*dir2[0]+dir[1]*dir2[1]+dir[2]*dir2[2];
						if (dd>0.0) {px[pntNum]=(double)i;	py[pntNum]=(double)j+0.5;	pz[pntNum]=(double)k;	pntNum++;}
					}
				}
				if (indexArray[i][j][k]!=indexArray[i][j][k+1]) {
					dir2[0]=dir2[1]=0.0;
					if (indexArray[i][j][k]>indexArray[i][j][k+1]) {
						dir2[2]=1.0; 	sID=indexArray[i][j][k+1];	eID=indexArray[i][j][k]; 
					}
					else {
						dir2[2]=-1.0; 	eID=indexArray[i][j][k+1];	sID=indexArray[i][j][k]; 
					}
					if (sID==csID && eID==ceID) {
						dd=dir[0]*dir2[0]+dir[1]*dir2[1]+dir[2]*dir2[2];
						if (dd>0.0) {px[pntNum]=(double)i;	py[pntNum]=(double)j;	pz[pntNum]=(double)k+0.5;	pntNum++;}
					}
				}

				if (pntNum>=49) break;
			}
			if (pntNum>=49) break;
		}
		if (pntNum>=49) break;
	}
	if (pntNum<10) {normal[0]=normal[1]=normal[2]=0; return;}	// the normal at this sample will be processed later by the normal filter

	cx=cy=cz=0.0;
	for(i=0;i<pntNum;i++) {cx+=px[i];	cy+=py[i];	cz+=pz[i];}
	div=1.0/(double)(pntNum);	cx=cx*div;	cy=cy*div;	cz=cz*div;

	GLKMatrixLib::CreateMatrix(covariantM,3,3);
	GLKMatrixLib::CreateMatrix(eigenvectors,3,3);	eigenvalues=new double[3];
	for(i=0;i<pntNum;i++) {
		covariantM[0][0]+=(px[i]-cx)*(px[i]-cx);	covariantM[0][1]+=(px[i]-cx)*(py[i]-cy);	covariantM[0][2]+=(px[i]-cx)*(pz[i]-cz);
		covariantM[1][1]+=(py[i]-cy)*(py[i]-cy);	covariantM[1][2]+=(py[i]-cy)*(pz[i]-cz);
		covariantM[2][2]+=(pz[i]-cz)*(pz[i]-cz);
	}
	covariantM[1][0]=covariantM[0][1];	covariantM[2][0]=covariantM[0][2]; 	covariantM[2][1]=covariantM[1][2];		

	bool bRes=GLKMatrixLib::JacobianEigensystemSolver(covariantM,3,eigenvectors,eigenvalues,1.0e-7,100);
	if (!bRes) printf("The computation of Jacobian EigenSystem fails\n");
	minIndex=0;	minValue=fabs(eigenvalues[0]);
	if (fabs(eigenvalues[1])<minValue) {minValue=fabs(eigenvalues[1]);minIndex=1;}
	if (fabs(eigenvalues[2])<minValue) minIndex=2;

	nx=eigenvectors[0][minIndex];
	ny=eigenvectors[1][minIndex];
	nz=eigenvectors[2][minIndex];
	dd=sqrt(nx*nx+ny*ny+nz*nz);
	if (dd>1.0e-5) {nx=nx/dd; ny=ny/dd; nz=nz/dd;} else {nx=ny=nz=0.0;}
	dd=nx*normal[0]+ny*normal[1]+nz*normal[2];
	if (dd>0.0) {
		normal[0]=nx; normal[1]=ny; normal[2]=nz;
	}
	else {
		normal[0]=-nx; normal[1]=-ny; normal[2]=-nz;
	}

	GLKMatrixLib::DeleteMatrix(covariantM,3,3);
	GLKMatrixLib::DeleteMatrix(eigenvectors,3,3);	delete []eigenvalues;
}

void LDNISolidOperation::_deleteHermiteDataSet(GLKObList *dataSet)
{
	GLKPOSITION Pos;

	for(Pos=dataSet->GetHeadPosition();Pos!=NULL;) {
		LDNIHermiteData *data=(LDNIHermiteData *)(dataSet->GetNext(Pos));
		delete data;
	}
	dataSet->RemoveAll();
}

void LDNISolidOperation::_normalCorrection(short nDir, bool bEnteringOrLeaving, short &ix, short &iy, short &iz)
{
	if (bEnteringOrLeaving) {
		switch(nDir) {
		case 0:{if (ix>=128) {ix=255-ix; iy=255-iy; iz=255-iz;}
			   }break;
		case 1:{if (iy>=128) {ix=255-ix; iy=255-iy; iz=255-iz;}
			   }break;
		case 2:{if (iz>=128) {ix=255-ix; iy=255-iy; iz=255-iz;}
			   }break;
		}
	}
	else {
		switch(nDir) {
		case 0:{if (ix<128) {ix=255-ix; iy=255-iy; iz=255-iz;}
			   }break;
		case 1:{if (iy<128) {ix=255-ix; iy=255-iy; iz=255-iz;}
			   }break;
		case 2:{if (iz<128) {ix=255-ix; iy=255-iy; iz=255-iz;}
			   }break;
		}
	}
}

void LDNISolidOperation::_encodeNormal(double nx, double ny, double nz, short &ix, short &iy, short &iz)
{
	ix=(short)((nx+1.0)*127.5);
	iy=(short)((ny+1.0)*127.5);
	iz=(short)((nz+1.0)*127.5);
}

void LDNISolidOperation::_collectingSamples(short nDir, LDNISolidNode *currentNode)
{
	int k,sampleNum=currentNode->GetSampleNum();	if (sampleNum==0) return;
	float *newSampleDepth;	short *newNx,*newNy,*newNz;	
	int newSampleNum=0;		
	newSampleDepth=new float[sampleNum];
	newNx=new short[sampleNum];	newNy=new short[sampleNum];	newNz=new short[sampleNum];
	
	bool bPrev,bNext;	
	bPrev=false;	// out of the solid
	for(k=0;k<sampleNum;k++) {
		if (currentNode->GetDepth(k)>0.0) 
			bNext=true;
		else
			bNext=false;

		if (bPrev!=bNext) {
			newSampleDepth[newSampleNum]=(float)(fabs(currentNode->GetDepth(k)));
			currentNode->GetNormal(k,newNx[newSampleNum],newNy[newSampleNum],newNz[newSampleNum]);
			newSampleNum++;		
		}
		bPrev=bNext;
	}

	if (newSampleNum<2) {
		currentNode->ReleaseSampleArray();
	}
	else {
		currentNode->MallocSampleArray(newSampleNum);
		for(k=0;k<newSampleNum;k++) {
			currentNode->SetDepth(k,newSampleDepth[k]);
			if (k%2==0)
				_normalCorrection(nDir,true,newNx[k],newNy[k],newNz[k]);
			else
				_normalCorrection(nDir,false,newNx[k],newNy[k],newNz[k]);
			currentNode->SetNormal(k,newNx[k],newNy[k],newNz[k]);
		}
	}

	delete []newSampleDepth;	delete []newNx;		delete []newNy;		delete []newNz;
}

bool LDNISolidOperation::_othorgonalFillingBasedCorrection(short nAxis, int ii, int jj, LDNISolid *solid)
{
	LDNISolidNode *solidNode=solid->GetLDNISolidNode(nAxis,ii,jj);	if (solidNode==NULL) return false;
	int k,sampleNum=solidNode->GetSampleNum();
	double lowerDepth,upperDepth,width=solid->GetGridWidth();
	int stIndex,edIndex;	bool bFilled=false;

	//-------------------------------------------------------------------------------------------
	//	Detecting the intervals that should be outside the volume one by one
	for(k=1;k<sampleNum-1;k++) {
		//---------------------------------------------------------------------------------------
		//	Step 1: find the grid nodes in this interval
		lowerDepth=solidNode->GetDepth(k);	
		if (lowerDepth<0.0) continue;	// this interval has already been flagged as outside
		upperDepth=solidNode->GetDepth(k+1);	
		stIndex=(int)(fabs(lowerDepth)/width+0.5);
		edIndex=(int)(fabs(upperDepth)/width+0.5);	
		if ((0.5+(double)edIndex)*width==fabs(upperDepth)) edIndex--;
		stIndex++;	edIndex--;
		if (stIndex>edIndex) continue;

		//---------------------------------------------------------------------------------------
		//	Step 2: detect the node to see if any of them is flagged as 'outside' in other directions
		for(int kk=stIndex;kk<=edIndex;kk++) {
			if ((_isPointOutside((nAxis+1)%3,jj,kk,ii,solid))
				|| (_isPointOutside((nAxis+2)%3,kk,ii,jj,solid))) {
				solidNode->SetDepth(k,(float)(-fabs(lowerDepth)));	// set the interval as 'outside'
				bFilled=true;	break;
			}
		}
	}

	return bFilled;
}

bool LDNISolidOperation::_isPointOutside(short nAxis, int ii, int jj, int kk, LDNISolid *solid)
{
	LDNISolidNode *solidNode=solid->GetLDNISolidNode(nAxis,ii,jj);	if (solidNode==NULL) return true;
	double depth,width=solid->GetGridWidth();

	int sampleNum=solidNode->GetSampleNum();	if (sampleNum==0) return true;
	depth=fabs(solidNode->GetDepth(0));	
	if (kk<(int)(depth/width+0.5)) return true;
	depth=fabs(solidNode->GetDepth(sampleNum-1));
	if (kk>(int)(depth/width+0.5)) return true;

	int iStDepth,iEdDepth;
	iStDepth=(int)(fabs(solidNode->GetDepth(0))/width+0.5);
	if (kk==iStDepth) return false;
	for(int k=1;k<sampleNum;k++) {
		iEdDepth=(int)(fabs(solidNode->GetDepth(k))/width+0.5);
		if (kk==iEdDepth) return false;
		if (kk>iStDepth && kk<iEdDepth) {
			if (solidNode->GetDepth(k-1)<0.0) return true; else return false;
		}
	}

	return false;
}

