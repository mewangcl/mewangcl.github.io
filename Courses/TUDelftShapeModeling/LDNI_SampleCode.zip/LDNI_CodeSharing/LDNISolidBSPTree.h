#ifndef _CCL_LDNISOLID_BSPTREE
#define _CCL_LDNISOLID_BSPTREE

#define MAX_BSPTREE_LEVEL		20
#define MAX_LDNI_LAYER_NUM		600000
#define APPROXIMATION_ERROR		0.5	

//#define _DEBUG_BSP_DISPLAY	true

class LDNISolidBSPTreeNode	
{
public:
	LDNISolidBSPTreeNode(void);
	virtual ~LDNISolidBSPTreeNode(void);

	double np[3],cp[3];		// the normal vector and the pnt vector of the plane
	LDNISolidBSPTreeNode *leftChild, *rightChild;
	bool bSolid;	// true - this is a solid cell
					// false - if (leftChild==NULL && rightChild==NULL), this is an empty cell; otherwise, this is a fuzzy cell.

	bool IsEmpty() {if ((!bSolid) && (leftChild==NULL) && (rightChild==NULL)) return true; else return false;};
	bool IsLeaveNode() {return (leftChild==NULL && rightChild==NULL);}
};

class LDNISolidBSPTreeOperation
{
public:
	LDNISolidBSPTreeOperation(void);
	virtual ~LDNISolidBSPTreeOperation(void);

	static void BSPTreeConstruction(LDNISolid *solid, LDNISolidBSPTreeNode *&root);
	static void LDNISolidSampledFromBSPTree(LDNISolidBSPTreeNode *root, short res, double gwidth, double origin[], LDNISolid *&solid);
	static bool PntMembershipClassification(LDNISolidBSPTreeNode *root, double pnt[]);

private:
	//-----------------------------------------------------------------------------------------------------------------------------------------------------------
	//	The functions for BSP-tree construction
	static void _cellConstruction(LDNISolidBSPTreeNode *cell, LDNISolid *solid, int sXYZ[], int eXYZ[], int level);
	static bool _isOrthogonalRefinementNeeded(LDNISolid *solid, int sXYZ[], int eXYZ[], double geoCriterion);
	static bool _isEmptyOrSolidCell(bool bNodeIn[]);
	static bool _complexCellCheck_InvalidEmptyOrSolidCell(LDNISolid *solid, bool bSolid, int sXYZ[], int eXYZ[]);
	static bool _complexCellCheck_AmbiguousFaceOrCell(bool bNodeIn[]);
	static bool _complexCellCheck_MultipleEdgeIntersections(LDNISolid *solid, int sXYZ[], int eXYZ[]);
	static bool _complexCellCheck_InvalidEmptyOrSolidFace(LDNISolid *solid,	int sXYZ[], int eXYZ[], bool bNodeIn[]);
	static void _compQEFPntInCell(LDNISolid *solid, int sXYZ[], int eXYZ[], double posQEF[], bool bTruncate);
	static bool _IsGeometryCompatibleInCell(LDNISolid *solid, int sXYZ[], int eXYZ[], double posQEF[], double geoCriterion);
	static bool _searchSamplesInCell(LDNISolid *solid, int sXYZ[], int eXYZ[], int &pntNum, double** &samplePnts);
	static void _nonorthogonalCellConstruction(LDNISolidBSPTreeNode *cell, int pntNum, double** samplePnts, int level, double tolerance);

	//-----------------------------------------------------------------------------------------------------------------------------------------------------------
	//	The functions for the rasterization of a solid represented by BSP-tree
	static void _compIntersectionsOnRay(LDNISolidBSPTreeNode *treeNode, short nDir, short i, short j, 
									int res, double gwidth, double origin[], double sDepth, double eDepth, 
									double sNx, double sNy,	double sNz, double eNx, double eNy,	double eNz,
									int &sampleNum, double *depth, double *nx, double *ny, double *nz, double tolerance);
	static bool _compSegmentPlaneIntersectionPnt(char nDir, short i, short j, double depth1, double depth2, double gwidth, 
									double origin[], double pc[], double np[], double &interDepth, bool &bDir);

	//-----------------------------------------------------------------------------------------------------------------------------------------------------------
	//	The general service functions
	static void encodeNormal(double nx, double ny, double nz, short &ix, short &iy, short &iz);

	//-----------------------------------------------------------------------------------------------------------------------------------------------------------
	//	The general service functions
	static void _debugSolidEmptyCheck(LDNISolidBSPTreeNode *root);
};

#endif