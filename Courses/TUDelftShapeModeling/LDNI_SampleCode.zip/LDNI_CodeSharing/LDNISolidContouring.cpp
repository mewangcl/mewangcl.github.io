#include <math.h>
#include <time.h>
#include <omp.h>

#include "..\GLKLib\GLKObList.h"
#include "..\GLKLib\GLKGeometry.h"
#include "..\GLKLib\GLKMatrixLib.h"

#include "..\QMeshLib\QMeshPatch.h"
#include "..\QMeshLib\QMeshNode.h"
#include "..\QMeshLib\QMeshEdge.h"
#include "..\QMeshLib\QMeshFace.h"

#include "LDNISolid.h"
#include "LDNISolidContouring.h"

LDNISolidContouring::LDNISolidContouring(void)
{
}

LDNISolidContouring::~LDNISolidContouring(void)
{
}

void LDNISolidContouring::MeshGeneration(LDNISolid* solid, QMeshPatch* &mesh)
{
	int res,cellNum,i,j,k,num;
	double tolerance;
	LDNISolidOctreeCell ****cellArray;
	LDNISolidOctreeCell **cellList;

	//-----------------------------------------------------------------------------
	//	Step 1: Preparation
	mesh=NULL;
	res=solid->GetResolution();
	tolerance=_CCL_TOLERANCE_RES*solid->GetGridWidth();
	int contouringRate=res;
	contouringRate=(int)(pow(2.0,(int)(log((double)res)/log(2.0)+1.0)));
	contouringRate=(contouringRate<_CCL_LDNICONTOURING_RATE)?contouringRate:_CCL_LDNICONTOURING_RATE;
	cellNum=(res-1)/contouringRate;
	if (cellNum*contouringRate<(res-1)) cellNum++;

	//-----------------------------------------------------------------------------
	//	Step 2: Construct octree cells for the mesh generation
	long time=clock();
	cellArray=(LDNISolidOctreeCell ****)new long[cellNum];
	cellList=(LDNISolidOctreeCell **)new long[cellNum*cellNum*cellNum*8];
	for(i=0;i<cellNum;i++) {
		cellArray[i]=(LDNISolidOctreeCell ***)new long[cellNum];
		for(j=0;j<cellNum;j++) {
			cellArray[i][j]=(LDNISolidOctreeCell **)new long[cellNum];
			for(k=0;k<cellNum;k++) {
				cellArray[i][j][k]=new LDNISolidOctreeCell;
				LDNISolidOctreeCell *root=cellArray[i][j][k];
				root->sX=i*contouringRate;
				root->eX=(i+1)*contouringRate;
				root->sY=j*contouringRate;
				root->eY=(j+1)*contouringRate;
				root->sZ=k*contouringRate;
				root->eZ=(k+1)*contouringRate;
				root->m_nodeInside[0]=solid->DetectNodeInOrOut(root->sX,root->sY,root->sZ);
				root->m_nodeInside[1]=solid->DetectNodeInOrOut(root->eX,root->sY,root->sZ);
				root->m_nodeInside[2]=solid->DetectNodeInOrOut(root->sX,root->eY,root->sZ);
				root->m_nodeInside[3]=solid->DetectNodeInOrOut(root->eX,root->eY,root->sZ);
				root->m_nodeInside[4]=solid->DetectNodeInOrOut(root->sX,root->sY,root->eZ);
				root->m_nodeInside[5]=solid->DetectNodeInOrOut(root->eX,root->sY,root->eZ);
				root->m_nodeInside[6]=solid->DetectNodeInOrOut(root->sX,root->eY,root->eZ);
				root->m_nodeInside[7]=solid->DetectNodeInOrOut(root->eX,root->eY,root->eZ);
				_cellRefinement(solid,root,tolerance,0);

				for(int id=0;id<8;id++)	cellList[(i*cellNum*cellNum+j*cellNum+k)*8+id]=root->m_childOctreeNode[id];
			}
		}
	}
	//-----------------------------------------------------------------------------
	//	Refine cells in the task-list
	printf("Number of Processors: %d\n",omp_get_num_procs());
	num=cellNum*cellNum*cellNum*8;
	omp_set_dynamic(8);
	omp_set_num_threads(8);
	printf("Number of Threads Allowed: %d\n",omp_get_max_threads());
#pragma omp parallel for schedule(dynamic) 
	for(int id=0;id<num;id++) {
//		printf("Thread ID: %d ",omp_get_thread_num());
		_cellRefinement(solid,cellList[id],tolerance,1);
	}
	printf("Octree Construction Time: %ld\n",clock()-time); time=clock();

	int nodeNum=0;	for(int id=0;id<num;id++) {if (cellList[id]) _debugCountNodeNum(cellList[id],nodeNum);}	printf("Octree Cell Num=%d\n",nodeNum);

	//-----------------------------------------------------------------------------
	//	Step 3: Mesh generation
	mesh=new QMeshPatch;
	_contourCellArray(solid,cellArray,cellNum,mesh);

	//-----------------------------------------------------------------------------
	//	Step 4: Post-processing
	_quadMeshToTrglMesh(mesh);
	_fillMeshTopology(mesh);
	printf("Mesh Generation Time: %ld\n",clock()-time); time=clock();

//	_nonmanifoldToManifoldCorrection(solid,mesh);
//	_fillMeshTopology(mesh);

//	QMeshPatch *newMesh=new QMeshPatch;
//	_debugContouringCell(solid,cellArray[0][0][0],newMesh);
//	delete mesh;	mesh=newMesh;
//	_debugManifoldCheck(mesh);

	//-----------------------------------------------------------------------------
	//	Step 5: Free the memory
	for(i=0;i<cellNum;i++) {
		for(j=0;j<cellNum;j++) {
			for(k=0;k<cellNum;k++) {
				delete (LDNISolidOctreeCell*)(cellArray[i][j][k]);
			}
			delete [](LDNISolidOctreeCell **)(cellArray[i][j]);
		}
		delete [](LDNISolidOctreeCell ***)(cellArray[i]);
	}
	delete [](LDNISolidOctreeCell ****)(cellArray);
	delete [](LDNISolidOctreeCell **)(cellList);
}

void LDNISolidContouring::_debugCountNodeNum(LDNISolidOctreeCell *cell, int &nodeNum)
{
	int i=0;

	for(i=0;i<8;i++) {
		if (cell->m_childOctreeNode[i]) {
			nodeNum+=8;
			_debugCountNodeNum(cell->m_childOctreeNode[i],nodeNum);
		}
	}
}

void LDNISolidContouring::_debugManifoldCheck(QMeshPatch *mesh)
{
	GLKPOSITION PosNode;

	for(PosNode=mesh->GetNodeList().GetHeadPosition();PosNode!=NULL;) {
		QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(PosNode));

		GLKPOSITION Pos;
		QMeshEdge* currentedge = NULL;
		QMeshEdge* startedge = NULL; QMeshEdge* nextedge = NULL;
		QMeshFace* face, *currentface;  
		int num,j,i,edgeNum;

		for(Pos = node->GetFaceList().GetHeadPosition(); Pos!=NULL;) {
			face = (QMeshFace*)(node->GetFaceList().GetNext(Pos));
			face->m_nIdentifiedPatchIndex = -1;
		}
		currentedge = (QMeshEdge*)(node->GetEdgeList().GetHead());

		startedge = currentedge;
		num = 0;
		do{
			if(currentedge->GetStartPoint() == node)
				currentface = currentedge->GetLeftFace();
			else
				currentface = currentedge->GetRightFace();

			if (currentface == NULL) {printf("Error: NULL currentFace is found!\n"); return;}
			currentface->m_nIdentifiedPatchIndex = num;

			int edgeNum = currentface->GetEdgeNum();
			nextedge = NULL;
			for(i=0;i<edgeNum;i++) {
				if(currentface->GetEdgeRecordPtr(i)==currentedge) continue;
				if( (currentface->GetEdgeRecordPtr(i)->GetStartPoint()==node) 
					|| (currentface->GetEdgeRecordPtr(i)->GetEndPoint()==node)) 
					{nextedge = currentface->GetEdgeRecordPtr(i); break;}
			}

			if (nextedge == NULL) {
				printf("Warning: The model is wrong in topology!\n");
				return;
			}
			if(nextedge->GetAttribFlag(1)) num++;
			currentedge = nextedge;
		}while(currentedge!=startedge);

		for(Pos=node->GetFaceList().GetHeadPosition();Pos!=NULL;) {
			face=(QMeshFace*)(node->GetFaceList().GetNext(Pos));
			i = face->m_nIdentifiedPatchIndex;
			if (i==-1) {
				printf("Warning:The model is wrong in topology! num=%d edgeNum=%d  faceNum=%d  nodeIndex=%d\n",
					num,node->GetEdgeNumber(),node->GetFaceNumber(),node->GetIndexNo());

				GLKPOSITION PosFace;	QMeshFace *tempFace;
				for(PosFace = node->GetFaceList().GetHeadPosition(); PosFace!=NULL;) {
					tempFace = (QMeshFace*)(node->GetFaceList().GetNext(PosFace));
					edgeNum=tempFace->GetEdgeNum();
					printf("face %d: ",tempFace->GetIndexNo());
					for(j=0;j<edgeNum;j++) printf("%d ",tempFace->GetEdgeRecordPtr(j)->GetIndexNo());
					printf("\n");
				}
				tempFace = (QMeshFace*)(node->GetFaceList().GetTail());

//				node->SetAttribFlag(4,true);
			}
		}
	}
}

void LDNISolidContouring::_debugContouringCell(LDNISolid* solid, LDNISolidOctreeCell *cell, QMeshPatch *mesh)
{
	QMeshNode *nodeArray[4];	int i,j;
	QMeshNode *nodes[8];		double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3];
	short faceTable[][4]={ {0,4,6,2}, {1,3,7,5}, {0,1,5,4}, {2,6,7,3}, {0,2,3,1}, {4,5,7,6} };

	if (!(cell->IsLeaf())) {
		for(i=0;i<8;i++) _debugContouringCell(solid,cell->m_childOctreeNode[i],mesh);
		return;
	}
//	if ((cell->eX-cell->sX)>1) return;
//	if (_isEmptyOrSolidCell(cell)) return; 
//	if (!(cell->bDebugStrange)) return;
	
	solid->GetOrigin(origin);
	width=solid->GetGridWidth();
	xmin=origin[0]+width*(double)(cell->sX);
	xmax=origin[0]+width*(double)(cell->eX);
	ymin=origin[1]+width*(double)(cell->sY);
	ymax=origin[1]+width*(double)(cell->eY);
	zmin=origin[2]+width*(double)(cell->sZ);
	zmax=origin[2]+width*(double)(cell->eZ);

	if (cell->sX<136) return;
	if (cell->eX>144) return;
	if (cell->sY<240) return;
	if (cell->eY>248) return;
	if (cell->sZ<128) return;
	if (cell->eZ>136) return;


//	printf("%d %d %d %d %d %d \n",cell->sX,cell->sY,cell->sZ,cell->eX,cell->eY,cell->eZ);

	for(i=0;i<8;i++) {
		nodes[i]=new QMeshNode;
		mesh->GetNodeList().AddTail(nodes[i]);	nodes[i]->SetMeshPatchPtr(mesh);
		nodes[i]->SetIndexNo(mesh->GetNodeNumber());
		switch(i) {
		case 0:nodes[i]->SetCoord3D(xmin,ymin,zmin);break;
		case 1:nodes[i]->SetCoord3D(xmax,ymin,zmin);break;
		case 2:nodes[i]->SetCoord3D(xmin,ymax,zmin);break;
		case 3:nodes[i]->SetCoord3D(xmax,ymax,zmin);break;
		case 4:nodes[i]->SetCoord3D(xmin,ymin,zmax);break;
		case 5:nodes[i]->SetCoord3D(xmax,ymin,zmax);break;
		case 6:nodes[i]->SetCoord3D(xmin,ymax,zmax);break;
		case 7:nodes[i]->SetCoord3D(xmax,ymax,zmax);break;
		}
		if (!(cell->m_nodeInside[i])) nodes[i]->SetAttribFlag(7);
	}
/*	if (( (cell->vertexAtEdge[0] && cell->vertexAtEdge[0]->GetIndexNo()==10301)
		|| (cell->vertexAtEdge[0] && cell->vertexAtEdge[0]->GetIndexNo()==10301)
		|| (cell->vertexAtEdge[0] && cell->vertexAtEdge[0]->GetIndexNo()==10301)
		|| (cell->vertexAtEdge[0] && cell->vertexAtEdge[0]->GetIndexNo()==10301) )) */
	{
		for(i=0;i<8;i++) if (cell->m_nodeInside[i]) nodes[i]->SetAttribFlag(0);
	}
	for(i=0;i<6;i++) {
		for(j=0;j<4;j++) {nodeArray[j]=nodes[faceTable[i][j]];}
		_createMeshFaceByVertices(nodeArray,mesh);
		QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetTail());
		int eNum=face->GetEdgeNum();
		for(j=0;j<eNum;j++) face->GetEdgeRecordPtr(j)->SetAttribFlag(0,true);
		face->SetEdgeNum(0);
	}
}

void LDNISolidContouring::_contourCellArray(LDNISolid *solid, LDNISolidOctreeCell ****cellArray, 
											int cellNum, QMeshPatch *mesh)
{
	int i,j,k;

	for(i=0;i<cellNum;i++) {
		for(j=0;j<cellNum;j++) {
			for(k=0;k<cellNum;k++) {
				_contourCellProc(solid,cellArray[i][j][k],mesh);
				if (i<cellNum-1) _contourFaceProc(solid,cellArray[i][j][k],cellArray[i+1][j][k],0,mesh);
				if (j<cellNum-1) _contourFaceProc(solid,cellArray[i][j][k],cellArray[i][j+1][k],1,mesh);
				if (k<cellNum-1) _contourFaceProc(solid,cellArray[i][j][k],cellArray[i][j][k+1],2,mesh);

				if ((i<cellNum-1) && (j<cellNum-1))
					_contourEdgeProc(solid,cellArray[i][j][k],cellArray[i+1][j][k],
							cellArray[i+1][j+1][k],cellArray[i][j+1][k],2,
							cellArray[i][j][k]->m_nodeInside[7],cellArray[i][j][k]->m_nodeInside[3],mesh);
				if ((i<cellNum-1) && (k<cellNum-1))
					_contourEdgeProc(solid,cellArray[i+1][j][k],cellArray[i][j][k],
							cellArray[i][j][k+1],cellArray[i+1][j][k+1],1,
							cellArray[i][j][k]->m_nodeInside[5],cellArray[i][j][k]->m_nodeInside[7],mesh);
				if ((j<cellNum-1) && (k<cellNum-1))
					_contourEdgeProc(solid,cellArray[i][j][k],cellArray[i][j+1][k],
							cellArray[i][j+1][k+1],cellArray[i][j][k+1],0,
							cellArray[i][j][k]->m_nodeInside[6],cellArray[i][j][k]->m_nodeInside[7],mesh);
			}
		}
	}
}

bool LDNISolidContouring::_complexCellCheck_AmbiguousFaceOrCell(LDNISolidOctreeCell *cell)
{
	int i,nCase;	bool bInOrOut;
	short faceTable[][4]={ {0,4,6,2}, {1,3,7,5}, {0,1,5,4}, {2,6,7,3}, {0,2,3,1}, {4,5,7,6} };
	short cellDiagonalTable[][2]={ {0,7}, {2,5}, {1,6}, {3,4} };

	for(i=0;i<6;i++) {
		if ((cell->m_nodeInside[faceTable[i][0]]==cell->m_nodeInside[faceTable[i][2]])
			&& (cell->m_nodeInside[faceTable[i][1]]==cell->m_nodeInside[faceTable[i][3]])
			&& (cell->m_nodeInside[faceTable[i][0]]!=cell->m_nodeInside[faceTable[i][1]])) 
			return true;
	}
	for(nCase=0;nCase<4;nCase++) {
		if (cell->m_nodeInside[cellDiagonalTable[nCase][0]]
			!=cell->m_nodeInside[cellDiagonalTable[nCase][1]]) continue;
		bInOrOut=cell->m_nodeInside[cellDiagonalTable[nCase][0]];
		for(i=0;i<8;i++) {
			if (i==cellDiagonalTable[nCase][0]) continue;
			if (i==cellDiagonalTable[nCase][1]) continue;
			if (cell->m_nodeInside[i]==bInOrOut) break;
		}
		if (i==8) 
			return true;	// the ambiguous happens
	}

	return false;
}

void LDNISolidContouring::_cellRefinement(LDNISolid* solid, LDNISolidOctreeCell *cell, 
										  double geoCriterion, int level)
{
	GLKObList hermiteDataSet;	double pp[3];
	double gwidth=solid->GetGridWidth();

	if ((cell->sX>=(cell->eX-1)) || (cell->sY>=(cell->eY-1)) || (cell->sZ>=(cell->eZ-1)) 
		|| (level>_CCL_OCTREE_LEVEL_THRESHOLD) 
		|| (gwidth*(double)(cell->eX-cell->sX)<=geoCriterion)) {
		bool bAmbiguousTopology=false;
		bAmbiguousTopology=_complexCellCheck_AmbiguousFaceOrCell(cell);
		if (bAmbiguousTopology) {
			//if (bAmbiguousTopology) printf("The topology ambiguity is found!\n");
			_ambiguousCellConstruction(solid,cell,false);
		}
		else 
		{
			hermiteDataSet.RemoveAll();
			_searchHermiteDataSet(solid,cell,&hermiteDataSet);
			if (hermiteDataSet.IsEmpty()) return;
			pp[0]=cell->pnts[0][0];	pp[1]=cell->pnts[0][1];	pp[2]=cell->pnts[0][2];
			_compPositionByHermiteData(solid,&hermiteDataSet,pp);
			cell->pnts[0][0]=pp[0];	cell->pnts[0][1]=pp[1];	cell->pnts[0][2]=pp[2];
			_deleteHermiteDataSet(&hermiteDataSet);
		}
		return;
	}

	if (level>=2) 
		if (_isCellNeedRefine(solid, cell, geoCriterion)==false) return;

	//-----------------------------------------------------------------------------
	//	Need to refine the cell
	int i,j,k,iX[3],iY[3],iZ[3];	bool bPntIn[3][3][3];	double origin[3],width;
	solid->GetOrigin(origin);		width=solid->GetGridWidth();
	LDNISolidOctreeCell *child;
	iX[0]=cell->sX;	iX[2]=cell->eX;	iY[0]=cell->sY;	iY[2]=cell->eY;	iZ[0]=cell->sZ;	iZ[2]=cell->eZ;
	iX[1]=(iX[0]+iX[2])/2;			iY[1]=(iY[0]+iY[2])/2;			iZ[1]=(iZ[0]+iZ[2])/2;
	bPntIn[0][0][0]=cell->m_nodeInside[0];	bPntIn[2][0][0]=cell->m_nodeInside[1];
	bPntIn[0][2][0]=cell->m_nodeInside[2];	bPntIn[2][2][0]=cell->m_nodeInside[3];
	bPntIn[0][0][2]=cell->m_nodeInside[4];	bPntIn[2][0][2]=cell->m_nodeInside[5];
	bPntIn[0][2][2]=cell->m_nodeInside[6];	bPntIn[2][2][2]=cell->m_nodeInside[7];
	for(k=0;k<3;k++) {
		for(j=0;j<3;j++) {
			for(i=0;i<3;i++) {
				if (!(i==1 || j==1 || k==1)) continue;
				bPntIn[i][j][k]=solid->DetectNodeInOrOut(iX[i],iY[j],iZ[k]);
			}
		}
	}
	//-----------------------------------------------------------------------------
	for(i=0;i<8;i++) {cell->m_childOctreeNode[i]=new LDNISolidOctreeCell;}
	for(k=0;k<2;k++) {
		for(j=0;j<2;j++) {
			for(i=0;i<2;i++) {
				child=cell->m_childOctreeNode[i+j*2+k*4];
				child->sX=iX[i];	child->sY=iY[j];	child->sZ=iZ[k];
				child->eX=iX[i+1];	child->eY=iY[j+1];	child->eZ=iZ[k+1];

				child->pnts[0][0]=origin[0]+width*0.5*(double)(iX[i]+iX[i+1]);
				child->pnts[0][1]=origin[1]+width*0.5*(double)(iY[j]+iY[j+1]);
				child->pnts[0][2]=origin[2]+width*0.5*(double)(iZ[k]+iZ[k+1]);

				child->m_nodeInside[0]=bPntIn[i][j][k];
				child->m_nodeInside[1]=bPntIn[i+1][j][k];
				child->m_nodeInside[2]=bPntIn[i][j+1][k];
				child->m_nodeInside[3]=bPntIn[i+1][j+1][k];
				child->m_nodeInside[4]=bPntIn[i][j][k+1];
				child->m_nodeInside[5]=bPntIn[i+1][j][k+1];
				child->m_nodeInside[6]=bPntIn[i][j+1][k+1];
				child->m_nodeInside[7]=bPntIn[i+1][j+1][k+1];
			}
		}
	}

	if (level==0) return;	// for building the task list of cell-refinement

	for(i=0;i<8;i++) _cellRefinement(solid,cell->m_childOctreeNode[i],geoCriterion,level+1);
}

bool LDNISolidContouring::_isCellNeedRefine(LDNISolid *solid, LDNISolidOctreeCell *cell, double geoCriterion)
{
	double pp[3];
	GLKObList hermiteDataSet;

	/////////////////////////////////////////////////////////////////////////////////
	//	Step 1: check whether it is a complex cell
	//-------------------------------------------------------------------------------
	//	Check 1 (complex cell) - for the invalid empty or solid cell
	if (_isEmptyOrSolidCell(cell)) {
		if (_complexCellCheck_InvalidEmptyOrSolidCell(solid,cell)) 
			return true;
		else
			return false;
	}
	//-------------------------------------------------------------------------------
	//	Check 2 & 3 (complex cell) - for the ambiguous face and the ambiguous volume
	if (_complexCellCheck_AmbiguousFaceOrCell(cell)) return true;
	//-------------------------------------------------------------------------------
	//	Check 4 (complex cell) - for the multiple intersection on edges
	//		(note that the hermite data collection is also collected in this step)
	//
	if (_complexCellCheck_MultipleEdgeIntersections(solid,cell)) return true;

	/////////////////////////////////////////////////////////////////////////////////
	//	Step 2: compute the position of the vertex in this cell and evaluate the error
	_searchHermiteDataSet(solid,cell,&hermiteDataSet);
	pp[0]=cell->pnts[0][0];	pp[1]=cell->pnts[0][1];	pp[2]=cell->pnts[0][2];
	if (!(hermiteDataSet.IsEmpty())) {
		_compPositionByHermiteData(solid,&hermiteDataSet,pp);
		cell->pnts[0][0]=pp[0];	cell->pnts[0][1]=pp[1];	cell->pnts[0][2]=pp[2];
		//-----------------------------------------------------------------------------------
		//	the following statements are to check the shape compatibility
		GLKPOSITION Pos;
		for(Pos=hermiteDataSet.GetHeadPosition();Pos!=NULL;) {
			LDNIHermiteData *data=(LDNIHermiteData *)(hermiteDataSet.GetNext(Pos));
			double dd=(pp[0]-data->pos[0])*(data->normal[0])
				+(pp[1]-data->pos[1])*(data->normal[1])
				+(pp[2]-data->pos[2])*(data->normal[2]);
			if (fabs(dd)>geoCriterion) {_deleteHermiteDataSet(&hermiteDataSet);	return true;}
		}
	}
	else {
//		printf("Empty cell is found!\n");
		_deleteHermiteDataSet(&hermiteDataSet);	return false;
	}

	//-------------------------------------------------------------------------------
	//	Check 6 (complex cell) - for the invalid empty or solid face
	//if (_complexCellCheck_InvalidEmptyOrSolidFace(solid,cell)) 
	//	{_deleteHermiteDataSet(&hermiteDataSet); return true;}

	/////////////////////////////////////////////////////////////////////////////////
	//	Step 3: free the memeory
	_deleteHermiteDataSet(&hermiteDataSet);
	return false;
}

bool LDNISolidContouring::_complexCellCheck_InvalidEmptyOrSolidFace(LDNISolid *solid,
																	LDNISolidOctreeCell *cell)
{
	int nFace,nAxis,i,j,iUpper,iLower,jUpper,jLower,res;
	bool bSolid,bConsistent;
	double faceDepth,width,depth1,depth2,maxDepth;
	LDNISolidNode *currentNode;
	short faceTable[][4]={ {0,4,6,2}, {1,3,7,5}, {0,1,5,4}, {2,6,7,3}, {0,2,3,1}, {4,5,7,6} };
	double eps=1.0e-5;

	res=solid->GetResolution(); width=solid->GetGridWidth(); maxDepth=width*(double)res;

	for(nFace=0;nFace<6;nFace++) {
		bSolid=cell->m_nodeInside[faceTable[nFace][0]];
		bConsistent=true;
		for(i=1;i<4;i++) {
			if (bSolid!=cell->m_nodeInside[faceTable[nFace][i]]) {bConsistent=false; break;}
		}
		if (!bConsistent) continue;

		switch(nFace) {
		case 0:{faceDepth=width*(double)(cell->sX);
				iLower=cell->sY;	iUpper=cell->eY;	jLower=cell->sZ;	jUpper=cell->eZ;
				nAxis=0;
			   }break;
		case 1:{faceDepth=width*(double)(cell->eX);
				iLower=cell->sY;	iUpper=cell->eY;	jLower=cell->sZ;	jUpper=cell->eZ;
				nAxis=0;
			   }break;
		case 2:{faceDepth=width*(double)(cell->sY);
				iLower=cell->sZ;	iUpper=cell->eZ;	jLower=cell->sX;	jUpper=cell->eX;
				nAxis=1;
			   }break;
		case 3:{faceDepth=width*(double)(cell->eY);
				iLower=cell->sZ;	iUpper=cell->eZ;	jLower=cell->sX;	jUpper=cell->eX;
				nAxis=1;
			   }break;
		case 4:{faceDepth=width*(double)(cell->sZ);
				iLower=cell->sX;	iUpper=cell->eX;	jLower=cell->sY;	jUpper=cell->eY;
				nAxis=2;
			   }break;
		case 5:{faceDepth=width*(double)(cell->eZ);
				iLower=cell->sX;	iUpper=cell->eX;	jLower=cell->sY;	jUpper=cell->eY;
				nAxis=2;
			   }break;
		}

		if (bSolid) {
			for(i=iLower;i<=iUpper;i++) {
				if ((i>=res) || (i<0)) return false;
				for(j=jLower;j<=jUpper;j++) {
					if ((j>=res) || (j<0)) return false;
					currentNode=solid->GetLDNISolidNode(nAxis,i,j);
					if (currentNode==NULL) return false;

					short k,nNum;
					k=0;	nNum=currentNode->GetSampleNum();	depth1=0.0;
					for(;;k++) {
						if (k<nNum) depth2=currentNode->GetDepth(k); else depth2=maxDepth;
						if ((depth1<faceDepth) && (depth2>faceDepth)) return true;
						if (k>=nNum) break;
						k++; depth1=currentNode->GetDepth(k);
						if (depth1>faceDepth+eps) break;
					}
				}
			}
		}
		else {
			for(i=iLower;i<=iUpper;i++) {
				if ((i>=res) || (i<0)) continue;
				for(j=jLower;j<=jUpper;j++) {
					if ((j>=res) || (j<0)) continue;
					currentNode=solid->GetLDNISolidNode(nAxis,i,j);
					if (currentNode==NULL) continue;

					short k,nNum;
					nNum=currentNode->GetSampleNum();
					for(k=0;k<nNum;k+=2) {
						depth1=currentNode->GetDepth(k); depth2=currentNode->GetDepth(k+1);
						if (depth1>=faceDepth+eps) break;
						if (depth2<faceDepth-eps) continue;
						if ((depth1<=faceDepth) && (depth2>=faceDepth)) return true;
					}
				}
			}
		}
	}

	return false;
}

bool LDNISolidContouring::_isEmptyOrSolidCell(LDNISolidOctreeCell *cell)
{
	int i;	bool bInOrOut,bSame;

	bInOrOut=cell->m_nodeInside[0];		bSame=true;
	for(i=1;i<8;i++) {if (cell->m_nodeInside[i]!=bInOrOut) {bSame=false;break;} }

	return bSame;
}

bool LDNISolidContouring::_complexCellCheck_MultipleEdgeIntersections(LDNISolid *solid,
																	  LDNISolidOctreeCell *cell)
{
	LDNISolidNode *currentNode;
	int sX,sY,sZ,eX,eY,eZ,nCase;
	double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3],upper,lower;

	solid->GetOrigin(origin);		width=solid->GetGridWidth();
	sX=cell->sX;	sY=cell->sY;	sZ=cell->sZ;	eX=cell->eX;	eY=cell->eY;	eZ=cell->eZ;
	xmin=width*(double)sX;	ymin=width*(double)sY;	zmin=width*(double)sZ;
	xmax=width*(double)eX;	ymax=width*(double)eY;	zmax=width*(double)eZ;

	for(nCase=0;nCase<12;nCase++) {
		switch(nCase) {
		case 0:{currentNode=solid->GetLDNISolidNode(0,sY,sZ);	lower=xmin;	upper=xmax;}break;
		case 1:{currentNode=solid->GetLDNISolidNode(0,eY,sZ);	lower=xmin;	upper=xmax;}break;
		case 2:{currentNode=solid->GetLDNISolidNode(0,sY,eZ);	lower=xmin;	upper=xmax;}break;
		case 3:{currentNode=solid->GetLDNISolidNode(0,eY,eZ);	lower=xmin;	upper=xmax;}break;

		case 4:{currentNode=solid->GetLDNISolidNode(1,sZ,sX);	lower=ymin;	upper=ymax;}break;
		case 5:{currentNode=solid->GetLDNISolidNode(1,eZ,sX);	lower=ymin;	upper=ymax;}break;
		case 6:{currentNode=solid->GetLDNISolidNode(1,sZ,eX);	lower=ymin;	upper=ymax;}break;
		case 7:{currentNode=solid->GetLDNISolidNode(1,eZ,eX);	lower=ymin;	upper=ymax;}break;

		case 8:{currentNode=solid->GetLDNISolidNode(2,sX,sY);	lower=zmin;	upper=zmax;}break;
		case 9:{currentNode=solid->GetLDNISolidNode(2,eX,sY);	lower=zmin;	upper=zmax;}break;
		case 10:{currentNode=solid->GetLDNISolidNode(2,sX,eY);	lower=zmin;	upper=zmax;}break;
		case 11:{currentNode=solid->GetLDNISolidNode(2,eX,eY);	lower=zmin;	upper=zmax;}break;
		}
		if (currentNode==NULL) continue;

		int intersectionPntNum=0;
		short k,nNum;
		nNum=currentNode->GetSampleNum();
		for(k=0;k<nNum;k++) {
			double depth=currentNode->GetDepth(k);
			if (depth>=upper) break;
			if (depth<lower) continue;
			intersectionPntNum++;
		}
		if (intersectionPntNum>1) return true;
	}

	return false;

}

bool LDNISolidContouring::_complexCellCheck_InvalidEmptyOrSolidCell(LDNISolid *solid,
																	LDNISolidOctreeCell *cell)
{
	int i,j,iLower,iUpper,jLower,jUpper,nAxis,res;
	LDNISolidNode *currentNode;					double upper,lower,width;
	double eps=1.0e-5;

	width=solid->GetGridWidth();	res=solid->GetResolution();
	for(nAxis=0;nAxis<3;nAxis++) {
		switch(nAxis) {
		case 0:{lower=width*(double)(cell->sX)-eps;	upper=width*(double)(cell->eX)+eps;
				iLower=cell->sY;	iUpper=cell->eY;
				jLower=cell->sZ;	jUpper=cell->eZ;
			   }break;
		case 1:{lower=width*(double)(cell->sY)-eps;	upper=width*(double)(cell->eY)+eps;
				iLower=cell->sZ;	iUpper=cell->eZ;
				jLower=cell->sX;	jUpper=cell->eX;
			   }break;
		case 2:{lower=width*(double)(cell->sZ)-eps;	upper=width*(double)(cell->eZ)+eps;
				iLower=cell->sX;	iUpper=cell->eX;
				jLower=cell->sY;	jUpper=cell->eY;
			   }break;
		}
		upper+=eps;	lower-=eps;
		for(i=iLower;i<=iUpper;i++) {
			if ((i>=res) || (i<0)) continue;
			for(j=jLower;j<=jUpper;j++) {
				if ((j>=res) || (j<0)) continue;
				currentNode=solid->GetLDNISolidNode(nAxis,i,j);
				if (currentNode==NULL) continue;

				short nNum=currentNode->GetSampleNum();
				for(short k=0;k<nNum;k++) {
					double depth=currentNode->GetDepth(k);
					if (depth>upper) break;
					if (depth<lower) continue;
					return true;
				}
			}
		}
	}

	return false;
}

void LDNISolidContouring::_searchHermiteDataSet(LDNISolid *solid, LDNISolidOctreeCell *cell, 
												GLKObList *hermiteDataSet)
{
	LDNISolidNode *currentNode;
	int sX,sY,sZ,eX,eY,eZ,ii,jj,is,ie,js,je,res;	short nAxis;
	double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3],upper,lower;
	double eps=1.0e-5;

	solid->GetOrigin(origin);		width=solid->GetGridWidth();	res=solid->GetResolution();
	sX=cell->sX;	sY=cell->sY;	sZ=cell->sZ;	eX=cell->eX;	eY=cell->eY;	eZ=cell->eZ;
	xmin=width*(double)sX;	ymin=width*(double)sY;	zmin=width*(double)sZ;
	xmax=width*(double)eX;	ymax=width*(double)eY;	zmax=width*(double)eZ;
	hermiteDataSet->RemoveAll();

	for(nAxis=0;nAxis<3;nAxis++) {
		switch(nAxis) {
		case 0:{lower=xmin-eps;	upper=xmax+eps;	is=sY; ie=eY; js=sZ; je=eZ;}break;
		case 1:{lower=ymin-eps;	upper=ymax+eps;	is=sZ; ie=eZ; js=sX; je=eX;}break;
		case 2:{lower=zmin-eps;	upper=zmax+eps;	is=sX; ie=eX; js=sY; je=eY;}break;
		}
		for(ii=is;ii<=ie;ii++) {
			if ((ii>=res) || (ii<0)) continue;
			for(jj=js;jj<=je;jj++) {
				if ((jj>=res) || (jj<0)) continue;
				currentNode=solid->GetLDNISolidNode(nAxis,ii,jj);
				if (currentNode==NULL) continue;

				short i,nNum=currentNode->GetSampleNum();
				for(i=0;i<nNum;i++) {
					double depth=currentNode->GetDepth(i);
					if (depth>upper) break;
					if (depth<lower) continue;

					LDNIHermiteData *data=new LDNIHermiteData;	hermiteDataSet->AddTail(data);
					currentNode->GetNormal(i,data->normal[0],data->normal[1],data->normal[2]);

					switch(nAxis) {
					case 0:{data->pos[0]=depth;	data->pos[1]=width*(double)ii; data->pos[2]=width*(double)jj;}break;
					case 1:{data->pos[0]=width*(double)jj; data->pos[1]=depth; data->pos[2]=width*(double)ii;}break;
					case 2:{data->pos[0]=width*(double)ii; data->pos[1]=width*(double)jj; data->pos[2]=depth;}break;
					}
					data->pos[0]=data->pos[0]+origin[0];
					data->pos[1]=data->pos[1]+origin[1];
					data->pos[2]=data->pos[2]+origin[2];
				}
			}
		}
	}
}

void LDNISolidContouring::_deleteHermiteDataSet(GLKObList *dataSet)
{
	GLKPOSITION Pos;

	for(Pos=dataSet->GetHeadPosition();Pos!=NULL;) {
		LDNIHermiteData *data=(LDNIHermiteData *)(dataSet->GetNext(Pos));
		delete data;
	}
	dataSet->RemoveAll();
}

void LDNISolidContouring::_compPositionByHermiteData(LDNISolid *solid, GLKObList *hermiteDataSet, double pp[], 
													 bool bUsingMassPoint, bool bTruncate)
{
	GLKPOSITION Pos;						double normal[3],pos[3],proj,scale;
	double criterion=0.01;					int i,j;
	double **A,**UU,**VV,**UUT,**VVT;		double *B,*X;

	if (hermiteDataSet->IsEmpty()) return;

	if (bTruncate) scale=solid->GetGridWidth()*2.0;

	//---------------------------------------------------------------------------
	//	Preparation
	GLKMatrixLib::CreateMatrix(A,3,3);		B=new double[3];	X=new double[3];
	GLKMatrixLib::CreateMatrix(UU,3,3);		GLKMatrixLib::CreateMatrix(VV,3,3);
	GLKMatrixLib::CreateMatrix(UUT,3,3);	GLKMatrixLib::CreateMatrix(VVT,3,3);
	//---------------------------------------------------------------------------
	if (bUsingMassPoint) {
		pp[0]=0.0;	pp[1]=0.0;	pp[2]=0.0;
		for(Pos=hermiteDataSet->GetHeadPosition();Pos!=NULL;) {
			LDNIHermiteData *data=(LDNIHermiteData *)(hermiteDataSet->GetNext(Pos));
			pp[0]+=data->pos[0];	pp[1]+=data->pos[1];	pp[2]+=data->pos[2];
		}
		pp[0]=pp[0]/(double)(hermiteDataSet->GetCount());
		pp[1]=pp[1]/(double)(hermiteDataSet->GetCount());
		pp[2]=pp[2]/(double)(hermiteDataSet->GetCount());
	}
	//---------------------------------------------------------------------------
	B[0]=B[1]=B[2]=X[0]=X[1]=X[2]=0.0;
	for(Pos=hermiteDataSet->GetHeadPosition();Pos!=NULL;) {
		LDNIHermiteData *data=(LDNIHermiteData *)(hermiteDataSet->GetNext(Pos));
		normal[0]=data->normal[0];	normal[1]=data->normal[1];	normal[2]=data->normal[2];
		pos[0]=data->pos[0];	pos[1]=data->pos[1];	pos[2]=data->pos[2];

		proj=(pos[0]-pp[0])*normal[0]+(pos[1]-pp[1])*normal[1]+(pos[2]-pp[2])*normal[2];
		B[0]+=proj*normal[0];	B[1]+=proj*normal[1];	B[2]+=proj*normal[2];	

		A[0][0]+=normal[0]*normal[0]; A[0][1]+=normal[0]*normal[1]; A[0][2]+=normal[0]*normal[2];
		A[1][0]+=normal[1]*normal[0]; A[1][1]+=normal[1]*normal[1]; A[1][2]+=normal[1]*normal[2];
		A[2][0]+=normal[2]*normal[0]; A[2][1]+=normal[2]*normal[1]; A[2][2]+=normal[2]*normal[2];
	}

	//---------------------------------------------------------------------------
	//	Singular Value Decomposition
	GLKMatrixLib::SingularValueDecomposition(A,3,3,UU,VVT);
	GLKMatrixLib::Transpose(UU,3,3,UUT);
	GLKMatrixLib::Transpose(VVT,3,3,VV);
	double maxFactor=(fabs(A[0][0])>fabs(A[1][1]))?(A[0][0]):(A[1][1]);
	maxFactor=(fabs(maxFactor)>fabs(A[2][2]))?(maxFactor):(A[2][2]);
	if (fabs(maxFactor)<1.0e-6) {
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				A[i][j]=0.0;
			}
		}
	}
	else {
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				if (i!=j) {
					A[i][j]=0.0;
				}
				else {
					if (fabs(A[i][j]/maxFactor)<criterion) 
//					if (fabs(A[i][j])<criterion) 
						A[i][j]=0.0; 
					else 
						A[i][j]=1.0/A[i][j];
				}
			}
		}
	}
	GLKMatrixLib::Mul(UUT,B,3,3,X);
	GLKMatrixLib::Mul(A,X,3,3,B);
	GLKMatrixLib::Mul(VV,B,3,3,X);
	//-----------------------------------------------------------------
	//	update node position
	if (bTruncate) {
		double dd=(X[0]*X[0]+X[1]*X[1]+X[2]*X[2]);
		if ((dd>scale) && (dd>1.0e-5)) {
			dd=sqrt(dd);	
			X[0]=X[0]/dd*scale;	X[1]=X[1]/dd*scale;	X[2]=X[2]/dd*scale;
		}
	}
	pp[0]=pp[0]+X[0];	pp[1]=pp[1]+X[1];	pp[2]=pp[2]+X[2];

	//---------------------------------------------------------------------------
	//	Free the memory
	GLKMatrixLib::DeleteMatrix(A,3,3);		delete []B;	delete []X;
	GLKMatrixLib::DeleteMatrix(UU,3,3);		GLKMatrixLib::DeleteMatrix(VV,3,3);
	GLKMatrixLib::DeleteMatrix(UUT,3,3);	GLKMatrixLib::DeleteMatrix(VVT,3,3);
}

void LDNISolidContouring::_ambiguousCellConstruction(LDNISolid *solid, LDNISolidOctreeCell *cell, bool bGapPreferred)
{
	GLKObList **hermiteDataEdges;
	const short edgeTable[][2]={
		{0,1},	{2,3},	{4,5},	{6,7},	
		{0,2},	{1,3},	{4,6},	{5,7},
		{0,4},	{1,5},	{2,6},	{3,7}
	};
	const short nodeTable[][3]={
		{0,0,0},	{1,0,0},	{0,1,0},	{1,1,0},
		{0,0,1},	{1,0,1},	{0,1,1},	{1,1,1}
	};
	const short nodeLinkTable[][3]={
		{1,2,4},	{0,3,5},	{0,3,6},	{1,2,7},
		{0,5,6},	{1,4,7},	{2,4,7},	{3,5,6}
	};
	const short nodeEdgeTable[][3][2]={
		{{0,0},{4,0},{8,0}},	{{0,1},{5,0},{9,0}},	{{4,1},{1,0},{10,0}},	{{5,1},{1,1},{11,0}},
		{{8,1},{2,0},{6,0}},	{{9,1},{2,1},{7,0}},	{{10,1},{6,1},{3,0}},	{{11,1},{7,1},{3,1}}
	};
	short nodesColor[8];	//	0 - not filled
							//	1 - with red
							//	2 - with green
							//	3 - with blue
	bool nodesFlags[8];
	short nColor,i,j,inClusterNum,outClusterNum,nLinkedIndex,distOut,distIn,nPntIndex;
	short sIndex,eIndex,dist;
	GLKObList hermiteDataSet;
	double pp[3],cp[3];

	//////////////////////////////////////////////////////////////////////////////////////
	//	Step 1: start the search of intersections on the edges of the cells
	hermiteDataEdges=(GLKObList**)new long[12];
	for(i=0;i<12;i++) hermiteDataEdges[i]=new GLKObList;
	_searchEdgeIntersections(solid, cell, hermiteDataEdges);

	//////////////////////////////////////////////////////////////////////////////////////
	//	Step 2: find out the configuration by the color flooding algorithm
	for(j=0;j<8;j++) {nodesColor[j]=0; nodesFlags[j]=cell->m_nodeInside[j];}
	//---------------------------------------------------------------------
	//	clustering of inside nodes
	for(nColor=1;nColor<=4;nColor++) {
		bool bFilled=false;
		for(j=0;j<8;j++) {	// fill in seed color
			if ((nodesColor[j]==0) && (nodesFlags[j])) {
				nodesColor[j]=nColor; bFilled=true;	break;
			}
		}
		while(bFilled){		// flooding the color
			bFilled=false;
			for(j=0;j<8;j++) {
				if (!(nodesFlags[j])) continue;
				if (nodesColor[j]!=nColor) continue;
				for(short i=0;i<3;i++) {
					nLinkedIndex=nodeLinkTable[j][i];
					if ((nodesColor[nLinkedIndex]==0) && (nodesFlags[nLinkedIndex])) {
						nodesColor[nLinkedIndex]=nColor; bFilled=true;
					}
				}
			}
		}
	}
	//---------------------------------------------------------------------
	//	clustering of outside nodes
	for(nColor=1;nColor<=4;nColor++) {
		bool bFilled=false;
		for(j=0;j<8;j++) // fill in seed color
			if ((nodesColor[j]==0) && (!(nodesFlags[j]))) {
				nodesColor[j]=nColor; bFilled=true;	break;
			}
		while(bFilled){	// flooding the color
			bFilled=false;
			for(j=0;j<8;j++) {
				if (nodesFlags[j]) continue;
				if (nodesColor[j]!=nColor) continue;
				for(short i=0;i<3;i++) {
					nLinkedIndex=nodeLinkTable[j][i];
					if ((nodesColor[nLinkedIndex]==0) && (!(nodesFlags[nLinkedIndex]))) {
						nodesColor[nLinkedIndex]=nColor; bFilled=true;
					}
				}
			}
		}
	}
	//---------------------------------------------------------------------
	//	compute the number of cluster
	inClusterNum=outClusterNum=0;
	for(j=0;j<8;j++) {
		if ((nodesFlags[j]) && (nodesColor[j]>inClusterNum)) inClusterNum=nodesColor[j];
		if ((!(nodesFlags[j])) && (nodesColor[j]>outClusterNum)) outClusterNum=nodesColor[j];
	}
	if (bGapPreferred) {
		//---------------------------------------------------------------------
		//	compute the directed distance between two outside clusters
		distOut=10;
		if (outClusterNum==2) {
			for(j=0;j<8;j++) {
				if (nodesFlags[j]) continue;
				if (nodesColor[j]!=1) continue;
				for(i=0;i<8;i++) {
					if (nodesFlags[i]) continue;
					if (nodesColor[i]!=2) continue;
					dist=(short)(fabs((double)(nodeTable[j][0]-nodeTable[i][0]))
						+fabs((double)(nodeTable[j][1]-nodeTable[i][1]))
						+fabs((double)(nodeTable[j][2]-nodeTable[i][2])));
					if (dist<distOut) distOut=dist;
				}
			}
		}
	}
	else {
		//---------------------------------------------------------------------
		//	compute the directed distance between two inside clusters
		distIn=10;
		if (inClusterNum==2) {
			for(j=0;j<8;j++) {
				if (!(nodesFlags[j])) continue;
				if (nodesColor[j]!=1) continue;
				for(i=0;i<8;i++) {
					if (!(nodesFlags[i])) continue;
					if (nodesColor[i]!=2) continue;
					dist=(short)(fabs((double)(nodeTable[j][0]-nodeTable[i][0]))
						+fabs((double)(nodeTable[j][1]-nodeTable[i][1]))
						+fabs((double)(nodeTable[j][2]-nodeTable[i][2])));
					if (dist<distIn) distIn=dist;
				}
			}
		}
	}

	/////////////////////////////////////////////////////////////////////////////
	//	Step 3: create cell-vertices and associate them onto the edges
	for(j=0;j<12;j++) cell->edgePntIndex[j]=-1;
	if (bGapPreferred) {
		if ((distOut==3) && (outClusterNum==2)) {
			for(j=0;j<12;j++) {
				sIndex=edgeTable[j][0];		eIndex=edgeTable[j][1];
				if (nodesFlags[sIndex]==nodesFlags[eIndex]) continue;
				if (nodesFlags[eIndex])
					cell->edgePntIndex[j]=nodesColor[sIndex]-1;
				else
					cell->edgePntIndex[j]=nodesColor[eIndex]-1;
			}
			cell->edgePntNum=(char)outClusterNum;
		}
		else {
			for(j=0;j<12;j++) {
				sIndex=edgeTable[j][0];		eIndex=edgeTable[j][1];
				if (nodesFlags[sIndex]==nodesFlags[eIndex]) continue;
				if (nodesFlags[sIndex])
					cell->edgePntIndex[j]=nodesColor[sIndex]-1;
				else
					cell->edgePntIndex[j]=nodesColor[eIndex]-1;
			}
			cell->edgePntNum=(char)inClusterNum;
		}
	}
	else {
		if ((distIn==3) && (inClusterNum==2)) {
			for(j=0;j<12;j++) {
				sIndex=edgeTable[j][0];		eIndex=edgeTable[j][1];
				if (nodesFlags[sIndex]==nodesFlags[eIndex]) continue;
				if (nodesFlags[sIndex])
					cell->edgePntIndex[j]=nodesColor[sIndex]-1;
				else
					cell->edgePntIndex[j]=nodesColor[eIndex]-1;
			}
			cell->edgePntNum=(char)inClusterNum;
		}
		else {
			for(j=0;j<12;j++) {
				sIndex=edgeTable[j][0];		eIndex=edgeTable[j][1];
				if (nodesFlags[sIndex]==nodesFlags[eIndex]) continue;
				if (nodesFlags[sIndex])
					cell->edgePntIndex[j]=nodesColor[eIndex]-1;
				else
					cell->edgePntIndex[j]=nodesColor[sIndex]-1;
			}
			cell->edgePntNum=(char)outClusterNum;
		}
	}

	/////////////////////////////////////////////////////////////////////////////
	//	Step 4: relocating the cell vertices by minimizing QEF
	cp[0]=cell->pnts[0][0];	cp[1]=cell->pnts[0][1];	cp[2]=cell->pnts[0][2];
	for(nPntIndex=0;nPntIndex<cell->edgePntNum;nPntIndex++) {
		hermiteDataSet.RemoveAll();
		pp[0]=cp[0];	pp[1]=cp[1];	pp[2]=cp[2];
		for(j=0;j<12;j++) {
			if (cell->edgePntIndex[j]!=nPntIndex) continue;
			hermiteDataSet.AddTail(hermiteDataEdges[j]);
		}
		_compPositionByHermiteData(solid,&hermiteDataSet,pp);
		cell->pnts[nPntIndex][0]=pp[0];
		cell->pnts[nPntIndex][1]=pp[1];
		cell->pnts[nPntIndex][2]=pp[2];
	}

	//////////////////////////////////////////////////////////////////////////////////////
	//	Step 5: free the memory
	for(i=0;i<12;i++) {
		_deleteHermiteDataSet(hermiteDataEdges[i]);	
		delete (GLKObList *)(hermiteDataEdges[i]);
	}
	delete [](GLKObList**)hermiteDataEdges;
}

void LDNISolidContouring::_searchEdgeIntersections(LDNISolid *solid, LDNISolidOctreeCell *cell,
												   GLKObList **hermiteDataEdges)
{
	LDNISolidNode *currentNode;
	int sX,sY,sZ,eX,eY,eZ,nCase;
	double xmin,ymin,zmin,xmax,ymax,zmax,width,origin[3],upper,lower;

	solid->GetOrigin(origin);		width=solid->GetGridWidth();
	sX=cell->sX;	sY=cell->sY;	sZ=cell->sZ;	eX=cell->eX;	eY=cell->eY;	eZ=cell->eZ;
	xmin=width*(double)sX;	ymin=width*(double)sY;	zmin=width*(double)sZ;
	xmax=width*(double)eX;	ymax=width*(double)eY;	zmax=width*(double)eZ;

	for(nCase=0;nCase<12;nCase++) {
		hermiteDataEdges[nCase]->RemoveAll();
		switch(nCase) {
		case 0:{currentNode=solid->GetLDNISolidNode(0,sY,sZ);	lower=xmin;	upper=xmax;}break;
		case 1:{currentNode=solid->GetLDNISolidNode(0,eY,sZ);	lower=xmin;	upper=xmax;}break;
		case 2:{currentNode=solid->GetLDNISolidNode(0,sY,eZ);	lower=xmin;	upper=xmax;}break;
		case 3:{currentNode=solid->GetLDNISolidNode(0,eY,eZ);	lower=xmin;	upper=xmax;}break;

		case 4:{currentNode=solid->GetLDNISolidNode(1,sZ,sX);	lower=ymin;	upper=ymax;}break;
		case 5:{currentNode=solid->GetLDNISolidNode(1,sZ,eX);	lower=ymin;	upper=ymax;}break;
		case 6:{currentNode=solid->GetLDNISolidNode(1,eZ,sX);	lower=ymin;	upper=ymax;}break;
		case 7:{currentNode=solid->GetLDNISolidNode(1,eZ,eX);	lower=ymin;	upper=ymax;}break;

		case 8:{currentNode=solid->GetLDNISolidNode(2,sX,sY);	lower=zmin;	upper=zmax;}break;
		case 9:{currentNode=solid->GetLDNISolidNode(2,eX,sY);	lower=zmin;	upper=zmax;}break;
		case 10:{currentNode=solid->GetLDNISolidNode(2,sX,eY);	lower=zmin;	upper=zmax;}break;
		case 11:{currentNode=solid->GetLDNISolidNode(2,eX,eY);	lower=zmin;	upper=zmax;}break;
		}
		if (currentNode==NULL) continue;

		short nNum=currentNode->GetSampleNum();
		for(short k=0;k<nNum;k++) {
			double depth=currentNode->GetDepth(k);
			if (depth>=upper) break;
			if (depth<lower) continue;
			LDNIHermiteData *data=new LDNIHermiteData;	
			hermiteDataEdges[nCase]->AddTail(data);
			currentNode->GetNormal(k,data->normal[0],data->normal[1],data->normal[2]);

			switch(nCase) {
			case 0:{data->pos[0]=depth;	data->pos[1]=width*(double)sY; data->pos[2]=width*(double)sZ;}break;
			case 1:{data->pos[0]=depth;	data->pos[1]=width*(double)eY; data->pos[2]=width*(double)sZ;}break;
			case 2:{data->pos[0]=depth;	data->pos[1]=width*(double)sY; data->pos[2]=width*(double)eZ;}break;
			case 3:{data->pos[0]=depth;	data->pos[1]=width*(double)eY; data->pos[2]=width*(double)eZ;}break;
			case 4:{data->pos[0]=width*(double)sX; data->pos[1]=depth; data->pos[2]=width*(double)sZ;}break;
			case 5:{data->pos[0]=width*(double)eX; data->pos[1]=depth; data->pos[2]=width*(double)sZ;}break;
			case 6:{data->pos[0]=width*(double)sX; data->pos[1]=depth; data->pos[2]=width*(double)eZ;}break;
			case 7:{data->pos[0]=width*(double)eX; data->pos[1]=depth; data->pos[2]=width*(double)eZ;}break;
			case 8:{data->pos[0]=width*(double)sX; data->pos[1]=width*(double)sY; data->pos[2]=depth;}break;
			case 9:{data->pos[0]=width*(double)eX; data->pos[1]=width*(double)sY; data->pos[2]=depth;}break;
			case 10:{data->pos[0]=width*(double)sX; data->pos[1]=width*(double)eY; data->pos[2]=depth;}break;
			case 11:{data->pos[0]=width*(double)eX; data->pos[1]=width*(double)eY; data->pos[2]=depth;}break;
			}
			data->pos[0]=data->pos[0]+origin[0];
			data->pos[1]=data->pos[1]+origin[1];
			data->pos[2]=data->pos[2]+origin[2];
		}
	}
}

void LDNISolidContouring::_createMeshFaceByVertices(QMeshNode *nodeArray[], QMeshPatch *mesh)
{
	QMeshNode *nodes[4];		int i,eNum;
	QMeshFace *newFace; 
	QMeshEdge *newEdge,*edge;	bool bDir;
	QMeshNode *sNode,*eNode;	GLKPOSITION Pos;

	//---------------------------------------------------------------------------------------
	//	There may have duplicated QMeshNode in the nodeArray, need to remove them!!!
	//		- the following lines is for this purpose
	eNum=0;
	for(i=0;i<4;i++) {
		if (nodeArray[i]==nodeArray[(i+1)%4]) continue;
		nodes[eNum]=nodeArray[i];	eNum++;
	}

	//---------------------------------------------------------------------------------------
	//	Construct the QMeshFace
	newFace=new QMeshFace;
	mesh->GetFaceList().AddTail(newFace);
	newFace->SetIndexNo(mesh->GetFaceNumber());
	newFace->SetMeshPatchPtr(mesh);		newFace->SetEdgeNum(eNum);
	for(i=0;i<eNum;i++) {
		sNode=nodes[i];	eNode=nodes[(i+1)%eNum];
		newEdge=NULL;
		for(Pos=sNode->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
			edge=(QMeshEdge *)(sNode->GetEdgeList().GetNext(Pos));
			if ((edge->GetEndPoint()==eNode) && (edge->GetLeftFace()==NULL)) {
				newEdge=edge;	bDir=true;		break;
			}
			else if ((edge->GetStartPoint()==eNode) && (edge->GetRightFace()==NULL)) {
				newEdge=edge;	bDir=false;		break;
			}
		}

		if (!newEdge) {
			newEdge=new QMeshEdge;	bDir=true;
			newEdge->SetStartPoint(sNode);	newEdge->SetEndPoint(eNode);
			sNode->GetEdgeList().AddTail(newEdge);	eNode->GetEdgeList().AddTail(newEdge);
			newEdge->SetMeshPatchPtr(mesh);	
			mesh->GetEdgeList().AddTail(newEdge);	newEdge->SetIndexNo(mesh->GetEdgeNumber());
		}
		else {
			if ((newEdge->GetLeftFace()!=NULL) && (newEdge->GetRightFace()!=NULL)) {
				printf("Non-manifold Edge is Found %d! \n",eNum);
				newEdge->SetAttribFlag(0);
			}
		}

		newFace->SetEdgeRecordPtr(i,newEdge);
		newFace->SetDirectionFlag(i,bDir);
		if (bDir)
			newEdge->SetLeftFace(newFace);
		else
			newEdge->SetRightFace(newFace);
	}
	newFace->CalPlaneEquation();
}

void LDNISolidContouring::_contourCellProc(LDNISolid *solid, LDNISolidOctreeCell *cell, QMeshPatch *mesh)
{
	int i;

	if (cell->IsLeaf()) return;

	for(i=0;i<8;i++) _contourCellProc(solid,cell->m_childOctreeNode[i],mesh);

	_contourFaceProc(solid,cell->m_childOctreeNode[0],cell->m_childOctreeNode[1],0,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[2],cell->m_childOctreeNode[3],0,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[4],cell->m_childOctreeNode[5],0,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[6],cell->m_childOctreeNode[7],0,mesh);

	_contourFaceProc(solid,cell->m_childOctreeNode[0],cell->m_childOctreeNode[2],1,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[1],cell->m_childOctreeNode[3],1,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[4],cell->m_childOctreeNode[6],1,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[5],cell->m_childOctreeNode[7],1,mesh);

	_contourFaceProc(solid,cell->m_childOctreeNode[0],cell->m_childOctreeNode[4],2,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[1],cell->m_childOctreeNode[5],2,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[2],cell->m_childOctreeNode[6],2,mesh);
	_contourFaceProc(solid,cell->m_childOctreeNode[3],cell->m_childOctreeNode[7],2,mesh);

	_contourEdgeProc(solid,cell->m_childOctreeNode[0],cell->m_childOctreeNode[2],
			cell->m_childOctreeNode[6],cell->m_childOctreeNode[4],0,
			cell->m_childOctreeNode[0]->m_nodeInside[6],cell->m_childOctreeNode[0]->m_nodeInside[7],
			mesh);
	_contourEdgeProc(solid,cell->m_childOctreeNode[1],cell->m_childOctreeNode[3],
			cell->m_childOctreeNode[7],cell->m_childOctreeNode[5],0,
			cell->m_childOctreeNode[1]->m_nodeInside[6],cell->m_childOctreeNode[1]->m_nodeInside[7],
			mesh);

	_contourEdgeProc(solid,cell->m_childOctreeNode[1],cell->m_childOctreeNode[0],
			cell->m_childOctreeNode[4],cell->m_childOctreeNode[5],1,
			cell->m_childOctreeNode[1]->m_nodeInside[4],cell->m_childOctreeNode[1]->m_nodeInside[6],
			mesh);
	_contourEdgeProc(solid,cell->m_childOctreeNode[3],cell->m_childOctreeNode[2],
			cell->m_childOctreeNode[6],cell->m_childOctreeNode[7],1,
			cell->m_childOctreeNode[3]->m_nodeInside[4],cell->m_childOctreeNode[3]->m_nodeInside[6],
			mesh);

	_contourEdgeProc(solid,cell->m_childOctreeNode[0],cell->m_childOctreeNode[1],
			cell->m_childOctreeNode[3],cell->m_childOctreeNode[2],2,
			cell->m_childOctreeNode[0]->m_nodeInside[3],cell->m_childOctreeNode[0]->m_nodeInside[7],
			mesh);
	_contourEdgeProc(solid,cell->m_childOctreeNode[4],cell->m_childOctreeNode[5],
			cell->m_childOctreeNode[7],cell->m_childOctreeNode[6],2,
			cell->m_childOctreeNode[4]->m_nodeInside[3],cell->m_childOctreeNode[4]->m_nodeInside[7],
			mesh);
}

void LDNISolidContouring::_contourFaceProc(LDNISolid *solid,
										   LDNISolidOctreeCell *pCell, LDNISolidOctreeCell *qCell, 
										   short nAxis, QMeshPatch *mesh)
{
	if ((pCell->IsLeaf()) && (qCell->IsLeaf())) return;

	if (pCell->IsLeaf()) {
		switch(nAxis) {
		case 0:{
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[0],0,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[2],0,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[4],0,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[6],0,mesh);

			_contourEdgeProc(solid,qCell->m_childOctreeNode[2],pCell,
							pCell,qCell->m_childOctreeNode[6],1,
							qCell->m_childOctreeNode[6]->m_nodeInside[0],
							qCell->m_childOctreeNode[6]->m_nodeInside[2],
							mesh);
			_contourEdgeProc(solid,qCell->m_childOctreeNode[0],pCell,
							pCell,qCell->m_childOctreeNode[4],1,
							qCell->m_childOctreeNode[4]->m_nodeInside[0],
							qCell->m_childOctreeNode[4]->m_nodeInside[2],
							mesh);
			_contourEdgeProc(solid,pCell,qCell->m_childOctreeNode[0],
							qCell->m_childOctreeNode[2],pCell,2,
							qCell->m_childOctreeNode[0]->m_nodeInside[2],
							qCell->m_childOctreeNode[0]->m_nodeInside[6],
							mesh);
			_contourEdgeProc(solid,pCell,qCell->m_childOctreeNode[4],
							qCell->m_childOctreeNode[6],pCell,2,
							qCell->m_childOctreeNode[4]->m_nodeInside[2],
							qCell->m_childOctreeNode[4]->m_nodeInside[6],
							mesh);
			   }break;
		case 1:{
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[0],1,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[1],1,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[4],1,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[5],1,mesh);

			_contourEdgeProc(solid,pCell,qCell->m_childOctreeNode[0],
							qCell->m_childOctreeNode[4],pCell,0,
							qCell->m_childOctreeNode[0]->m_nodeInside[4],
							qCell->m_childOctreeNode[0]->m_nodeInside[5],
							mesh);
			_contourEdgeProc(solid,pCell,qCell->m_childOctreeNode[1],
							qCell->m_childOctreeNode[5],pCell,0,
							qCell->m_childOctreeNode[1]->m_nodeInside[4],
							qCell->m_childOctreeNode[1]->m_nodeInside[5],
							mesh);
			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[1],qCell->m_childOctreeNode[0],2,
							qCell->m_childOctreeNode[1]->m_nodeInside[0],
							qCell->m_childOctreeNode[1]->m_nodeInside[4],
							mesh);
			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[5],qCell->m_childOctreeNode[4],2,
							qCell->m_childOctreeNode[5]->m_nodeInside[0],
							qCell->m_childOctreeNode[5]->m_nodeInside[4],
							mesh);
			   }break;
		case 2:{
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[0],2,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[1],2,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[2],2,mesh);
			_contourFaceProc(solid,pCell,qCell->m_childOctreeNode[3],2,mesh);

			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[3],qCell->m_childOctreeNode[1],0,
							qCell->m_childOctreeNode[3]->m_nodeInside[0],
							qCell->m_childOctreeNode[3]->m_nodeInside[1],
							mesh);
			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[2],qCell->m_childOctreeNode[0],0,
							qCell->m_childOctreeNode[2]->m_nodeInside[0],
							qCell->m_childOctreeNode[2]->m_nodeInside[1],
							mesh);
			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[2],qCell->m_childOctreeNode[3],1,
							qCell->m_childOctreeNode[2]->m_nodeInside[1],
							qCell->m_childOctreeNode[2]->m_nodeInside[3],
							mesh);
			_contourEdgeProc(solid,pCell,pCell,
							qCell->m_childOctreeNode[0],qCell->m_childOctreeNode[1],1,
							qCell->m_childOctreeNode[0]->m_nodeInside[1],
							qCell->m_childOctreeNode[0]->m_nodeInside[3],
							mesh);
			   }break;
		}
	}
	else if (qCell->IsLeaf()) {
		switch(nAxis) {
		case 0:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[1],qCell,0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[3],qCell,0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[5],qCell,0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell,0,mesh);

			_contourEdgeProc(solid,qCell,pCell->m_childOctreeNode[3],
							pCell->m_childOctreeNode[7],qCell,1,
							pCell->m_childOctreeNode[3]->m_nodeInside[5],
							pCell->m_childOctreeNode[3]->m_nodeInside[7],
							mesh);
			_contourEdgeProc(solid,qCell,pCell->m_childOctreeNode[1],
							pCell->m_childOctreeNode[5],qCell,1,
							pCell->m_childOctreeNode[1]->m_nodeInside[5],
							pCell->m_childOctreeNode[1]->m_nodeInside[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[1],qCell,
							qCell,pCell->m_childOctreeNode[3],2,
							pCell->m_childOctreeNode[3]->m_nodeInside[1],
							pCell->m_childOctreeNode[3]->m_nodeInside[5],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],qCell,
							qCell,pCell->m_childOctreeNode[7],2,
							pCell->m_childOctreeNode[7]->m_nodeInside[1],
							pCell->m_childOctreeNode[7]->m_nodeInside[5],
							mesh);
			   }break;
		case 1:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[2],qCell,1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[3],qCell,1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[6],qCell,1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell,1,mesh);

			_contourEdgeProc(solid,pCell->m_childOctreeNode[2],qCell,
							qCell,pCell->m_childOctreeNode[6],0,
							pCell->m_childOctreeNode[6]->m_nodeInside[2],
							pCell->m_childOctreeNode[6]->m_nodeInside[3],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[3],qCell,
							qCell,pCell->m_childOctreeNode[7],0,
							pCell->m_childOctreeNode[7]->m_nodeInside[2],
							pCell->m_childOctreeNode[7]->m_nodeInside[3],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[2],pCell->m_childOctreeNode[3],
							qCell,qCell,2,
							pCell->m_childOctreeNode[2]->m_nodeInside[3],
							pCell->m_childOctreeNode[2]->m_nodeInside[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[6],pCell->m_childOctreeNode[7],
							qCell,qCell,2,
							pCell->m_childOctreeNode[6]->m_nodeInside[3],
							pCell->m_childOctreeNode[6]->m_nodeInside[7],
							mesh);
			   }break;
		case 2:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[4],qCell,2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[5],qCell,2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[6],qCell,2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell,2,mesh);

			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],pCell->m_childOctreeNode[7],
							qCell,qCell,0,
							pCell->m_childOctreeNode[5]->m_nodeInside[6],
							pCell->m_childOctreeNode[5]->m_nodeInside[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[4],pCell->m_childOctreeNode[6],
							qCell,qCell,0,
							pCell->m_childOctreeNode[4]->m_nodeInside[6],
							pCell->m_childOctreeNode[4]->m_nodeInside[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[7],pCell->m_childOctreeNode[6],
							qCell,qCell,1,
							pCell->m_childOctreeNode[7]->m_nodeInside[4],
							pCell->m_childOctreeNode[7]->m_nodeInside[6],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],pCell->m_childOctreeNode[4],
							qCell,qCell,1,
							pCell->m_childOctreeNode[5]->m_nodeInside[4],
							pCell->m_childOctreeNode[5]->m_nodeInside[6],
							mesh);
			   }break;
		}
	}
	else {	// neither cells are leaf
		switch(nAxis) {
		case 0:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[1],qCell->m_childOctreeNode[0],0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[3],qCell->m_childOctreeNode[2],0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[5],qCell->m_childOctreeNode[4],0,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell->m_childOctreeNode[6],0,mesh);

			_contourEdgeProc(solid,qCell->m_childOctreeNode[2],pCell->m_childOctreeNode[3],
							pCell->m_childOctreeNode[7],qCell->m_childOctreeNode[6],1,
							pCell->m_childOctreeNode[3]->m_nodeInside[5],
							pCell->m_childOctreeNode[3]->m_nodeInside[7],
							mesh);
			_contourEdgeProc(solid,qCell->m_childOctreeNode[0],pCell->m_childOctreeNode[1],
							pCell->m_childOctreeNode[5],qCell->m_childOctreeNode[4],1,
							pCell->m_childOctreeNode[1]->m_nodeInside[5],
							pCell->m_childOctreeNode[1]->m_nodeInside[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[1],qCell->m_childOctreeNode[0],
							qCell->m_childOctreeNode[2],pCell->m_childOctreeNode[3],2,
							pCell->m_childOctreeNode[3]->m_nodeInside[1],
							pCell->m_childOctreeNode[3]->m_nodeInside[5],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],qCell->m_childOctreeNode[4],
							qCell->m_childOctreeNode[6],pCell->m_childOctreeNode[7],2,
							pCell->m_childOctreeNode[7]->m_nodeInside[1],
							pCell->m_childOctreeNode[7]->m_nodeInside[5],
							mesh);
			   }break;
		case 1:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[2],qCell->m_childOctreeNode[0],1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[3],qCell->m_childOctreeNode[1],1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[6],qCell->m_childOctreeNode[4],1,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell->m_childOctreeNode[5],1,mesh);

			_contourEdgeProc(solid,pCell->m_childOctreeNode[2],qCell->m_childOctreeNode[0],
							qCell->m_childOctreeNode[4],pCell->m_childOctreeNode[6],0,
							pCell->m_childOctreeNode[6]->m_nodeInside[2],
							pCell->m_childOctreeNode[6]->m_nodeInside[3],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[3],qCell->m_childOctreeNode[1],
							qCell->m_childOctreeNode[5],pCell->m_childOctreeNode[7],0,
							pCell->m_childOctreeNode[7]->m_nodeInside[2],
							pCell->m_childOctreeNode[7]->m_nodeInside[3],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[2],pCell->m_childOctreeNode[3],
							qCell->m_childOctreeNode[1],qCell->m_childOctreeNode[0],2,
							pCell->m_childOctreeNode[2]->m_nodeInside[3],
							pCell->m_childOctreeNode[2]->m_nodeInside[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[6],pCell->m_childOctreeNode[7],
							qCell->m_childOctreeNode[5],qCell->m_childOctreeNode[4],2,
							pCell->m_childOctreeNode[6]->m_nodeInside[3],
							pCell->m_childOctreeNode[6]->m_nodeInside[7],
							mesh);
			   }break;
		case 2:{
			_contourFaceProc(solid,pCell->m_childOctreeNode[4],qCell->m_childOctreeNode[0],2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[5],qCell->m_childOctreeNode[1],2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[6],qCell->m_childOctreeNode[2],2,mesh);
			_contourFaceProc(solid,pCell->m_childOctreeNode[7],qCell->m_childOctreeNode[3],2,mesh);

			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],pCell->m_childOctreeNode[7],
							qCell->m_childOctreeNode[3],qCell->m_childOctreeNode[1],0,
							pCell->m_childOctreeNode[5]->m_nodeInside[6],
							pCell->m_childOctreeNode[5]->m_nodeInside[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[4],pCell->m_childOctreeNode[6],
							qCell->m_childOctreeNode[2],qCell->m_childOctreeNode[0],0,
							pCell->m_childOctreeNode[4]->m_nodeInside[6],
							pCell->m_childOctreeNode[4]->m_nodeInside[7],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[7],pCell->m_childOctreeNode[6],
							qCell->m_childOctreeNode[2],qCell->m_childOctreeNode[3],1,
							pCell->m_childOctreeNode[7]->m_nodeInside[4],
							pCell->m_childOctreeNode[7]->m_nodeInside[6],
							mesh);
			_contourEdgeProc(solid,pCell->m_childOctreeNode[5],pCell->m_childOctreeNode[4],
							qCell->m_childOctreeNode[0],qCell->m_childOctreeNode[1],1,
							pCell->m_childOctreeNode[5]->m_nodeInside[4],
							pCell->m_childOctreeNode[5]->m_nodeInside[6],
							mesh);
			   }break;
		}
	}
}

void LDNISolidContouring::_contourEdgeProc(LDNISolid *solid,
										   LDNISolidOctreeCell *pCell, LDNISolidOctreeCell *qCell, 
										   LDNISolidOctreeCell *rCell, LDNISolidOctreeCell *sCell, 
										   short nAxis, bool sPntIn, bool ePntIn, QMeshPatch *mesh)
{
	const short edgeTable[][4]={ {3,2,0,1},{6,7,5,4},{11,10,8,9} };

	if ((pCell->IsLeaf()) && (qCell->IsLeaf()) && (rCell->IsLeaf()) && (sCell->IsLeaf())) {
		if (sPntIn==ePntIn) return;

		//-----------------------------------------------------------------------------------
		//	Construct faces
		int i;
		QMeshNode *nodeArray[4];	QMeshNode *vertexNode;
		LDNISolidOctreeCell *currentCell;
		for(i=0;i<4;i++) {
			switch(i) {
			case 0:currentCell=pCell;break;
			case 1:currentCell=qCell;break;
			case 2:currentCell=rCell;break;
			case 3:currentCell=sCell;break;
			}

			short edgeIndex=edgeTable[nAxis][i];
			short pntIndex=currentCell->edgePntIndex[edgeIndex];
			if (currentCell->vertexAtEdge[pntIndex]==NULL) {

				vertexNode=new QMeshNode;
				mesh->GetNodeList().AddTail(vertexNode);	vertexNode->SetMeshPatchPtr(mesh);
				vertexNode->SetIndexNo(mesh->GetNodeNumber());
				vertexNode->SetCoord3D(currentCell->pnts[pntIndex][0],
							currentCell->pnts[pntIndex][1],currentCell->pnts[pntIndex][2]);
				currentCell->vertexAtEdge[pntIndex]=vertexNode;
			}
			vertexNode=currentCell->vertexAtEdge[pntIndex];
			if (sPntIn)
				nodeArray[i]=vertexNode;
			else
				nodeArray[3-i]=vertexNode;
		}
		_createMeshFaceByVertices(nodeArray,mesh);

		//-----------------------------------------------------------------------------------
		//	Store the hermite data related to this face
		double hP[3],hV[3],edgeDir[3];
		
		//	search the minimal edge and its corresponding (i,j) and interval
		LDNISolidOctreeCell *cells[4];	int minL,minIndex,ii,jj;	
		double lower,upper,ww,origin[3];
		cells[0]=pCell;	cells[1]=qCell;	cells[2]=rCell;	cells[3]=sCell;
		solid->GetOrigin(origin);
		minL=solid->GetResolution()*2;	ww=solid->GetGridWidth();
		for(i=0;i<4;i++) {
			if ((cells[i]->eX-cells[i]->sX)<minL) {minL=cells[i]->eX-cells[i]->sX;	minIndex=i;}
		}
		switch(nAxis) {
		case 0:{
			switch(minIndex) {
			case 0:{ii=cells[minIndex]->eY;jj=cells[minIndex]->eZ;
				   }break;
			case 1:{ii=cells[minIndex]->sY;jj=cells[minIndex]->eZ;
				   }break;
			case 2:{ii=cells[minIndex]->sY;jj=cells[minIndex]->sZ;
				   }break;
			case 3:{ii=cells[minIndex]->eY;jj=cells[minIndex]->sZ;
				   }break;
			}
			lower=ww*(double)(cells[minIndex]->sX);	upper=ww*(double)(cells[minIndex]->eX);
			hP[1]=origin[1]+ww*(double)ii;
			hP[2]=origin[2]+ww*(double)jj;
			   }break;
		case 1:{
			switch(minIndex) {
			case 0:{ii=cells[minIndex]->eZ;jj=cells[minIndex]->sX;
				   }break;
			case 1:{ii=cells[minIndex]->eZ;jj=cells[minIndex]->eX;
				   }break;
			case 2:{ii=cells[minIndex]->sZ;jj=cells[minIndex]->eX;
				   }break;
			case 3:{ii=cells[minIndex]->sZ;jj=cells[minIndex]->sX;
				   }break;
			}
			lower=ww*(double)(cells[minIndex]->sY);	upper=ww*(double)(cells[minIndex]->eY);
			hP[0]=origin[0]+ww*(double)jj;
			hP[2]=origin[2]+ww*(double)ii;
			   }break;
		case 2:{
			switch(minIndex) {
			case 0:{ii=cells[minIndex]->eX;jj=cells[minIndex]->eY;
				   }break;
			case 1:{ii=cells[minIndex]->sX;jj=cells[minIndex]->eY;
				   }break;
			case 2:{ii=cells[minIndex]->sX;jj=cells[minIndex]->sY;
				   }break;
			case 3:{ii=cells[minIndex]->eX;jj=cells[minIndex]->sY;
				   }break;
			}
			lower=ww*(double)(cells[minIndex]->sZ);	upper=ww*(double)(cells[minIndex]->eZ);
			hP[0]=origin[0]+ww*(double)ii;
			hP[1]=origin[1]+ww*(double)jj;
			   }break;
		}

		edgeDir[0]=edgeDir[1]=edgeDir[2]=0.0;
		if (sPntIn) edgeDir[nAxis]=1.0; else edgeDir[nAxis]=-1.0;

		LDNISolidNode *currentNode;
		double minDelta=1.0e+32,midDepth=(lower+upper)*0.5,dd;
		double eps=1.0e-8;
		currentNode=solid->GetLDNISolidNode(nAxis,ii,jj);
		bool bFound=false;
		if (currentNode!=NULL) {
			short k,nNum;
			nNum=currentNode->GetSampleNum();
			for(k=0;k<nNum;k++) {
				double depth=currentNode->GetDepth(k);
				if (depth<(lower-eps)) continue;	
				if (depth>(upper+eps)) break;
				if (fabs(depth-midDepth)>=minDelta) continue;
				currentNode->GetNormal(k,hV[0],hV[1],hV[2]);
				hP[nAxis]=origin[nAxis]+depth;		minDelta=fabs(depth-midDepth);
				bFound=true;
			}
		}
		QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetTail());
//		if (!bFound) face->SetAttribFlag(4,true);
		dd=edgeDir[0]*hV[0]+edgeDir[1]*hV[1]+edgeDir[2]*hV[2];
		if (dd<0.0) {hV[0]=-hV[0]; hV[1]=-hV[1]; hV[2]=-hV[2];}
		face->SetHermiteData(hP,hV);
	}
	else {	
		//-----------------------------------------------------------------------------------
		//	Visit the two sub-edges on this edge
		bool ssIn,eeIn;		LDNISolidOctreeCell	*cells[4];		int i,k;
		LDNISolidOctreeCell *currentCell;
		short table[][2][4][3]={
			{{{6,6,7},{4,4,5},{0,0,1},{2,2,3}},{{7,6,7},{5,4,5},{1,0,1},{3,2,3}}},
			{{{4,4,6},{5,5,7},{1,1,3},{0,0,2}},{{6,4,6},{7,5,7},{3,1,3},{2,0,2}}},
			{{{3,3,7},{2,2,6},{0,0,4},{1,1,5}},{{7,3,7},{6,2,6},{4,0,4},{5,1,5}}}
		};
		for(k=0;k<2;k++) {
			for(i=0;i<4;i++) {
				switch(i) {
				case 0:currentCell=pCell;break;
				case 1:currentCell=qCell;break;
				case 2:currentCell=rCell;break;
				case 3:currentCell=sCell;break;
				}
				if (currentCell->IsLeaf()) cells[i]=currentCell;
				else {
					cells[i]=currentCell->m_childOctreeNode[table[nAxis][k][i][0]];
					ssIn=cells[i]->m_nodeInside[table[nAxis][k][i][1]];
					eeIn=cells[i]->m_nodeInside[table[nAxis][k][i][2]];
				}
			}
			_contourEdgeProc(solid,cells[0],cells[1],cells[2],cells[3],nAxis,ssIn,eeIn,mesh);
		}
	}
}

void LDNISolidContouring::_fillMeshTopology(QMeshPatch *mesh)
{
	GLKPOSITION Pos;	int i,index;

	index=1;
	for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;index++) {
		QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->SetIndexNo(index);
		node->GetFaceList().RemoveAll();
		node->GetEdgeList().RemoveAll();
		node->SetAttribFlag(7,false);
	}
	index=1;
	for(Pos=mesh->GetEdgeList().GetHeadPosition();Pos!=NULL;index++) {
		QMeshEdge *edge=(QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->SetIndexNo(index);
		edge->GetStartPoint()->GetEdgeList().AddTail(edge);
		edge->GetEndPoint()->GetEdgeList().AddTail(edge);
		if (edge->GetLeftFace()==edge->GetRightFace()) printf("Warning: invalid topology is found!\n");
		if ((edge->GetLeftFace()==NULL) || (edge->GetRightFace()==NULL)) {
			edge->SetAttribFlag(0,true);
			 printf("Warning: boundary edge is found!\n");
		}
	}
	index=1;
	for(Pos=mesh->GetFaceList().GetHeadPosition();Pos!=NULL;index++) {
		QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		face->SetIndexNo(index);
		face->CalPlaneEquation();
		int eNum=face->GetEdgeNum();
		for(i=0;i<eNum;i++) {
			if (face->IsNormalDirection(i))
				face->GetEdgeRecordPtr(i)->SetLeftFace(face);
			else
				face->GetEdgeRecordPtr(i)->SetRightFace(face);
			face->GetNodeRecordPtr(i)->GetFaceList().AddTail(face);
		}
	}
}

void LDNISolidContouring::_nonmanifoldToManifoldCorrection(LDNISolid *solid, QMeshPatch *mesh)
{
	int *singularNodeTable;
	bool bSingularNode;					int i,j,singularNodeNum;
	GLKPOSITION Pos;		
	GLKPOSITION PosFace;
	GLKObList nodeList,hermiteDataSet;	double pp[3];

	//---------------------------------------------------------------------------------
	//	Step 1: Check and fix the singular vertices
	nodeList.RemoveAll();
 	bSingularNode=_nonmanifoldNodeCheck(mesh,singularNodeNum,singularNodeTable);
	if (bSingularNode) {
		printf("Warning: %d non-manifold vertex is found and fixed!\n",singularNodeNum);

		QMeshNode **nodeArray=(QMeshNode **)new long[mesh->GetNodeNumber()];
		i=0;
		for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;i++)
			nodeArray[i]=(QMeshNode*)(mesh->GetNodeList().GetNext(Pos));

		int n=0;	double xx,yy,zz;
		for(i=0;i<singularNodeNum;i++) {
			QMeshNode *currentNode=nodeArray[singularNodeTable[n]]; n++;
			currentNode->SetAttribFlag(4,true);
			nodeList.AddTail(currentNode);
			
			int clusterNum=singularNodeTable[n];	n++;
			currentNode->GetCoord3D(xx,yy,zz);

			QMeshNode **newNodeArray=(QMeshNode **)new long[clusterNum-1];
			for(j=0;j<clusterNum-1;j++) {
				newNodeArray[j]=new QMeshNode;
				newNodeArray[j]->SetMeshPatchPtr(mesh);
				newNodeArray[j]->SetCoord3D(xx,yy,zz);
				mesh->GetNodeList().AddTail(newNodeArray[j]);
				newNodeArray[j]->SetIndexNo(mesh->GetNodeNumber());
				newNodeArray[j]->SetAttribFlag(4,true);
				nodeList.AddTail(newNodeArray[j]);
			}

			for(Pos=currentNode->GetFaceList().GetHeadPosition();Pos!=NULL;) {
				QMeshFace *face=(QMeshFace *)(currentNode->GetFaceList().GetNext(Pos));
				int faceColor=singularNodeTable[n];	n++;
				if (faceColor==1) continue;
				int edgeNum=face->GetEdgeNum();
				for(j=0;j<edgeNum;j++) {
					QMeshEdge *edge=face->GetEdgeRecordPtr(j);
					if (edge->GetStartPoint()==currentNode)
						edge->SetStartPoint(newNodeArray[faceColor-2]);
					if (edge->GetEndPoint()==currentNode)
						edge->SetEndPoint(newNodeArray[faceColor-2]);
				}
			}

			delete [](QMeshNode **)newNodeArray;
		}

		delete []singularNodeTable;		delete [](QMeshNode **)nodeArray;
	}

	//---------------------------------------------------------------------------------
	//	Step 2: Refill topology information
	for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;) {
		QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
		node->GetEdgeList().RemoveAll();
		node->GetFaceList().RemoveAll();
	}
	for(Pos=mesh->GetEdgeList().GetHeadPosition();Pos!=NULL;) {
		QMeshEdge *edge=(QMeshEdge *)(mesh->GetEdgeList().GetNext(Pos));
		edge->GetStartPoint()->GetEdgeList().AddTail(edge);
		edge->GetEndPoint()->GetEdgeList().AddTail(edge);
		if (!(edge->GetLeftFace() && edge->GetRightFace())) {
			edge->SetAttribFlag(0);	
			edge->GetStartPoint()->SetAttribFlag(0);	
			edge->GetEndPoint()->SetAttribFlag(0);
		}
	}
	for(Pos=mesh->GetFaceList().GetHeadPosition();Pos!=NULL;) {
		QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		int eNum=face->GetEdgeNum();
		for(i=0;i<eNum;i++)	face->GetNodeRecordPtr(i)->GetFaceList().AddTail(face);
	}

	//---------------------------------------------------------------------------------
	//	Step 3: Reshape the corrected singular vertices
	for(Pos=nodeList.GetHeadPosition();Pos!=NULL;) {
		QMeshNode *node=(QMeshNode *)(nodeList.GetNext(Pos));
		node->SetAttribFlag(4,false);
		hermiteDataSet.RemoveAll();		
		node->GetCoord3D(pp[0],pp[1],pp[2]);

		for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
			LDNIHermiteData *data=new LDNIHermiteData;
			face->GetHermiteData(data->pos,data->normal);
			hermiteDataSet.AddTail(data);
		}

		_compPositionByHermiteData(solid,&hermiteDataSet,pp);
		node->SetCoord3D(pp[0],pp[1],pp[2]);
		_deleteHermiteDataSet(&hermiteDataSet);
	}
	//---------------------------------------------------------------------------------
	for(Pos=nodeList.GetHeadPosition();Pos!=NULL;) {
		QMeshNode *node=(QMeshNode *)(nodeList.GetNext(Pos));
		for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
			face->CalPlaneEquation();
		}
	}
}

bool LDNISolidContouring::_nonmanifoldNodeCheck(QMeshPatch *mesh, int &singularNodeNum, int* &singularNodeTable)
{
	GLKPOSITION Pos;	
	GLKPOSITION PosFace;	float rr,gg,bb;
	GLKArray *info;

	info=new GLKArray(200,200,1);	singularNodeNum=0;

	for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;) {
		QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));

		for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
			QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
			face->SetColor(0,0,0);
		}

		int nColorNum=0;	bool bFilled;
		do{
			bFilled=false;

			for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
				QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
				face->GetColor(rr,gg,bb);
				if ((int)rr==0) {
					nColorNum++;	bFilled=true;
					_floodingFacesAroundNode(node, face, nColorNum);
				}
			}
		}while(bFilled);

		if (nColorNum>1) {
			singularNodeNum++;	info->Add((int)(node->GetIndexNo()-1));
			info->Add((int)(nColorNum));
			for(PosFace=node->GetFaceList().GetHeadPosition();PosFace!=NULL;) {
				QMeshFace *face=(QMeshFace *)(node->GetFaceList().GetNext(PosFace));
				face->GetColor(rr,gg,bb);
				info->Add((int)(rr));
			}
		}
	}

	if (singularNodeNum==0) {delete info; return false;}

	//-------------------------------------------------------------------------------------
	//	output the node information table
	int len=info->GetSize();
	singularNodeTable=new int[len];
	for(int i=0;i<len;i++) singularNodeTable[i]=info->GetIntAt(i);
	delete info;

	return true;
}

void LDNISolidContouring::_floodingFacesAroundNode(QMeshNode *node, QMeshFace *seedFace, int nColor)
{
	float rr,gg,bb;
	int i,eNum;		QMeshFace *nextFace;

	seedFace->SetColor((float)nColor,0,0);
	eNum=seedFace->GetEdgeNum();
	for(i=0;i<eNum;i++) {
		QMeshEdge *edge=seedFace->GetEdgeRecordPtr(i);
		if ((edge->GetStartPoint()==node) || (edge->GetEndPoint()==node)) {
			if (edge->GetLeftFace()==seedFace) 
				nextFace=edge->GetRightFace();
			else
				nextFace=edge->GetLeftFace();
			if (!nextFace) continue;
			nextFace->GetColor(rr,gg,bb);
			if ((int)rr==0) _floodingFacesAroundNode(node, nextFace, nColor);
		}
	}
}

void LDNISolidContouring::_quadMeshToTrglMesh(QMeshPatch *mesh)
{
	GLKPOSITION Pos;	GLKObList newFaceList;
	QMeshEdge *edges[4];	QMeshNode *nodes[4];	bool bEdgeDirs[4];
	int i;		double pos[4][3],pp1[3],pp2[3],pp3[3];	
	double d1,d2,dd;	short nCase;
	double fnv[4][3],nv1[3],nv2[3];	bool bRes;		//double hP[3],hV[3];
	GLKGeometry geo;

	newFaceList.RemoveAll();
	for(Pos=mesh->GetFaceList().GetHeadPosition();Pos!=NULL;) {
		QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
		if (face->GetEdgeNum()==3) continue;

		//--------------------------------------------------------------------------------
		//	Step 1: data preparation
		for(i=0;i<4;i++) {
			edges[i]=face->GetEdgeRecordPtr(i);
			nodes[i]=face->GetNodeRecordPtr(i);
			bEdgeDirs[i]=face->IsNormalDirection(i);
			face->GetNodePos(i,pos[i][0],pos[i][1],pos[i][2]);
			if (bEdgeDirs[i]) {
				edges[i]->GetEndPoint()->GetCoord3D(pp1[0],pp1[1],pp1[2]);
				edges[i]->GetStartPoint()->GetCoord3D(pp2[0],pp2[1],pp2[2]);
				edges[i]->GetRightFace()->CalCenterPos(pp3[0],pp3[1],pp3[2]);
				geo.CalPlaneEquation(pp1,pp2,pp3,fnv[i][0],fnv[i][1],fnv[i][2],dd);
//				edges[i]->GetRightFace()->GetPlaneEquation(fnv[i][0],fnv[i][1],fnv[i][2],dd);
			}
			else {
				edges[i]->GetStartPoint()->GetCoord3D(pp1[0],pp1[1],pp1[2]);
				edges[i]->GetEndPoint()->GetCoord3D(pp2[0],pp2[1],pp2[2]);
				edges[i]->GetLeftFace()->CalCenterPos(pp3[0],pp3[1],pp3[2]);
				geo.CalPlaneEquation(pp1,pp2,pp3,fnv[i][0],fnv[i][1],fnv[i][2],dd);
//				edges[i]->GetLeftFace()->GetPlaneEquation(fnv[i][0],fnv[i][1],fnv[i][2],dd);
			}
		}

		//--------------------------------------------------------------------------------
		//	Step 2: detect the optimal triangulation (case 0: linking 0-2; case 1: linking 1-3)
		//--------------------------------------------------------------------------------
		//	evaluate the objective function for normal variation
		double hPos[3],hNormal[3];
		face->GetHermiteData(hPos,hNormal);
		//--------------------------------------------------------------------------------
		bRes=geo.CalPlaneEquation(pos[0],pos[1],pos[2],nv1[0],nv1[1],nv1[2],dd);
		if (!bRes) {nv1[0]=0.0; nv1[1]=0.0; nv1[2]=0.0;}
		bRes=geo.CalPlaneEquation(pos[0],pos[2],pos[3],nv2[0],nv2[1],nv2[2],dd);
		if (!bRes) {nv2[0]=0.0; nv2[1]=0.0; nv2[2]=0.0;}
		dd=1.0-geo.VectorProject(nv1,fnv[0]);	d1=dd;
		dd=1.0-geo.VectorProject(nv1,fnv[1]);	d1=(dd>d1)?dd:d1;
		dd=1.0-geo.VectorProject(nv2,fnv[2]);	d1=(dd>d1)?dd:d1;
		dd=1.0-geo.VectorProject(nv2,fnv[3]);	d1=(dd>d1)?dd:d1;
		//--------------------------------------------------------------------------------
		bRes=geo.CalPlaneEquation(pos[0],pos[1],pos[3],nv1[0],nv1[1],nv1[2],dd);
		if (!bRes) {nv1[0]=0.0; nv1[1]=0.0; nv1[2]=0.0;}
		bRes=geo.CalPlaneEquation(pos[1],pos[2],pos[3],nv2[0],nv2[1],nv2[2],dd);
		if (!bRes) {nv2[0]=0.0; nv2[1]=0.0; nv2[2]=0.0;}
		dd=1.0-geo.VectorProject(nv1,fnv[0]);	d2=dd;
		dd=1.0-geo.VectorProject(nv1,fnv[3]);	d2=(dd>d2)?dd:d2;
		dd=1.0-geo.VectorProject(nv2,fnv[1]);	d2=(dd>d2)?dd:d2;
		dd=1.0-geo.VectorProject(nv2,fnv[2]);	d2=(dd>d2)?dd:d2;
		//--------------------------------------------------------------------------------
		double normal_threshold=0.000001;
		if ((d1<d2))// && (fabs(d2-d1)>normal_threshold)) 
			nCase=0; 
		else if ((d1>d2))// && (fabs(d1-d2)>normal_threshold))
			nCase=1;
		else {
			d1=geo.Distance_to_Point(pos[0],pos[2]);
			d2=geo.Distance_to_Point(pos[1],pos[3]);
			if (d1<d2) nCase=0; else nCase=1;
		}

		//--------------------------------------------------------------------------------
		//	Step 3: 
		switch(nCase) {
		case 0:{
			QMeshEdge *newEdge=new QMeshEdge;
			newEdge->SetMeshPatchPtr(mesh);
			mesh->GetEdgeList().AddTail(newEdge);
			newEdge->SetIndexNo(mesh->GetEdgeNumber());
			newEdge->SetStartPoint(nodes[0]);	nodes[0]->GetEdgeList().AddTail(newEdge);
			newEdge->SetEndPoint(nodes[2]);		nodes[2]->GetEdgeList().AddTail(newEdge);

			face->SetEdgeNum(3);	
			face->SetEdgeRecordPtr(2,newEdge);
			face->SetDirectionFlag(2,false);
			face->SetHermiteData(hPos,hNormal);

			QMeshFace *newFace=new QMeshFace;
			newFace->SetMeshPatchPtr(mesh);
			newFaceList.AddTail(newFace);
			newFace->SetIndexNo(newFaceList.GetCount()+mesh->GetFaceNumber());
			newFace->SetEdgeNum(3);
			newFace->SetEdgeRecordPtr(0,newEdge);
			newFace->SetDirectionFlag(0,true);
			newFace->SetEdgeRecordPtr(1,edges[2]);
			newFace->SetDirectionFlag(1,bEdgeDirs[2]);
			newFace->SetEdgeRecordPtr(2,edges[3]);
			newFace->SetDirectionFlag(2,bEdgeDirs[3]);
			newFace->SetHermiteData(hPos,hNormal);

			newEdge->SetLeftFace(newFace);
			newEdge->SetRightFace(face);
			if (face->GetAttribFlag(4)) newFace->SetAttribFlag(4);
			   }break;
		case 1:{
			QMeshEdge *newEdge=new QMeshEdge;
			newEdge->SetMeshPatchPtr(mesh);
			mesh->GetEdgeList().AddTail(newEdge);
			newEdge->SetIndexNo(mesh->GetEdgeNumber());
			newEdge->SetStartPoint(nodes[1]);	nodes[1]->GetEdgeList().AddTail(newEdge);
			newEdge->SetEndPoint(nodes[3]);		nodes[3]->GetEdgeList().AddTail(newEdge);

			face->SetEdgeNum(3);	
			face->SetEdgeRecordPtr(0,newEdge);
			face->SetDirectionFlag(0,false);
			face->SetHermiteData(hPos,hNormal);

			QMeshFace *newFace=new QMeshFace;
			newFace->SetMeshPatchPtr(mesh);
			newFaceList.AddTail(newFace);
			newFace->SetIndexNo(newFaceList.GetCount()+mesh->GetFaceNumber());
			newFace->SetEdgeNum(3);
			newFace->SetEdgeRecordPtr(0,newEdge);
			newFace->SetDirectionFlag(0,true);
			newFace->SetEdgeRecordPtr(1,edges[3]);
			newFace->SetDirectionFlag(1,bEdgeDirs[3]);
			newFace->SetEdgeRecordPtr(2,edges[0]);
			newFace->SetDirectionFlag(2,bEdgeDirs[0]);
			newFace->SetHermiteData(hPos,hNormal);

			newEdge->SetLeftFace(newFace);
			newEdge->SetRightFace(face);
			if (face->GetAttribFlag(4)) newFace->SetAttribFlag(4);
			   }break;
		}
	}

	mesh->GetFaceList().AddTail(&newFaceList);
}
