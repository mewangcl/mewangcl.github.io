#define _CRT_SECURE_NO_DEPRECATE

#include <math.h>
#include "LDNISolid.h"

LDNISolid::LDNISolid(void)
{
	m_res=0;	m_materialTypeNum=1;
}

LDNISolid::~LDNISolid(void)
{
	ReleaseMemoryOfSolidNodeArray();
}

void LDNISolid::MallocMemoryOfSolidNodeArray(int res)
{
	int i,j;

	if (m_res!=0) ReleaseMemoryOfSolidNodeArray();

	m_res=res;	m_materialTypeNum=1;
	m_xNodeArray=(LDNISolidNode ***)new long[m_res];
	m_yNodeArray=(LDNISolidNode ***)new long[m_res];
	m_zNodeArray=(LDNISolidNode ***)new long[m_res];
	for(i=0;i<m_res;i++) {
		m_xNodeArray[i]=(LDNISolidNode **)new long[m_res];
		m_yNodeArray[i]=(LDNISolidNode **)new long[m_res];
		m_zNodeArray[i]=(LDNISolidNode **)new long[m_res];
		for(j=0;j<m_res;j++) {
			m_xNodeArray[i][j]=NULL;	m_yNodeArray[i][j]=NULL;	m_zNodeArray[i][j]=NULL;
		}
	}
}

void LDNISolid::ReleaseMemoryOfSolidNodeArray()
{
	if (m_res==0) return;

	int i,j;
	for(i=0;i<m_res;i++) {
		for(j=0;j<m_res;j++) {
			if (m_xNodeArray[i][j]) delete (LDNISolidNode*)(m_xNodeArray[i][j]);
			if (m_yNodeArray[i][j]) delete (LDNISolidNode*)(m_yNodeArray[i][j]);
			if (m_zNodeArray[i][j]) delete (LDNISolidNode*)(m_zNodeArray[i][j]);
		}
		delete [](LDNISolidNode **)(m_xNodeArray[i]);
		delete [](LDNISolidNode **)(m_yNodeArray[i]);
		delete [](LDNISolidNode **)(m_zNodeArray[i]);
	}
	delete [](LDNISolidNode ***)m_xNodeArray;
	delete [](LDNISolidNode ***)m_yNodeArray;
	delete [](LDNISolidNode ***)m_zNodeArray;

	m_res=0;
}

void LDNISolid::EmptySolidNodeArray()
{
	if (m_res==0) return;

	int i,j;
	for(i=0;i<m_res;i++) {
		for(j=0;j<m_res;j++) {
			if (m_xNodeArray[i][j]) delete (LDNISolidNode*)(m_xNodeArray[i][j]);
			if (m_yNodeArray[i][j]) delete (LDNISolidNode*)(m_yNodeArray[i][j]);
			if (m_zNodeArray[i][j]) delete (LDNISolidNode*)(m_zNodeArray[i][j]);
			m_xNodeArray[i][j]=m_yNodeArray[i][j]=m_zNodeArray[i][j]=NULL;
		}
	}
}

bool LDNISolid::SetLDNISolidNode(short nAxis, int iIndex, int jIndex, LDNISolidNode *solidNode)
{
	if ((iIndex<0) || (iIndex>=m_res) || (jIndex<0) || (jIndex>=m_res)) return false;

	LDNISolidNode*** nodeArray;
	switch(nAxis) {
	case 0:{nodeArray=m_xNodeArray;   }break;
	case 1:{nodeArray=m_yNodeArray;   }break;
	case 2:{nodeArray=m_zNodeArray;   }break;
	}
	nodeArray[iIndex][jIndex]=solidNode;

	return true;
}

LDNISolidNode* LDNISolid::GetLDNISolidNode(short nAxis, int iIndex, int jIndex)
{
	if ((iIndex>=m_res) || (jIndex>=m_res) || (iIndex<0) || (jIndex<0)) return NULL;

	LDNISolidNode*** nodeArray;
	switch(nAxis) {
	case 0:{nodeArray=m_xNodeArray;   }break;
	case 1:{nodeArray=m_yNodeArray;   }break;
	case 2:{nodeArray=m_zNodeArray;   }break;
	}
	return nodeArray[iIndex][jIndex];
}


long LDNISolid::CompSampleNum()
{
	long num=0;		int i,j;

	for(i=0;i<m_res;i++) {
		for(j=0;j<m_res;j++) {
			if (m_xNodeArray[i][j]) num+=m_xNodeArray[i][j]->GetSampleNum();
			if (m_yNodeArray[i][j]) num+=m_yNodeArray[i][j]->GetSampleNum();
			if (m_zNodeArray[i][j]) num+=m_zNodeArray[i][j]->GetSampleNum();
		}
	}

	return num;
}

long LDNISolid::CompMemoryRequired()
{
	long ram=0;		int i,j;

	ram+=m_res*m_res*sizeof(long)*3;	// for the pointer array of samples

	for(i=0;i<m_res;i++) {
		for(j=0;j<m_res;j++) {
			if (m_xNodeArray[i][j])
				ram+=(m_xNodeArray[i][j]->GetSampleNum())*(sizeof(float)+3);	// "sizeof(float)" is for "depth"
			if (m_yNodeArray[i][j])
				ram+=(m_yNodeArray[i][j]->GetSampleNum())*(sizeof(float)+3);	// normal is approximated so that only 3-bytes are needed for each sample
			if (m_zNodeArray[i][j])
				ram+=(m_zNodeArray[i][j]->GetSampleNum())*(sizeof(float)+3);
		}
	}

	return ram;
}

void LDNISolid::FileWrite(char *filename)
{
	FILE *fp;	int i,j,nCase;	short num=0;
	LDNISolidNode *currentNode;

	if (!(fp=fopen(filename,"w+b"))) {printf("LDNI File Export Error!\n");return;}

	fwrite(&m_res,sizeof(int),1,fp);
	fwrite(&m_width,sizeof(double),1,fp);
	fwrite(m_origin,sizeof(double),3,fp);

	for(i=0;i<m_res;i++) {
		for(j=0;j<m_res;j++) {
			for(nCase=0;nCase<3;nCase++) {
				switch(nCase) {
				case 0:currentNode=m_xNodeArray[i][j];break;
				case 1:currentNode=m_yNodeArray[i][j];break;
				case 2:currentNode=m_zNodeArray[i][j];break;
				}
				num=0;
				if (currentNode) num=currentNode->GetSampleNum();
				fwrite(&num,sizeof(short),1,fp);
				if (currentNode) currentNode->WriteSample(fp);
			}
		}
	}

	fclose(fp);
}

void LDNISolid::FileRead(char *filename)
{
	FILE *fp;	int i,j,res,nCase;	short num;
	LDNISolidNode *currentNode;

	if (!(fp=fopen(filename,"r+b"))) {printf("LDNI File Import Error!\n");return;}

	fread(&res,sizeof(int),1,fp);	MallocMemoryOfSolidNodeArray(res);
	fread(&m_width,sizeof(double),1,fp);
	fread(m_origin,sizeof(double),3,fp);

	for(i=0;i<res;i++) {
		for(j=0;j<res;j++) {
			for(nCase=0;nCase<3;nCase++) {
				fread(&num,sizeof(short),1,fp);
				if (num==0) continue;
				currentNode=new LDNISolidNode;
				currentNode->MallocSampleArray(num);
				currentNode->ReadSample(fp);
				switch(nCase) {
				case 0:m_xNodeArray[i][j]=currentNode;break;
				case 1:m_yNodeArray[i][j]=currentNode;break;
				case 2:m_zNodeArray[i][j]=currentNode;break;
				}
			}
		}
	}
	fclose(fp);
}

bool LDNISolid::DetectPointInOrOut(float px, float py, float pz)
{
	int i,j,k;
	double ox,oy,oz,xx,yy,zz;
	short index,sampleNum;
	bool bXdir,bYdir,bZdir;
	LDNISolidNode *currentNode;

	//---------------------------------------------------------------------------------
	//	Our rule is that: for any direction, if a point is outside, then it is outside
	ox=m_origin[0]-m_width*0.5;	oy=m_origin[1]-m_width*0.5;	oz=m_origin[2]-m_width*0.5;
	i=(int)((px-ox)/m_width);
	j=(int)((py-oy)/m_width);
	k=(int)((pz-oz)/m_width);
	if ((i<0) || (i>=m_res)) return false;
	if ((j<0) || (j>=m_res)) return false;
	if ((k<0) || (k>=m_res)) return false;

	bXdir=false;
	if (m_xNodeArray[j][k]) {
		xx=px-m_origin[0];
		currentNode=m_xNodeArray[j][k];	sampleNum=currentNode->GetSampleNum();
		for(index=0;index<sampleNum;index+=2) {
			if (xx<currentNode->GetDepth(index)) break;
			if ((xx>=currentNode->GetDepth(index)) 
				&& (xx<=currentNode->GetDepth(index+1))) {bXdir=true;break;}
		}
	}
	bYdir=false;
	if (m_yNodeArray[k][i]) {
		yy=py-m_origin[1];
		currentNode=m_yNodeArray[k][i];	sampleNum=currentNode->GetSampleNum();
		for(index=0;index<sampleNum;index+=2) {
			if (yy<currentNode->GetDepth(index)) break;
			if ((yy>=currentNode->GetDepth(index)) 
				&& (yy<=currentNode->GetDepth(index+1))) {bYdir=true;break;}
		}
	}
	bZdir=false;
	if (m_zNodeArray[i][j]) {
		zz=pz-m_origin[2];
		currentNode=m_zNodeArray[i][j];	sampleNum=currentNode->GetSampleNum();
		for(index=0;index<sampleNum;index+=2) {
			if (zz<currentNode->GetDepth(index)) break;
			if ((zz>=currentNode->GetDepth(index)) 
				&& (zz<=currentNode->GetDepth(index+1))) {bZdir=true;break;}
		}
	}

	if (bXdir && bYdir && bZdir) return true;

	return false;
}

int LDNISolid::DetectNodeMaterialType(int i, int j, int k)
{
	double xx,yy,zz;
	LDNISolidNode *currentNode;
	short index,sampleNum;
	int xType,yType,zType;

	if ((i<0) || (j<0) || (k<0)) return 0;
	if ((i>=m_res) || (j>=m_res) || (k>=m_res)) return 0;

	xType=yType=zType=0;
	xx=m_width*(double)i;	yy=m_width*(double)j;	zz=m_width*(double)k;
	if (m_xNodeArray[j][k]) {
		currentNode=m_xNodeArray[j][k];
		sampleNum=currentNode->GetSampleNum();
		for(index=0;index<sampleNum-1;index++) {
			if (xx<currentNode->GetDepth(index)) break;
			if ((xx>=currentNode->GetDepth(index)) 
				&& (xx<=currentNode->GetDepth(index+1))) {
//					xType=(currentNode->GetID(index))%(m_materialTypeNum+1);
//					if (xType!=0) return xType;
					xType=(currentNode->GetID(index))%(m_materialTypeNum+1);	break;
			}
		}
	}
	if (m_yNodeArray[k][i]) {
		currentNode=m_yNodeArray[k][i];
		sampleNum=currentNode->GetSampleNum();
		for(index=0;index<sampleNum-1;index++) {
			if (yy<currentNode->GetDepth(index)) break;
			if ((yy>=currentNode->GetDepth(index)) 
				&& (yy<=currentNode->GetDepth(index+1))) {
//					yType=(currentNode->GetID(index))%(m_materialTypeNum+1);
//					if (yType!=0) return yType;
					yType=(currentNode->GetID(index))%(m_materialTypeNum+1);	break;
			}
		}
	}
	if (m_zNodeArray[i][j]) {
		currentNode=m_zNodeArray[i][j];
		sampleNum=currentNode->GetSampleNum();
		for(index=0;index<sampleNum-1;index++) {
			if (zz<currentNode->GetDepth(index)) break;
			if ((zz>=currentNode->GetDepth(index)) 
				&& (zz<=currentNode->GetDepth(index+1))) {
//					zType=(currentNode->GetID(index))%(m_materialTypeNum+1);
//					if (zType!=0) return zType;
					zType=(currentNode->GetID(index))%(m_materialTypeNum+1);	break;
			}
		}
	}

	if ((xType==yType) && (xType!=0)) return xType;
	if ((xType==zType) && (xType!=0)) return xType;
	if ((yType==zType) && (yType!=0)) return yType;

	return 0;
}

bool LDNISolid::DetectNodeInOrOut(int i, int j, int k)
{
	double xx,yy,zz;
	LDNISolidNode *currentNode;
	short index,sampleNum;
	int num=0;	// the number of detections that find it is IN
	bool xInside=false,yInside=false,zInside=false;
	double eps=1.0e-8;

	if ((i<0) || (j<0) || (k<0)) return false;
	if ((i>=m_res) || (j>=m_res) || (k>=m_res)) return false;

	xx=m_width*(double)i;	yy=m_width*(double)j;	zz=m_width*(double)k;
	if (m_xNodeArray[j][k]) {
		currentNode=m_xNodeArray[j][k];
		sampleNum=currentNode->GetSampleNum();
		for(index=0;index<sampleNum;index+=2) {
			if (xx<currentNode->GetDepth(index)) break;
			if ((xx>=currentNode->GetDepth(index)) 
				&& (xx<=currentNode->GetDepth(index+1))) {num++; xInside=true; break;}
		}
	}
	if (m_yNodeArray[k][i]) {
		currentNode=m_yNodeArray[k][i];
		sampleNum=currentNode->GetSampleNum();
		for(index=0;index<sampleNum;index+=2) {
			if (yy<currentNode->GetDepth(index)) break;
			if ((yy>=currentNode->GetDepth(index)) 
				&& (yy<=currentNode->GetDepth(index+1))) {num++; yInside=true; break;}
		}
	}
	if (m_zNodeArray[i][j]) {
		currentNode=m_zNodeArray[i][j];
		sampleNum=currentNode->GetSampleNum();
		for(index=0;index<sampleNum;index+=2) {
			if (zz<currentNode->GetDepth(index)) break;
			if ((zz>=currentNode->GetDepth(index)) 
				&& (zz<=currentNode->GetDepth(index+1))) {num++; zInside=true; break;}
		}
	}

	if (num==0) return false;
	if (num==3) return true;
	if (num>=2) return true;	// remove this get better result on Bunny repair
	return false;

	//----------------------------------------------------------------------------------
	//	regularization of the samples by small perturbation
	if (num==1) {  // Adding this may lead to odd number of intersection points
		if (xInside) {
			currentNode=m_xNodeArray[j][k];
			sampleNum=currentNode->GetSampleNum();
			for(index=0;index<sampleNum;index+=2) {
				if (xx<currentNode->GetDepth(index)) break;
				if ((xx>=currentNode->GetDepth(index)) && (xx<=currentNode->GetDepth(index+1))) {
					if (fabs(xx-currentNode->GetDepth(index))<fabs(xx-currentNode->GetDepth(index+1)))
						currentNode->SetDepth(index,(float)(xx+eps));
					else
						currentNode->SetDepth(index+1,(float)(xx-eps));
				}
			}
		}
		else if (yInside) {
			currentNode=m_yNodeArray[k][i];
			sampleNum=currentNode->GetSampleNum();
			for(index=0;index<sampleNum;index+=2) {
				if (yy<currentNode->GetDepth(index)) break;
				if ((yy>=currentNode->GetDepth(index)) && (yy<=currentNode->GetDepth(index+1))) {
					if (fabs(yy-currentNode->GetDepth(index))<fabs(yy-currentNode->GetDepth(index+1)))
						currentNode->SetDepth(index,(float)(yy+eps));
					else
						currentNode->SetDepth(index+1,(float)(yy-eps));
				}
			}
		}
		else if (zInside) {
			currentNode=m_zNodeArray[i][j];
			sampleNum=currentNode->GetSampleNum();
			for(index=0;index<sampleNum;index+=2) {
				if (zz<currentNode->GetDepth(index)) break;
				if ((zz>=currentNode->GetDepth(index)) && (zz<=currentNode->GetDepth(index+1))) {
					if (fabs(zz-currentNode->GetDepth(index))<fabs(zz-currentNode->GetDepth(index+1)))
						currentNode->SetDepth(index,(float)(zz+eps));
					else
						currentNode->SetDepth(index+1,(float)(zz-eps));
				}
			}
		}
	}
	else if (num==2)
	{
		double temp,minD;	short closestIndex;
		if (!xInside) {
			currentNode=m_xNodeArray[j][k];
			minD=1.0e+32;
			if (currentNode) {
				sampleNum=currentNode->GetSampleNum();
				for(index=0;index<sampleNum;index++) {
					temp=fabs(xx-currentNode->GetDepth(index));
					if (temp<minD) {minD=temp; closestIndex=index;}
				}
				if (closestIndex%2==0)
					currentNode->SetDepth(closestIndex,(float)(xx-eps));
				else
					currentNode->SetDepth(closestIndex,(float)(xx+eps));
				}
			else {
				currentNode=new LDNISolidNode;
				currentNode->MallocSampleArray(2);
				currentNode->SetDepth(0,(float)(xx-eps));
				currentNode->SetNormal(0,0,127,127);
				currentNode->SetDepth(1,(float)(xx+eps));
				currentNode->SetNormal(1,255,127,127);
				m_xNodeArray[j][k]=currentNode;
			}
		}
		if (!yInside) {
			minD=1.0e+32;
			currentNode=m_yNodeArray[k][i];
			if (currentNode) {
				sampleNum=currentNode->GetSampleNum();
				for(index=0;index<sampleNum;index++) {
					temp=fabs(yy-currentNode->GetDepth(index));
					if (temp<minD) {minD=temp; closestIndex=index;}
				}
				if (closestIndex%2==0)
					currentNode->SetDepth(closestIndex,(float)(yy-eps));
				else
					currentNode->SetDepth(closestIndex,(float)(yy+eps));
			}
			else {
				currentNode=new LDNISolidNode;
				currentNode->MallocSampleArray(2);
				currentNode->SetDepth(0,(float)(yy-eps));
				currentNode->SetNormal(0,127,0,127);
				currentNode->SetDepth(1,(float)(yy+eps));
				currentNode->SetNormal(1,127,255,127);
				m_yNodeArray[k][i]=currentNode;
			}
		}
		if (!zInside) {
			minD=1.0e+32;
			currentNode=m_zNodeArray[i][j];
			if (currentNode) {
				sampleNum=currentNode->GetSampleNum();
				for(index=0;index<sampleNum;index++) {
					temp=fabs(zz-currentNode->GetDepth(index));
					if (temp<minD) {minD=temp; closestIndex=index;}
				}
				if (closestIndex%2==0)
					currentNode->SetDepth(closestIndex,(float)(zz-eps));
				else
					currentNode->SetDepth(closestIndex,(float)(zz+eps));
			}
			else {
				currentNode=new LDNISolidNode;
				currentNode->MallocSampleArray(2);
				currentNode->SetDepth(0,(float)(zz-eps));
				currentNode->SetNormal(0,127,127,0);
				currentNode->SetDepth(1,(float)(zz+eps));
				currentNode->SetNormal(1,127,127,255);
				m_zNodeArray[i][j]=currentNode;
			}
		}
		//printf("%d %d %d\n",i,j,k);
		return true;
	}

	return false;
}

void LDNISolid::ImageTmgFileRead(char *filename)
{
	FILE *fp;	int i,j,k,res,index,num,nMax;	short nAxis;
	LDNISolidNode *currentNode;
	double origin[3],gwidth,depth;	int nx,ny,nz,rr,gg,bb;
	char buf[255];

	if (!(fp=fopen(filename,"r"))) {printf("LDNI Image File Export Error!\n");return;}
	fscanf(fp,"%s\n",buf);
	fscanf(fp,"%s %d\n",buf,&res);
	fscanf(fp,"%s %lf %lf %lf \n",buf,&(origin[0]),&(origin[1]),&(origin[2]));
	fscanf(fp,"%s %lf\n",buf,&gwidth);
	//------------------------------------------------------------------------------
	MallocMemoryOfSolidNodeArray(res);
	SetGridWidth(gwidth);	SetOrigin(origin);

	for(nAxis=0;nAxis<3;nAxis++) {
		fscanf(fp,"%s\n",buf);	
		fscanf(fp,"%s\n",buf);	
		fscanf(fp,"%s\n",buf);

		//--------------------------------------------------------------------------
		//	Step 1: input the image for number of intersection points
		for(i=0;i<m_res;i++) {
			for(j=0;j<m_res;j++) {
				fscanf(fp,"%d ",&num);
				if (num==0) continue;
				currentNode=new LDNISolidNode;
				SetLDNISolidNode(nAxis,i,j,currentNode);
				currentNode->MallocSampleArray(num);
			}
			fscanf(fp,"\n");
		}
		fscanf(fp,"%s\n",buf);
		fscanf(fp,"%s %d\n",buf,&nMax);

		//--------------------------------------------------------------------------
		//	Step 3: input the LDNIs
		for(k=0;k<nMax;k++) {
			fscanf(fp,"%s\n",buf);
			fscanf(fp,"%s %s %s %d %s %s %d\n",buf,buf,buf,&num,buf,buf,&res);
			fscanf(fp,"%s\n",buf);	
			fscanf(fp,"%s\n",buf);	
			fscanf(fp,"%s\n",buf);

			//----------------------------------------------------------------------
			//	for depth image
			index=0;
			for(i=0;i<m_res;i++) {
				for(j=0;j<m_res;j++) {
					currentNode=GetLDNISolidNode(nAxis,i,j);
					if (!currentNode) continue;
					num=currentNode->GetSampleNum();
					if (k>=num) continue;
					fscanf(fp,"%d %d %d ",&rr,&gg,&bb);
					RGBToDepthConversion((short)rr,(short)gg,(short)bb,depth);
					currentNode->SetDepth(k,(float)depth);
					index++;
					if ((index%res)==0) fscanf(fp,"\n");
				}
			}
			for(;index<res*res;index++) fscanf(fp,"%f ",&depth);
			fscanf(fp,"\n");

			fscanf(fp,"%s\n",buf);	
			fscanf(fp,"%s\n",buf);	
			fscanf(fp,"%s\n",buf);
			//----------------------------------------------------------------------
			//	for normal image
			index=0;
			for(i=0;i<m_res;i++) {
				for(j=0;j<m_res;j++) {
					currentNode=GetLDNISolidNode(nAxis,i,j);
					if (!currentNode) continue;
					num=currentNode->GetSampleNum();
					if (k>=num) continue;
					fscanf(fp,"%d %d %d  ",&nx,&ny,&nz);
					currentNode->SetNormal(k,(short)nx,(short)ny,(short)nz);
					index++;
					if ((index%res)==0) fscanf(fp,"\n");
				}
			}
			for(;index<res*res;index++) fscanf(fp,"%d %d %d  ",&nx,&ny,&nz);
			fscanf(fp,"\n");
		}

		fscanf(fp,"%s\n",buf);	fscanf(fp,"%s\n",buf);	fscanf(fp,"%s\n",buf);
//		break;
	}
	fclose(fp);
}

void LDNISolid::ImageTmgFileWrite(char *filename)
{
	FILE *fp;	int i,j,k,nAxis,res,index;	short num=0,nMax;
	LDNISolidNode *currentNode;		int *nNumArray;		
	double depth;	short nx,ny,nz,rr,gg,bb;

	if (!(fp=fopen(filename,"w"))) {printf("LDNI Image File Export Error!\n");return;}

	fprintf(fp,"#--------------------------------------------------------\n");
	fprintf(fp,"Resolution_of_LDNI: %d \n",m_res);
	fprintf(fp,"Origin: %.15lf %.15lf %.15lf \n",m_origin[0],m_origin[1],m_origin[2]);
	fprintf(fp,"Sample_Width: %.15lf \n",m_width);
	for(nAxis=0;nAxis<3;nAxis++) {
		fprintf(fp,"#--------------------------------------------------------\n");
		switch(nAxis) {
		case 0:{fprintf(fp,"#The_Layer_Depth-Normal_Images_(LDNI)_along_X-axis \n");
			   }break;
		case 1:{fprintf(fp,"#The_Layer_Depth-Normal_Images_(LDNI)_along_Y-axis \n");
			   }break;
		case 2:{fprintf(fp,"#The_Layer_Depth-Normal_Images_(LDNI)_along_Z-axis \n");
			   }break;
		}
		fprintf(fp,"#--------------------------------------------------------\n");

		//--------------------------------------------------------------------------
		//	Step 1: output the image for number of intersection points
		nMax=0;
		for(i=0;i<m_res;i++) {
			for(j=0;j<m_res;j++) {
				currentNode=GetLDNISolidNode(nAxis,i,j);
				if (!currentNode) 
					num=0;
				else
					num=currentNode->GetSampleNum();
				if (num>nMax) nMax=num;
				fprintf(fp,"%d ",(int)(num));
			}
			fprintf(fp,"\n");
		}

		//--------------------------------------------------------------------------
		//	Step 2: compute the number of pixels at each layer
		fprintf(fp,"#--------------------------------------------------------\n");
		fprintf(fp,"number_of_layer: %d \n",nMax);
		nNumArray=new int[nMax];
		for(i=0;i<nMax;i++) nNumArray[i]=0;
		for(i=0;i<m_res;i++) {
			for(j=0;j<m_res;j++) {
				currentNode=GetLDNISolidNode(nAxis,i,j);
				if (!currentNode) continue;
				num=currentNode->GetSampleNum();
				for(k=0;k<num;k++) (nNumArray[k])++;
			}
		}

		//--------------------------------------------------------------------------
		//	Step 3: output the LDNIs
		for(k=0;k<nMax;k++) {
			res=(int)(sqrt((double)(nNumArray[k])));
			if ((res*res)!=nNumArray[k]) res++;
			fprintf(fp,"#--------------------------------------------------------\n");
			fprintf(fp,"Layer_%d with sample_num: %d and resolution: %d\n",(k+1),nNumArray[k],res);
			fprintf(fp,"#--------------------------------------------------------\n");

			fprintf(fp,"#The_depth_image\n");
			fprintf(fp,"#--------------------------------------------------------\n");
			index=0;
			for(i=0;i<m_res;i++) {
				for(j=0;j<m_res;j++) {
					currentNode=GetLDNISolidNode(nAxis,i,j);
					if (!currentNode) continue;
					num=currentNode->GetSampleNum();
					if (k>=num) continue;
					depth=currentNode->GetDepth(k);
					DepthToRGBConversion(depth,rr,gg,bb);
					fprintf(fp,"%d %d %d  ",rr,gg,bb);
					index++;
					if ((index%res)==0) fprintf(fp,"\n");
				}
			}
			for(;index<res*res;index++) fprintf(fp,"%f ",0.0f);
			fprintf(fp,"\n");

			fprintf(fp,"#--------------------------------------------------------\n");
			fprintf(fp,"#The_normal_image\n");
			fprintf(fp,"#--------------------------------------------------------\n");
			index=0;
			for(i=0;i<m_res;i++) {
				for(j=0;j<m_res;j++) {
					currentNode=GetLDNISolidNode(nAxis,i,j);
					if (!currentNode) continue;
					num=currentNode->GetSampleNum();
					if (k>=num) continue;
					currentNode->GetNormal(k,nx,ny,nz);
					fprintf(fp,"%d %d %d  ",(int)nx,(int)ny,(int)nz);
					index++;
					if ((index%res)==0) fprintf(fp,"\n");
				}
			}
			for(;index<res*res;index++) fprintf(fp,"0 0 0  ");
			fprintf(fp,"\n");
		}
		
		//--------------------------------------------------------------------------
		//	Step 4: the end of layer and free the memory
		delete []nNumArray;
		fprintf(fp,"#--------------------------------------------------------\n");
		fprintf(fp,"#_The_end_of_LDNI\n");
		fprintf(fp,"#--------------------------------------------------------\n");
		fprintf(fp,"\n");
	}

	fclose(fp);
}

void LDNISolid::RGBToDepthConversion(short rr, short gg, short bb, double &depth)
{
	int value;

	value=(int)rr*65536+(int)gg*256+(int)bb;
	depth=(double)value/16777216.0*m_width*(double)m_res;
}

void LDNISolid::DepthToRGBConversion(double depth, short &rr, short &gg, short &bb)
{
	int value;

	value=(int)(depth/(m_width*(double)m_res)*16777216.0);
	rr=(short)(value/65536);
	value=value-rr*65536;
	gg=(short)(value/256);
	bb=(short)(value-gg*256);
}

void LDNISolid::ExpansionByNewBoundingBox(double boundingBox[])
{
	int sdx,sdy,sdz,edx,edy,edz,total;	 double wx,wy,wz;	int i,j; short k,num;
	LDNISolidNode ***xNodeArray,***yNodeArray,***zNodeArray;
	double depth;

	m_origin[0]=m_origin[0]-m_width*0.5;
	m_origin[1]=m_origin[1]-m_width*0.5;
	m_origin[2]=m_origin[2]-m_width*0.5;

	//------------------------------------------------------------------------------
	//	Step 1: determine the number of expansion
	boundingBox[0]=boundingBox[0]-m_width*2.0;	
	boundingBox[2]=boundingBox[2]-m_width*2.0;	
	boundingBox[4]=boundingBox[4]-m_width*2.0;	
	boundingBox[1]=boundingBox[1]+m_width*2.0;	
	boundingBox[3]=boundingBox[3]+m_width*2.0;	
	boundingBox[5]=boundingBox[5]+m_width*2.0;	
	//------------------------------------------------------------------------------
	sdx=sdy=sdz=0;
	if (boundingBox[0]<m_origin[0]) sdx=(int)((m_origin[0]-boundingBox[0])/m_width+0.5);
	if (boundingBox[2]<m_origin[1]) sdy=(int)((m_origin[1]-boundingBox[2])/m_width+0.5);
	if (boundingBox[4]<m_origin[2]) sdz=(int)((m_origin[2]-boundingBox[4])/m_width+0.5);
	//------------------------------------------------------------------------------
	wx=m_origin[0]+m_width*(double)(m_res);
	wy=m_origin[1]+m_width*(double)(m_res);
	wz=m_origin[2]+m_width*(double)(m_res);
	edx=edy=edz=0;
	if (boundingBox[1]>wx) edx=(int)((boundingBox[1]-wx)/m_width+0.5);
	if (boundingBox[3]>wy) edy=(int)((boundingBox[3]-wy)/m_width+0.5);
	if (boundingBox[5]>wz) edz=(int)((boundingBox[5]-wz)/m_width+0.5);
	//------------------------------------------------------------------------------
	total=sdx+edx;
	if ((sdy+edy)>total) total=sdy+edy;
	if ((sdz+edz)>total) total=sdz+edz;
	edx=total-sdx;	edy=total-sdy;	edz=total-sdz;

	//------------------------------------------------------------------------------
	//	Step 2: create new arrays of LDNISolidNode
	xNodeArray=(LDNISolidNode ***)new long[m_res+total];
	yNodeArray=(LDNISolidNode ***)new long[m_res+total];
	zNodeArray=(LDNISolidNode ***)new long[m_res+total];
	for(i=0;i<m_res+total;i++) {
		xNodeArray[i]=(LDNISolidNode **)new long[m_res+total];
		yNodeArray[i]=(LDNISolidNode **)new long[m_res+total];
		zNodeArray[i]=(LDNISolidNode **)new long[m_res+total];
		for(j=0;j<m_res+total;j++) {
			xNodeArray[i][j]=NULL;	yNodeArray[i][j]=NULL;	zNodeArray[i][j]=NULL;
		}
	}

	//------------------------------------------------------------------------------
	//	Step 3: fill new arrays by the existing LDNISolidNodes
	for(i=0;i<m_res;i++) {
		for(j=0;j<m_res;j++) {
			xNodeArray[i+sdy][j+sdz]=m_xNodeArray[i][j];
			yNodeArray[i+sdz][j+sdx]=m_yNodeArray[i][j];
			zNodeArray[i+sdx][j+sdy]=m_zNodeArray[i][j];
			//----------------------------------------------------------------------
			if ((sdx!=0) && (m_xNodeArray[i][j])) {
				num=m_xNodeArray[i][j]->GetSampleNum();
				for(k=0;k<num;k++) {
					depth=m_xNodeArray[i][j]->GetDepth(k);
					depth=depth+m_width*(double)sdx;
					m_xNodeArray[i][j]->SetDepth(k,(float)depth);
				}
			}
			//----------------------------------------------------------------------
			if ((sdy!=0) && (m_yNodeArray[i][j])) {
				num=m_yNodeArray[i][j]->GetSampleNum();
				for(k=0;k<num;k++) {
					depth=m_yNodeArray[i][j]->GetDepth(k);
					depth=depth+m_width*(double)sdy;
					m_yNodeArray[i][j]->SetDepth(k,(float)depth);
				}
			}
			//----------------------------------------------------------------------
			if ((sdz!=0) && (m_zNodeArray[i][j])) {
				num=m_zNodeArray[i][j]->GetSampleNum();
				for(k=0;k<num;k++) {
					depth=m_zNodeArray[i][j]->GetDepth(k);
					depth=depth+m_width*(double)sdz;
					m_zNodeArray[i][j]->SetDepth(k,(float)depth);
				}
			}
		}
	}

	//------------------------------------------------------------------------------
	//	Step 4: delete old arrays of LDNISolidNodes
	for(i=0;i<m_res;i++) {
		delete [](LDNISolidNode **)(m_xNodeArray[i]);
		delete [](LDNISolidNode **)(m_yNodeArray[i]);
		delete [](LDNISolidNode **)(m_zNodeArray[i]);
	}
	delete [](LDNISolidNode ***)m_xNodeArray;
	delete [](LDNISolidNode ***)m_yNodeArray;
	delete [](LDNISolidNode ***)m_zNodeArray;

	//------------------------------------------------------------------------------
	//	Step 5: update other information of the LDNISolid
	m_xNodeArray=xNodeArray;	m_yNodeArray=yNodeArray;	m_zNodeArray=zNodeArray;
	m_origin[0]=m_origin[0]-m_width*(double)sdx+m_width*0.5;
	m_origin[1]=m_origin[1]-m_width*(double)sdy+m_width*0.5;
	m_origin[2]=m_origin[2]-m_width*(double)sdz+m_width*0.5;
	m_res+=total;

	//------------------------------------------------------------------------------
	//	Step 6: update the boundingBox[] for the sampling of mesh surface bounded by it
	boundingBox[0]=m_origin[0]-m_width*0.5;	
	boundingBox[2]=m_origin[1]-m_width*0.5;	
	boundingBox[4]=m_origin[2]-m_width*0.5;	
	boundingBox[1]=boundingBox[0]+m_width*((double)m_res);
	boundingBox[3]=boundingBox[2]+m_width*((double)m_res);
	boundingBox[5]=boundingBox[4]+m_width*((double)m_res);
}

void LDNISolidNode::MallocSampleArray(short num)
{
	if (sampleNum!=0) ReleaseSampleArray();

	short i;
	sampleNum=num;
	depth=new float[num];
	id=new int[num];	for(i=0;i<num;i++) id[i]=1;
	nv=(unsigned char**)new long[num];
	for(i=0;i<num;i++) nv[i]=new unsigned char[3];
}

void LDNISolidNode::ReleaseSampleArray()
{
	if (sampleNum==0) return;

	delete []depth;	delete []id;
	for(short i=0;i<sampleNum;i++) delete [](unsigned char*)(nv[i]);
	delete [](unsigned char**)nv;

	sampleNum=0;
}

double LDNISolidNode::GetDepth(short index) {return (double)(depth[index]);}

void LDNISolidNode::GetNormal(short index, short &nx, short &ny, short &nz)
{
	nx=nv[index][0];	ny=nv[index][1];	nz=nv[index][2];
}

void LDNISolidNode::GetNormal(short index, double &nx, double &ny, double &nz)
{
	nx=(double)(nv[index][0])/254.0*2.0-1.0;
	ny=(double)(nv[index][1])/254.0*2.0-1.0;
	nz=(double)(nv[index][2])/254.0*2.0-1.0;
}

void LDNISolidNode::SetDepth(short index, float value) {depth[index]=value;};

void LDNISolidNode::SetNormal(short index, short nx, short ny, short nz)
{
	nv[index][0]=(unsigned char)nx;
	nv[index][1]=(unsigned char)ny;
	nv[index][2]=(unsigned char)nz;
}

void LDNISolidNode::WriteSample(FILE *fp)
{
	short i;
	fwrite(depth,sizeof(float),sampleNum,fp);
	for(i=0;i<sampleNum;i++) fwrite((nv[i]),sizeof(unsigned char),3,fp);
}

void LDNISolidNode::ReadSample(FILE *fp)
{
	short i;
	fread(depth,sizeof(float),sampleNum,fp);
	for(i=0;i<sampleNum;i++) fread((nv[i]),sizeof(unsigned char),3,fp);
}

void LDNISolidNode::SortSamplesByDepth()
{
	short i,j;
	unsigned char tx,ty,tz;		float tDepth;

	for(i=0;i<sampleNum;i++) {
		for(j=i+1;j<sampleNum;j++) {
			if (depth[j]>=depth[i]) continue;
			tx=nv[j][0];	ty=nv[j][1];	tz=nv[j][2];	tDepth=depth[j];
			nv[j][0]=nv[i][0];	nv[j][1]=nv[i][1];	nv[j][2]=nv[i][2];	depth[j]=depth[i];
			nv[i][0]=tx;	nv[i][1]=ty;	nv[i][2]=tz;	depth[i]=tDepth;
		}
	}
}
