#define _CRT_SECURE_NO_DEPRECATE

#include <math.h>
#include <time.h>
#include <sys/stat.h>

#include <GL/glew.h>
#include <GL/glaux.h>

#include "..\GLKLib\GLK.h"
#include "..\GLKLib\GLKObList.h"

#include "..\QMeshLib\QMeshPatch.h"
#include "..\QMeshLib\QMeshNode.h"
#include "..\QMeshLib\QMeshEdge.h"
#include "..\QMeshLib\QMeshFace.h"

#include "LDNISolid.h"
#include "LDNISolidOperation.h"
#include "LDNISolidSampling.h"

LDNISolidSampling::LDNISolidSampling()
{
}

LDNISolidSampling::~LDNISolidSampling()
{
}

void LDNISolidSampling::MeshToLDNISolidSampling(QMeshPatch *mesh, LDNISolid* &solid, 
												double boundingBox[], int res, bool bWithSortAndCheck)
{
	GLKObList meshList;				int displayListIndex;
	double origin[3],gridWidth;		bool bShader=false;

	solid=new LDNISolid;
	solid->MallocMemoryOfSolidNodeArray(res);

	if ((boundingBox[0]==boundingBox[1]) && (boundingBox[2]==boundingBox[3]) && (boundingBox[4]==boundingBox[5])) {
		meshList.RemoveAll();	meshList.AddTail(mesh);
		LDNISolidOperation::CompBoundingBox(&meshList, boundingBox, true, res);
	}

	//---------------------------------------------------------------------------------
	//	Preparation
	gridWidth=(boundingBox[1]-boundingBox[0])/(double)res;
	solid->SetGridWidth(gridWidth);
	origin[0]=boundingBox[0]+gridWidth*0.5;
	origin[1]=boundingBox[2]+gridWidth*0.5;
	origin[2]=boundingBox[4]+gridWidth*0.5;
	solid->SetOrigin(origin);
	
	//---------------------------------------------------------------------------------
	//	For using geometry shader to speed up
	long time=clock();
	GLhandleARB g_programObj, g_vertexShader, g_GeometryShader, g_FragShader;
	GLenum InPrimType=GL_POINTS, OutPrimType=GL_TRIANGLES;		int OutVertexNum=3;
	GLuint vertexTexture;
	bShader=_shaderInitialization();	//bShader=false;
	if (bShader) {
		//------------------------------------------------------------------------
		//	Shader set-up
		const char *VshaderString[1];
		const char *GshaderString[1];
		const char *FshaderString[1];
		GLint bVertCompiled = 0;
		GLint bGeoCompiled = 0;
		GLint bLinked = 0;
		char str[4096] = "";
		
		g_vertexShader = glCreateShaderObjectARB( GL_VERTEX_SHADER_ARB );
		unsigned char *ShaderAssembly = _readShaderFile( "VertexShader.vert" );
		VshaderString[0] = (char*)ShaderAssembly;
		glShaderSourceARB( g_vertexShader, 1, VshaderString, NULL );
		glCompileShaderARB( g_vertexShader);
		delete ShaderAssembly;
		glGetObjectParameterivARB( g_vertexShader, GL_OBJECT_COMPILE_STATUS_ARB,&bVertCompiled );
		if (bVertCompiled  == false) {
			glGetInfoLogARB(g_vertexShader, sizeof(str), NULL, str);
			printf("Vertex Shader Compile Error");	bShader=false;
		}

		g_GeometryShader = glCreateShaderObjectARB( GL_GEOMETRY_SHADER_EXT );
		ShaderAssembly = _readShaderFile( "GeometryShader.geo" );
		GshaderString[0] = (char*)ShaderAssembly;
		glShaderSourceARB( g_GeometryShader, 1, GshaderString, NULL );
		glCompileShaderARB( g_GeometryShader);
		delete ShaderAssembly;
		glGetObjectParameterivARB( g_GeometryShader, GL_OBJECT_COMPILE_STATUS_ARB,&bVertCompiled );
		if (bVertCompiled  == false) {
			glGetInfoLogARB(g_GeometryShader, sizeof(str), NULL, str);
			printf("Geo Shader Compile Error");	bShader=false;
		}

		g_FragShader = glCreateShaderObjectARB( GL_FRAGMENT_SHADER_ARB );
		ShaderAssembly = _readShaderFile( "FragmentShader.frag" );
		FshaderString[0] = (char*)ShaderAssembly;
		glShaderSourceARB( g_FragShader, 1, FshaderString, NULL );
		glCompileShaderARB( g_FragShader);
		delete ShaderAssembly;
		glGetObjectParameterivARB( g_FragShader, GL_OBJECT_COMPILE_STATUS_ARB,&bVertCompiled );
		if (bVertCompiled  == false) {
			glGetInfoLogARB(g_FragShader, sizeof(str), NULL, str);
			printf("Vertex Shader Compile Error");	bShader=false;
		}
	
		g_programObj = glCreateProgramObjectARB();
		glAttachObjectARB( g_programObj, g_vertexShader );
		glAttachObjectARB( g_programObj, g_GeometryShader );
		glAttachObjectARB( g_programObj, g_FragShader );

		//-----------------------------------------------------------------------------
		//	Configuration setting for geometry shader
		glProgramParameteriEXT(g_programObj, GL_GEOMETRY_INPUT_TYPE_EXT, InPrimType);
		glProgramParameteriEXT(g_programObj, GL_GEOMETRY_OUTPUT_TYPE_EXT, OutPrimType);
		glProgramParameteriEXT(g_programObj, GL_GEOMETRY_VERTICES_OUT_EXT, OutVertexNum); 
		
		glLinkProgramARB( g_programObj);
		glGetObjectParameterivARB( g_programObj, GL_OBJECT_LINK_STATUS_ARB, &bLinked );
		if( bLinked == false ) {
			glGetInfoLogARB( g_programObj, sizeof(str), NULL, str );
			printf("Linking Fail: %s\n",str);	bShader=false;
		}
	}
	//---------------------------------------------------------------------------------
	if (bShader) {
		//-----------------------------------------------------------------------------
		//	Step 1: creating texture for vertex array and binding
		int xF,yF,i,nodeNum,eNum;	GLKPOSITION Pos;	double xx,yy,zz;
		nodeNum=mesh->GetNodeNumber();
		_texCalProduct(nodeNum,xF,yF);
		yF = ceil(nodeNum/(xF-1.0));
		printf("Texture Size: xF=%d yF=%d\n",xF,yF);
		float* verTex=new float[xF*yF*3];
		i=0;
		for(Pos=mesh->GetNodeList().GetHeadPosition();Pos!=NULL;i++) {
			QMeshNode *node=(QMeshNode *)(mesh->GetNodeList().GetNext(Pos));
			if (i%xF==0) i++;	// since "floor(1.0/1.0)" NOT equal to 1.0 in the shading language
			node->SetIndexNo(i);	node->GetCoord3D(xx,yy,zz);
			verTex[i*3]=(float)xx; verTex[i*3+1]=(float)yy; verTex[i*3+2]=(float)zz;
		}
		glEnable(GL_TEXTURE_RECTANGLE_ARB);
		glGenTextures(1, &vertexTexture);
		glBindTexture(GL_TEXTURE_RECTANGLE_ARB, vertexTexture);
		glTexParameteri(GL_TEXTURE_RECTANGLE_ARB,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
		glTexParameteri(GL_TEXTURE_RECTANGLE_ARB,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
		glTexParameteri(GL_TEXTURE_RECTANGLE_ARB,GL_TEXTURE_WRAP_S,GL_CLAMP);
		glTexParameteri(GL_TEXTURE_RECTANGLE_ARB,GL_TEXTURE_WRAP_T,GL_CLAMP);
		glTexImage2D(GL_TEXTURE_RECTANGLE_ARB, 0, GL_RGB32F_ARB, xF, yF, 0, GL_RGB, GL_FLOAT, verTex);
		glBindTexture(GL_TEXTURE_RECTANGLE_ARB, 0);
		delete []verTex;

		//-----------------------------------------------------------------------------
		//	Step 2: building GL-list for activating the geometry shader
		displayListIndex = glGenLists(1);
		glNewList(displayListIndex, GL_COMPILE);
		glBegin(GL_POINTS);
		for(Pos=mesh->GetFaceList().GetHeadPosition();Pos!=NULL;) {
			QMeshFace *face=(QMeshFace *)(mesh->GetFaceList().GetNext(Pos));
			eNum=face->GetEdgeNum();
			for(i=0;i<=eNum-3;i++) {
				glVertex3f(face->GetNodeRecordPtr(0)->GetIndexNo(),
					face->GetNodeRecordPtr(i+1)->GetIndexNo(),
					face->GetNodeRecordPtr(i+2)->GetIndexNo());
			}
		}
		glEnd();
		glEndList();

		//-----------------------------------------------------------------------------
		//	Step 3: using program objects and the texture
		GLint id0,id1;	double centerPos[3];
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_RECTANGLE_ARB,vertexTexture);
		glUseProgramObjectARB(g_programObj);
		id0 = glGetUniformLocationARB(g_programObj,"sizeNx");
		glUniform1fARB(id0,(float)xF);
		centerPos[0]=(boundingBox[0]+boundingBox[1])*0.5;
		centerPos[1]=(boundingBox[2]+boundingBox[3])*0.5;
		centerPos[2]=(boundingBox[4]+boundingBox[5])*0.5;
		id1 = glGetUniformLocationARB(g_programObj,"Cent");
		glUniform3fARB(id1,centerPos[0],centerPos[1],centerPos[2]);
	}

	//---------------------------------------------------------------------------------
	//	Sampling
	if (!bShader) displayListIndex=_buildObjectColorNormalDisplayList(mesh, boundingBox);
	printf("GLList ID: %d\n",displayListIndex);
	time=clock()-time;	printf("GLList building time is %ld (ms)\n",time);
	time=clock();
	_decompositionOfLDIColorNormal(mesh, solid, boundingBox, 0, displayListIndex, bWithSortAndCheck);
	time=clock()-time;	printf("x-Decomposing time is %ld (ms)\n",time);
	time=clock();
	_decompositionOfLDIColorNormal(mesh, solid, boundingBox, 1, displayListIndex, bWithSortAndCheck);
	time=clock()-time;	printf("y-Decomposing time is %ld (ms)\n",time);
	time=clock();
	_decompositionOfLDIColorNormal(mesh, solid, boundingBox, 2, displayListIndex, bWithSortAndCheck);
	time=clock()-time;	printf("z-Decomposing time is %ld (ms)\n",time);
	glDeleteLists(displayListIndex, 1);

	//---------------------------------------------------------------------------------
	//	For releasing memory for using geometry shader
	if (bShader) {	// ending the program objects and the unbind the texture
		glBindTexture( GL_TEXTURE_RECTANGLE_ARB, 0);
		glDisable(GL_TEXTURE_RECTANGLE_ARB);
		glDeleteTextures(1, &vertexTexture);
		glUseProgramObjectARB(0);
	}
	glDeleteObjectARB( g_vertexShader);
	glDeleteObjectARB( g_GeometryShader);
	glDeleteObjectARB( g_FragShader);
	glDeleteObjectARB( g_programObj);
}

int LDNISolidSampling::_buildObjectColorNormalDisplayList(QMeshPatch *mesh, double boundingBox[])
{
	QMeshFace *face;	QMeshNode *node;
	GLKPOSITION PosFace;	int i,k,num;
	double xx,yy,zz,nx,ny,nz,dd,centerPos[3];	float cx,cy,cz;

	centerPos[0]=(boundingBox[0]+boundingBox[1])*0.5;
	centerPos[1]=(boundingBox[2]+boundingBox[3])*0.5;
	centerPos[2]=(boundingBox[4]+boundingBox[5])*0.5;

	int dispListIndex = glGenLists(1);
	glNewList(dispListIndex, GL_COMPILE);

	glBegin(GL_TRIANGLES);
	for(PosFace=(mesh->GetFaceList()).GetHeadPosition();PosFace!=NULL;) {
		face=(QMeshFace *)((mesh->GetFaceList()).GetNext(PosFace));

		face->GetPlaneEquation(nx,ny,nz,dd);
		glColor3f((float)((nx+1.0)*0.5), (float)((ny+1.0)*0.5), (float)((nz+1.0)*0.5));
		
		num=face->GetEdgeNum();
		for(k=0;k<num-2;k++) {
			for(i=0;i<3;i++) {
				if (i<1)
					node=face->GetNodeRecordPtr(i);
				else
					node=face->GetNodeRecordPtr(i+k);
				node->GetCoord3D(xx,yy,zz);
				cx=(float)(xx-centerPos[0]);	
				cy=(float)(yy-centerPos[1]);	
				cz=(float)(zz-centerPos[2]);
				glVertex3f(cx,cy,cz);
			}
		}
	}
	glEnd();

	glEndList();

	return dispListIndex;
}

void LDNISolidSampling::_decompositionOfLDIColorNormal(QMeshPatch *mesh, LDNISolid *solid, 
													   double boundingBox[], short nAxis,
													   int displayListIndex, bool bWithSortAndCheck)
{
	short n_max,i,j,n,nTiledGridNum,xIndex,yIndex;
	double width,gWidth;

	LDNISolidNode *currentNode;
	int nDivideRes=_CCL_LDNISAMPLING_RATE+1;
	GLfloat *depthLayerArray;
	unsigned char *redLayerArray,*greenLayerArray,*blueLayerArray;
	GLint *stencilArray;

	int res=solid->GetResolution();
	long total_n_max=0;

	long time=0,time2;

	//------------------------------------------------------------------------
	//	Preparation
	nTiledGridNum=(res-1)/(nDivideRes-1);
	if ((nTiledGridNum*(nDivideRes-1))<(res-1)) nTiledGridNum++;
	width=boundingBox[1]-boundingBox[0];
	gWidth=solid->GetGridWidth();
	//------------------------------------------------------------------------
	depthLayerArray=new GLfloat[nDivideRes*nDivideRes];
	redLayerArray=new unsigned char[nDivideRes*nDivideRes];
	greenLayerArray=new unsigned char[nDivideRes*nDivideRes];
	blueLayerArray=new unsigned char[nDivideRes*nDivideRes];

	//------------------------------------------------------------------------
	//	Step 1: Setup the rendering environment
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_STENCIL_TEST);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glDisable(GL_POLYGON_OFFSET_FILL);
	glDisable(GL_POLYGON_OFFSET_LINE);
    glDisable(GL_BLEND);	
	glDisable(GL_POLYGON_SMOOTH);	// turn off anti-aliasing
	glDisable(GL_POINT_SMOOTH);
	glDisable(GL_LINE_SMOOTH);
	glDisable(GL_MAP_COLOR);	glDisable(GL_DITHER);
	glShadeModel(GL_FLAT);
	glDisable(GL_LIGHTING);   glDisable(GL_LIGHT0);
	glDisable(GL_LOGIC_OP);
	glDisable(GL_COLOR_MATERIAL);
	glDisable(GL_ALPHA_TEST);

	//------------------------------------------------------------------------
	//	Step 2: Tiled Rendering to get the Hermite samples
	stencilArray=new GLint[nDivideRes*nDivideRes];
	//------------------------------------------------------------------------
	for(xIndex=0;xIndex<nTiledGridNum;xIndex++) {
		for(yIndex=0;yIndex<nTiledGridNum;yIndex++) {
			//------------------------------------------------------------------------
			//	Rendering step 1: setting the viewing window
			glViewport(0,0,nDivideRes,nDivideRes);
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			//------------------------------------------------------------------------
			//	The eye is located at (0, 0, 0), the near clipping plane is at the z=0 plane
			//		the far clipping plane is at the z=(boundingBox[5]-boundingBox[4]) plane
			double sx,sy;
			sx=-width*0.5+(double)xIndex*(double)(nDivideRes-1)*gWidth;
			sy=-width*0.5+(double)yIndex*(double)(nDivideRes-1)*gWidth;
			glOrtho(sx,sx+(double)(nDivideRes)*gWidth,sy,sy+(double)(nDivideRes)*gWidth,
					width*0.5,-width*0.5);
			//	Note that:	in "glOrtho(left,right,bottom,top,near,far);"
			//		(left,right,bottom,top) are located at the boundary of pixel instead of
			//		the center of pixels
			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();

			//------------------------------------------------------------------------
			//	Rendering step 2: determine the number of layers
			glClearColor( 1.0f, 1.0f, 1.0f, 1.0f );	
			glClearDepth(1.0);
			glClearStencil(0);	glColor3f(1,1,1);
			glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
			glDepthFunc(GL_ALWAYS);
			glStencilFunc(GL_GREATER, 1, 0xff);
			glStencilOp(GL_INCR, GL_INCR, GL_INCR);
			glPushMatrix();
			switch(nAxis) {
				case 0:{glRotatef(-90,0,1,0);	glRotatef(-90,1,0,0); }break;
				case 1:{glRotatef(90,0,1,0);	glRotatef(90,0,0,1);  }break;
			}
			glCallList(displayListIndex);	glFlush();
			//------------------------------------------------------------------------
			glReadPixels(0,0,nDivideRes,nDivideRes,GL_STENCIL_INDEX,GL_INT,stencilArray);
		//	for(i=0;i<res;i++) {for(j=0;j<res;j++) printf("%d",(int)(stencilArray[i*res+j])); printf("\n");}
			n_max=0;
			for(i=0;i<nDivideRes;i++) 
				for(j=0;j<nDivideRes;j++) 
					if (stencilArray[i*nDivideRes+j]>n_max) n_max=stencilArray[i*nDivideRes+j];
			if (n_max>total_n_max) total_n_max=n_max;

			//------------------------------------------------------------------------
			//	Rendering step 3: decomposing the Layered Depth Images (LDIs) and record its corresponding normals
			short iST,jST;
			iST=jST=0;
			if (xIndex!=0) iST=1;
			if (yIndex!=0) jST=1;
			n=1;
			while(n<=n_max){
				time2=clock();
				GLint OldPackAlignment;
				glGetIntegerv(GL_PACK_ALIGNMENT,&OldPackAlignment); 
				glPixelStorei(GL_PACK_ALIGNMENT,1);
				glReadPixels(0,0,nDivideRes,nDivideRes,GL_DEPTH_COMPONENT,GL_FLOAT,depthLayerArray);
				glReadPixels(0,0,nDivideRes,nDivideRes,GL_RED,GL_UNSIGNED_BYTE,redLayerArray);
				glReadPixels(0,0,nDivideRes,nDivideRes,GL_GREEN,GL_UNSIGNED_BYTE,greenLayerArray);
				glReadPixels(0,0,nDivideRes,nDivideRes,GL_BLUE,GL_UNSIGNED_BYTE,blueLayerArray);
				glPixelStorei(GL_PACK_ALIGNMENT,OldPackAlignment);

				for(i=iST;i<nDivideRes;i++) { // column 
					if (i+xIndex*(nDivideRes-1)>=res) continue;
					for(j=jST;j<nDivideRes;j++) { // row 
						if (j+yIndex*(nDivideRes-1)>=res) continue;
						int index=i+j*nDivideRes;
						//if (depthLayerArray[index]==1.0f) continue;
						if (stencilArray[index]<n) continue;
						
						//---------------------------------------------------------------------------------
						//	fill-in the data for LDNISolid
						short sampleNum=(short)(stencilArray[index]);
						LDNISolidNode *currentNode;
						if (n==1) {
							currentNode=new LDNISolidNode;
							currentNode->MallocSampleArray(sampleNum);
							solid->SetLDNISolidNode(nAxis,i+xIndex*(nDivideRes-1),j+yIndex*(nDivideRes-1),currentNode);
						}
						else {
							currentNode=solid->GetLDNISolidNode(nAxis,i+xIndex*(nDivideRes-1),j+yIndex*(nDivideRes-1));
						}

						double depth=depthLayerArray[index]*width
									-0.5*gWidth;	// As the origion is located at the center of a pixel,
													//	so the depth is shifted with "0.5*gridWidth"
						currentNode->SetDepth(n-1,(float)depth);
						currentNode->SetNormal(n-1,(short)(redLayerArray[index]),
									(short)(greenLayerArray[index]),(short)(blueLayerArray[index]));
					}
				}

				time2=clock()-time2;	time+=time2;
				if (n==n_max) break;
				n++;

				glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
				glStencilFunc(GL_GREATER, n, 0xff);
				glStencilOp(GL_KEEP, GL_INCR, GL_INCR);
				glCallList(displayListIndex);	glFlush();
			}
			glPopMatrix();
		}
	}
	printf("n_max=%ld \n",total_n_max);
	printf("Texture Size: %f (MB)\n",(float)(total_n_max*res*res*2*4)/(1024.0f*1024.0f));

	//------------------------------------------------------------------------
	//	Step 4: Set the rendering parameters back
	glEnable(GL_POLYGON_OFFSET_FILL);
	glEnable(GL_POLYGON_OFFSET_LINE);
    glEnable(GL_BLEND);	
	glEnable(GL_DITHER);
	glDisable(GL_STENCIL_TEST);
	glDepthFunc(GL_LESS);
	glEnable(GL_MAP_COLOR);				
	glShadeModel(GL_SMOOTH);   
	glEnable(GL_LIGHTING);   glEnable(GL_LIGHT0);
//	glEnable(GL_POLYGON_SMOOTH);// adding this will make the invalid display on the Thinkpad laptop	
	glEnable(GL_POINT_SMOOTH);
//	glEnable(GL_LINE_SMOOTH);	// adding this will make the Compaq laptop's running fail
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

	//------------------------------------------------------------------------
	//	Step 5: Sorting LDISolidNodes by their depth values
	if (bWithSortAndCheck) {
		for(i=0;i<res;i++) {
			for(j=0;j<res;j++) {
				currentNode=solid->GetLDNISolidNode(nAxis,i,j);
				if (currentNode==NULL) continue;
				short num=currentNode->GetSampleNum();		
				/*if (num%2==1) {
					printf("Singular Sample is found and fixed!\n");
					double *depth;	short *nx,*ny,*nz;
					depth=new double[num+1];	
					nx=new short[num+1];	ny=new short[num+1];	nz=new short[num+1];
					short k;
					for(k=0;k<num;k++) {
						depth[k]=currentNode->GetDepth(k);
						currentNode->GetNormal(k,nx[k],ny[k],nz[k]);
					}
					depth[num]=width;	nx[num]=ny[num]=nz[num]=128;
					switch(nAxis) {
						case 0:nx[num]=255;break;
						case 1:ny[num]=255;break;
						case 2:nz[num]=255;break;
					}

					currentNode->MallocSampleArray(num+1);
					for(k=0;k<=num;k++) {
						currentNode->SetDepth(k,depth[k]);
						currentNode->SetNormal(k,nx[k],ny[k],nz[k]);
					}
					delete []depth;		
					delete []nx;	delete []ny;	delete[]nz;
				}*/
				currentNode->SortSamplesByDepth();
			}
		}
	}

	//------------------------------------------------------------------------
	//	Step 6: Free the memory
	delete []stencilArray;		
	delete []depthLayerArray;		
	delete []redLayerArray;		delete []greenLayerArray;	delete []blueLayerArray;

	printf("Readback time: %ld (ms)\n",time);
}

bool LDNISolidSampling::_shaderInitialization()
{
	if(glewInit() != GLEW_OK) {
		printf("glewInit failed. Exiting...\n");
		return false;
	}
	if (glewIsSupported("GL_VERSION_2_0"))
		printf("Ready for OpenGL 2.0\n");
	else {
		printf("OpenGL 2.0 not supported\n");
		return false;
	}

	return true;
}

unsigned char* LDNISolidSampling::_readShaderFile( const char *fileName )
{
    FILE *file = fopen( fileName, "r" );

    if( file == NULL ) {
       	printf("Cannot open shader file!");
		return 0;
    }
	struct _stat fileStats;
    if( _stat( fileName, &fileStats ) != 0 ) {
        printf("Cannot get file stats for shader file!");
        return 0;
    }
    unsigned char *buffer = new unsigned char[fileStats.st_size];
	int bytes = fread( buffer, 1, fileStats.st_size, file );
    buffer[bytes] = 0;

	fclose( file );

	return buffer;
}

//----------------------------------------------------------
//	Function to calulate 2D size texture from 1D texture
void LDNISolidSampling::_texCalProduct(int in,int &outx, int &outy)
{
	int left = 0;
	int right = 0;
	int div3left = 0;
	int div3right = 0;

	left = int(floor(sqrt((float)in)))-1;
	right = int(ceil(sqrt((float)in)));
	while(left*right < in)
	{
		right++;
	}
	if (left%3 == 0 && left*right>=in)
	{
		div3left = left;
		div3right = right;
	}
	else if (right%3 == 0 && left*right>=in)
	{
		div3left = right;
		div3right = left;
	}
	right++;
	left--;
	if (left%3 == 0 && left*right>=in)
	{
		div3left = left;
		div3right = right;
	}
	else if (right%3 == 0 && left*right>=in)
	{
		div3left = right;
		div3right = left;
	}
	while(left*right > in)
	{
		right++;
		left--;
		if (left%3 == 0 && left*right>in)
		{
			div3left = left;
			div3right = right;
		}
		else if (right%3 == 0 && left*right>in)
		{
			div3left = right;
			div3right = left;
		}
	}
	if (right*left < in)
	{
		right--;
		left++;
		if (left%3 == 0 )
		{
			div3left = left;
			div3right = right;
		}
		else if (right%3 == 0)
		{
			div3left = right;
			div3right = left;
		} 
	}
	outx = div3left;
	outy = div3right;

	if (outx==0 || outy==0) {outx=in; outy=1;}
}
